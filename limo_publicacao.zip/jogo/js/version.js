// Fonte única da versão exibida, testada e empacotada.
export const GAME_VERSION = '1.50.0';
export const GAME_RELEASE_NAME = 'Raízes: O Despertar';
export const GAME_LABEL = `v${GAME_VERSION} · ${GAME_RELEASE_NAME}`;
