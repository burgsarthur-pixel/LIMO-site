// =====================================================================
// CLIENTE DO SERVIDOR DE DESENVOLVIMENTO (tools/servidor-dev.py)
// Permite SALVAR a sala direto na pasta do projeto no computador, mesmo editando pelo celular.
// Com o servidor comum (python -m http.server) o ping falha e o botão "Salvar no PC" não aparece.
// =====================================================================
export function criarClienteServidor(fetchFn = (typeof fetch === 'function' ? fetch.bind(globalThis) : null), base = '') {
  return {
    async ping() {
      if (!fetchFn) return false;
      try {
        const r = await fetchFn(`${base}__dev/ping`, { cache: 'no-store' });
        if (!r.ok) return false;
        const j = await r.json();
        return !!(j && j.ok && j.salvar);
      } catch (e) { return false; }
    },

    /** @returns {{ok:true, arquivo, indiceAtualizado, backup}|{ok:false, error}} */
    async salvar(id, texto) {
      if (!fetchFn) return { ok: false, error: 'este navegador não tem fetch' };
      try {
        const r = await fetchFn(`${base}__dev/salvar-sala`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, texto }) });
        let j = {};
        try { j = await r.json(); } catch (e) { /* resposta sem JSON */ }
        if (!j || typeof j !== 'object') j = {};
        if (!r.ok || !j.ok) return { ok: false, error: j.erro || `HTTP ${r.status}` };
        return j;
      } catch (e) { return { ok: false, error: `sem conexão com o servidor (${e.message})` }; }
    },
  };
}
