// =====================================================================
// SALVAR / ABRIR ARQUIVOS .json (sala do editor, progresso do jogador)
// Em vez de só gerar texto, grava um ARQUIVO de verdade. Ordem de tentativa (a primeira que o navegador suporta):
//   1) seletor nativo "Salvar como…" (Chrome/Edge no computador: o jogador escolhe pasta e nome);
//   2) folha de compartilhamento com o arquivo (iPhone/iPad: "Salvar em Arquivos");
//   3) download comum (Android, Firefox, Safari de mesa: vai para a pasta Downloads).
// Lógica sem dependência de DOM global: `win` e `doc` são injetados (testável em Node).
// =====================================================================

const LIMITE_LEITURA = 5 * 1024 * 1024;   // 5 MB: uma sala/progresso é bem menor; barra arquivo errado

/** Grava `texto` como arquivo. Devolve { ok, via, nome } ou { ok:false, cancelado:true } ou { ok:false, error }. */
export async function salvarArquivo({ nome, texto, tipo = 'application/json', win = globalThis.window, doc = globalThis.document }) {
  if (typeof win?.showSaveFilePicker === 'function') {
    try {
      const h = await win.showSaveFilePicker({ suggestedName: nome, types: [{ description: 'Arquivo JSON', accept: { 'application/json': ['.json'] } }] });
      const w = await h.createWritable(); await w.write(texto); await w.close();
      return { ok: true, via: 'seletor', nome: h.name || nome };
    } catch (e) {
      if (e && e.name === 'AbortError') return { ok: false, cancelado: true, via: 'seletor' };   // fechou a janela: não é erro
      /* seletor bloqueado (iframe, permissão): cai para o download */
    }
  }
  const ios = /iPhone|iPad|iPod/i.test(win?.navigator?.userAgent || '');
  if (ios && typeof win?.File === 'function' && typeof win.navigator?.share === 'function') {
    try {
      const arquivo = new win.File([texto], nome, { type: tipo });
      if (win.navigator.canShare?.({ files: [arquivo] })) { await win.navigator.share({ files: [arquivo], title: nome }); return { ok: true, via: 'compartilhar', nome }; }
    } catch (e) { if (e && e.name === 'AbortError') return { ok: false, cancelado: true, via: 'compartilhar' }; }
  }
  try {
    const blob = new win.Blob([texto], { type: tipo }); const url = win.URL.createObjectURL(blob);
    const a = doc.createElement('a'); a.href = url; a.download = nome; doc.body.appendChild(a); a.click(); a.remove();
    win.setTimeout?.(() => win.URL.revokeObjectURL(url), 4000);
    return { ok: true, via: 'download', nome };
  } catch (e) { return { ok: false, error: e?.message || 'o navegador não conseguiu criar o arquivo' }; }
}

/** Lê um File escolhido pelo jogador. Devolve { ok, texto } ou { ok:false, error }. */
export async function lerArquivo(arquivo) {
  if (!arquivo) return { ok: false, error: 'nenhum arquivo escolhido' };
  if (arquivo.size > LIMITE_LEITURA) return { ok: false, error: 'arquivo grande demais para ser uma sala/progresso do LIMO' };
  try {
    const texto = typeof arquivo.text === 'function' ? await arquivo.text() : await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = () => rej(r.error); r.readAsText(arquivo); });
    return { ok: true, texto, nome: arquivo.name || '' };
  } catch (e) { return { ok: false, error: e?.message || 'não foi possível ler o arquivo' }; }
}

export const textoDoSalvamento = (r) => (r.cancelado ? 'Salvamento cancelado.' : r.ok
  ? ({ seletor: `Arquivo salvo: ${r.nome}.`, compartilhar: `Arquivo enviado para salvar: ${r.nome}.`, download: `Arquivo baixado: ${r.nome} (pasta Downloads).` }[r.via])
  : `Não foi possível salvar o arquivo (${r.error}).`);
