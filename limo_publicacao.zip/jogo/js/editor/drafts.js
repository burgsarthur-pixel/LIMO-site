// =====================================================================
// RASCUNHOS DO EDITOR (localStorage, quando disponível)
// A exportação de arquivo é a forma CONFIÁVEL de guardar um mapa; o rascunho é só uma rede de segurança.
// Se o armazenamento estiver bloqueado/cheio (navegador privado, etc.), nada quebra: devolve {ok:false}.
// =====================================================================
const PREFIXO = 'limo.rascunho.';

export class DraftStore {
  /** @param obterStorage função que devolve o storage (pode lançar erro em alguns navegadores) */
  constructor(obterStorage = () => globalThis.localStorage) { this._obter = obterStorage; }

  _storage() { try { const s = this._obter(); return s || null; } catch (e) { return null; } }

  available() {
    const s = this._storage();
    if (!s) return false;
    try { s.setItem(`${PREFIXO}__teste`, '1'); s.removeItem(`${PREFIXO}__teste`); return true; } catch (e) { return false; }
  }

  save(id, texto) {
    const s = this._storage();
    if (!s) return { ok: false, error: 'armazenamento indisponível' };
    try { s.setItem(PREFIXO + id, texto); return { ok: true }; } catch (e) { return { ok: false, error: e && e.name === 'QuotaExceededError' ? 'armazenamento cheio' : 'não foi possível gravar' }; }
  }

  load(id) { const s = this._storage(); try { return s ? s.getItem(PREFIXO + id) : null; } catch (e) { return null; } }

  remove(id) { const s = this._storage(); try { s?.removeItem(PREFIXO + id); } catch (e) { /* ignorado */ } }

  list() {
    const s = this._storage(); const ids = [];
    try { for (let i = 0; i < s.length; i++) { const k = s.key(i); if (k && k.startsWith(PREFIXO) && k !== `${PREFIXO}__teste`) ids.push(k.slice(PREFIXO.length)); } } catch (e) { return []; }
    return ids.sort();
  }
}
