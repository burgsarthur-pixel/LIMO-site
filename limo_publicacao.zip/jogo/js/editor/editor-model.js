// =====================================================================
// MODELO DO EDITOR (sem DOM): o "documento" da sala + todas as operações de edição.
// A interface (editor-ui.js) só chama estes métodos; por isso tudo aqui é testado em Node.
//
// Toda edição acontece dentro de uma TRANSAÇÃO (begin ... commit). Cada transação vira UM item
// de desfazer/refazer (ex.: uma pincelada inteira, um preenchimento, uma colagem).
// =====================================================================
import { GENES } from '../entities/genes.js';
import { TileMap, LAYER_NAMES } from '../world/tilemap.js';
import { validateRoomData, BIOME_IDS, KNOWN_ENEMY_KINDS } from '../world/room-validation.js';
import { roomToJson, formatRoomJson } from '../world/room-export.js';
import { validarDepth } from '../render/depth-config.js';

const MAX_HISTORICO = 200; // Limite máximo de ações guardadas na pilha de desfazer/refazer
const ID_VALIDO = /^[a-z0-9_]+$/; // Regex estrito para validar IDs de salas e entidades (letras minúsculas, números e "_")
const clonar = (v) => JSON.parse(JSON.stringify(v)); // Função utilitária segura para clonagem profunda de objetos e arrays

export class EditorError extends Error {
  constructor(mensagem, erros = []) {
    super(mensagem);
    this.name = 'EditorError';
    this.errors = erros; // Lista detalhada de erros de validação
  }
}

export class EditorModel {
  constructor({ catalog, config, logger = null, roomData }) {
    this.catalog = catalog; 
    this.config = config; 
    this.logger = logger;
    this._ouvintes = new Set(); // Conjunto de funções ouvintes notificadas em alterações do modelo
    
    // Estados iniciais das ferramentas e propriedades de desenho
    this.layer = 'solid'; 
    this.tool = 'pencil'; 
    this.brushSize = 1;
    this.tileId = catalog.has(1) ? 1 : catalog.all()[0].id;
    this.copyAllLayers = false; 
    this.clipboard = null; // Área de transferência para copiar e colar blocos de tiles
    
    // Validação rigorosa dos dados iniciais da sala antes de construir o modelo de edição
    const r = this._validar(roomData);
    if (r.errors.length) throw new EditorError(`Sala inválida: ${r.errors[0]}`, r.errors);
    this._aplicar(roomData);
  }

  // -----------------------------------------------------------------
  // SECÇÃO: ESTADO E EVENTOS (Observer Pattern)
  // -----------------------------------------------------------------
  
  // Regista uma função para ser avisada sempre que o modelo da sala sofrer alterações visuais ou estruturais
  subscribe(fn) {
    this._ouvintes.add(fn);
    return () => this._ouvintes.delete(fn);
  }
  
  // Dispara um evento para todos os componentes da interface inscritos
  _emitir(tipo) {
    for (const fn of this._ouvintes) fn(tipo);
  }

  // Valida o JSON atual da sala cruzando com as regras do motor do jogo e hitbox do jogador
  _validar(json, extra = {}) {
    const h = this.config.player.hitbox;
    return validateRoomData(json, this.catalog, {
      playerHitbox: h,
      view: { width: this.config.render.internalWidth, height: this.config.render.internalHeight },
      ...extra
    });
  }

  // Carrega e aplica os dados brutos da sala nas estruturas internas do editor
  _aplicar(json) {
    this.map = new TileMap(json, this.catalog);
    this.meta = { id: json.id, name: json.name, biome: json.biome, ...(json.mapPos ? { mapPos: clonar(json.mapPos) } : {}) };
    this.depth = json.depth ? clonar(json.depth) : null;   // v1.38: profundidade 2.5D (null = sala sem o sistema)
    this.bossIntro = json.bossIntro ? clonar(json.bossIntro) : null;   // gatilho da luta de chefe: o editor não o edita, mas não pode descartá-lo ao salvar
    this.feixes = json.feixes ? clonar(json.feixes) : [];   // v1.42: feixes de luz (o editor ainda não os edita, mas não pode descartá-los ao salvar)
    this.entities = clonar(json.entities);
    this.connections = clonar(json.connections || []);
    this.undoStack = []; 
    this.redoStack = []; 
    this._tx = null; 
    this._ultimo = null;
    this.selection = null; 
    this.sel = null; // item selecionado no painel (inimigo/entidade ou passagem)
    this.dirty = false; // Indica se existem alterações não salvas
    this._emitir('load');
  }

  // Propriedades computadas para verificar disponibilidade de histórico
  get canUndo() { return this.undoStack.length > 0; }
  get canRedo() { return this.redoStack.length > 0; }

  // -----------------------------------------------------------------
  // SECÇÃO: TRANSAÇÕES E SISTEMA DE HISTÓRICO (UNDO / REDO)
  // -----------------------------------------------------------------
  
  // Inicia uma nova transação de alterações para agrupar ações num único passo de histórico
  begin(rotulo = 'Edição') {
    if (this._tx) this.commit();
    this._tx = { rotulo, cells: [], extras: [] };
  }

  // Finaliza e consolida a transação atual, guardando-a no histórico
  commit() {
    const tx = this._tx; 
    this._tx = null;
    if (!tx || (!tx.cells.length && !tx.extras.length)) return false;
    this._empilhar(tx);
    return true;
  }

  // Insere a transação na pilha de desfazer e limpa a pilha de refazer
  _empilhar(tx) {
    this.undoStack.push(tx);
    if (this.undoStack.length > MAX_HISTORICO) this.undoStack.shift();
    this.redoStack.length = 0; 
    this.dirty = true;
    this._emitir('change');
  }

  // Executa uma função utilitária dentro de uma transação isolada de forma automática
  _auto(rotulo, fn) {
    const proprio = !this._tx;
    if (proprio) this.begin(rotulo);
    const r = fn();
    if (proprio) this.commit();
    return r;
  }

  // Modifica o ID de um tile numa célula do mapa e regista o estado anterior para permitir o Undo
  _celula(camada, tx, ty, id) {
    if (!this.map.inBounds(tx, ty)) return false;
    const antes = this.map.getTileId(camada, tx, ty);
    if (antes === id) return false;
    this.map.setTileId(camada, tx, ty, id);
    this._tx?.cells.push({ camada, x: tx, y: ty, antes, depois: id });
    return true;
  }

  // Reverte a última operação realizada no mapa ou entidades
  undo() {
    if (this._tx) this.commit();
    const tx = this.undoStack.pop();
    if (!tx) return false;
    for (let i = tx.cells.length - 1; i >= 0; i--) {
      const c = tx.cells[i]; 
      this.map.setTileId(c.camada, c.x, c.y, c.antes);
    }
    for (let i = tx.extras.length - 1; i >= 0; i--) tx.extras[i].undo();
    this.redoStack.push(tx); 
    this.dirty = true; 
    this._ajustarSelecao(); 
    this._emitir('change');
    return true;
  }

  // Reaplica a operação previamente desfeita
  redo() {
    if (this._tx) this.commit();
    const tx = this.redoStack.pop();
    if (!tx) return false;
    for (const c of tx.cells) this.map.setTileId(c.camada, c.x, c.y, c.depois);
    for (const e of tx.extras) e.redo();
    this.undoStack.push(tx); 
    this.dirty = true; 
    this._ajustarSelecao(); 
    this._emitir('change');
    return true;
  }

  // Atualiza os limites da área selecionada caso ocorra redimensionamento da sala
  _ajustarSelecao() {
    const s = this.selection;
    if (s && (s.x0 >= this.map.width || s.y0 >= this.map.height)) this.selection = null;
    else if (s) {
      s.x1 = Math.min(s.x1, this.map.width - 1);
      s.y1 = Math.min(s.y1, this.map.height - 1);
    }
    this._ajustarSel();
  }

  // -----------------------------------------------------------------
  // SECÇÃO: FERRAMENTAS DE PINTURA (Pincel, Borracha, Linhas)
  // -----------------------------------------------------------------
  
  // Retorna a lista de coordenadas afetadas com base no tamanho do pincel ativo (1x1, 2x2, 3x3)
  _celulasDoPincel(tx, ty) {
    const n = this.brushSize; 
    const off = Math.floor((n - 1) / 2); 
    const lista = [];
    for (let dy = 0; dy < n; dy++) {
      for (let dx = 0; dx < n; dx++) {
        lista.push([tx - off + dx, ty - off + dy]);
      }
    }
    return lista;
  }

  // Aplica carimbos de tiles no mapa utilizando o pincel ou a borracha
  _carimbar(tx, ty) {
    const id = this._apagando ? 0 : this.tileId;
    if (id !== 0 && !this.catalog.has(id)) return 0;
    let n = 0;
    for (const [x, y] of this._celulasDoPincel(tx, ty)) {
      if (this._celula(this.layer, x, y, id)) n++;
    }
    return n;
  }

  // Desenha uma linha rasterizada de tiles entre dois pontos utilizando o Algoritmo de Bresenham
  _linha(x0, y0, x1, y1) {
    let n = 0; 
    const dx = Math.abs(x1 - x0); 
    const dy = -Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1; 
    const sy = y0 < y1 ? 1 : -1;
    let erro = dx + dy; 
    let x = x0; 
    let y = y0;
    for (;;) {
      n += this._carimbar(x, y);
      if (x === x1 && y === y1) break;
      const e2 = 2 * erro;
      if (e2 >= dy) { erro += dy; x += sx; }
      if (e2 <= dx) { erro += dx; y += sy; }
    }
    return n;
  }

  // Inicia um traço contínuo de desenho ao clicar no mapa
  beginStroke(tx, ty, apagar = false) {
    this.begin(apagar ? 'Apagar' : 'Pintar'); 
    this._apagando = apagar; 
    this._ultimo = [tx, ty];
    return this._carimbar(tx, ty);
  }

  // Continua o traço de desenho enquanto o ponteiro é arrastado pelo ecrã
  moveStroke(tx, ty) {
    if (!this._tx || !this._ultimo) return 0;
    const [x0, y0] = this._ultimo; 
    this._ultimo = [tx, ty];
    return this._linha(x0, y0, tx, ty);
  }

  // Termina o traço e consolida a transação no histórico
  endStroke() {
    this._ultimo = null; 
    return this.commit();
  }

  // Cancela o traço atual em curso, revertendo imediatamente as alterações visuais
  cancelStroke() {
    const tx = this._tx; 
    this._tx = null; 
    this._ultimo = null;
    if (!tx) return false;
    for (let i = tx.cells.length - 1; i >= 0; i--) {
      const c = tx.cells[i]; 
      this.map.setTileId(c.camada, c.x, c.y, c.antes);
    }
    this._emitir('tool');
    return true;
  }

  // -----------------------------------------------------------------
  // SECÇÃO: PREENCHIMENTO E CONTA-GOTAS
  // -----------------------------------------------------------------
  
  // Preenche uma área contínua de tiles idênticos (Bucket Fill / Flood Fill)
  fill(tx, ty, apagar = false) {
    if (!this.map.inBounds(tx, ty)) return 0;
    const alvo = this.map.getTileId(this.layer, tx, ty);
    const novo = apagar ? 0 : this.tileId;
    if (alvo === novo || (novo !== 0 && !this.catalog.has(novo))) return 0;
    return this._auto('Preencher', () => {
      const { width: w, height: h } = this.map; 
      const visto = new Uint8Array(w * h); 
      const pilha = [ty * w + tx]; 
      let n = 0;
      while (pilha.length) {
        const i = pilha.pop();
        if (visto[i]) continue;
        visto[i] = 1;
        const x = i % w; 
        const y = (i - x) / w;
        if (this.map.getTileId(this.layer, x, y) !== alvo) continue;
        this._celula(this.layer, x, y, novo); 
        n++;
        if (x > 0) pilha.push(i - 1); 
        if (x < w - 1) pilha.push(i + 1);
        if (y > 0) pilha.push(i - w); 
        if (y < h - 1) pilha.push(i + w);
      }
      return n;
    });
  }

  // Ferramenta conta-gotas: capta o ID do tile clicado para o definir como pincel ativo
  eyedrop(tx, ty) {
    const id = this.map.getTileId(this.layer, tx, ty);
    if (id > 0) {
      this.tileId = id; 
      this.tool = 'pencil'; 
      this._emitir('tool');
    }
    return id;
  }

  // -----------------------------------------------------------------
  // SECÇÃO: SELEÇÃO, CÓPIA E COLAGEM
  // -----------------------------------------------------------------
  
  // Define uma área retangular de seleção no mapa
  select(x0, y0, x1, y1) {
    const c = (v, max) => Math.max(0, Math.min(max, v));
    const ax = c(x0, this.map.width - 1); 
    const bx = c(x1, this.map.width - 1); 
    const ay = c(y0, this.map.height - 1); 
    const by = c(y1, this.map.height - 1);
    this.selection = {
      x0: Math.min(ax, bx),
      y0: Math.min(ay, by),
      x1: Math.max(ax, bx),
      y1: Math.max(ay, by)
    };
    this._emitir('selection');
  }

  // Limpa a seleção retangular ativa
  clearSelection() {
    this.selection = null; 
    this._emitir('selection');
  }

  // Retorna quais camadas devem ser afetadas por operações de cópia/corte
  _camadasAfetadas() {
    return this.copyAllLayers ? LAYER_NAMES : [this.layer];
  }

  // Copia os tiles da área selecionada para a área de transferência interna
  copy() {
    const s = this.selection;
    if (!s) return false;
    const w = s.x1 - s.x0 + 1; 
    const h = s.y1 - s.y0 + 1; 
    const camadas = {};
    for (const nome of this._camadasAfetadas()) {
      const arr = new Uint16Array(w * h);
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          arr[y * w + x] = this.map.getTileId(nome, s.x0 + x, s.y0 + y);
        }
      }
      camadas[nome] = arr;
    }
    this.clipboard = { w, h, layers: camadas };
    this._emitir('clipboard');
    return true;
  }

  // Recorta a seleção atual (copia para o clipboard e apaga os tiles originais)
  cut() {
    if (!this.copy()) return false;
    this.deleteSelection();
    return true;
  }

  // Apaga todos os tiles contidos dentro da seleção atual
  deleteSelection() {
    const s = this.selection;
    if (!s) return 0;
    return this._auto('Apagar seleção', () => {
      let n = 0;
      for (const nome of this._camadasAfetadas()) {
        for (let y = s.y0; y <= s.y1; y++) {
          for (let x = s.x0; x <= s.x1; x++) {
            if (this._celula(nome, x, y, 0)) n++;
          }
        }
      }
      return n;
    });
  }

  // Cola o conteúdo copiado a partir de uma coordenada de destino (tx, ty)
  paste(tx, ty) {
    const cb = this.clipboard;
    if (!cb) return 0;
    const n = this._auto('Colar', () => {
      let total = 0;
      for (const [nome, arr] of Object.entries(cb.layers)) {
        for (let y = 0; y < cb.h; y++) {
          for (let x = 0; x < cb.w; x++) {
            const id = arr[y * cb.w + x];
            if (id !== 0 && this._celula(nome, tx + x, ty + y, id)) total++;
          }
        }
      }
      return total;
    });
    this.select(tx, ty, tx + cb.w - 1, ty + cb.h - 1);
    return n;
  }

  // -----------------------------------------------------------------
  // SECÇÃO: GESTÃO DE ENTIDADES (Início, Inimigos e Portas Manuais)
  // -----------------------------------------------------------------
  
  // Define ou reposiciona a entidade playerStart (ponto de nascimento do jogador na sala)
  setPlayerStart(tx, ty) {
    if (!this.map.inBounds(tx, ty)) return false;
    const antes = clonar(this.entities);
    const e = this.entities.find((x) => x.type === 'playerStart');
    if (e) {
      e.x = tx; 
      e.y = ty;
    } else {
      this.entities.push({ type: 'playerStart', x: tx, y: ty });
    }
    const depois = clonar(this.entities);
    this._empilhar({
      rotulo: 'Início do jogador',
      cells: [],
      extras: [{
        undo: () => { this.entities = clonar(antes); },
        redo: () => { this.entities = clonar(depois); }
      }]
    });
    return true;
  }

  get playerStart() {
    return this.entities.find((e) => e.type === 'playerStart') || null;
  }

  // Adiciona ou remove um inimigo na coordenada (tx, ty) do mapa
  addEnemy(tx, ty) {
    if (!this.map.inBounds(tx, ty)) return false;
    const antes = clonar(this.entities);
    const index = this.entities.findIndex((e) => e.type === 'enemy' && e.x === tx && e.y === ty);
    if (index >= 0) {
      this.entities.splice(index, 1);
    } else {
      this.entities.push({ type: 'enemy', id: this._idLivre(`inimigo_${tx}_${ty}`), kind: 'crawler', x: tx, y: ty });
    }
    const depois = clonar(this.entities);
    this._empilhar({
      rotulo: 'Adicionar/Remover Inimigo',
      cells: [],
      extras: [{
        undo: () => { this.entities = clonar(antes); },
        redo: () => { this.entities = clonar(depois); }
      }]
    });
    return true;
  }

  get enemies() {
    return this.entities.filter((e) => e.type === 'enemy');
  }
  
  // Adiciona, remove ou gere uma porta com destino manual configurável (door)
  addDoor(tx, ty) {
    if (!this.map.inBounds(tx, ty)) return false;
    const antes = clonar(this.entities);
    const index = this.entities.findIndex((e) => e.type === 'door' && e.x === tx && e.y === ty);
    if (index >= 0) {
      this.entities.splice(index, 1);
    } else {
      // Determina a direção padrão com base na borda em que foi colocada
      let dir = 'right';
      if (tx === 0) dir = 'left';
      else if (tx === this.map.width - 1) dir = 'right';
      else if (ty === 0) dir = 'up';
      else if (ty === this.map.height - 1) dir = 'down';

      // Cria um ID único para a porta e inicializa os campos de destino manual vazios
      const id = `porta_${tx}_${ty}`;
      this.entities.push({
        type: 'door',
        id,
        x: tx,
        y: ty,
        dir,
        targetRoom: '',    // ID da sala de destino configurada manualmente
        targetDoor: ''     // ID da porta correspondente na sala de destino
      });
    }
    const depois = clonar(this.entities);
    this._empilhar({
      rotulo: 'Adicionar/Remover Porta',
      cells: [],
      extras: [{
        undo: () => { this.entities = clonar(antes); },
        redo: () => { this.entities = clonar(depois); }
      }]
    });
    return true;
  }

  // Atualiza os parâmetros de destino manual de uma porta específica pelo seu ID
  updateDoor(id, { targetRoom, targetDoor, dir }) {
    const antes = clonar(this.entities);
    const door = this.entities.find((e) => e.type === 'door' && e.id === id);
    if (!door) return false;

    if (targetRoom !== undefined) door.targetRoom = targetRoom;
    if (targetDoor !== undefined) door.targetDoor = targetDoor;
    if (dir !== undefined) door.dir = dir;

    const depois = clonar(this.entities);
    this._empilhar({
      rotulo: 'Atualizar Porta',
      cells: [],
      extras: [{
        undo: () => { this.entities = clonar(antes); },
        redo: () => { this.entities = clonar(depois); }
      }]
    });
    return true;
  }

  get doors() {
    return this.entities.filter((e) => e.type === 'door');
  }

  /** Alterna uma âncora orgânica da Tendril na célula, com histórico atômico. */
  addTendrilAnchor(tx, ty) {
    return this._alternarTendril(tx, ty, 'tendrilAnchor', 'Âncora da Tendril');
  }

  /** Alterna um objeto ativável pela Tendril; a área de puzzle pode ser editada no JSON exportado. */
  addTendrilObject(tx, ty) {
    return this._alternarTendril(tx, ty, 'tendrilObject', 'Objeto da Tendril');
  }

  _alternarTendril(tx, ty, type, rotulo) {
    if (!this.map.inBounds(tx, ty)) return false;
    const antes = clonar(this.entities);
    const index = this.entities.findIndex((e) => e.type === type && e.x === tx && e.y === ty);
    if (index >= 0) this.entities.splice(index, 1);
    else {
      const prefixo = type === 'tendrilAnchor' ? 'ancora' : 'objeto_tendril';
      this.entities.push({ type, id: `${prefixo}_${tx}_${ty}`, x: tx, y: ty, ...(type === 'tendrilObject' ? { text: 'Algo se move ao ser puxado.' } : {}) });
    }
    const depois = clonar(this.entities);
    this._empilhar({ rotulo: `Adicionar/Remover ${rotulo}`, cells: [], extras: [{
      undo: () => { this.entities = clonar(antes); },
      redo: () => { this.entities = clonar(depois); },
    }] });
    return true;
  }

  // -----------------------------------------------------------------
  // Casulo de Repouso (checkpoint) e genes a coletar
  // -----------------------------------------------------------------
  /** Alterna um Casulo de Repouso (entidade "checkpoint": descansar nele restaura a vida e abre a tela de genes). */
  addCheckpoint(tx, ty) { return this._alternarObjeto(tx, ty, 'checkpoint', `repouso_${tx}_${ty}`, {}, 'Casulo de Repouso'); }

  /** Alterna um gene a coletar; `geneSelecionado` é o id do catálogo (entities/genes.js) escolhido no painel. */
  addGene(tx, ty) { return this._alternarObjeto(tx, ty, 'gene', `gene_${tx}_${ty}`, { gene: this.geneSelecionado || GENES.find((g) => g.implementado).id }, 'Gene'); }

  _alternarObjeto(tx, ty, type, id, extra, rotulo) {
    if (!this.map.inBounds(tx, ty)) return false;
    const antes = clonar(this.entities);
    const index = this.entities.findIndex((e) => e.type === type && e.x === tx && e.y === ty);
    if (index >= 0) this.entities.splice(index, 1); else this.entities.push({ type, id, x: tx, y: ty, ...extra });
    const depois = clonar(this.entities);
    this._empilhar({ rotulo: `Adicionar/Remover ${rotulo}`, cells: [], extras: [{ undo: () => { this.entities = clonar(antes); }, redo: () => { this.entities = clonar(depois); } }] });
    return true;
  }

  get checkpoints() { return this.entities.filter((e) => e.type === 'checkpoint'); }
  get genes() { return this.entities.filter((e) => e.type === 'gene'); }

  get tendrilAnchors() { return this.entities.filter((e) => e.type === 'tendrilAnchor'); }
  get tendrilObjects() { return this.entities.filter((e) => e.type === 'tendrilObject'); }

  // -----------------------------------------------------------------
  // SECÇÃO: EDIÇÃO DE ENTIDADES (inimigos etc.) E PASSAGENS (as portas de verdade do jogo)
  // As "passagens" são as `connections` do JSON: um retângulo de gatilho + sala de destino.
  // Tudo aqui entra no desfazer/refazer. Os métodos devolvem { ok, errors }.
  // -----------------------------------------------------------------

  _estado() { return { e: clonar(this.entities), c: clonar(this.connections) }; }
  _restaurarEstado(s) { this.entities = clonar(s.e); this.connections = clonar(s.c); }

  /** Guarda o estado "antes" de uma edição em andamento (ex.: arrastar um inimigo). Termine com endEdicao. */
  beginEdicao() { if (this._tx) this.commit(); return this._estado(); }

  /** Registra UM item de desfazer se algo mudou desde `antes`. */
  endEdicao(rotulo, antes) {
    const depois = this._estado();
    if (JSON.stringify(antes) === JSON.stringify(depois)) return false;
    this._empilhar({ rotulo, cells: [], extras: [{ undo: () => this._restaurarEstado(antes), redo: () => this._restaurarEstado(depois) }] });
    return true;
  }

  /** Aplica `mutar` e só mantém se NÃO surgir erro de validação novo (erros que já existiam não bloqueiam). */
  _aplicarValidado(rotulo, mutar, extra = {}) {
    const antes = this.beginEdicao();
    const errosAntes = new Set(this._validar(this.toJson(), extra).errors);
    try { mutar(); } catch (e) { this._restaurarEstado(antes); return { ok: false, errors: [e.message] }; }
    const r = this._validar(this.toJson(), extra);
    const novos = r.errors.filter((m) => !errosAntes.has(m));
    if (novos.length) { this._restaurarEstado(antes); return { ok: false, errors: novos, warnings: r.warnings }; }
    this.endEdicao(rotulo, antes);
    this._ajustarSel();
    return { ok: true, errors: [], warnings: r.warnings };
  }

  _lerJson(texto, tipoEsperado) {
    let v;
    try { v = JSON.parse(texto); } catch (e) { return { erro: `JSON inválido: ${e.message}` }; }
    if (tipoEsperado === 'array' && !Array.isArray(v)) return { erro: 'Esperava uma lista [ ... ].' };
    if (tipoEsperado === 'objeto' && (!v || typeof v !== 'object' || Array.isArray(v))) return { erro: 'Esperava um objeto { ... }.' };
    return { v };
  }

  // ---- seleção (o que aparece no painel "Selecionado") ----
  selecionarEntidade(index) { this.sel = this.entities[index] ? { tipo: 'entidade', index } : null; this._emitir('sel'); }
  selecionarPassagem(id) { this.sel = this.connections.some((c) => c.id === id) ? { tipo: 'passagem', id } : null; this._emitir('sel'); }
  limparSel() { if (!this.sel) return; this.sel = null; this._emitir('sel'); }
  _ajustarSel() {
    const s = this.sel;
    if (!s) return;
    if (s.tipo === 'entidade' && !this.entities[s.index]) this.sel = null;
    if (s.tipo === 'passagem' && !this.connections.some((c) => c.id === s.id)) this.sel = null;
  }
  get entidadeSel() { return this.sel && this.sel.tipo === 'entidade' ? this.entities[this.sel.index] || null : null; }
  get passagemSel() { return this.sel && this.sel.tipo === 'passagem' ? this.connections.find((c) => c.id === this.sel.id) || null : null; }

  // ---- busca por célula ----
  /** Índice da entidade (exceto playerStart) que ocupa a célula; paredes frágeis e objetos grandes ocupam w×h. */
  entityAt(tx, ty) {
    for (let i = this.entities.length - 1; i >= 0; i--) {
      const e = this.entities[i];
      if (e.type === 'playerStart') continue;
      const w = Number.isInteger(e.w) ? e.w : 1; const h = Number.isInteger(e.h) ? e.h : 1;
      if (tx >= e.x && tx < e.x + w && ty >= e.y && ty < e.y + h) return i;
    }
    return -1;
  }
  /** Id da passagem cujo gatilho cobre a célula (ou null). */
  passagemEm(tx, ty) {
    for (let i = this.connections.length - 1; i >= 0; i--) {
      const t = this.connections[i].trigger;
      if (t && tx >= t.x && tx < t.x + t.w && ty >= t.y && ty < t.y + t.h) return this.connections[i].id;
    }
    return null;
  }

  _idLivre(base) {
    const usados = new Set(this.entities.map((e) => e.id));
    if (!usados.has(base)) return base;
    let i = 2;
    while (usados.has(`${base}_${i}`)) i++;
    return `${base}_${i}`;
  }

  /** Muda campos de uma entidade. Valor vazio/undefined/null apaga o campo (volta ao padrão do jogo). */
  updateEntity(index, patch, rotulo = 'Editar item') {
    const e = this.entities[index];
    if (!e) return { ok: false, errors: ['Item inexistente.'] };
    const erros = [];
    for (const [k, v] of Object.entries(patch)) {
      const vazio = v === undefined || v === null || v === '';
      if (k === 'type') erros.push('O tipo não muda aqui: use o JSON do item.');
      else if (k === 'id' && !vazio) {
        if (!ID_VALIDO.test(v)) erros.push('id inválido: use letras minúsculas, números e "_".');
        else if (this.entities.some((o, i) => i !== index && o.id === v)) erros.push(`Já existe um item com o id "${v}" nesta sala.`);
      } else if (k === 'x' || k === 'y') {
        const max = k === 'x' ? this.map.width : this.map.height;
        if (!Number.isInteger(v) || v < 0 || v >= max) erros.push(`${k} deve ser um inteiro de 0 a ${max - 1}.`);
      } else if (e.type === 'enemy' && ['speed', 'life', 'damage'].includes(k) && !vazio && !(Number.isFinite(v) && v > 0)) {
        erros.push(`"${k}" precisa ser um número positivo (ou vazio para usar o padrão).`);
      } else if (e.type === 'enemy' && k === 'kind' && !vazio && !KNOWN_ENEMY_KINDS.includes(v)) {
        erros.push(`Espécie inválida "${v}" (use ${KNOWN_ENEMY_KINDS.join(', ')}).`);
      } else if (k === 'kind' && e.type === 'enemy' && vazio) { /* vazio = padrão (rastejante) */ }
    }
    if (erros.length) return { ok: false, errors: erros };
    const antes = this.beginEdicao();
    for (const [k, v] of Object.entries(patch)) {
      if (v === undefined || v === null || v === '') delete e[k]; else e[k] = v;
    }
    this.endEdicao(rotulo, antes);
    return { ok: true, errors: [] };
  }

  /** Move a entidade para a célula (um item de desfazer). Para arrastar: mude x/y direto e feche com endEdicao. */
  moveEntity(index, tx, ty) { return this.updateEntity(index, { x: tx, y: ty }, 'Mover item'); }

  removeEntity(index) {
    const e = this.entities[index];
    if (!e) return { ok: false, errors: ['Item inexistente.'] };
    if (e.type === 'playerStart') return { ok: false, errors: ['O início do jogador não pode ser removido (mova-o com a ferramenta ☺ Início).'] };
    const antes = this.beginEdicao();
    this.entities.splice(index, 1);
    this.endEdicao('Remover item', antes);
    this.sel = null; this._emitir('sel');
    return { ok: true, errors: [] };
  }

  /** Coloca um inimigo novo (ou seleciona o que já está lá). Devolve o índice. */
  addEnemyOrSelect(tx, ty, props = {}) {
    if (!this.map.inBounds(tx, ty)) return -1;
    const ja = this.entities.findIndex((e) => e.type === 'enemy' && e.x === tx && e.y === ty);
    if (ja >= 0) { this.selecionarEntidade(ja); return ja; }
    const antes = this.beginEdicao();
    this.entities.push({ type: 'enemy', id: this._idLivre(`inimigo_${tx}_${ty}`), kind: 'crawler', x: tx, y: ty, ...props });
    this.endEdicao('Adicionar inimigo', antes);
    this.selecionarEntidade(this.entities.length - 1);
    return this.entities.length - 1;
  }

  // ---- passagens (connections) ----
  _idPassagemLivre() {
    const usados = new Set(this.connections.map((c) => c.id));
    let i = this.connections.length + 1;
    while (usados.has(`passagem_${i}`)) i++;
    return `passagem_${i}`;
  }

  /** Cria uma passagem com o gatilho {x,y,w,h} (limitado à sala). Destino em branco: escolha depois. */
  addConnection(trigger, dados = {}) {
    const W = this.map.width; const H = this.map.height;
    const x = Math.max(0, Math.min(W - 1, trigger.x)); const y = Math.max(0, Math.min(H - 1, trigger.y));
    const w = Math.max(1, Math.min(W - x, trigger.w)); const h = Math.max(1, Math.min(H - y, trigger.h));
    const antes = this.beginEdicao();
    const id = dados.id && ID_VALIDO.test(dados.id) && !this.connections.some((c) => c.id === dados.id) ? dados.id : this._idPassagemLivre();
    this.connections.push({ id, to: dados.to || '', toConnection: dados.toConnection || '', trigger: { x, y, w, h } });
    this.endEdicao('Adicionar passagem', antes);
    this.selecionarPassagem(id);
    return { ok: true, id, errors: [] };
  }

  /** Toque numa célula: se for na borda da sala, cria o gatilho típico de 1×3 (ou 3×1); senão 1×1. */
  addConnectionAt(tx, ty) {
    const W = this.map.width; const H = this.map.height;
    let t = { x: tx, y: ty, w: 1, h: 1 };
    if (tx === 0 || tx === W - 1) t = { x: tx, y: Math.max(0, Math.min(H - 3, ty - 1)), w: 1, h: Math.min(3, H) };
    else if (ty === 0 || ty === H - 1) t = { x: Math.max(0, Math.min(W - 3, tx - 1)), y: ty, w: Math.min(3, W), h: 1 };
    return this.addConnection(t);
  }

  /** patch: { id, to, toConnection, trigger:{x,y,w,h parciais}, spawn:{x,y}|null, requires:string|null } */
  updateConnection(id, patch, rotulo = 'Editar passagem') {
    const c = this.connections.find((x) => x.id === id);
    if (!c) return { ok: false, errors: ['Passagem inexistente.'] };
    const erros = [];
    if (patch.id !== undefined && patch.id !== id) {
      if (!ID_VALIDO.test(patch.id)) erros.push('id inválido: use letras minúsculas, números e "_".');
      else if (this.connections.some((o) => o.id === patch.id)) erros.push(`Já existe a passagem "${patch.id}" nesta sala.`);
    }
    let trigger = null;
    if (patch.trigger) {
      trigger = { ...c.trigger, ...patch.trigger };
      const ok = [trigger.x, trigger.y, trigger.w, trigger.h].every(Number.isInteger) && trigger.w >= 1 && trigger.h >= 1;
      if (!ok) erros.push('O gatilho precisa de x, y, w, h inteiros (w e h ≥ 1).');
      else if (trigger.x < 0 || trigger.y < 0 || trigger.x + trigger.w > this.map.width || trigger.y + trigger.h > this.map.height) erros.push('O gatilho sai da sala.');
    }
    if (patch.spawn && !(Number.isInteger(patch.spawn.x) && Number.isInteger(patch.spawn.y))) erros.push('O ponto de chegada (spawn) precisa de x e y inteiros.');
    if (erros.length) return { ok: false, errors: erros };
    const antes = this.beginEdicao();
    if (patch.to !== undefined) c.to = patch.to;
    if (patch.toConnection !== undefined) c.toConnection = patch.toConnection;
    if (trigger) c.trigger = trigger;
    if ('spawn' in patch) { if (patch.spawn) c.spawn = { x: patch.spawn.x, y: patch.spawn.y }; else delete c.spawn; }
    if ('requires' in patch) { if (patch.requires) c.requires = patch.requires; else delete c.requires; }
    if ('requerGene' in patch) { if (patch.requerGene) c.requerGene = patch.requerGene; else delete c.requerGene; }
    if (patch.id !== undefined && patch.id !== id) { c.id = patch.id; if (this.sel?.tipo === 'passagem' && this.sel.id === id) this.sel = { tipo: 'passagem', id: patch.id }; }
    this.endEdicao(rotulo, antes);
    return { ok: true, errors: [] };
  }

  removeConnection(id) {
    const i = this.connections.findIndex((c) => c.id === id);
    if (i < 0) return { ok: false, errors: ['Passagem inexistente.'] };
    const antes = this.beginEdicao();
    this.connections.splice(i, 1);
    this.endEdicao('Remover passagem', antes);
    this._ajustarSel(); this._emitir('sel');
    return { ok: true, errors: [] };
  }

  // ---- JSON cru (para quando os campos não bastam) ----
  /** Troca a lista inteira de entidades pelo JSON do texto. Só aceita se não criar erro novo. */
  setEntitiesJson(texto, extra = {}) {
    const r = this._lerJson(texto, 'array'); if (r.erro) return { ok: false, errors: [r.erro] };
    return this._aplicarValidado('Editar entidades (JSON)', () => { this.entities = r.v; }, extra);
  }
  setConnectionsJson(texto, extra = {}) {
    const r = this._lerJson(texto, 'array'); if (r.erro) return { ok: false, errors: [r.erro] };
    return this._aplicarValidado('Editar passagens (JSON)', () => { this.connections = r.v; }, extra);
  }
  /** Troca UM item pelo objeto JSON do texto (aceita mudar o tipo e campos extras). */
  replaceEntityJson(index, texto, extra = {}) {
    if (!this.entities[index]) return { ok: false, errors: ['Item inexistente.'] };
    const r = this._lerJson(texto, 'objeto'); if (r.erro) return { ok: false, errors: [r.erro] };
    return this._aplicarValidado('Editar item (JSON)', () => { this.entities[index] = r.v; }, extra);
  }
  replaceConnectionJson(id, texto, extra = {}) {
    const i = this.connections.findIndex((c) => c.id === id);
    if (i < 0) return { ok: false, errors: ['Passagem inexistente.'] };
    const r = this._lerJson(texto, 'objeto'); if (r.erro) return { ok: false, errors: [r.erro] };
    const res = this._aplicarValidado('Editar passagem (JSON)', () => { this.connections[i] = r.v; }, extra);
    if (res.ok && this.sel?.tipo === 'passagem' && this.sel.id === id) { this.sel = typeof r.v.id === 'string' ? { tipo: 'passagem', id: r.v.id } : null; this._emitir('sel'); }
    return res;
  }

  // -----------------------------------------------------------------
  // SECÇÃO: DIMENSÕES E METADADOS DA SALA
  // -----------------------------------------------------------------
  
  // Redimensiona a largura e altura em tiles da sala atual
  resize(largura, altura) {
    if (![largura, altura].every((n) => Number.isInteger(n) && n >= 1 && n <= 500)) {
      return { ok: false, error: 'Largura e altura devem ser inteiros de 1 a 500.' };
    }
    if (largura === this.map.width && altura === this.map.height) {
      return { ok: true, changed: false };
    }
    
    if (this._tx) this.commit();
    const snapAntes = this.map.snapshot();
    const entAntes = clonar(this.entities);
    this.map.resize(largura, altura);
    for (const e of this.entities) {
      e.x = Math.min(e.x, largura - 1);
      e.y = Math.min(e.y, altura - 1);
    }
    const snapDepois = this.map.snapshot(); 
    const entDepois = clonar(this.entities);
    this._empilhar({
      rotulo: 'Redimensionar',
      cells: [],
      extras: [{
        undo: () => { this.map.restore(snapAntes); this.entities = clonar(entAntes); },
        redo: () => { this.map.restore(snapDepois); this.entities = clonar(entDepois); },
      }],
    });
    this._ajustarSelecao();
    return { ok: true, changed: true };
  }

  // Altera os metadados principais da sala (ID, nome ou bioma) com validação prévia
  setMeta({ id, name, biome, mapPos }) {
    const erros = [];
    if (id !== undefined && !ID_VALIDO.test(id)) erros.push('id inválido: use letras minúsculas, números e "_".');
    if (name !== undefined && !String(name).trim()) erros.push('O nome não pode ficar vazio.');
    if (biome !== undefined && !BIOME_IDS.includes(biome)) erros.push(`Bioma inválido (use ${BIOME_IDS.join(', ')}).`);
    if (mapPos !== undefined && mapPos !== null && !(Number.isInteger(mapPos.x) && Number.isInteger(mapPos.y))) {
      erros.push('mapPos precisa ter coordenadas inteiras x e y.');
    }
    if (erros.length) return { ok: false, errors: erros };
    if (id !== undefined) this.meta.id = id;
    if (name !== undefined) this.meta.name = String(name).trim();
    if (biome !== undefined) this.meta.biome = biome;
    if (mapPos !== undefined) { if (mapPos === null) delete this.meta.mapPos; else this.meta.mapPos = clonar(mapPos); }
    this.dirty = true; 
    this._emitir('meta');
    return { ok: true };
  }

  /** Define (ou remove, com null) o bloco de profundidade 2.5D. Só visual: não toca mapa, colisão nem entidades. Troca o objeto inteiro (os caches do renderer reconhecem). */
  setDepth(depth) {
    const v = validarDepth(depth === null ? undefined : depth);
    if (v.errors.length) return { ok: false, errors: v.errors };
    this.depth = depth === null ? null : clonar(depth); this.dirty = true; this._emitir('meta');
    return { ok: true, warnings: v.warnings };
  }

  toJson() {
    return roomToJson({ ...this.meta, depth: this.depth, bossIntro: this.bossIntro, feixes: this.feixes, map: this.map, entities: this.entities, connections: this.connections });
  }
  
  toText() {
    return formatRoomJson(this.toJson());
  }
  
  validate(extra = {}) {
    return this._validar(this.toJson(), extra);
  }
  
  markSaved() {
    this.dirty = false; 
    this._emitir('meta');
  }

  // Carrega e valida os dados de uma sala a partir de um objeto ou string JSON
  loadFromJson(entrada, extra = {}) {
    let json = entrada;
    if (typeof entrada === 'string') {
      try {
        json = JSON.parse(json);
      } catch (e) {
        return { ok: false, errors: [`JSON inválido: ${e.message}`], warnings: [] };
      }
    }
    const r = this._validar(json, extra);
    if (r.errors.length) return { ok: false, errors: r.errors, warnings: r.warnings };
    this._aplicar(json);
    return { ok: true, errors: [], warnings: r.warnings };
  }

  // Duplica a sala ativa gerando automaticamente um novo ID livre e único
  duplicate(idsUsados = []) {
    const base = `${this.meta.id}_copia`; 
    let novo = base; 
    let i = 2;
    while (idsUsados.includes(novo)) novo = `${base}${i++}`;
    const json = this.toJson(); 
    json.id = novo; 
    json.name = `${this.meta.name} (cópia)`;
    this._aplicar(json); 
    this.dirty = true; 
    this._emitir('meta');
    return novo;
  }

}
