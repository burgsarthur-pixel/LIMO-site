// =====================================================================
// VISTA DO EDITOR (matemática pura): zoom, rolagem e conversão de coordenadas.
// "view" = {x, y, zoom}: x,y = canto superior esquerdo visível, em pixels do MUNDO; zoom = escala.
// Só usamos níveis de zoom fixos para a pixel art continuar nítida.
// =====================================================================

import { clamp as limitar } from '../core/math.js';

export const ZOOM_LEVELS = [0.5, 1, 2, 3, 4, 6];


export function nearestZoomIndex(zoom) {
  let melhor = 0;
  ZOOM_LEVELS.forEach((z, i) => { if (Math.abs(Math.log(z / zoom)) < Math.abs(Math.log(ZOOM_LEVELS[melhor] / zoom))) melhor = i; });
  return melhor;
}

export function stepZoom(zoom, direcao) { return ZOOM_LEVELS[limitar(nearestZoomIndex(zoom) + direcao, 0, ZOOM_LEVELS.length - 1)]; }

/** Ponto da tela (px do canvas interno) -> célula do mapa. */
export function screenToCell(view, px, py, tileSize) {
  return { tx: Math.floor((px / view.zoom + view.x) / tileSize), ty: Math.floor((py / view.zoom + view.y) / tileSize) };
}

/** Muda o zoom mantendo o ponto (px,py) da tela parado (zoom "em direção ao dedo/cursor"). */
export function zoomAt(view, novoZoom, px, py) {
  const wx = px / view.zoom + view.x; const wy = py / view.zoom + view.y;
  view.zoom = novoZoom; view.x = wx - px / novoZoom; view.y = wy - py / novoZoom;
  return view;
}

/** Impede de "perder" o mapa: permite sair meia tela além das bordas; mapa pequeno fica centralizado. */
export function clampView(view, larguraMapa, alturaMapa, larguraTela, alturaTela) {
  const visL = larguraTela / view.zoom; const visA = alturaTela / view.zoom;
  const eixo = (v, mapa, vis) => {
    if (mapa <= vis) return (mapa - vis) / 2;           // sala menor que a tela: fica centralizada
    const folga = vis * 0.5;
    return limitar(v, -folga, mapa - vis + folga);
  };
  view.x = eixo(view.x, larguraMapa, visL); view.y = eixo(view.y, alturaMapa, visA);
  return view;
}

/** Zoom e posição que mostram a sala inteira, centralizada. */
export function fitView(larguraMapa, alturaMapa, larguraTela, alturaTela) {
  let zoom = ZOOM_LEVELS[0];
  for (const z of ZOOM_LEVELS) if (larguraMapa * z <= larguraTela && alturaMapa * z <= alturaTela) zoom = z;
  return { zoom, x: (larguraMapa - larguraTela / zoom) / 2, y: (alturaMapa - alturaTela / zoom) / 2 };
}

/** Gesto de pinça: começa com os dois dedos (a, b) e a vista inicial. */
export function startPinch(a, b, view) {
  return { dist0: Math.hypot(b.x - a.x, b.y - a.y) || 1, zoom0: view.zoom, mid0: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, view0: { ...view } };
}

/** Nova vista conforme os dedos (a, b) se afastam/aproximam e se movem. */
export function updatePinch(g, a, b) {
  const dist = Math.hypot(b.x - a.x, b.y - a.y) || 1;
  const zoom = ZOOM_LEVELS[nearestZoomIndex(g.zoom0 * (dist / g.dist0))];
  const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
  // ponto do mundo que estava sob o centro inicial dos dedos deve ficar sob o centro atual
  const wx = g.mid0.x / g.view0.zoom + g.view0.x; const wy = g.mid0.y / g.view0.zoom + g.view0.y;
  return { zoom, x: wx - mid.x / zoom, y: wy - mid.y / zoom };
}

/** Coordenadas do evento -> pixels do canvas interno. */
export function canvasPoint(clientX, clientY, rect, larguraInterna, alturaInterna) {
  return { x: ((clientX - rect.left) / rect.width) * larguraInterna, y: ((clientY - rect.top) / rect.height) * alturaInterna };
}
