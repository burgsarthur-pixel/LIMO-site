// EDITOR DE MAPAS (interface). Só existe em modo dev (?dev=1) e usa o MESMO formato de sala do jogo.
// =====================================================================
import { EditorModel } from './editor-model.js';
import { PRESETS as PRESETS_DEPTH, presetSoVolume, PLANOS as PLANOS_DEPTH, MOTIVOS as MOTIVOS_DEPTH, MAX_CAMADAS as MAX_CAMADAS_DEPTH } from '../render/depth-config.js';
import { LAYER_NAMES } from '../world/tilemap.js';
import { buildRoom } from '../world/room-loader.js';
import { blankRoomJson } from '../world/room-export.js';
import { BIOME_IDS, KNOWN_ENEMY_KINDS } from '../world/room-validation.js';
import { ABILITY_IDS, ABILITIES } from '../entities/abilities.js';
import { ENEMY_DEFAULTS } from '../entities/enemy.js';
import { previewVariant } from '../world/autotile.js';
import { GENES } from '../entities/genes.js';
import { salvarArquivo, lerArquivo, textoDoSalvamento } from './arquivo.js';
import { drawCheckpoint, drawGenePickup } from '../entities/entity-art.js';
import { drawPlayer } from '../render/player-art.js';
import { DEBUG_COLORS } from '../debug/debug-overlay.js';
import { screenToCell, zoomAt, clampView, fitView, stepZoom, startPinch, updatePinch, canvasPoint } from './editor-view.js';

const NOMES_CAMADAS = {
  backgroundFar: 'Fundo distante', backgroundMid: 'Fundo intermediário', decoBack: 'Decoração (atrás)', solid: 'Sólidos',
  platform: 'Plataformas', decoFront: 'Decoração (frente)', interactive: 'Interativos / dano', foreground: 'Primeiro plano',
};
const FERRAMENTAS = [
  ['pencil', '✏ Pincel'], ['eraser', '⌫ Borracha'], ['fill', '▨ Preencher'], ['select', '▭ Selecionar'],
  ['pan', '✋ Mover vista'], ['eyedropper', '💧 Conta-gotas'], ['start', '☺ Início'], ['enemy', '👾 Inimigo'], ['door', '🚪 Porta'],
  ['tendrilAnchor', '〰 Âncora'], ['tendrilObject', '◇ Objeto Tendril'], ['checkpoint', '🛌 Repouso'], ['gene', '🧬 Gene'],
  ['inspect', '☝ Editar item'], ['passage', '⇥ Passagem'],
];
const COR_ESPECIE = { crawler: '#d95763', flyer: '#e6a23c', leaper: '#b57edc', armored: '#6f8fa8', boss: '#ff3030' };
const NOME_ESPECIE = { crawler: 'Rastejante', flyer: 'Esporo (voa)', leaper: 'Saltador', armored: 'Couraçado', boss: 'Chefe' };
const COR_OUTROS = { echo: '#9ad1ff', vida: '#ff7fa8', encaixe: '#7fe8ff', mutation: '#ffd24a', cura: '#8dffb0', ferida: '#ff9a7a', paredeFragil: '#c8a27a', npc: '#f1c3c0' };

export function createEditor({ game, config, logger, renderer, canvas, catalog, roomIds = [], fetchJson = null, drafts = null, servidor = null, doc = document, win = (typeof window !== 'undefined' ? window : null) }) {
  const h = (tag, props = {}, ...filhos) => {
    const el = doc.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') el.className = v; else if (k === 'text') el.textContent = v; else if (k === 'ed') el.dataset.ed = v; else el[k] = v;
    }
    for (const f of filhos) if (f) el.appendChild(f);
    return el;
  };
  const botao = (texto, ed, fn, titulo = '') => { const b = h('button', { text: texto, type: 'button', class: 'ed-btn', ed, title: titulo }); b.addEventListener('click', fn); return b; };
  const secao = (titulo, aberta) => { const corpo = h('div', { class: 'ed-body' }); const det = h('details', {}, h('summary', { text: titulo }), corpo); det.open = !!aberta; return { det, corpo }; };
  const caixa = (texto, ed, valor, aoMudar) => {
    const i = h('input', { type: 'checkbox', ed }); i.checked = !!valor; i.addEventListener('change', () => aoMudar(i.checked));
    return { label: h('label', { class: 'ed-check' }, i, h('span', { text: texto })), input: i };
  };
  const campo = (tipo, ed, valor = '') => h('input', { type: tipo, ed, class: 'ed-input', value: String(valor) });

  let model = null; let aberto = false; let testando = false;
  let view = { x: 0, y: 0, zoom: 2 };
  let avisouRascunho = false; let hover = null; let modoColar = false; let espaco = false; let bloqueado = false;
  let grade = false; let colisoes = false; let ultimaExportacao = ''; let timerRascunho = null;
  const camadaVisivel = Object.fromEntries(LAYER_NAMES.map((n) => [n, true]));
  const ponteiros = new Map(); let pinca = null; let acao = null;
  const W = () => config.render.internalWidth; const H = () => config.render.internalHeight;
  const todosIds = () => [...new Set([...roomIds, ...(drafts ? drafts.list() : [])])];

  const painel = h('aside', { id: 'editor-panel', class: 'hidden' });
  const cab = h('div', { class: 'ed-head' }, h('b', { text: 'EDITOR DE MAPAS' }));
  const bSalvarPc = botao('💾', 'salvar-servidor', () => salvarNoServidor(), 'Salvar no computador'); bSalvarPc.classList.add('hidden');
  const verificarServidor = () => { if (!servidor || !servidor.ping) return; Promise.resolve().then(() => servidor.ping()).then((ok) => bSalvarPc.classList.toggle('hidden', !ok)).catch(() => bSalvarPc.classList.add('hidden')); };
  cab.append(bSalvarPc, botao('▶ Testar', 'testar', () => testar()), botao('✕', 'fechar', () => api.close()));
  painel.appendChild(cab);
  const msgBox = h('div', { class: 'ed-msgs', ed: 'mensagens' });
  const status = h('div', { class: 'ed-status', ed: 'status' });
  const gamepadHelp = h('div', { class: 'ed-gamepad-help', text: 'GAMEPAD · Analógico esquerdo/D-pad: cursor · A: desenhar · B: apagar/cancelar · X: conta-gotas · Y: ferramenta · LB/RB: tile · LT/RT: zoom · L3: grade · R3: camada · Start: testar · Back: sair' });
  painel.append(status, gamepadHelp, msgBox);
  const dizer = (linhas, tipo = 'info') => {
    msgBox.replaceChildren(...[].concat(linhas).slice(0, 8).map((t) => h('div', { class: `ed-msg ${tipo}`, text: t })));
    if (tipo === 'erro') logger.warn('interface', `Editor: ${[].concat(linhas)[0]}`);
  };

  const sala = secao('Sala', false);
  const selSala = h('select', { class: 'ed-input', ed: 'sala-select' });
  selSala.addEventListener('change', () => trocarSala(selSala.value));
  const idIn = campo('text', 'meta-id'); const nomeIn = campo('text', 'meta-nome');
  const bioma = h('select', { class: 'ed-input', ed: 'meta-bioma' }); for (const b of BIOME_IDS) bioma.appendChild(h('option', { value: b, text: b }));
  idIn.addEventListener('change', () => { const r = model.setMeta({ id: idIn.value.trim() }); if (!r.ok) { dizer(r.errors, 'erro'); idIn.value = model.meta.id; } else refreshSalas(); });
  nomeIn.addEventListener('change', () => { const r = model.setMeta({ name: nomeIn.value }); if (!r.ok) { dizer(r.errors, 'erro'); nomeIn.value = model.meta.name; } });
  bioma.addEventListener('change', () => model.setMeta({ biome: bioma.value }));
  const larg = campo('number', 'tam-w'); const alt = campo('number', 'tam-h');
  const formNova = h('div', { class: 'ed-form hidden', ed: 'form-nova' });
  const nId = campo('text', 'nova-id', 'sala_nova'); const nNome = campo('text', 'nova-nome', 'Sala nova'); const nW = campo('number', 'nova-w', 40); const nH = campo('number', 'nova-h', 24);
  formNova.append(h('div', { class: 'ed-sub', text: 'Nova sala' }), nId, nNome, h('div', { class: 'ed-row' }, nW, nH),
    botao('Criar', 'nova-criar', () => criarSala()), botao('Cancelar', 'nova-cancelar', () => formNova.classList.add('hidden')));
  const formImp = h('div', { class: 'ed-form hidden', ed: 'form-importar' });
  const area = h('textarea', { class: 'ed-input ed-area', ed: 'importar-texto', placeholder: 'Cole aqui o JSON' }); area.setAttribute('rows', '5');
  const arquivo = h('input', { type: 'file', ed: 'importar-arquivo', accept: '.json' });
  arquivo.addEventListener('change', async () => {   // abrir um arquivo .json de sala: lê e já carrega
    const f = arquivo.files && arquivo.files[0]; if (!f) return;
    const r = await lerArquivo(f); arquivo.value = '';   // limpar permite escolher o mesmo arquivo de novo
    if (!r.ok) { dizer(`Erro ao abrir o arquivo: ${r.error}`, 'erro'); return; }
    area.value = r.texto; importar(r.texto);
  });
  formImp.append(h('div', { class: 'ed-sub', text: 'Importar sala' }), arquivo, area,
    botao('Carregar', 'importar-carregar', () => importar(area.value)), botao('Fechar', 'importar-fechar', () => formImp.classList.add('hidden')));
  sala.corpo.append(selSala,
    h('div', { class: 'ed-row wrap' }, botao('Nova', 'sala-nova', () => formNova.classList.toggle('hidden')), botao('Duplicar', 'sala-duplicar', () => duplicar()),
      botao('📂 Abrir arquivo', 'sala-abrir', () => arquivo.click()), botao('💾 Salvar arquivo', 'sala-exportar', () => exportar()), botao('Colar texto', 'sala-importar', () => formImp.classList.toggle('hidden')), botao('Copiar texto', 'sala-copiar', () => copiarTexto()), botao('Validar', 'sala-validar', () => validar())),
    formNova, formImp,
    h('div', { class: 'ed-sub', text: 'Identificação' }), idIn, nomeIn, bioma,
    h('div', { class: 'ed-sub', text: 'Tamanho (tiles)' }),
    h('div', { class: 'ed-row' }, larg, alt, botao('Aplicar', 'tam-aplicar', () => aplicarTamanho())));
  painel.appendChild(sala.det);

  // --- Secção dedicada às Portas e Destinos Manuais ---
  const secPortas = secao('Portas manuais (🚪 entidade door)', false);
  const listaPortasDiv = h('div', { class: 'ed-portas-list' });
  secPortas.corpo.append(listaPortasDiv);
  painel.appendChild(secPortas.det);

  const fer = secao('Ferramentas', true);
  const botoesFerr = {};
  const gradeF = h('div', { class: 'ed-grid4' });
  for (const [id, rotulo] of FERRAMENTAS) { botoesFerr[id] = botao(rotulo, `ferr-${id}`, () => { model.tool = id; modoColar = false; refreshUi(); }); gradeF.appendChild(botoesFerr[id]); }
  const botoesPincel = {};
  const linhaPincel = h('div', { class: 'ed-row' }, h('span', { text: 'Pincel:' }));
  for (const n of [1, 2, 3]) { botoesPincel[n] = botao(`${n}×${n}`, `pincel-${n}`, () => { model.brushSize = n; refreshUi(); }); linhaPincel.appendChild(botoesPincel[n]); }
  const bDesfazer = botao('↶ Desfazer', 'desfazer', () => { model.undo(); }); const bRefazer = botao('↷ Refazer', 'refazer', () => { model.redo(); });
  const todasCam = caixa('todas as camadas', 'todas-camadas', false, (v) => { model.copyAllLayers = v; });
  const bColar = botao('Colar', 'colar', () => iniciarColagem());
  const sGrade = caixa('Grade (opcional)', 'grade', false, (v) => { grade = v; game.debug.editorGrid = v; }); const sColisao = caixa('Ver colisões', 'colisoes', false, (v) => { colisoes = v; });
  // Gene a colocar (ferramenta 🧬): os 15 espaços do catálogo; os reservados avisam na validação
  const selGene = h('select', { class: 'ed-input', 'data-testid': 'gene-selecionado', title: 'Qual gene a ferramenta 🧬 Gene coloca' });
  for (const g of GENES) selGene.appendChild(h('option', { value: g.id, text: `${String(g.slot).padStart(2, '0')} · ${g.implementado ? g.nome : '(reservado)'}` }));
  selGene.addEventListener('change', () => { model.geneSelecionado = selGene.value; });
  const linhaGene = h('div', { class: 'ed-row' }, h('span', { text: 'Gene:' }), selGene);
  fer.corpo.append(gradeF, linhaGene, linhaPincel, h('div', { class: 'ed-row' }, bDesfazer, bRefazer),
    h('div', { class: 'ed-row wrap' }, botao('Copiar', 'copiar', () => { dizer(model.copy() ? 'Copiado.' : 'Selecione uma área.'); }),
      botao('Recortar', 'recortar', () => { if (!model.cut()) dizer('Selecione uma área.'); }), bColar,
      botao('Apagar sel.', 'apagar-selecao', () => { model.deleteSelection(); }),
      botao('Limpar sel.', 'limpar-selecao', () => { model.clearSelection(); modoColar = false; refreshUi(); })),
    todasCam.label,
    h('div', { class: 'ed-row' }, botao('Zoom −', 'zoom-menos', () => mudarZoom(-1)), botao('Zoom +', 'zoom-mais', () => mudarZoom(1)), botao('Ajustar', 'zoom-ajustar', () => { view = fitView(model.map.pixelWidth, model.map.pixelHeight, W(), H()); })),
    h('div', { class: 'ed-row' }, sGrade.label, sColisao.label));
  painel.appendChild(fer.det);

  // --- Selecionado / Inimigos / Passagens / JSON avançado ---
  const secSel = secao('Selecionado (inimigo, item ou passagem)', true); painel.appendChild(secSel.det);
  const secInim = secao('Inimigos da sala', false); painel.appendChild(secInim.det);
  const secPass = secao('Passagens = portas do jogo', false); painel.appendChild(secPass.det);
  const secJson = secao('JSON avançado', false); painel.appendChild(secJson.det);

  const cam = secao('Camadas', true); const botoesCamada = {};
  for (const nome of LAYER_NAMES) {
    const b = botao(NOMES_CAMADAS[nome], `camada-${nome}`, () => { model.layer = nome; refreshUi(); });
    const olho = caixa('', `camada-visivel-${nome}`, true, (v) => { camadaVisivel[nome] = v; });
    botoesCamada[nome] = b; cam.corpo.appendChild(h('div', { class: 'ed-row' }, b, olho.label));
  }
  painel.appendChild(cam.det);

  // --- v1.38 Profundidade 2.5D: configura volume dos tiles e parallax SEM refazer a sala (só grava o bloco `depth`; mapa e colisões intactos) ---
  const dp = secao('Profundidade 2.5D (visual)', false); let dpJson = '';
  const dpCorpo = h('div', { class: 'ed-depth' }); dp.corpo.appendChild(dpCorpo);
  const dpAtual = () => (model.depth ? JSON.parse(JSON.stringify(model.depth)) : null);
  const dpMudar = (fn) => { const d = dpAtual() || presetSoVolume(); fn(d); const r = model.setDepth(d); if (!r.ok) dizer(r.errors[0], 'erro'); refreshDepth(); };
  const dpNum = (ed, valor, min, max, passo, aoMudar) => { const i = h('input', { type: 'number', ed, class: 'ed-input', value: String(valor) }); Object.assign(i, { min, max, step: passo }); i.addEventListener('change', () => aoMudar(Number(i.value))); return i; };
  function refreshDepth() {
    const d = model ? model.depth : null; const json = JSON.stringify(d); if (json === dpJson) return; dpJson = json;
    dpCorpo.textContent = '';
    const linha = (...f) => h('div', { class: 'ed-row wrap' }, ...f);
    dpCorpo.appendChild(linha(botao('Preset Raízes', 'depth-preset-raizes', () => { model.setDepth(PRESETS_DEPTH.raizes()); refreshDepth(); }, 'Volume + parallax em 3 planos (fundo, meio, frente)'),
      botao('Só volume', 'depth-so-volume', () => { model.setDepth(presetSoVolume()); refreshDepth(); }, 'Relevo nos tiles sem mexer no fundo'),
      botao('Remover', 'depth-remover', () => { model.setDepth(null); refreshDepth(); }, 'Volta ao visual original da sala')));
    if (!d) { dpCorpo.appendChild(h('div', { class: 'ed-msg', text: 'Sala sem 2.5D: visual original. Escolha um preset para ativar.' })); return; }
    const v = d.volume || {}; const p = d.parallax || { camadas: [] };
    dpCorpo.appendChild(h('div', { class: 'ed-sub', text: 'Tiles volumétricos' }));
    dpCorpo.appendChild(linha(caixa('Volume', 'depth-volume-ativo', v.ativo !== false, (x) => dpMudar((q) => { q.volume = { ...(q.volume || {}), ativo: x }; })).label,
      caixa('Sombra projetada', 'depth-volume-sombra', v.sombra !== false, (x) => dpMudar((q) => { q.volume = { ...(q.volume || {}), sombra: x }; })).label));
    dpCorpo.appendChild(linha(h('span', { text: 'Força' }), dpNum('depth-volume-forca', v.forca ?? 1, 0, 1.5, 0.1, (x) => dpMudar((q) => { q.volume = { ...(q.volume || {}), forca: x }; })),
      h('span', { text: 'Espessura' }), dpNum('depth-volume-espessura', v.espessura ?? 2, 0, 3, 1, (x) => dpMudar((q) => { q.volume = { ...(q.volume || {}), espessura: x }; }))));
    dpCorpo.appendChild(h('div', { class: 'ed-sub', text: 'Parallax (visto no teste/jogo; o editor mostra o mapa cru)' }));
    dpCorpo.appendChild(linha(caixa('Parallax', 'depth-parallax-ativo', p.ativo !== false && (p.camadas || []).length > 0, (x) => dpMudar((q) => { q.parallax = { ...(q.parallax || { camadas: [] }), ativo: x }; })).label,
      caixa('Substitui fundo de tiles', 'depth-parallax-substitui', p.substituiFundo !== false, (x) => dpMudar((q) => { q.parallax = { ...(q.parallax || { camadas: [] }), substituiFundo: x }; })).label));
    (p.camadas || []).forEach((c, i) => {
      const sel = (ed, lista, atual, campoNome) => { const e = h('select', { class: 'ed-input', ed }); for (const o of lista) e.appendChild(h('option', { value: o, text: o })); e.value = atual; e.addEventListener('change', () => dpMudar((q) => { q.parallax.camadas[i][campoNome] = e.value; })); return e; };
      const num = (campoNome, min, max, passo) => dpNum(`depth-cam${i}-${campoNome}`, c[campoNome] ?? 0, min, max, passo, (x) => dpMudar((q) => { q.parallax.camadas[i][campoNome] = x; }));
      dpCorpo.appendChild(h('div', { class: 'ed-sub', text: `${i + 1}. ${c.id || 'camada'}` }));
      dpCorpo.appendChild(linha(sel(`depth-cam${i}-plano`, PLANOS_DEPTH, c.plano || 'fundo', 'plano'), sel(`depth-cam${i}-motivo`, MOTIVOS_DEPTH, c.motivo || 'troncos', 'motivo'),
        botao('✕', `depth-cam${i}-remover`, () => dpMudar((q) => { q.parallax.camadas.splice(i, 1); }), 'Remover camada')));
      dpCorpo.appendChild(linha(h('span', { text: 'vx' }), num('vx', 0, 2, 0.05), h('span', { text: 'vy' }), num('vy', 0, 2, 0.05), h('span', { text: 'alfa' }), num('alfa', 0, 1, 0.05), h('span', { text: 'névoa' }), num('nevoa', 0, 1, 0.05)));
    });
    dpCorpo.appendChild(botao('+ camada', 'depth-cam-nova', () => dpMudar((q) => {
      q.parallax = q.parallax || { ativo: true, substituiFundo: true, camadas: [] }; q.parallax.camadas = q.parallax.camadas || [];
      if (q.parallax.camadas.length >= MAX_CAMADAS_DEPTH) { dizer(`No máximo ${MAX_CAMADAS_DEPTH} camadas (desempenho no celular).`, 'aviso'); return; }
      q.parallax.camadas.push({ id: `camada${q.parallax.camadas.length + 1}`, plano: 'meio', motivo: 'raizes', vx: 0.5, vy: 0.3, alfa: 0.8, nevoa: 0.2, densidade: 1, semente: 100 + q.parallax.camadas.length });
      q.parallax.ativo = true;
    })));
  }
  painel.appendChild(dp.det);

  const pal = secao('Paleta de tiles', true); const botoesTile = {}; const gradeP = h('div', { class: 'ed-palette' });
  const buscaTiles = h('input', { type: 'search', class: 'ed-input', ed: 'buscar-tiles', placeholder: 'Buscar tile por nome ou ID…' });
  const filtroCategoria = h('select', { class: 'ed-input', ed: 'filtro-categoria' });
  filtroCategoria.append(h('option', { value: '', text: 'Todas as categorias' }));
  const categoriasTiles = [...new Set(catalog.all().map((t) => t.category))].sort();
  for (const cat of categoriasTiles) filtroCategoria.append(h('option', { value: cat, text: cat }));
  const filtroBioma = h('select', { class: 'ed-input', ed: 'filtro-bioma' });
  for (const [value, label] of [['', 'Todos os biomas'], ['raizes', 'Raízes'], ['jardim', 'Jardim'], ['nucleo', 'Núcleo']]) filtroBioma.append(h('option', { value, text: label }));
  const todosBotoesTiles = [];
  for (const t of catalog.all()) {
    const c = h('canvas', {}); c.width = 24; c.height = 24;
    const cx = c.getContext('2d'); if (cx) cx.imageSmoothingEnabled = false;
    renderer.graphics?.draw(cx, t.id, t.autotile ? previewVariant(t.autotile.mode) : 0, 0, 0, 24);
    const legenda = h('span', { class: 'ed-tile-label', text: `${t.id} · ${t.name}` });
    const b = h('button', { type: 'button', class: 'ed-tile', ed: `tile-${t.id}`, title: `${t.id} · ${t.name} · ${t.category} · ${t.biome}` }, c, legenda);
    b.addEventListener('click', () => { model.tileId = t.id; if (!['pencil', 'fill'].includes(model.tool)) model.tool = 'pencil'; refreshUi(); });
    botoesTile[t.id] = b; todosBotoesTiles.push({ tile: t, button: b });
  }
  const filtrarPaleta = () => {
    const q = buscaTiles.value.trim().toLocaleLowerCase('pt-BR');
    const cat = filtroCategoria.value; const bio = filtroBioma.value;
    const visiveis = todosBotoesTiles.filter(({ tile }) => {
      const texto = `${tile.id} ${tile.name} ${tile.category} ${tile.biome}`.toLocaleLowerCase('pt-BR');
      return (!q || texto.includes(q)) && (!cat || tile.category === cat) && (!bio || tile.biome === bio || tile.biome === 'todos');
    });
    gradeP.replaceChildren(...visiveis.map((item) => item.button));
    contadorTiles.textContent = `${visiveis.length} de ${todosBotoesTiles.length} tiles`;
  };
  const contadorTiles = h('div', { class: 'ed-sub', text: `${todosBotoesTiles.length} tiles disponíveis` });
  buscaTiles.addEventListener('input', filtrarPaleta); filtroCategoria.addEventListener('change', filtrarPaleta); filtroBioma.addEventListener('change', filtrarPaleta);
  pal.corpo.append(buscaTiles, filtroCategoria, filtroBioma, contadorTiles, gradeP); filtrarPaleta(); painel.appendChild(pal.det);
  doc.body.appendChild(painel);
  function refreshSalas() {
    const atual = model ? model.meta.id : '';
    const opcoes = [h('option', { value: 'atual', text: `${atual} (editando)` })];
    for (const id of roomIds) opcoes.push(h('option', { value: `file:${id}`, text: `${id} (arquivo)` }));
    if (drafts) for (const id of drafts.list()) opcoes.push(h('option', { value: `draft:${id}`, text: `${id} (rascunho)` }));
    selSala.replaceChildren(...opcoes); selSala.value = 'atual';
  }

  /** Portas (entidades "door") de uma sala: a que está sendo editada, uma do mundo carregado ou um rascunho. */
  function portasDaSala(rid) {
    let ents = null;
    if (rid === model.meta.id) ents = model.entities;
    else if (game.world && game.world.has(rid)) ents = game.world.get(rid).entities;
    else if (drafts) { try { ents = JSON.parse(drafts.load(rid)).entities; } catch (e) { ents = null; } }
    return (ents || []).filter((e) => e.type === 'door' && typeof e.id === 'string');
  }

  function refreshPortas() {
    if (!model) return;
    const doors = model.doors || [];
    if (doors.length === 0) {
      listaPortasDiv.replaceChildren(h('div', { class: 'ed-msg info', text: 'Nenhuma porta colocada. Use a ferramenta 🚪 Porta no mapa.' }));
      return;
    }

    const elementos = doors.map((d) => {
      const card = h('div', { class: 'ed-door-card', style: 'margin-bottom: 8px; padding: 6px; background: rgba(0,255,200,0.08); border: 1px solid rgba(0,255,200,0.3); border-radius: 4px;' });
      const titulo = h('div', { style: 'font-weight: bold; margin-bottom: 4px;', text: `🚪 ${d.id} (x:${d.x}, y:${d.y})` });

      // Seleção da Sala de Destino (targetRoom)
      const lblSala = h('label', { class: 'ed-sub', text: 'Sala de Destino (targetRoom):' });
      const selSalaDest = h('select', { class: 'ed-input' });
      selSalaDest.appendChild(h('option', { value: '', text: '-- Selecione a sala --' }));
      for (const rid of todosIds()) {
        const opt = h('option', { value: rid, text: rid });
        if (d.targetRoom === rid) opt.selected = true;
        selSalaDest.appendChild(opt);
      }
      selSalaDest.addEventListener('change', () => {
        model.updateDoor(d.id, { targetRoom: selSalaDest.value });
      });

      // Porta de destino: lista com as portas que existem na sala escolhida (sem digitar IDs)
      const lblPorta = h('label', { class: 'ed-sub', text: 'Porta de destino (nessa sala):' });
      const selPortaDest = h('select', { class: 'ed-input' });
      const destinos = d.targetRoom ? portasDaSala(d.targetRoom) : [];
      selPortaDest.appendChild(h('option', { value: '', text: d.targetRoom ? '-- Início da sala (automático) --' : '-- Escolha a sala primeiro --' }));
      for (const pd of destinos) {
        const opt = h('option', { value: pd.id, text: `${pd.id} (x:${pd.x}, y:${pd.y})` });
        if (d.targetDoor === pd.id) opt.selected = true;
        selPortaDest.appendChild(opt);
      }
      if (d.targetDoor && !destinos.some((pd) => pd.id === d.targetDoor)) {
        const opt = h('option', { value: d.targetDoor, text: `${d.targetDoor} (não encontrada)` }); opt.selected = true; selPortaDest.appendChild(opt);
      }
      selPortaDest.addEventListener('change', () => { model.updateDoor(d.id, { targetDoor: selPortaDest.value }); });
      const estado = !d.targetRoom ? '⚠ Sem destino: esta porta ainda não leva a lugar nenhum.'
        : (d.targetDoor && !destinos.some((pd) => pd.id === d.targetDoor)) ? '⚠ A porta de destino não existe nessa sala.'
        : `✔ Leva para "${d.targetRoom}"${d.targetDoor ? ` · porta ${d.targetDoor}` : ' · início da sala'}`;
      const lblEstado = h('div', { class: 'ed-sub', text: estado });
      const inpPortaDest = lblEstado;

      card.append(titulo, lblSala, selSalaDest, lblPorta, selPortaDest, inpPortaDest);
      return card;
    });

    listaPortasDiv.replaceChildren(...elementos);
  }

  // ================= Painéis de edição: item selecionado, inimigos, passagens, JSON =================
  const idsConhecidos = () => [...new Set([...todosIds(), model.meta.id])];
  const extraValidacao = () => ({ knownRoomIds: idsConhecidos() });
  const rotulado = (rotulo, el) => h('label', { class: 'ed-field' }, h('span', { text: rotulo }), el);
  const entradaTexto = (ed, valor, aoMudar, ph = '') => { const i = campo('text', ed, valor ?? ''); i.placeholder = ph; i.addEventListener('change', () => aoMudar(i.value.trim())); return i; };
  const entradaNum = (ed, valor, aoMudar, ph = '', passo = '1') => { const i = campo('number', ed, valor ?? ''); i.placeholder = ph; i.step = passo; i.addEventListener('change', () => aoMudar(i.value.trim() === '' ? undefined : Number(i.value))); return i; };
  const selecao = (ed, opcoes, atual, aoMudar) => {
    const sl = h('select', { class: 'ed-input', ed });
    for (const [v, t] of opcoes) sl.appendChild(h('option', { value: v, text: t }));
    if (!opcoes.some(([v]) => v === atual)) sl.appendChild(h('option', { value: atual, text: `${atual} (não existe)` }));
    sl.value = atual; sl.addEventListener('change', () => aoMudar(sl.value)); return sl;
  };
  const listaJson = (arr) => (arr.length ? `[\n${arr.map((e) => `  ${JSON.stringify(e)}`).join(',\n')}\n]` : '[]');
  const resultado = (res, okMsg = null) => {
    if (!res.ok) { dizer(res.errors, 'erro'); erroPainel = res.errors.slice(0, 4); ultimaSig = ''; refreshPaineis(); return false; }
    if (okMsg) dizer([okMsg, ...(res.warnings || []).map((w) => `Aviso: ${w}`)], res.warnings && res.warnings.length ? 'aviso' : 'ok');
    return true;
  };
  let jsonItemAberto = false; let erroPainel = null;
  function blocoJson(titulo, objeto, aoAplicar, ed) {
    const det = h('details', { class: 'ed-json' }, h('summary', { text: titulo }));
    const ta = h('textarea', { class: 'ed-input ed-area', ed }); ta.value = JSON.stringify(objeto, null, 2); ta.setAttribute('rows', '9'); ta.spellcheck = false;
    det.append(ta, h('div', { class: 'ed-row wrap' }, botao('✔ Aplicar JSON', `${ed}-aplicar`, () => aoAplicar(ta.value)), botao('↺ Restaurar', `${ed}-restaurar`, () => { ta.value = JSON.stringify(objeto, null, 2); })));
    det.open = jsonItemAberto; det.addEventListener('toggle', () => { jsonItemAberto = det.open; });
    return det;
  }
  function passagensDaSala(rid) {
    let cs = null;
    if (rid === model.meta.id) cs = model.connections;
    else if (game.world && game.world.has(rid)) cs = game.world.get(rid).connections;
    else if (drafts) { try { cs = JSON.parse(drafts.load(rid)).connections; } catch (e) { cs = null; } }
    return cs || [];
  }
  const problemasDe = (erros, ...chaves) => erros.filter((m) => chaves.some((k) => m.includes(k)));
  const caixaProblemas = (lista, avisos = []) => h('div', { class: 'ed-probs' }, ...lista.map((t) => h('div', { class: 'ed-msg erro', text: `⚠ ${t}` })), ...avisos.map((t) => h('div', { class: 'ed-msg aviso', text: `⚠ ${t}` })));
  const irPara = (x, y) => { hover = { tx: x, ty: y }; api.centerOn(x, y); };

  function cartaoEntidade(idx, erros) {
    const e = model.entities[idx]; const card = h('div', { class: 'ed-card' });
    const ehInimigo = e.type === 'enemy';
    card.appendChild(h('div', { class: 'ed-card-title', text: `${ehInimigo ? '👾' : '◆'} ${e.type}${e.id ? ` · ${e.id}` : ''}  (${e.x},${e.y})` }));
    const aplicar = (patch) => resultado(model.updateEntity(idx, patch));
    const campos = h('div', { class: 'ed-two' });
    campos.append(rotulado('id', entradaTexto('sel-id', e.id, (v) => aplicar({ id: v }), ehInimigo ? '(sem id)' : '')));
    if (ehInimigo) {
      campos.append(rotulado('espécie', selecao('sel-kind', KNOWN_ENEMY_KINDS.map((k) => [k, NOME_ESPECIE[k] || k]), e.kind || 'crawler', (v) => aplicar({ kind: v }))));
      campos.append(rotulado('nome', entradaTexto('sel-name', e.name, (v) => aplicar({ name: v }), e.kind === 'boss' ? 'obrigatório p/ chefe' : 'padrão da espécie')));
      campos.append(rotulado('vida', entradaNum('sel-life', e.life, (v) => aplicar({ life: v }), `padrão ${ENEMY_DEFAULTS.life}`)));
      campos.append(rotulado('velocidade', entradaNum('sel-speed', e.speed, (v) => aplicar({ speed: v }), `padrão ${ENEMY_DEFAULTS.speed}`, 'any')));
      campos.append(rotulado('dano', entradaNum('sel-damage', e.damage, (v) => aplicar({ damage: v }), `padrão ${ENEMY_DEFAULTS.damage}`)));
    }
    campos.append(rotulado('x (tile)', entradaNum('sel-x', e.x, (v) => aplicar({ x: v }))), rotulado('y (tile)', entradaNum('sel-y', e.y, (v) => aplicar({ y: v }))));
    card.appendChild(campos);
    if (typeof e.text === 'string') { const t = h('textarea', { class: 'ed-input', ed: 'sel-text' }); t.value = e.text; t.setAttribute('rows', '3'); t.addEventListener('change', () => aplicar({ text: t.value })); card.appendChild(rotulado('texto', t)); }
    const prob = problemasDe(erros, e.id ? `"${e.id}"` : `Entidade ${idx} (`);
    if (prob.length) card.appendChild(caixaProblemas(prob));
    card.appendChild(h('div', { class: 'ed-row wrap' }, botao('🔍 Ir até', 'sel-ir', () => irPara(e.x, e.y)),
      botao('🗑 Remover', 'sel-remover', () => { if (resultado(model.removeEntity(idx))) dizer('Item removido.', 'ok'); })));
    card.appendChild(blocoJson('{ } JSON deste item (campos extras, mudar tipo…)', e, (texto) => { if (resultado(model.replaceEntityJson(idx, texto, extraValidacao()), 'Item atualizado ✔')) { /* reconstruído pelo modelo */ } }, 'sel-json'));
    return card;
  }

  function cartaoPassagem(c, erros) {
    const card = h('div', { class: 'ed-card ed-card-pass' }); const t = c.trigger || { x: 0, y: 0, w: 1, h: 1 };
    card.appendChild(h('div', { class: 'ed-card-title', text: `⇥ ${c.id} → ${c.to || '?'}  (${t.x},${t.y} ${t.w}×${t.h})` }));
    const aplicar = (patch) => resultado(model.updateConnection(c.id, patch));
    const salas = todosIds().map((r) => [r, r]); salas.unshift(['', '— escolha a sala —']);
    const destinos = c.to ? passagensDaSala(c.to) : [];
    const portas = [['', c.to ? '— escolha a passagem —' : '— escolha a sala primeiro —'], ...destinos.map((d) => [d.id, d.id])];
    const campos = h('div', { class: 'ed-two' });
    campos.append(rotulado('id', entradaTexto('sel-id', c.id, (v) => aplicar({ id: v }))));
    campos.append(rotulado('exige habilidade', selecao('sel-requires', [['', '(livre)'], ...ABILITY_IDS.map((a) => [a, ABILITIES[a].nome])], c.requires || '', (v) => aplicar({ requires: v || null }))));
    campos.append(rotulado('exige gene equipado', selecao('sel-requer-gene', [['', '(livre)'], ...GENES.filter((g) => g.implementado).map((g) => [g.id, g.nome])], (Array.isArray(c.requerGene) ? c.requerGene[0] : c.requerGene) || '', (v) => aplicar({ requerGene: v || null }))));
    card.appendChild(campos);
    card.appendChild(rotulado('sala de destino', selecao('sel-to', salas, c.to || '', (v) => aplicar({ to: v, toConnection: '' }))));
    card.appendChild(rotulado('passagem de chegada (na sala de destino)', selecao('sel-toconn', portas, c.toConnection || '', (v) => aplicar({ toConnection: v }))));
    card.appendChild(h('div', { class: 'ed-sub', text: 'Gatilho (em tiles)' }));
    const g = h('div', { class: 'ed-four' });
    for (const k of ['x', 'y', 'w', 'h']) g.append(rotulado(k, entradaNum(`sel-t${k}`, t[k], (v) => aplicar({ trigger: { [k]: v } }))));
    card.appendChild(g);
    const temSpawn = !!c.spawn; const sp = c.spawn || { x: 1, y: 1 };
    const cx = caixa('ponto de chegada fixo (spawn) na sala de destino', 'sel-spawn-on', temSpawn, (v) => aplicar({ spawn: v ? { x: sp.x, y: sp.y } : null }));
    card.appendChild(cx.label);
    if (temSpawn) { const gs = h('div', { class: 'ed-two' }); gs.append(rotulado('spawn x', entradaNum('sel-spx', sp.x, (v) => aplicar({ spawn: { x: v, y: sp.y } }))), rotulado('spawn y', entradaNum('sel-spy', sp.y, (v) => aplicar({ spawn: { x: sp.x, y: v } })))); card.appendChild(gs); }
    const avisos = [];
    if (c.to && c.toConnection && destinos.length && !destinos.some((d) => d.id === c.toConnection)) avisos.push(`"${c.to}" não tem a passagem "${c.toConnection}".`);
    const par = destinos.find((d) => d.id === c.toConnection);
    if (par && par.to !== model.meta.id) avisos.push(`A volta ("${par.id}") aponta para "${par.to}", não para esta sala.`);
    const prob = problemasDe(erros, `"${c.id}"`);
    if (prob.length || avisos.length) card.appendChild(caixaProblemas(prob, avisos));
    card.appendChild(h('div', { class: 'ed-row wrap' }, botao('🔍 Ir até', 'sel-ir', () => irPara(t.x, t.y)),
      botao('🗑 Remover', 'sel-remover', () => { if (resultado(model.removeConnection(c.id))) dizer('Passagem removida.', 'ok'); })));
    card.appendChild(blocoJson('{ } JSON desta passagem', c, (texto) => { resultado(model.replaceConnectionJson(c.id, texto, extraValidacao()), 'Passagem atualizada ✔'); }, 'sel-json'));
    return card;
  }

  let ultimaSig = ''; let timerPaineis = null; let jsonSujo = false;
  const sigAtual = () => JSON.stringify([model.meta.id, model.entities, model.connections, model.sel, todosIds()]);

  const selJson = h('select', { class: 'ed-input', ed: 'json-alvo' });
  selJson.append(h('option', { value: 'entidades', text: 'Entidades (inimigos, itens, início…)' }), h('option', { value: 'passagens', text: 'Passagens (portas do jogo)' }));
  const taJson = h('textarea', { class: 'ed-input ed-area ed-area-grande', ed: 'json-area' }); taJson.setAttribute('rows', '12'); taJson.spellcheck = false;
  function carregarJson() { if (!model) return; taJson.value = listaJson(selJson.value === 'entidades' ? model.entities : model.connections); jsonSujo = false; }
  selJson.addEventListener('change', carregarJson); taJson.addEventListener('input', () => { jsonSujo = true; });
  secJson.corpo.append(h('div', { class: 'ed-sub', text: 'Edite o texto e aplique: só entra se não criar erro novo na sala. Dá para desfazer (↶).' }), selJson, taJson,
    h('div', { class: 'ed-row wrap' },
      botao('✔ Aplicar', 'json-aplicar', () => { const r = selJson.value === 'entidades' ? model.setEntitiesJson(taJson.value, extraValidacao()) : model.setConnectionsJson(taJson.value, extraValidacao()); if (resultado(r, 'JSON aplicado ✔')) carregarJson(); }),
      botao('↺ Recarregar', 'json-recarregar', () => carregarJson())));

  function reconstruirPaineis(restaurarFoco) {
    if (!model) return;
    const ativo = restaurarFoco ? doc.activeElement : null;
    const chave = ativo && ativo.dataset ? ativo.dataset.ed : null; const ini = ativo ? ativo.selectionStart : null; const fim = ativo ? ativo.selectionEnd : null;
    ultimaSig = sigAtual();
    const erros = model.validate({ knownRoomIds: idsConhecidos() }).errors;
    // Selecionado
    const es = model.entidadeSel; const ps = model.passagemSel;
    if (es) corpoSelecionado(cartaoEntidade(model.sel.index, erros));
    else if (ps) corpoSelecionado(cartaoPassagem(ps, erros));
    else secSel.corpo.replaceChildren(h('div', { class: 'ed-msg info', text: 'Nada selecionado. Use ☝ Editar item (ou a ferramenta 👾 / ⇥) e toque num inimigo, item ou passagem no mapa. Arraste para mover.' }));
    if (erroPainel) { secSel.corpo.prepend(...erroPainel.map((t) => h('div', { class: 'ed-msg erro', text: `✖ ${t}` }))); secSel.det.open = true; erroPainel = null; }
    // Inimigos
    const inims = model.entities.map((e, i) => [e, i]).filter(([e]) => e.type === 'enemy');
    secInim.corpo.replaceChildren(
      ...(inims.length ? inims.map(([e, i]) => { const b = botao(`${e.kind === 'boss' ? '👑' : '👾'} ${e.id || '(sem id)'} · ${e.kind || 'crawler'} (${e.x},${e.y})`, `inim-${i}`, () => { model.selecionarEntidade(i); irPara(e.x, e.y); }); if (model.sel && model.sel.tipo === 'entidade' && model.sel.index === i) b.classList.add('active'); b.classList.add('ed-listbtn'); return b; })
        : [h('div', { class: 'ed-msg info', text: 'Nenhum inimigo nesta sala.' })]),
      botao('＋ Inimigo no cursor', 'inim-novo', () => { const c = hover || { tx: 1, ty: 1 }; model.addEnemyOrSelect(c.tx, c.ty); }, 'Coloca um inimigo na célula do cursor (ou seleciona o que já estiver lá)'));
    secInim.det.querySelector('summary').textContent = `Inimigos da sala (${inims.length})`;
    // Passagens
    secPass.corpo.replaceChildren(
      ...(model.connections.length ? model.connections.map((c) => { const b = botao(`⇥ ${c.id} → ${c.to || '?'}`, `pass-${c.id}`, () => { model.selecionarPassagem(c.id); if (c.trigger) irPara(c.trigger.x, c.trigger.y); }); if (model.sel && model.sel.tipo === 'passagem' && model.sel.id === c.id) b.classList.add('active'); b.classList.add('ed-listbtn'); return b; })
        : [h('div', { class: 'ed-msg info', text: 'Esta sala não tem passagens. Use ⇥ Passagem: toque na borda da sala (cria 1×3) ou arraste um retângulo.' })]),
      botao('＋ Passagem no cursor', 'pass-nova', () => { const c = hover || { tx: 0, ty: 1 }; model.addConnectionAt(c.tx, c.ty); }, 'Cria uma passagem na célula do cursor (na borda vira 1×3)'));
    secPass.det.querySelector('summary').textContent = `Passagens = portas do jogo (${model.connections.length})`;
    if (!jsonSujo) carregarJson();
    refreshPortas();
    if (chave) { const novo = painel.querySelector(`[data-ed="${chave}"]`); if (novo) { novo.focus(); try { if (ini != null) novo.setSelectionRange(ini, fim); } catch (e) { /* tipo sem seleção */ } } }
  }
  let selAnterior = '';
  function corpoSelecionado(card) {
    secSel.corpo.replaceChildren(card);
    const chave = JSON.stringify(model.sel); if (chave !== selAnterior && model.sel) { secSel.det.open = true; if (selAnterior !== chave) secSel.det.scrollIntoView?.({ block: 'nearest' }); }
    selAnterior = chave;
  }
  function refreshPaineis() {
    if (!model || sigAtual() === ultimaSig) return;
    const a = doc.activeElement;
    const digitandoNoPainel = a && a !== doc.body && painel.contains(a) && ['INPUT', 'SELECT', 'TEXTAREA'].includes(a.tagName);
    if (digitandoNoPainel && win) { if (!timerPaineis) timerPaineis = win.setTimeout(() => { timerPaineis = null; reconstruirPaineis(true); }, 0); return; }
    reconstruirPaineis(false);
  }

  function refreshUi() {
    if (!model) return;
    for (const [id, b] of Object.entries(botoesFerr)) b.classList.toggle('active', model.tool === id);
    for (const [n, b] of Object.entries(botoesPincel)) b.classList.toggle('active', model.brushSize === Number(n));
    for (const [n, b] of Object.entries(botoesCamada)) b.classList.toggle('active', model.layer === n);
    for (const [id, b] of Object.entries(botoesTile)) b.classList.toggle('active', model.tileId === Number(id));
    bDesfazer.disabled = !model.canUndo; bRefazer.disabled = !model.canRedo; bColar.classList.toggle('active', modoColar);
    if (doc.activeElement !== idIn) idIn.value = model.meta.id;
    nomeIn.value = model.meta.name; bioma.value = model.meta.biome; larg.value = String(model.map.width); alt.value = String(model.map.height);
    const t = catalog.get(model.tileId);
    const c = hover ? `${hover.tx},${hover.ty}` : '—';
    status.textContent = `${model.meta.id}${model.dirty ? ' •alterado' : ''} · ${NOMES_CAMADAS[model.layer]} · tile ${model.tileId} · célula ${c}${modoColar ? ' · COLANDO: toque para colar' : ''}`;
    refreshPaineis(); refreshDepth();
  }

  function agendarRascunho() {
    if (!drafts || !win) return;
    win.clearTimeout(timerRascunho);
    timerRascunho = win.setTimeout(salvarRascunho, 700);
  }
  function salvarRascunho() {
    if (!model || !drafts) return { ok: false };
    const r = drafts.save(model.meta.id, model.toText());
    if (!r.ok && !avisouRascunho) { avisouRascunho = true; dizer([`Rascunho automático indisponível (${r.error || 'erro'}). Use Exportar para guardar o trabalho.`], 'aviso'); }
    return r;
  }

  function aoMudarModelo(tipo) {
    if (tipo === 'load') { modoColar = false; acao = null; centralizarNoInicio(); refreshSalas(); }
    if (tipo === 'change' || tipo === 'meta') agendarRascunho();
    refreshUi();
  }

  function centralizarNoInicio() {
    const s = model.playerStart; const ts = model.map.tileSize;
    view = { zoom: 2, x: 0, y: 0 };
    const cx = s ? s.x : Math.floor(model.map.width / 2); const cy = s ? s.y : Math.floor(model.map.height / 2);
    hover = { tx: Math.max(0, Math.min(model.map.width - 1, cx)), ty: Math.max(0, Math.min(model.map.height - 1, cy)) };
    view.x = (cx + 0.5) * ts - W() / 4; view.y = (cy + 0.5) * ts - H() / 4;
    clampView(view, model.map.pixelWidth, model.map.pixelHeight, W(), H());
  }

  function validar() {
    const r = model.validate({ knownRoomIds: [...new Set([...roomIds, model.meta.id])] });
    if (r.errors.length) dizer([`${r.errors.length} erro(s):`, ...r.errors], 'erro');
    else dizer(['Sala válida ✔', ...r.warnings.map((w) => `Aviso: ${w}`)], r.warnings.length ? 'aviso' : 'ok');
    return r;
  }

  /** Salva a sala como ARQUIVO .json (seletor "Salvar como", compartilhar no iOS ou download). Devolve o texto na hora; o aviso vem quando o arquivo é gravado. */
  function exportar() {
    const r = model.validate({ knownRoomIds: [...new Set([...roomIds, model.meta.id])] });
    const texto = model.toText(); ultimaExportacao = texto;
    const avisos = r.errors.length ? ['ATENÇÃO: a sala salva tem erro(s):', ...r.errors] : [];
    salvarArquivo({ nome: `${model.meta.id}.json`, texto, win, doc }).then((res) => {
      if (res.ok) model.markSaved();
      dizer([textoDoSalvamento(res), ...(res.ok ? avisos : [])], !res.ok ? (res.cancelado ? 'info' : 'erro') : (r.errors.length ? 'aviso' : 'ok'));
    });
    return texto;
  }

  /** Cópia em texto (para colar em outro lugar): agora é um botão à parte, não mais o jeito de salvar. */
  function copiarTexto() {
    const texto = model.toText();
    Promise.resolve().then(() => win.navigator.clipboard.writeText(texto)).then(() => dizer('JSON da sala copiado como texto.', 'ok')).catch(() => dizer('O navegador não deixou copiar. Use 💾 Salvar arquivo.', 'aviso'));
    return texto;
  }

  function importar(texto) {
    const r = model.loadFromJson(texto, { knownRoomIds: roomIds });
    if (!r.ok) { dizer([`Erro na importação:`, ...r.errors], 'erro'); return false; }
    model.dirty = true; formImp.classList.add('hidden');
    dizer(`Sala "${model.meta.id}" importada.`, 'ok'); return true;
  }

  async function salvarNoServidor() {
    if (!servidor) return false;
    const r = model.validate({ knownRoomIds: [...new Set([...roomIds, model.meta.id])] });
    if (r.errors.length) { dizer(['Corrija antes de salvar:', ...r.errors], 'erro'); return false; }
    const res = await servidor.salvar(model.meta.id, model.toText());
    if (!res.ok) { dizer([`Não foi possível salvar: ${res.error}. Use Exportar para não perder o trabalho.`], 'erro'); return false; }
    model.markSaved(); if (!roomIds.includes(model.meta.id)) roomIds.push(model.meta.id); refreshSalas();
    dizer(`Salvo no computador: ${res.arquivo}`, 'ok'); return true;
  }

  function duplicar() { const novo = model.duplicate(todosIds()); dizer(`Duplicada como "${novo}".`, 'ok'); }

  function criarSala() {
    const id = nId.value.trim(); const w = Number(nW.value); const hh = Number(nH.value);
    const minW = config.render.internalWidth / catalog.tileSize; const minH = config.render.internalHeight / catalog.tileSize;
    if (![w, hh].every(Number.isInteger) || w < minW || hh < minH || w > 500 || hh > 500) { dizer(`Tamanho inválido: use de ${minW}×${minH} (tamanho da tela) até 500×500 tiles.`, 'erro'); return false; }
    if (todosIds().includes(id)) { dizer(`Já existe uma sala com o id \"${id}\". Escolha outro id.`, 'erro'); return false; }
    const r = model.loadFromJson(blankRoomJson({ id, name: nNome.value.trim(), width: w, height: hh }, catalog));
    if (!r.ok) { dizer(r.errors, 'erro'); return false; }
    model.dirty = true; formNova.classList.add('hidden'); dizer(`Sala "${id}" criada.`, 'ok'); return true;
  }

  function aplicarTamanho() {
    const r = model.resize(Number(larg.value), Number(alt.value));
    if (!r.ok) { dizer(r.error, 'erro'); refreshUi(); } else if (r.changed) dizer(`Tamanho atualizado.`, 'ok');
  }

  async function trocarSala(valor) {
    if (valor === 'atual') return;
    const [tipo, id] = [valor.slice(0, valor.indexOf(':')), valor.slice(valor.indexOf(':') + 1)];
    try {
      let texto = null;
      if (tipo === 'draft') texto = drafts.load(id);
      else if (game.world && game.world.has(id)) texto = game.world.get(id);
      else if (fetchJson) texto = await fetchJson(`${config.rooms.path}${id}.json`);
      if (texto == null) throw new Error();
      const lido = model.loadFromJson(texto, { knownRoomIds: roomIds });
      if (!lido.ok) { dizer([`Não foi possível abrir "${id}":`, ...lido.errors], 'erro'); return; }
      if (tipo === 'draft') model.dirty = true;
      dizer(`Sala "${id}" aberta.`, 'ok');
    } catch (e) { dizer(`Não foi possível abrir "${id}"${e && e.message ? ': ' + e.message : ''}`, 'erro'); refreshSalas(); }
  }

  function testar() {
    const r = model.validate({ knownRoomIds: [...new Set([...roomIds, model.meta.id])] });
    if (r.errors.length) { dizer(['Corrija antes de testar:', ...r.errors], 'erro'); return false; }
    let salaPronta;
    try { salaPronta = buildRoom(model.toJson(), catalog, config, logger); } catch (e) { dizer([e.message], 'erro'); return false; }
    api.close(); game.setRoom(salaPronta); testando = true;
    doc.getElementById('btn-editor-back')?.classList.remove('hidden'); doc.getElementById('btn-editor')?.classList.add('hidden');
    return true;
  }

  function iniciarColagem() {
    if (!model.clipboard) { dizer('Nada copiado.'); return; }
    modoColar = true; refreshUi();
  }

  function mudarZoom(dir, px = W() / 2, py = H() / 2) {
    const novo = stepZoom(view.zoom, dir);
    if (novo !== view.zoom) { zoomAt(view, novo, px, py); clampView(view, model.map.pixelWidth, model.map.pixelHeight, W(), H()); refreshUi(); }
  }

  const ponto = (e) => canvasPoint(e.clientX, e.clientY, canvas.getBoundingClientRect(), W(), H());
  const celula = (p) => screenToCell(view, p.x, p.y, model.map.tileSize);

  function iniciarAcao(e, p) {
    const c = celula(p); hover = c; const apagar = e.button === 2;
    let ferr = model.tool; if (e.button === 1 || espaco) ferr = 'pan';
    if (modoColar) { acao = { tipo: 'toque', ferr: 'colar', apagar }; return; }
    switch (ferr) {
      case 'pencil': case 'eraser': model.beginStroke(c.tx, c.ty, ferr === 'eraser' || apagar); acao = { tipo: 'pintar', moveu: false, tx: c.tx, ty: c.ty }; break;
      case 'select': acao = { tipo: 'selecionar', x0: c.tx, y0: c.ty }; model.select(c.tx, c.ty, c.tx, c.ty); break;
      case 'pan': acao = { tipo: 'mover', sx: p.x, sy: p.y, vx: view.x, vy: view.y }; break;
      case 'inspect': case 'enemy': {
        const i = model.entityAt(c.tx, c.ty);
        if (i >= 0 && (ferr === 'inspect' || model.entities[i].type === 'enemy')) { model.selecionarEntidade(i); acao = { tipo: 'mover-ent', index: i, antes: model.beginEdicao(), moveu: false }; break; }
        const pid = ferr === 'inspect' ? model.passagemEm(c.tx, c.ty) : null;
        if (pid) { model.selecionarPassagem(pid); const t = model.passagemSel.trigger; acao = { tipo: 'mover-pass', id: pid, ox: c.tx - t.x, oy: c.ty - t.y, antes: model.beginEdicao(), moveu: false }; break; }
        if (ferr === 'inspect') { model.limparSel(); acao = null; } else acao = { tipo: 'toque', ferr, apagar };
        break;
      }
      case 'passage': {
        const pid = model.passagemEm(c.tx, c.ty);
        if (pid) { model.selecionarPassagem(pid); const t = model.passagemSel.trigger; acao = { tipo: 'mover-pass', id: pid, ox: c.tx - t.x, oy: c.ty - t.y, antes: model.beginEdicao(), moveu: false }; }
        else acao = { tipo: 'passagem', x0: c.tx, y0: c.ty, x1: c.tx, y1: c.ty };
        break;
      }
      case 'fill': case 'eyedropper': case 'start': case 'door': case 'tendrilAnchor': case 'tendrilObject': case 'checkpoint': case 'gene': acao = { tipo: 'toque', ferr, apagar }; break;
    }
  }

  function moverAcao(p) {
    const c = celula(p); const mudou = !hover || hover.tx !== c.tx || hover.ty !== c.ty; hover = c;
    if (acao) {
      if (acao.tipo === 'pintar' && (model.tool === 'pencil' || model.tool === 'eraser')) {
        if (c.tx !== acao.tx || c.ty !== acao.ty) acao.moveu = true;
        model.moveStroke(c.tx, c.ty);
      }
      else if (acao.tipo === 'selecionar') model.select(acao.x0, acao.y0, c.tx, c.ty);
      else if (acao.tipo === 'mover-ent') {
        const e = model.entities[acao.index];
        if (e) { const nx = Math.max(0, Math.min(model.map.width - (Number.isInteger(e.w) ? e.w : 1), c.tx)); const ny = Math.max(0, Math.min(model.map.height - (Number.isInteger(e.h) ? e.h : 1), c.ty)); if (nx !== e.x || ny !== e.y) { e.x = nx; e.y = ny; acao.moveu = true; } }
      } else if (acao.tipo === 'mover-pass') {
        const cn = model.connections.find((x) => x.id === acao.id);
        if (cn) { const t = cn.trigger; const nx = Math.max(0, Math.min(model.map.width - t.w, c.tx - acao.ox)); const ny = Math.max(0, Math.min(model.map.height - t.h, c.ty - acao.oy)); if (nx !== t.x || ny !== t.y) { t.x = nx; t.y = ny; acao.moveu = true; } }
      } else if (acao.tipo === 'passagem') { acao.x1 = c.tx; acao.y1 = c.ty; }
      else if (acao.tipo === 'mover') {
        view.x = acao.vx - (p.x - acao.sx) / view.zoom;
        view.y = acao.vy - (p.y - acao.sy) / view.zoom;
        clampView(view, model.map.pixelWidth, model.map.pixelHeight, W(), H());
      }
    }
    if (mudou) refreshUi();
  }

  function terminarAcao() {
    const a = acao; acao = null;
    if (!a) return;
    if (a.tipo === 'pintar') model.endStroke();
    else if (a.tipo === 'mover-ent' || a.tipo === 'mover-pass') { model.endEdicao(a.tipo === 'mover-ent' ? 'Mover item' : 'Mover passagem', a.antes); refreshUi(); }
    else if (a.tipo === 'passagem') {
      const x0 = Math.min(a.x0, a.x1); const y0 = Math.min(a.y0, a.y1); const x1 = Math.max(a.x0, a.x1); const y1 = Math.max(a.y0, a.y1);
      if (x0 === x1 && y0 === y1) model.addConnectionAt(x0, y0); else model.addConnection({ x: x0, y: y0, w: x1 - x0 + 1, h: y1 - y0 + 1 });
      dizer('Passagem criada: escolha a sala de destino no painel "Selecionado".', 'ok'); refreshUi();
    }
    else if (a.tipo === 'toque' && hover) {
      if (a.ferr === 'colar') { model.paste(hover.tx, hover.ty); modoColar = false; }
      else if (a.ferr === 'fill') model.fill(hover.tx, hover.ty, a.apagar);
      else if (a.ferr === 'eyedropper') model.eyedrop(hover.tx, hover.ty);
      else if (a.ferr === 'start') model.setPlayerStart(hover.tx, hover.ty);
      else if (a.ferr === 'enemy') model.addEnemyOrSelect(hover.tx, hover.ty);
      else if (a.ferr === 'door') model.addDoor(hover.tx, hover.ty);
      else if (a.ferr === 'checkpoint') model.addCheckpoint(hover.tx, hover.ty);
      else if (a.ferr === 'gene') model.addGene(hover.tx, hover.ty);
      else if (a.ferr === 'tendrilAnchor') model.addTendrilAnchor(hover.tx, hover.ty);
      else if (a.ferr === 'tendrilObject') model.addTendrilObject(hover.tx, hover.ty);
      refreshUi();
    }
  }

  function cancelarAcao() {
    if (acao && acao.tipo === 'pintar' && !acao.moveu) model.cancelStroke(); else if (acao && acao.tipo === 'pintar') model.endStroke();
    else if (acao && (acao.tipo === 'mover-ent' || acao.tipo === 'mover-pass')) model._restaurarEstado(acao.antes);
    acao = null;
  }

  canvas.addEventListener('pointerdown', (e) => {
    if (!aberto) return;
    e.preventDefault?.(); canvas.setPointerCapture?.(e.pointerId);
    const p = ponto(e); ponteiros.set(e.pointerId, p);
    if (ponteiros.size === 2) { cancelarAcao(); const [a, b] = [...ponteiros.values()]; pinca = startPinch(a, b, view); bloqueado = true; return; }
    if (ponteiros.size > 2 || bloqueado) return;
    iniciarAcao(e, p);
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!aberto) return;
    const p = ponto(e);
    if (!ponteiros.has(e.pointerId)) { const c = celula(p); if (!hover || hover.tx !== c.tx || hover.ty !== c.ty) { hover = c; refreshUi(); } return; }
    ponteiros.set(e.pointerId, p);
    if (pinca && ponteiros.size === 2) { const [a, b] = [...ponteiros.values()]; view = updatePinch(pinca, a, b); clampView(view, model.map.pixelWidth, model.map.pixelHeight, W(), H()); return; }
    if (!bloqueado) moverAcao(p);
  });
  const soltar = (e) => {
    if (!ponteiros.delete(e.pointerId)) return;
    if (ponteiros.size < 2) pinca = null;
    if (!bloqueado) terminarAcao();
    if (ponteiros.size === 0) { bloqueado = false; refreshUi(); }
  };
  for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) canvas.addEventListener(ev, soltar);
  canvas.addEventListener('wheel', (e) => { if (!aberto) return; e.preventDefault?.(); const p = ponto(e); mudarZoom(e.deltaY < 0 ? 1 : -1, p.x, p.y); });
  canvas.addEventListener('contextmenu', (e) => { if (aberto) e.preventDefault?.(); });

  const digitando = (e) => { const t = e.target; const tag = t && t.tagName ? String(t.tagName).toLowerCase() : ''; return tag === 'input' || tag === 'textarea' || tag === 'select'; };
  const aoTecla = (e) => {
    if (!aberto || digitando(e)) return;
    const ctrl = e.ctrlKey || e.metaKey; const k = (e.key || '').toLowerCase();
    if (e.code === 'Space') { espaco = true; e.preventDefault?.(); return; }
    if (ctrl && k === 'z') { e.preventDefault?.(); if (e.shiftKey) model.redo(); else model.undo(); return; }
    if (ctrl && k === 'y') { e.preventDefault?.(); model.redo(); return; }
    if (ctrl && k === 'c') { e.preventDefault?.(); model.copy(); return; }
    if (ctrl && k === 'x') { e.preventDefault?.(); model.cut(); return; }
    if (ctrl && k === 'v') { e.preventDefault?.(); iniciarColagem(); return; }
    if (e.code === 'Delete' || e.code === 'Backspace') {
      e.preventDefault?.();
      if (!model.selection && model.sel) { const r = model.sel.tipo === 'entidade' ? model.removeEntity(model.sel.index) : model.removeConnection(model.sel.id); if (!r.ok) dizer(r.errors, 'erro'); return; }
      model.deleteSelection(); return;
    }
    if (e.code === 'Escape') { modoColar = false; model.clearSelection(); model.limparSel(); refreshUi(); return; }
    const atalhos = { b: 'pencil', e: 'eraser', f: 'fill', v: 'select', h: 'pan', i: 'eyedropper' };
    if (!ctrl && atalhos[k]) { model.tool = atalhos[k]; modoColar = false; refreshUi(); }
    else if (k === 'g') { grade = !grade; sGrade.input.checked = grade; game.debug.editorGrid = grade; }
    else if (k === '+' || k === '=') mudarZoom(1); else if (k === '-') mudarZoom(-1);
  };
  const aoSoltarTecla = (e) => { if (e.code === 'Space') espaco = false; };

  const idsCatalogo = () => catalog.all().map((t) => t.id);
  let gamepadPintando = false; let gamepadApagando = false; let gamepadConectado = false;
  let gamepadMoveX = 0; let gamepadMoveY = 0; let gamepadPanX = 0; let gamepadPanY = 0;
  let gamepadMoveAccX = 0; let gamepadMoveAccY = 0; let gamepadDpadAntes = 0;
  const zonaPad = 0.24;
  function moverCursorPad(dx, dy) {
    if (!model || (!dx && !dy)) return;
    const atual = hover || { tx: Math.floor(model.map.width / 2), ty: Math.floor(model.map.height / 2) };
    const tx = Math.max(0, Math.min(model.map.width - 1, atual.tx + dx));
    const ty = Math.max(0, Math.min(model.map.height - 1, atual.ty + dy));
    if (!hover || tx !== hover.tx || ty !== hover.ty) { hover = { tx, ty }; manterCursorVisivel(); refreshUi(); }
    if (gamepadPintando || gamepadApagando) model.moveStroke(hover.tx, hover.ty);
  }
  function manterCursorVisivel() {
    if (!hover || !model) return;
    const margem = catalog.tileSize * 2;
    const px = (hover.tx + 0.5) * catalog.tileSize; const py = (hover.ty + 0.5) * catalog.tileSize;
    if (px < view.x + margem) view.x = px - margem;
    else if (px > view.x + W() / view.zoom - margem) view.x = px - W() / view.zoom + margem;
    if (py < view.y + margem) view.y = py - margem;
    else if (py > view.y + H() / view.zoom - margem) view.y = py - H() / view.zoom + margem;
    clampView(view, model.map.pixelWidth, model.map.pixelHeight, W(), H());
  }
  function acaoNoCursor(apagar = false) {
    if (!model || !hover) return;
    const { tx, ty } = hover;
    if (modoColar) { model.paste(tx, ty); modoColar = false; refreshUi(); return; }
    if (model.tool === 'pencil' || model.tool === 'eraser') {
      model.beginStroke(tx, ty, apagar || model.tool === 'eraser'); model.endStroke();
    } else if (model.tool === 'fill') model.fill(tx, ty, apagar);
    else if (model.tool === 'eyedropper') model.eyedrop(tx, ty);
    else if (model.tool === 'select') { model.select(tx, ty, tx, ty); }
    else if (model.tool === 'start') model.setPlayerStart(tx, ty);
    else if (model.tool === 'enemy') model.addEnemyOrSelect(tx, ty);
    else if (model.tool === 'inspect') { const i = model.entityAt(tx, ty); const pid = model.passagemEm(tx, ty); if (i >= 0) model.selecionarEntidade(i); else if (pid) model.selecionarPassagem(pid); else model.limparSel(); }
    else if (model.tool === 'passage') { const pid = model.passagemEm(tx, ty); if (pid) model.selecionarPassagem(pid); else model.addConnectionAt(tx, ty); }
    else if (model.tool === 'door') model.addDoor(tx, ty);
    else if (model.tool === 'checkpoint') model.addCheckpoint(tx, ty);
    else if (model.tool === 'gene') model.addGene(tx, ty);
    else if (model.tool === 'tendrilAnchor') model.addTendrilAnchor(tx, ty);
    else if (model.tool === 'tendrilObject') model.addTendrilObject(tx, ty);
    refreshUi();
  }
  function ciclarTile(direcao) {
    const ids = idsCatalogo(); if (!ids.length) return;
    let i = ids.indexOf(model.tileId); if (i < 0) i = 0;
    model.tileId = ids[(i + direcao + ids.length) % ids.length];
    if (!['pencil', 'fill'].includes(model.tool)) model.tool = 'pencil';
    const b = botoesTile[model.tileId]; if (b && b.parentElement) b.scrollIntoView?.({ block: 'nearest' });
    refreshUi();
  }
  function ciclarFerramenta() {
    const lista = ['pencil', 'eraser', 'fill', 'select', 'pan', 'eyedropper', 'start', 'enemy', 'door', 'tendrilAnchor', 'tendrilObject', 'checkpoint', 'gene', 'inspect', 'passage'];
    model.tool = lista[(lista.indexOf(model.tool) + 1) % lista.length]; modoColar = false; refreshUi();
  }
  function tratarGamepad(pad, estado = {}) {
    if (!aberto || !pad) {
      if (gamepadPintando || gamepadApagando) { if (model) model.endStroke(); }
      gamepadPintando = false; gamepadApagando = false; gamepadConectado = false;
      gamepadHelp.classList.remove('connected'); gamepadMoveAccX = 0; gamepadMoveAccY = 0; gamepadDpadAntes = 0;
      return;
    }
    gamepadConectado = true;
    const { down = new Set(), pressed = new Set(), released = new Set(), dt = 0 } = estado;
    const eg = config.controls.gamepad.editor;
    const eixo = (i) => Math.abs(pad.axes?.[i] || 0) > zonaPad ? pad.axes[i] : 0;
    const direcao = (v) => v < -0.45 ? -1 : v > 0.45 ? 1 : 0;
    gamepadMoveX = eixo(eg.cursorAxisX); gamepadMoveY = eixo(eg.cursorAxisY);
    gamepadPanX = eixo(eg.panAxisX); gamepadPanY = eixo(eg.panAxisY);
    gamepadMoveAccX += gamepadMoveX * dt * 8; gamepadMoveAccY += gamepadMoveY * dt * 8;
    let mx = 0, my = 0;
    while (Math.abs(gamepadMoveAccX) >= 1) { const d = Math.sign(gamepadMoveAccX); mx += d; gamepadMoveAccX -= d; }
    while (Math.abs(gamepadMoveAccY) >= 1) { const d = Math.sign(gamepadMoveAccY); my += d; gamepadMoveAccY -= d; }
    const dpadX = (down.has(15) ? 1 : 0) - (down.has(14) ? 1 : 0);
    const dpadY = (down.has(13) ? 1 : 0) - (down.has(12) ? 1 : 0);
    const dpadMask = (down.has(12) ? 1 : 0) | (down.has(13) ? 2 : 0) | (down.has(14) ? 4 : 0) | (down.has(15) ? 8 : 0);
    if (dpadMask && dpadMask !== gamepadDpadAntes) { mx += dpadX; my += dpadY; gamepadMoveAccX = 0; gamepadMoveAccY = 0; }
    else if (dpadMask) { gamepadMoveAccX += dpadX * dt * 7; gamepadMoveAccY += dpadY * dt * 7; }
    else { gamepadMoveAccX = 0; gamepadMoveAccY = 0; }
    gamepadDpadAntes = dpadMask;
    while (Math.abs(gamepadMoveAccX) >= 1) { const d = Math.sign(gamepadMoveAccX); mx += d; gamepadMoveAccX -= d; }
    while (Math.abs(gamepadMoveAccY) >= 1) { const d = Math.sign(gamepadMoveAccY); my += d; gamepadMoveAccY -= d; }
    if (mx || my) moverCursorPad(Math.sign(mx), Math.sign(my));
    if (gamepadPanX || gamepadPanY) {
      view.x += gamepadPanX * dt * 220 / view.zoom; view.y += gamepadPanY * dt * 220 / view.zoom;
      clampView(view, model.map.pixelWidth, model.map.pixelHeight, W(), H());
    }
    if (pressed.has(eg.previousTile)) ciclarTile(-1);
    if (pressed.has(eg.nextTile)) ciclarTile(1);
    if (pressed.has(eg.cycleTool)) ciclarFerramenta();
    if (pressed.has(eg.eyedropper)) { model.tool = 'eyedropper'; acaoNoCursor(false); }
    if (pressed.has(eg.toggleGrid)) { grade = !grade; sGrade.input.checked = grade; game.debug.editorGrid = grade; refreshUi(); }
    if (pressed.has(eg.nextLayer)) { const i = LAYER_NAMES.indexOf(model.layer); model.layer = LAYER_NAMES[(i + 1) % LAYER_NAMES.length]; refreshUi(); }
    if (pressed.has(eg.zoomOut)) mudarZoom(-1);
    if (pressed.has(eg.zoomIn)) mudarZoom(1);
    if (pressed.has(eg.test)) testar();
    if (pressed.has(eg.close)) api.close();
    if (pressed.has(eg.cancel)) { if (modoColar) modoColar = false; else if (model.selection) model.clearSelection(); else model.tool = 'pencil'; refreshUi(); }
    const ferramentaDePincel = model.tool === 'pencil' || model.tool === 'eraser';
    const querPintar = down.has(eg.confirm) && ferramentaDePincel;
    const querApagar = down.has(eg.cancel) && !modoColar && ferramentaDePincel;
    if (pressed.has(eg.confirm) && !ferramentaDePincel) acaoNoCursor(false);
    if (pressed.has(eg.confirm) && ferramentaDePincel) { gamepadPintando = true; model.beginStroke(hover?.tx ?? 0, hover?.ty ?? 0, model.tool === 'eraser'); }
    if (pressed.has(eg.cancel) && !modoColar && ferramentaDePincel) { gamepadApagando = true; model.beginStroke(hover?.tx ?? 0, hover?.ty ?? 0, true); }
    if (gamepadPintando && released.has(eg.confirm)) { model.endStroke(); gamepadPintando = false; }
    if (gamepadApagando && released.has(eg.cancel)) { model.endStroke(); gamepadApagando = false; }
    if ((gamepadPintando || gamepadApagando) && hover) model.moveStroke(hover.tx, hover.ty);
    gamepadHelp.classList.toggle('connected', gamepadConectado);
  }

  function render() {
    const ctx = renderer.ctx; renderer.clear();
    if (!model || !renderer.graphics) return;
    const mapa = model.map; const ts = mapa.tileSize; const z = view.zoom;
    const camX = Math.round(view.x); const camY = Math.round(view.y); const visW = W() / z; const visH = H() / z;
    ctx.save(); ctx.scale(z, z);
    renderer._depAtual = renderer._profundidade(model.depth, null, null, { W: mapa.pixelWidth, H: mapa.pixelHeight }, true);   // 2.5D: o editor mostra o volume dos tiles (o parallax só aparece no jogo/teste)
    renderer.drawMapLayers(mapa, camX, camY, visW, visH, camadaVisivel);
    renderer._depAtual = null;
    ctx.translate(-camX, -camY);
    const fino = 1 / z;

    const s = model.playerStart; const hb = config.player.hitbox;
    const marca = (px, py, alpha) => {
      ctx.globalAlpha = alpha;
      drawPlayer(ctx, { body: { x: px, y: py, w: hb.w, h: hb.h }, squash: { value: 0 }, state: 'idle', facing: 1, invuln: 0, life: 1 }, 0, 0, config);
      ctx.globalAlpha = 1;
    };
    if (s) { marca((s.x + 0.5) * ts - hb.w / 2, (s.y + 1) * ts - hb.h, 1); ctx.strokeStyle = '#7cfc00'; ctx.lineWidth = fino; ctx.strokeRect(s.x * ts, s.y * ts, ts, ts); }

    ctx.save();
    // Passagens (portas do jogo): retângulo do gatilho
    for (const c of model.connections || []) {
      const t = c.trigger; if (!t) continue;
      const sel = model.sel && model.sel.tipo === 'passagem' && model.sel.id === c.id;
      ctx.fillStyle = sel ? 'rgba(255,225,53,0.30)' : 'rgba(255,140,0,0.26)'; ctx.fillRect(t.x * ts, t.y * ts, t.w * ts, t.h * ts);
      ctx.strokeStyle = sel ? '#ffe135' : '#ff9a1f'; ctx.lineWidth = fino * (sel ? 2.5 : 1.5); ctx.strokeRect(t.x * ts, t.y * ts, t.w * ts, t.h * ts);
      ctx.font = '5px monospace'; ctx.textAlign = 'left'; ctx.textBaseline = 'bottom'; ctx.fillStyle = '#000'; ctx.fillText(`${c.id}→${c.to || '?'}`, t.x * ts + 1.4, t.y * ts - 0.6); ctx.fillStyle = sel ? '#ffe135' : '#ffc16b'; ctx.fillText(`${c.id}→${c.to || '?'}`, t.x * ts + 1, t.y * ts - 1);
    }
    if (acao && acao.tipo === 'passagem') {
      const x0 = Math.min(acao.x0, acao.x1); const y0 = Math.min(acao.y0, acao.y1); const w = Math.abs(acao.x1 - acao.x0) + 1; const h2 = Math.abs(acao.y1 - acao.y0) + 1;
      ctx.fillStyle = 'rgba(255,140,0,0.35)'; ctx.fillRect(x0 * ts, y0 * ts, w * ts, h2 * ts); ctx.strokeStyle = '#ffe135'; ctx.lineWidth = fino * 2; ctx.strokeRect(x0 * ts, y0 * ts, w * ts, h2 * ts);
    }

    if (model.enemies) {
      ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (const en of model.enemies) {
        const sel = model.entidadeSel === en;
        ctx.fillStyle = COR_ESPECIE[en.kind || 'crawler'] || '#d95763';
        ctx.fillRect(en.x * ts + 2, en.y * ts + 2, ts - 4, ts - 4);
        ctx.fillStyle = '#fff'; ctx.fillText((en.kind || 'crawler')[0].toUpperCase(), en.x * ts + ts / 2, en.y * ts + ts / 2 + 0.5);
        ctx.strokeStyle = sel ? '#ffe135' : '#ffffff';
        ctx.lineWidth = fino * (sel ? 3 : 1);
        ctx.strokeRect(en.x * ts, en.y * ts, ts, ts);
      }
    }

    for (const e of model.entities) {   // outros itens (memória, vida, mutação, parede frágil…): marcador simples para dar para selecionar
      const cor = COR_OUTROS[e.type]; if (!cor) continue;
      const w = Number.isInteger(e.w) ? e.w : 1; const h2 = Number.isInteger(e.h) ? e.h : 1; const sel = model.entidadeSel === e;
      ctx.globalAlpha = 0.35; ctx.fillStyle = cor; ctx.fillRect(e.x * ts, e.y * ts, w * ts, h2 * ts); ctx.globalAlpha = 1;
      ctx.strokeStyle = sel ? '#ffe135' : cor; ctx.lineWidth = fino * (sel ? 3 : 1.2); ctx.strokeRect(e.x * ts + 0.5, e.y * ts + 0.5, w * ts - 1, h2 * ts - 1);
    }
    const seld = model.entidadeSel;
    if (seld && !['enemy'].includes(seld.type) && !COR_OUTROS[seld.type] && seld.type !== 'playerStart') { ctx.strokeStyle = '#ffe135'; ctx.lineWidth = fino * 3; ctx.strokeRect(seld.x * ts, seld.y * ts, ts, ts); }
    ctx.restore();

    if (model.doors) {
      for (const d of model.doors) {
        ctx.fillStyle = 'rgba(0, 255, 200, 0.4)';
        ctx.fillRect(d.x * ts, d.y * ts, ts, ts);
        ctx.strokeStyle = '#00ffc8';
        ctx.lineWidth = fino;
        ctx.strokeRect(d.x * ts, d.y * ts, ts, ts);
      }
    }

    const tt = game.metrics.totalSteps / 60;
    for (const cp of model.checkpoints || []) drawCheckpoint(ctx, true, cp.x, cp.y, ts, 0, 0, tt, false);   // mesmo sprite do jogo
    for (const ge of model.genes || []) {
      const def = GENES.find((x) => x.id === ge.gene); drawGenePickup(ctx, def || GENES[0], ge.x, ge.y, ts, 0, 0, tt);
      ctx.strokeStyle = def?.implementado ? '#ffe69a' : '#ff9a7a'; ctx.lineWidth = fino; ctx.strokeRect(ge.x * ts + 0.5, ge.y * ts + 0.5, ts - 1, ts - 1);   // laranja = espaço reservado
    }
    for (const e of [...(model.tendrilAnchors || []), ...(model.tendrilObjects || [])]) {
      const cx = e.x * ts + ts / 2; const cy = e.y * ts + ts / 2; const r = e.type === 'tendrilAnchor' ? 4 : 5;
      ctx.fillStyle = '#102a25'; ctx.fillRect(cx - r - 1, cy - r - 1, 2 * r + 2, 2 * r + 2);
      ctx.fillStyle = e.type === 'tendrilAnchor' ? '#4fd9ae' : '#e6a8ff'; ctx.fillRect(cx - r, cy - r, 2 * r, 2 * r);
      ctx.fillStyle = '#eaffd8'; ctx.fillRect(cx - 1, cy - 1, 2, 2);
      ctx.strokeStyle = e.type === 'tendrilAnchor' ? '#73e6bc' : '#f0c8ff'; ctx.lineWidth = fino; ctx.strokeRect(e.x * ts + 0.5, e.y * ts + 0.5, ts - 1, ts - 1);
    }

    if (game.debug.editorGrid !== undefined && game.debug.editorGrid !== grade) { grade = game.debug.editorGrid; sGrade.input.checked = grade; }   // o painel de diagnóstico também liga/desliga
    if (grade) {
      const passo = z < 1 ? 4 : 1; ctx.strokeStyle = 'rgba(255,255,255,0.13)'; ctx.lineWidth = fino; ctx.beginPath();
      const x0 = Math.max(0, Math.floor(camX / ts)); const x1 = Math.min(mapa.width, Math.ceil((camX + visW) / ts));
      const y0 = Math.max(0, Math.floor(camY / ts)); const y1 = Math.min(mapa.height, Math.ceil((camY + visH) / ts));
      for (let x = x0 - (x0 % passo); x <= x1; x += passo) { ctx.moveTo(x * ts, y0 * ts); ctx.lineTo(x * ts, y1 * ts); }
      for (let y = y0 - (y0 % passo); y <= y1; y += passo) { ctx.moveTo(x0 * ts, y * ts); ctx.lineTo(x1 * ts, y * ts); }
      ctx.stroke();
    }

    if (colisoes) {
      ctx.lineWidth = fino;
      mapa.forEachCollidable(camX, camY, visW, visH, (c) => {
        ctx.strokeStyle = c.kind === 'solid' ? DEBUG_COLORS.solid : c.kind === 'oneway' ? DEBUG_COLORS.oneway : DEBUG_COLORS.damage;
        ctx.strokeRect(c.x, c.y, c.w, c.h);
      });
    }

    ctx.strokeStyle = DEBUG_COLORS.roomBounds; ctx.lineWidth = fino * 2; ctx.strokeRect(0, 0, mapa.pixelWidth, mapa.pixelHeight);

    const sel = model.selection;
    if (sel) {
      ctx.fillStyle = 'rgba(0,200,255,0.18)'; ctx.fillRect(sel.x0 * ts, sel.y0 * ts, (sel.x1 - sel.x0 + 1) * ts, (sel.y1 - sel.y0 + 1) * ts);
      ctx.strokeStyle = '#00e5ff'; ctx.lineWidth = fino * 2; ctx.strokeRect(sel.x0 * ts, sel.y0 * ts, (sel.x1 - sel.x0 + 1) * ts, (sel.y1 - sel.y0 + 1) * ts);
    }

    if (hover) {
      if (modoColar && model.clipboard) {
        const cb = model.clipboard; ctx.globalAlpha = 0.6;
        for (const [nome, arr] of Object.entries(cb.layers)) { void nome; for (let y = 0; y < cb.h; y++) for (let x = 0; x < cb.w; x++) { const id = arr[y * cb.w + x]; if (id) renderer.graphics.draw(ctx, id, 0, (hover.tx + x) * ts, (hover.ty + y) * ts); } }
        ctx.globalAlpha = 1; ctx.strokeStyle = '#ffe135'; ctx.lineWidth = fino * 2; ctx.strokeRect(hover.tx * ts, hover.ty * ts, cb.w * ts, cb.h * ts);
      } else if (model.tool === 'start') marca((hover.tx + 0.5) * ts - hb.w / 2, (hover.ty + 1) * ts - hb.h, 0.5);
      else if (model.tool === 'enemy') {
        ctx.fillStyle = 'rgba(217, 87, 99, 0.5)';
        ctx.fillRect(hover.tx * ts, hover.ty * ts, ts, ts);
        ctx.strokeStyle = '#d95763';
        ctx.lineWidth = fino * 2;
        ctx.strokeRect(hover.tx * ts, hover.ty * ts, ts, ts);
      } else if (model.tool === 'door') {
        ctx.fillStyle = 'rgba(0, 255, 200, 0.5)';
        ctx.fillRect(hover.tx * ts, hover.ty * ts, ts, ts);
        ctx.strokeStyle = '#00ffc8';
        ctx.lineWidth = fino * 2;
        ctx.strokeRect(hover.tx * ts, hover.ty * ts, ts, ts);
      } else if (model.tool === 'checkpoint' || model.tool === 'gene') {
        ctx.globalAlpha = 0.6;
        if (model.tool === 'checkpoint') drawCheckpoint(ctx, true, hover.tx, hover.ty, ts, 0, 0, tt, false);
        else drawGenePickup(ctx, GENES.find((x) => x.id === model.geneSelecionado) || GENES[0], hover.tx, hover.ty, ts, 0, 0, tt);
        ctx.globalAlpha = 1; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = fino * 2; ctx.strokeRect(hover.tx * ts, hover.ty * ts, ts, ts);
      } else if (['pencil', 'eraser'].includes(model.tool)) {
        const n = model.brushSize; const off = Math.floor((n - 1) / 2);
        if (model.tool === 'pencil' && model.tileId) { ctx.globalAlpha = 0.45; for (let dy = 0; dy < n; dy++) for (let dx = 0; dx < n; dx++) renderer.graphics.draw(ctx, model.tileId, 0, (hover.tx - off + dx) * ts, (hover.ty - off + dy) * ts); ctx.globalAlpha = 1; }
        ctx.strokeStyle = model.tool === 'eraser' ? '#ff6b6b' : '#ffffff'; ctx.lineWidth = fino; ctx.strokeRect((hover.tx - off) * ts, (hover.ty - off) * ts, n * ts, n * ts);
      } else { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = fino; ctx.strokeRect(hover.tx * ts, hover.ty * ts, ts, ts); }
    }
    ctx.restore();
  }

  const larguraPainel = () => Math.min(Math.round(((win && win.innerWidth) || 800) * 0.46), 330);

  const api = {
    element: painel,
    isOpen: () => aberto,
    get model() { return model; },
    get view() { return view; },
    get exportText() { return ultimaExportacao; },
    render, refresh: refreshUi, validar, exportar, importar, testar, salvarRascunho, salvarNoServidor,
    handleGamepad: tratarGamepad,
    cellCenterClient(tx, ty) {
      const r = canvas.getBoundingClientRect(); const ts = model.map.tileSize;
      const ix = ((tx + 0.5) * ts - view.x) * view.zoom; const iy = ((ty + 0.5) * ts - view.y) * view.zoom;
      return { clientX: r.left + (ix / W()) * r.width, clientY: r.top + (iy / H()) * r.height };
    },
    centerOn(tx, ty, zoom = null) {
      const ts = model.map.tileSize;
      if (zoom) view.zoom = zoom;
      view.x = (tx + 0.5) * ts - W() / (2 * view.zoom); view.y = (ty + 0.5) * ts - H() / (2 * view.zoom);
      clampView(view, model.map.pixelWidth, model.map.pixelHeight, W(), H()); refreshUi();
    },
    open() {
      if (aberto) return;
      if (!model) { model = new EditorModel({ catalog, config, logger, roomData: game.roomData }); model.subscribe(aoMudarModelo); centralizarNoInicio(); }
      aberto = true; testando = false;
      verificarServidor();
      doc.getElementById('btn-editor-back')?.classList.add('hidden'); doc.getElementById('btn-editor')?.classList.remove('hidden');
      if (game.paused) game.resume();
      game.input.releaseAll(); game.editing = true; game.customRender = render;
      painel.classList.remove('hidden'); doc.body.classList.add('editor-open');
      renderer.insets.right = larguraPainel(); renderer.resize();
      win?.addEventListener('keydown', aoTecla); win?.addEventListener('keyup', aoSoltarTecla);
      refreshSalas(); refreshUi();
    },
    close() {
      if (!aberto) return;
      cancelarAcao(); if (gamepadPintando || gamepadApagando) model?.endStroke(); gamepadPintando = false; gamepadApagando = false;
      ponteiros.clear(); pinca = null; bloqueado = false;
      aberto = false; game.editing = false; game.customRender = null;
      painel.classList.add('hidden'); doc.body.classList.remove('editor-open');
      renderer.insets.right = 0; renderer.resize();
      win?.removeEventListener('keydown', aoTecla); win?.removeEventListener('keyup', aoSoltarTecla);
    },
    toggle() { if (aberto) api.close(); else { doc.getElementById('btn-editor-back')?.classList.add('hidden'); api.open(); } },
    get testando() { return testando; },
  };
  return api;
}
