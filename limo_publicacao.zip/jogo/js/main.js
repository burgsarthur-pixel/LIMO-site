// =====================================================================
// INICIALIZAÇÃO: monta todas as peças e inicia o jogo.
// =====================================================================
import { createConfig } from './config.js';
import { Logger } from './core/logger.js';
import { InputState, attachKeyboard, attachTouch, GamepadPoller } from './core/input.js';
import { Game } from './core/game.js';
import { Progress } from './core/progress.js';
import { SaveStore } from './core/save.js';
import { Renderer } from './render/renderer.js';
import { createHud } from './ui/hud.js';
import { nomeDoFinal } from './core/story.js';
import { createToast } from './ui/toast.js';
import { createScreens } from './ui/screens.js';
import { CanvasPauseMenu } from './ui/canvas-pause-menu.js';
import { CanvasStoryCard } from './ui/canvas-story-card.js';
import { CanvasDialogo } from './ui/canvas-dialogo.js';
import { CanvasGenesMenu } from './ui/canvas-genes-menu.js';
import { CanvasCatalogo } from './ui/canvas-catalogo.js';
import { salvarArquivo, lerArquivo, textoDoSalvamento } from './editor/arquivo.js';
import { createWorldMap } from './ui/world-map.js';
import { loadCatalog, loadRoomIndex, defaultFetchJson } from './world/room-loader.js';
import { World } from './world/world.js';
import { loadTilesets } from './render/tileset-loader.js';
import { resolveDevMode, gravarDevMode, urlSemDev } from './core/dev-mode.js';
import { BUILD_OVERRIDES, isReleaseBuild } from './build-profile.js';
import { GAME_LABEL } from './version.js';

const params = new URLSearchParams(location.search);
const config = createConfig(BUILD_OVERRIDES);
const dev = isReleaseBuild ? { ativo: false, esquecer: false } : resolveDevMode(location.search);
config.debug.devMode = dev.ativo;
if (dev.esquecer) gravarDevMode(false);                                          // ?dev=0 também apaga a escolha salva

const logger = new Logger({ maxEntries: config.debug.maxLogEntries, dedupeWindowMs: config.debug.dedupeWindowMs, mirrorToConsole: config.debug.mirrorToConsole });
const screens = createScreens(document);
const $ = (id) => document.getElementById(id);
document.title = `LIMO · ${GAME_LABEL}`;
$('title-version').textContent = GAME_LABEL;

// Erros inesperados vão para o console de debug e para a tela (nada de falha silenciosa).
window.addEventListener('error', (e) => logger.error('erros', `${e.message} (${e.filename || '?'}:${e.lineno || '?'})`));
window.addEventListener('unhandledrejection', (e) => logger.error('erros', `Promessa rejeitada: ${e.reason && e.reason.message ? e.reason.message : e.reason}`));

async function iniciar() {
  try {
    screens.setLoading(true, 'Carregando…');
    const canvas = $('game');
    const renderer = new Renderer(canvas, config, logger);
    const input = new InputState();
    const catalogo = await loadCatalog(config, logger);
    const mundo = await World.load(config, catalogo, logger);                 // todas as salas + passagens
    const tilesets = await loadTilesets(catalogo, logger);                    // spritesheets PNG (se falharem, usa arte provisória)
    renderer.useCatalog(catalogo, catalogo.tileSize, tilesets);
    // A Tecelã usa a arte procedural original; combate e hitboxes permanecem independentes do visual.

    const hud = createHud(document); const toast = createToast(document); const saveStore = new SaveStore();
    const game = new Game({ config, logger, input, catalog: catalogo, renderer, ui: { hud, screens, toast } });
    game.attachWorld({ world: mundo, progress: Progress.novo(config), saveStore });
    game.enterRoom(config.rooms.startRoom, { healFull: true });               // cena de fundo da tela inicial
    game.suspended = 'titulo';
    const mapa = createWorldMap({ doc: document, game, catalog: catalogo });
    const pauseMenu = new CanvasPauseMenu({
      canvas, renderer, config,
      actions: {
        resume: () => game.resume(),
        save: () => game.salvarAgora(),
        info: () => game.infoSalvamento(),
        restart: () => $('btn-restart-pause').click(),
        map: () => $('btn-pause-map').click(),
        catalog: () => game.abrirCatalogo(),
        export: () => $('btn-export-progress').click(),
        import: () => $('btn-import-progress').click(),
        reset: () => $('btn-reset-progress').click(),
        editor: () => $('btn-pause-editor').click(),
        dev: config.debug.allowDevToggle ? () => $('btn-dev-toggle').click() : null,
      },
    });
    renderer.setPauseMenu(pauseMenu);
    screens.setCanvasPauseMenu(pauseMenu);
    const storyCard = new CanvasStoryCard({ canvas, renderer, config });
    renderer.setStoryCard(storyCard);
    screens.setCanvasStoryCard(storyCard);
    const genesMenu = new CanvasGenesMenu({ canvas, renderer, config });   // tela de genes: abre ao descansar num Casulo de Repouso
    renderer.setGenesMenu(genesMenu); game.ui.genesMenu = genesMenu;
    const catalogoMenu = new CanvasCatalogo({ canvas, renderer, config });   // v1.39.0: catálogo de descobertas (botão 📖, menu de pausa ou tecla C)
    renderer.setCatalogoMenu(catalogoMenu); game.ui.catalogoMenu = catalogoMenu;
    const dialogo = new CanvasDialogo({ canvas, renderer, config });   // v1.43: diálogo dos NPCs (avança com E, toque no quadro, botão de interação ou A do gamepad)
    renderer.setDialogo(dialogo); game.ui.dialogo = dialogo;
    game.ui.interagir = (perto, modo = 'descansar') => {   // o mesmo botão serve ao casulo (☾) e aos NPCs (💬)
      const b = $('btn-interact'); if (!b) return; b.classList.toggle('locked', !perto);
      if (b.dataset.modo !== modo) {
        b.dataset.modo = modo; const conversar = modo === 'conversar'; b.innerHTML = `<svg class="ico"><use href="#${conversar ? 'i-talk' : 'i-rest'}"/></svg>`;
        b.setAttribute('aria-label', conversar ? 'Conversar' : 'Descansar no Casulo de Repouso'); b.title = conversar ? 'Conversar (E ou ↑)' : 'Descansar (E ou ↑): troca genes e salva';
      }
    };

    // ---- controles ----
    const abrirMapa = () => { if (!game.editing && !game.paused && (!game.suspended || game.suspended === 'mapa')) mapa.toggle(); };
    const comandos = {
      pause: () => { if (mapa.isOpen()) mapa.close(); else if (!game.editing && !game.suspended) game.togglePause(); },
      toggleDebug: null, toggleEditor: null, toggleMap: abrirMapa, onGamepadFrame: (pad, estado) => { genesMenu.aoGamepad(estado); catalogoMenu.aoGamepad(estado); dialogo.aoGamepad(estado); }, editorActive: () => !!editor?.isOpen(),
    };
    const gamepad = new GamepadPoller(input, config, navigator, comandos);
    game.beforeFrame = () => gamepad.poll();
    attachTouch(input, $('touch-controls'));

    // ---- tela inicial e salvamento ----
    const prepararTitulo = () => {
      const lido = saveStore.ler(mundo);
      const textos = {
        'sem-save': '', ok: '',
        incompativel: `Há um salvamento de OUTRA versão do jogo (${lido.versao}); não dá para continuar. "Novo jogo" apaga esse salvamento.`,
        corrompido: `O salvamento está corrompido ou não combina com as salas atuais (${lido.erro}). "Novo jogo" apaga esse salvamento.`,
        indisponivel: 'Seu navegador está bloqueando o salvamento: dá para jogar, mas o progresso NÃO será guardado.',
      };
      let resumo = '';
      if (lido.estado === 'ok') {
        const d = lido.dados; const muts = Object.values(d.habilidades).filter(Boolean).length - 1;
        resumo = `Último salvamento: ${new Date(d.salvoEm).toLocaleString('pt-BR')} · ${d.visitadas.length} sala(s) · ${Math.max(0, muts)} mutação(ões) extra(s)`;
        if (lido.recuperado) resumo = `${lido.avisoRecuperacao} ${resumo}`;
      }
      if (lido.estado === 'ok' && lido.dados?.final) resumo += ` · Final: ${nomeDoFinal(lido.dados.final) || lido.dados.final}`;
      screens.configurarTitulo({ podeContinuar: lido.estado === 'ok', mensagem: textos[lido.estado], resumo });
      return lido;
    };
    const novoJogo = async (pedirConfirmacao) => {
      const lido = saveStore.ler(mundo);
      if (pedirConfirmacao && ['ok', 'corrompido', 'incompativel'].includes(lido.estado)) {
        if (!(await screens.confirmar('Apagar o progresso salvo e começar um jogo novo?', 'Apagar e recomeçar'))) return false;
      }
      game.startNewGame(); screens.showTitle(false); return true;   // o prólogo vira cartão de história (Game.startNewGame)
    };
    const continuar = () => {
      const lido = saveStore.ler(mundo);
      if (lido.estado !== 'ok') { prepararTitulo(); return false; }
      game.continueGame(lido.dados); screens.showTitle(false); return true;
    };
    $('btn-novo-jogo').addEventListener('click', () => novoJogo(true));
    $('btn-expedicao').addEventListener('click', () => { game.startExpedition(); screens.showTitle(false); });   // salas novas a cada expedição
    $('btn-continuar').addEventListener('click', continuar);

    // ---- botões da interface ----
    const btnAudio = $('btn-audio'); const marcarAudio = () => { btnAudio.classList.toggle('muted', !!game.audio.mudo); btnAudio.setAttribute('aria-pressed', String(!game.audio.mudo)); };
    btnAudio.addEventListener('click', () => { game.audio.desbloquear(); game.audio.toggleMudo(); if (!game.audio.mudo) game.audio.tocar('teste_audio'); marcarAudio(); }); marcarAudio();
    const gesto = () => { game.audio.desbloquear(); for (const ev of ['pointerdown', 'keydown']) window.removeEventListener(ev, gesto); };   // navegadores só liberam áudio após um gesto
    for (const ev of ['pointerdown', 'keydown']) window.addEventListener(ev, gesto);
    $('btn-pause').addEventListener('click', () => { if (!game.editing && !game.suspended) game.togglePause(); });
    $('btn-resume').addEventListener('click', () => game.resume());
    $('btn-restart-pause').addEventListener('click', () => { game.resume(); game.restartRoom(); });
    $('btn-retry').addEventListener('click', () => game.respawnAtCheckpoint());
    $('btn-fullscreen').addEventListener('click', () => screens.toggleFullscreen());
    $('btn-map').addEventListener('click', abrirMapa);
    $('btn-catalogo')?.addEventListener('click', () => game.abrirCatalogo());
    window.addEventListener('keydown', (e) => { if (e.code === 'KeyC' && !e.repeat && !e.ctrlKey && !e.metaKey && !e.altKey && !catalogoMenu.open && !game.editing && !(e.target?.tagName === 'INPUT' || e.target?.tagName === 'TEXTAREA')) game.abrirCatalogo(); });
    $('btn-map-close').addEventListener('click', () => mapa.close());
    $('btn-pause-map').addEventListener('click', () => { game.resume(); abrirMapa(); });
    $('btn-reset-progress').addEventListener('click', async () => {
      if (await screens.confirmar('Apagar TODO o progresso (mutações, mapa e checkpoints) e recomeçar do zero?', 'Apagar e recomeçar')) { game.resume(); game.startNewGame(); }
    });
    $('btn-export-progress').addEventListener('click', () => {
      const resultado = saveStore.exportar(mundo);
      if (!resultado.ok) { game.toast(resultado.error); return; }
      const nome = `LIMO-progresso-${GAME_LABEL.split(' ')[0].replace('v', '')}.json`;
      salvarArquivo({ nome, texto: resultado.texto, win: window, doc: document }).then((r) => game.toast(r.ok ? `${textoDoSalvamento(r)} Guarde-o em lugar seguro.` : textoDoSalvamento(r), 3600));
    });
    const inputImportar = $('input-import-progress');
    $('btn-import-progress').addEventListener('click', () => inputImportar.click());
    inputImportar.addEventListener('change', async () => {
      const arquivo = inputImportar.files?.[0]; inputImportar.value = '';
      if (!arquivo) return;
      if (!(await screens.confirmar('Importar este progresso vai substituir o salvamento atual. A cópia anterior ficará guardada como backup. Continuar?', 'Importar progresso'))) return;
      const lido = await lerArquivo(arquivo); if (!lido.ok) { game.toast(`Não foi possível ler o arquivo: ${lido.error}`); return; }
      const resultado = saveStore.importar(lido.texto, mundo);
      if (!resultado.ok) { game.toast(`Não foi possível importar: ${resultado.error}`); return; }
      game.toast('Progresso importado. Reiniciando…'); setTimeout(() => location.reload(), 700);
    });

    // Modo desenvolvedor por TOQUE (sem teclado e sem mexer na URL)
    const btnDev = $('btn-dev-toggle');
    if (config.debug.allowDevToggle) {
      btnDev.classList.remove('hidden');
      btnDev.textContent = `🛠 Modo desenvolvedor: ${config.debug.devMode ? 'LIGADO' : 'DESLIGADO'}`;
      btnDev.addEventListener('click', () => {
        const gravou = gravarDevMode(!config.debug.devMode);
        const alvo = gravou ? urlSemDev(location.href) : (() => { const u = new URL(location.href); u.searchParams.set('dev', config.debug.devMode ? '0' : '1'); return u.toString(); })();
        if (alvo === location.href) location.reload(); else location.replace(alvo);
      });
    }

    // ---- editor: disponível no menu Canvas sem exigir modo desenvolvedor ----
    let editor = null; let painel = null;
    const abrirEditor = async () => {
      if (!editor) {
        const { createEditor } = await import('./editor/editor-ui.js');
        const { DraftStore } = await import('./editor/drafts.js');
        const { criarClienteServidor } = await import('./editor/dev-server.js');
        const roomIds = [...new Set([...(await loadRoomIndex(config, logger)), ...mundo.ids()])];
        editor = createEditor({ game, config, logger, renderer, canvas, catalog: catalogo, roomIds, fetchJson: defaultFetchJson, drafts: new DraftStore(), servidor: criarClienteServidor() });
        comandos.onGamepadFrame = (pad, estado) => { genesMenu.aoGamepad(estado); catalogoMenu.aoGamepad(estado); editor?.handleGamepad(pad, estado); };
        if (window.__limo) window.__limo.editor = editor;   // modo dev: deixa o editor acessível no console
      }
      game.resume(); editor.open();
    };
    comandos.toggleEditor = () => { void abrirEditor(); };
    const btnEditor = $('btn-editor'); btnEditor.classList.remove('hidden'); btnEditor.addEventListener('click', () => { void abrirEditor(); });
    const btnPausaEditor = $('btn-pause-editor');
    btnPausaEditor.addEventListener('click', () => { void abrirEditor(); });
    $('btn-editor-back').addEventListener('click', () => editor?.toggle());

    // Ferramentas de depuração continuam opcionais e separadas do editor.
    if (config.debug.devMode) {
      const { createDebugPanel } = await import('./debug/debug-panel.js');
      painel = createDebugPanel({ game, config, logger, renderer, canvas });
      comandos.toggleDebug = () => painel.toggle();
      const btnDevPainel = $('btn-dev'); btnDevPainel.classList.remove('hidden');
      btnDevPainel.addEventListener('click', () => painel.toggle());
      window.__limo = { game, config, logger, painel, editor, mundo, mapa, saveStore };
    }
    attachKeyboard(input, config, window, comandos);

    // ---- como começar: tela inicial ou parâmetros de URL ----
    const iniciarParam = params.get('iniciar') || (params.get('editor') === '1' ? 'auto' : null);
    if (iniciarParam === 'novo') game.startNewGame();
    else if (iniciarParam === 'continuar' || iniciarParam === 'auto') { const lido = saveStore.ler(mundo); if (lido.estado === 'ok') game.continueGame(lido.dados); else game.startNewGame(); }
    else { prepararTitulo(); screens.showTitle(true); }
    if (params.get('editor') === '1') void abrirEditor();

    // ---- tamanho da tela e ciclo de vida ----
    const redimensionar = () => {
      const info = renderer.resize();
      if (info) {
        const margem = (window.innerWidth - info.cssWidth) / 2;
        document.documentElement.style.setProperty('--ctl-escala', Math.max(0.7, Math.min(1, (margem - 18) / 150)).toFixed(3));
        document.documentElement.style.setProperty('--hud-escala', Math.max(0.6, Math.min(1, (margem - 8) / 190)).toFixed(3));   // HUD cabe na lateral livre
      }
    };
    window.addEventListener('resize', redimensionar);
    window.addEventListener('orientationchange', () => setTimeout(redimensionar, 200));
    window.visualViewport?.addEventListener('resize', redimensionar);
    redimensionar();
    document.addEventListener('visibilitychange', () => { input.releaseAll(); if (document.hidden) game.saveProgress('saindo'); if (document.hidden && !game.suspended && !game.editing) game.pause(); });
    window.addEventListener('pagehide', () => { game.saveProgress('saindo'); });   // celular: o navegador pode encerrar a aba logo depois
    window.addEventListener('blur', () => input.releaseAll());

    screens.setLoading(false);
    game.start();
    logger.info('geral', `Jogo iniciado${config.debug.devMode ? ' (modo dev)' : ''}.`);
  } catch (e) {
    console.error("Erro fatal ao iniciar o jogo:", e);
    screens.setLoading(false);
    screens.showError(e.message || 'Erro ao iniciar o jogo.', e.details || [String(e.stack || e)]);
  }
}

iniciar();
