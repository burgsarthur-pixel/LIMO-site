// =====================================================================
// CONFIGURAÇÃO CENTRAL DO JOGO
// Todos os números "mexíveis" ficam aqui. Nenhum outro arquivo deve ter
// valores de física/câmera/controles escritos no meio do código.
// Unidades: pixels (px) e segundos (s), a não ser que o comentário diga outra coisa.
// =====================================================================

export const DEFAULT_CONFIG = {
  // Mecânicas do corpo do deus
  mecanicas: {
    pulso: { batidasPorFase: 1, aviso: 0.6 },                       // esfíncteres trocam de estado a cada batida (3,2 s); piscam 0,6 s antes
    fungo: { duracao: 3.5, alcance: 0.95 },                         // fungo de luz fica aceso 3,5 s depois que a luz do Limo o toca (alcance = fração da luz)
    ferida: { tempoCura: 0.9, alcance: 6, custoPadrao: 3, essenciaMax: 9, escuridao: 0.2, inimigoMenosVida: 1 },
  },
  render: {
    internalWidth: 320,        // resolução interna (proporção 4:3). Mude para 640x480 se quiser mais área visível.
    internalHeight: 240,
    maxIntegerScale: 0,        // 0 = maior escala inteira que couber na tela; >0 limita (útil para testar desempenho)
    playerDrawsAfterLayer: 'interactive', // camadas depois desta ficam NA FRENTE do jogador
    backgroundColor: '#0a0e0b',
    pixelPerfect: true,        // true = escala INTEIRA (nítida); false = ocupa a tela toda com escala fracionária
    // --- Iluminação sombria: camada configurável por cima da cena (nunca altera as cores base dos tiles) ---
    darknessOverlay: 0.18,     // 0..1  escuridão translúcida sobre o cenário
    vignetteStrength: 0.68,    // 0..1  escurecimento das bordas (em faixas, estilo 16-bit)
    ambientGlow: 0.08,         // 0..1  luz central suave
    creatureLight: 0.16,       // 0..1  brilho em volta do jogador/criaturas (itens, checkpoints e chefes brilham um pouco mais)
    lightRadius: 70,           // px: alcance da luz do Limo (tocha)
    lightFlicker: 0.06,        // 0..0.2  oscilação da chama
    lightOcclusion: true,      // paredes bloqueiam a luz do Limo (sombras reais)
    lightMapScale: 0.5,        // v1.41.0: resolução do mapa de escuridão (0.25–1). Menor = borda mais esfumaçada e mais barato; 1 = nítido
    lightShadowSoftness: 3,    // v1.41.0: px de "tamanho" da fonte de luz do Limo: penumbra nas sombras das paredes (0 = sombra dura)
    lightShadowSamples: 5,     // v1.41.0: 1–9 amostras da penumbra (mais = mais lisa, mais custo)
    feixes: { ligado: true, celula: 4, raios: 32, poeira: 14, volume: 0.22, superficie: 0.75, quique: 0.35, furo: 1.6 },   // v1.42.0: feixes de luz físicos (js/render/feixes.js). celula = px por célula do campo (maior = mais barato/mais macio)
    lightHalo: 0.34,           // v1.41.0: bruma larga em volta de cada luz (0 desliga)
    shadowDepth: 0.5,          // 0..0.9  quanto o que está FORA da luz escurece (somado a darknessOverlay)
    darknessColor: [10, 6, 22], // azul-violeta de luto; as luzes quentes/verdes ganham contraste
    melancholyTint: [44, 25, 70],
    melancholyStrength: 0.11,   // véu frio discreto, Canvas 2D e sem shader WebGL
    organicBackground: true,   // fundo contínuo e orgânico (sem tiles quadrados visíveis)
    vida: { ligado: true },   // v1.38.0: mundo vivo (ecossistema, clima, esporelitos). `nivel`: 0 desliga, 1 leve, 2 completo; sem `nivel`, Android/celular usa 1
    tileReacao: { ligado: true, forca: 1, maxEsporos: 36 },   // v1.28.0: decoração se mexe quando Limo/inimigos passam (só visual)
    autotileBorders: true,     // contornos irregulares dos tiles de autotile (desligar ajuda a diagnosticar linhas)
  },
  transition: {
    outTime: 0.36,             // s para fechar suavemente antes de trocar de sala
    inTime: 0.48,               // s para revelar suavemente a sala nova
  },
  loop: {
    fixedStep: 1 / 60,         // passo fixo da física (s). A física não depende do FPS do aparelho.
    maxStepsPerFrame: 5,       // evita "espiral da morte" se o aparelho travar
    maxFrameTime: 0.1,         // tempo máximo (s) aceito entre dois quadros
  },
  physics: {
    maxSpeed: 100,             // velocidade horizontal máxima (px/s)
    acceleration: 900,         // px/s² ao andar
    deceleration: 1100,        // px/s² ao soltar o controle
    turnMultiplier: 1.8,       // aceleração extra ao inverter a direção
    airControl: 0.7,           // 0..1: fração do controle que existe no ar
    gravity: 1000,             // px/s²
    fallGravityMultiplier: 1.25, // queda um pouco mais rápida que a subida (pulo mais "firme")
    jumpSpeed: 380,            // velocidade inicial do pulo (px/s). Altura ≈ jumpSpeed² / (2·gravity)
    jumpCutFactor: 0.45,       // ao soltar o pulo subindo, a velocidade vertical é multiplicada por isto
    maxFallSpeed: 420,         // velocidade máxima de queda (px/s)
    coyoteTime: 0.1,           // pode pular até 0,1 s depois de sair da borda
    jumpBufferTime: 0.12,      // o pulo apertado até 0,12 s antes de aterrissar é lembrado
    dropThroughTime: 0.2,      // tempo atravessando plataforma para baixo (↓ + pulo)
  },
  dash: {                      // "investida orgânica"
    speed: 260,
    duration: 0.16,
    cooldown: 0.3,             // recuperação depois da investida
    airDashes: 1,              // investidas no ar por salto (recarrega ao tocar o chão)
    exitSpeedFactor: 0.6,      // fração da velocidade máxima mantida ao terminar
    recoilSpeed: 150,          // impacto: ao bater num inimigo a investida acaba e o Limo é jogado para trás (px/s)
    recoilTime: 0.16,          // s sem controle horizontal depois do impacto
    recoilLift: 55,            // pequeno pulinho do impacto (px/s)
    enemyKnockback: 120,       // empurrão num inimigo LEVE atingido (pesados e chefes não se movem) (px/s)
  },
  player: {
    hitbox: { w: 10, h: 12 },  // caixa de colisão (independente da arte)
    sprite: { w: 16, h: 16, offsetX: 0, offsetY: 0 }, // arte é ancorada no centro-base da hitbox
    maxLife: 5,
    invulnerability: 1.2,      // s de invulnerabilidade depois de levar dano
    hurtTime: 0.25,            // s sem controle depois do dano
    knockbackX: 90,
    knockbackY: 140,
    voidMargin: 48,            // cair mais que isto abaixo da sala = "queda no vazio"
    healAtCheckpoint: true,    // ao ativar um checkpoint, a vida volta ao máximo
    safeSpotDelay: 0.2,        // s em chão firme para registrar posição segura de respawn
    safeSpotMargin: 8,         // px de distância mínima da borda do chão para a posição ser considerada segura
  },
  abilities: {
    initial: { investida: true }, // mutações que o jogador já possui ao começar
    saltoElastico: { extraJumps: 1, speedFactor: 0.92 }, // 2º pulo no ar: quantos e com que força (× jumpSpeed)
    tendril: { alcance: 104, velocidadePuxao: 92, toleranciaLinha: 2 },
    instanteVital: { duracao: 0.7, escalaMinima: 0.15, entrada: 0.06, saida: 0.25 },   // v1.40.0: desaceleração do mundo ao concluir uma cura (ver entities/instante-vital.js)
  },
  foco: {},    // ajustes do foco/cura (ver FOCO_DEFAULTS em js/entities/foco.js)
  melee: {},   // ajustes do ataque básico (ver MELEE_DEFAULTS em js/entities/melee.js)
  camera: {
    followSpeed: 8,            // maior = câmera mais "colada" no jogador; menor = mais suave
  },
  controls: {
    keyboard: {
      actions: {
        left: ['KeyA', 'ArrowLeft'],
        right: ['KeyD', 'ArrowRight'],
        up: ['KeyW', 'ArrowUp'],
        down: ['KeyS', 'ArrowDown'],
        jump: ['Space', 'KeyZ'], // W/↑ ficam livres para o golpe direcionado para cima
        dash: ['ShiftLeft', 'ShiftRight', 'KeyK', 'KeyX'], // tecla da investida (configurável)
        tendril: ['KeyV'],
        attack: ['KeyJ', 'KeyC'],                       // ataque básico (combo de 3)
        foco: ['KeyF', 'KeyH'],                         // foco: segure parado no chão para curar com material biológico
        interact: ['KeyE'],                             // descansar no Casulo de Repouso (↑/W e joystick/direcional para cima também descansam)
      },
      commands: {
        pause: ['Escape', 'KeyP'],
        debug: ['F3', 'Backquote'],   // só funciona com ?dev=1
        editor: ['F4'],               // editor de mapas (só com ?dev=1)
        map: ['KeyM'],                // mapa de exploração
      },
    },
    gamepad: {                 // índices do mapeamento "standard" da Gamepad API
      deadzone: 0.28,
      left: [14], right: [15], up: [12], down: [13],
      jump: [0], dash: [1, 2], tendril: [3], attack: [5, 7], foco: [4, 6],
      // Botões de sistema do padrão Xbox/Standard: Back, Start, L3 e R3.
      mapButton: 8, pauseButton: 9, debugButton: 10, editorButton: 11,
      // Editor: A=desenhar, B=apagar/cancelar, X=conta-gotas, Y=trocar ferramenta.
      editor: { confirm: 0, cancel: 1, eyedropper: 2, cycleTool: 3, previousTile: 4, nextTile: 5,
        zoomOut: 6, zoomIn: 7, close: 8, test: 9, toggleGrid: 10, nextLayer: 11,
        cursorAxisX: 0, cursorAxisY: 1, panAxisX: 2, panAxisY: 3 },
    },
  },
  rooms: {
    path: 'data/rooms/',
    tilesFile: 'data/tiles.json',
    startRoom: 'raizes_camara',
  },
  debug: {
    devMode: false,            // ligado por ?dev=1, pelo botão do menu de pausa, ou editando aqui. DESLIGADO por padrão.
    allowDevToggle: true,      // mostra o botão "Modo desenvolvedor" no menu de pausa. Ponha false na versão final.
    maxLogEntries: 300,
    dedupeWindowMs: 1000,      // mensagens idênticas dentro deste tempo viram "×N"
    mirrorToConsole: false,
    metricsIntervalMs: 250,
  },
};

// ---------- utilidades de configuração ----------

export function deepClone(valor) { return JSON.parse(JSON.stringify(valor)); }

/** Copia `origem` por cima de `destino` (mantendo a identidade dos objetos de destino). */
export function assignDeep(destino, origem) {
  for (const [chave, valor] of Object.entries(origem)) {
    const ehObjeto = valor && typeof valor === 'object' && !Array.isArray(valor);
    if (ehObjeto && destino[chave] && typeof destino[chave] === 'object' && !Array.isArray(destino[chave])) {
      assignDeep(destino[chave], valor);
    } else {
      destino[chave] = Array.isArray(valor) ? valor.slice() : valor;
    }
  }
  return destino;
}

/** Cria uma configuração nova (cópia independente dos padrões). */
export function createConfig(overrides = null) {
  const config = deepClone(DEFAULT_CONFIG);
  if (overrides) assignDeep(config, overrides);
  return config;
}

export function getByPath(obj, caminho) { return caminho.split('.').reduce((o, k) => (o == null ? o : o[k]), obj); }

export function setByPath(obj, caminho, valor) {
  const chaves = caminho.split('.');
  const ultima = chaves.pop();
  chaves.reduce((o, k) => o[k], obj)[ultima] = valor;
}

/** Restaura todos os padrões (mantém o modo dev ligado/desligado como estava). */
export function resetToDefaults(config) {
  const dev = config.debug.devMode;
  assignDeep(config, deepClone(DEFAULT_CONFIG));
  config.debug.devMode = dev;
  return config;
}

// ---------- parâmetros editáveis no painel de debug ----------
export const PARAM_SCHEMA = [
  { grupo: 'Movimento', path: 'physics.maxSpeed', label: 'Velocidade máxima', min: 20, max: 300, step: 5, unidade: 'px/s' },
  { grupo: 'Movimento', path: 'physics.acceleration', label: 'Aceleração', min: 100, max: 4000, step: 50, unidade: 'px/s²' },
  { grupo: 'Movimento', path: 'physics.deceleration', label: 'Desaceleração', min: 100, max: 4000, step: 50, unidade: 'px/s²' },
  { grupo: 'Movimento', path: 'physics.airControl', label: 'Controle aéreo', min: 0, max: 1, step: 0.05, unidade: '0-1' },
  { grupo: 'Pulo', path: 'physics.gravity', label: 'Gravidade', min: 200, max: 3000, step: 25, unidade: 'px/s²' },
  { grupo: 'Pulo', path: 'physics.jumpSpeed', label: 'Força do pulo', min: 100, max: 800, step: 10, unidade: 'px/s' },
  { grupo: 'Pulo', path: 'physics.maxFallSpeed', label: 'Velocidade de queda', min: 100, max: 1000, step: 10, unidade: 'px/s' },
  { grupo: 'Pulo', path: 'physics.fallGravityMultiplier', label: 'Gravidade na queda (×)', min: 1, max: 3, step: 0.05, unidade: '×' },
  { grupo: 'Pulo', path: 'physics.jumpCutFactor', label: 'Corte do pulo', min: 0, max: 1, step: 0.05, unidade: '0-1' },
  { grupo: 'Pulo', path: 'physics.coyoteTime', label: 'Coyote time', min: 0, max: 0.5, step: 0.01, unidade: 's' },
  { grupo: 'Pulo', path: 'physics.jumpBufferTime', label: 'Jump buffer', min: 0, max: 0.5, step: 0.01, unidade: 's' },
  { grupo: 'Pulo', path: 'abilities.saltoElastico.speedFactor', label: 'Salto Elástico: força (× pulo)', min: 0.3, max: 1.5, step: 0.01, unidade: '×' },
  { grupo: 'Investida', path: 'dash.speed', label: 'Velocidade', min: 50, max: 800, step: 10, unidade: 'px/s' },
  { grupo: 'Investida', path: 'dash.duration', label: 'Duração', min: 0.03, max: 0.6, step: 0.01, unidade: 's' },
  { grupo: 'Investida', path: 'dash.recoilSpeed', label: 'Recuo do Limo no impacto', min: 0, max: 400, step: 10, unidade: 'px/s' },
  { grupo: 'Investida', path: 'dash.enemyKnockback', label: 'Empurrão em inimigo leve', min: 0, max: 400, step: 10, unidade: 'px/s' },
  { grupo: 'Investida', path: 'dash.cooldown', label: 'Recuperação', min: 0, max: 2, step: 0.05, unidade: 's' },
  { grupo: 'Jogador', path: 'player.maxLife', label: 'Vida máxima (vale ao reiniciar)', min: 1, max: 20, step: 1, unidade: '' },
  { grupo: 'Jogador', path: 'player.invulnerability', label: 'Invulnerabilidade pós-dano', min: 0, max: 5, step: 0.1, unidade: 's' },
  { grupo: 'Câmera', path: 'camera.followSpeed', label: 'Seguimento (maior = mais rígida)', min: 1, max: 60, step: 1, unidade: '1/s' },
  { grupo: 'Vídeo', path: 'render.maxIntegerScale', label: 'Escala máxima (0 = automática)', min: 0, max: 8, step: 1, unidade: '×' },
];

/** Valida o texto digitado para um parâmetro. Devolve {ok:true,value} ou {ok:false,error}. */
export function validateParam(item, bruto) {
  if (bruto === null || bruto === undefined || String(bruto).trim() === '') {
    return { ok: false, error: 'Informe um número.' };
  }
  const n = Number(String(bruto).trim().replace(',', '.'));
  if (!Number.isFinite(n)) return { ok: false, error: 'Valor inválido: use apenas números.' };
  if (n < item.min || n > item.max) return { ok: false, error: `Fora do limite (${item.min} a ${item.max}).` };
  return { ok: true, value: n };
}

/** Só os parâmetros que diferem do padrão (para exportar). */
export function paramsDiff(config) {
  const diff = {};
  for (const item of PARAM_SCHEMA) {
    const atual = getByPath(config, item.path);
    const padrao = getByPath(DEFAULT_CONFIG, item.path);
    if (atual !== padrao) {
      const partes = item.path.split('.');
      const ultima = partes.pop();
      let alvo = diff;
      for (const p of partes) alvo = alvo[p] = alvo[p] || {};
      alvo[ultima] = atual;
    }
  }
  return diff;
}

export function exportParamsJson(config) {
  return JSON.stringify({ formato: 'limo-parametros', versao: 1, parametros: paramsDiff(config) }, null, 2);
}
