// =====================================================================
// DEBUG: DESENHOS POR CIMA DO JOGO (hitboxes, colisões, limites)
// Usa a MESMA consulta de colisão da física, então mostra exatamente o que o jogo "vê".
// =====================================================================
import { spriteRect } from '../render/player-art.js';

export const DEBUG_COLORS = {
  playerHitbox: '#00ff66',  // hitbox do jogador
  spriteBox: '#ff40ff',     // retângulo da arte (separado da hitbox)
  solid: '#3b82ff',         // tiles sólidos
  oneway: '#00e5ff',        // plataformas atravessáveis por baixo
  damage: '#ff3030',        // zonas de dano
  roomBounds: '#ffd400',    // limites da sala
  cameraBounds: '#ff9100',  // limites do centro da câmera
  contact: '#ffffff',       // lados com contato
  groundProbe: '#ffff66',   // faixa de detecção de chão
  transition: '#ff7be5',    // passagens entre salas (área) e seu ponto de chegada
  object: '#7be5ff',        // checkpoints e mutações
};

function caixa(ctx, x, y, w, h, cor, tracejada = false) {
  ctx.strokeStyle = cor; ctx.lineWidth = 1;
  ctx.setLineDash?.(tracejada ? [3, 2] : []);
  ctx.strokeRect(Math.round(x) + 0.5, Math.round(y) + 0.5, Math.max(1, Math.round(w) - 1), Math.max(1, Math.round(h) - 1));
  ctx.setLineDash?.([]);
}

export function drawDebugOverlay(ctx, game, camX, camY) {
  const o = game.debug.overlays; const mapa = game.map; const cfg = game.config;
  if (!mapa || game.debug.visual === false) return;   // interruptor mestre do "debug visual"
  const vw = cfg.render.internalWidth; const vh = cfg.render.internalHeight;

  if (o.solids || o.platforms || o.damage) {
    mapa.forEachCollidable(camX, camY, vw, vh, (c) => {
      const cor = c.kind === 'solid' ? (o.solids && DEBUG_COLORS.solid)
        : c.kind === 'oneway' ? (o.platforms && DEBUG_COLORS.oneway)
          : (o.damage && DEBUG_COLORS.damage);
      if (cor) caixa(ctx, c.x - camX, c.y - camY, c.w, c.h, cor);
    });
  }

  // Desenha passagens/transições e objetos se ativado no debug
  if (o.transitions && game.roomData) {
    const ts = mapa.tileSize;
    for (const c of game.roomData.connections || []) {
      caixa(ctx, c.trigger.x * ts - camX, c.trigger.y * ts - camY, c.trigger.w * ts, c.trigger.h * ts, DEBUG_COLORS.transition, true);
    }
  }
  if (o.entities && game.roomData) {   // entidades separadas das passagens, para isolar qual camada desenha o quê
    const ts = mapa.tileSize;
    for (const e of game.roomData.entities || []) if (e.type !== 'playerStart') caixa(ctx, e.x * ts - camX, e.y * ts - camY, ts, ts, DEBUG_COLORS.object);
  }
  if (o.gridTiles) {   // grade de tiles SOBRE o jogo (só diagnóstico; começa desligada)
    const ts = mapa.tileSize; ctx.fillStyle = 'rgba(255,255,255,0.16)';
    for (let x = -(Math.round(camX) % ts); x < vw; x += ts) ctx.fillRect(x, 0, 1, vh);
    for (let y = -(Math.round(camY) % ts); y < vh; y += ts) ctx.fillRect(0, y, vw, 1);
  }

  if (o.roomBounds) caixa(ctx, -camX, -camY, mapa.pixelWidth, mapa.pixelHeight, DEBUG_COLORS.roomBounds, true);
  if (o.cameraBounds) {
    const r = game.camera.centerRange(mapa.pixelWidth, mapa.pixelHeight);
    caixa(ctx, r.minX - camX, r.minY - camY, r.maxX - r.minX + 1, r.maxY - r.minY + 1, DEBUG_COLORS.cameraBounds, true);
    const cx = Math.round(game.camera.x + vw / 2 - camX); const cy = Math.round(game.camera.y + vh / 2 - camY);
    ctx.fillStyle = DEBUG_COLORS.cameraBounds; ctx.fillRect(cx - 3, cy, 7, 1); ctx.fillRect(cx, cy - 3, 1, 7);
  }
  if (o.spriteBox) {
    const s = spriteRect(game.player, camX, camY, cfg);
    caixa(ctx, s.x, s.y, s.w, s.h, DEBUG_COLORS.spriteBox, true);
  }
  if (o.hitboxes) {
    const b = game.player.body;
    caixa(ctx, b.x - camX, b.y - camY, b.w, b.h, DEBUG_COLORS.playerHitbox);
    caixa(ctx, b.x - camX, b.y + b.h - camY, b.w, 1, DEBUG_COLORS.groundProbe);
    const c = game.player.contacts; ctx.fillStyle = DEBUG_COLORS.contact;
    if (c.left) ctx.fillRect(Math.round(b.x - camX) - 2, Math.round(b.y - camY), 2, b.h);
    if (c.right) ctx.fillRect(Math.round(b.x + b.w - camX), Math.round(b.y - camY), 2, b.h);
    if (c.up) ctx.fillRect(Math.round(b.x - camX), Math.round(b.y - camY) - 2, b.w, 2);
    if (game.player.onGround) ctx.fillRect(Math.round(b.x - camX), Math.round(b.y + b.h - camY), b.w, 2);
  }
}
