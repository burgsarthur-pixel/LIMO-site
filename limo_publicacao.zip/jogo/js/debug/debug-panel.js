// =====================================================================
// PAINEL DE DEBUG (SÓ EM MODO DESENVOLVIMENTO: abra o jogo com ?dev=1)
// Mostra valores reais atualizados durante a execução, permite mexer em parâmetros
// com validação, teleportar, pausar, avançar quadro a quadro etc.
// Este arquivo só é carregado quando devMode está ligado.
// =====================================================================
import { PARAM_SCHEMA, validateParam, getByPath, setByPath, resetToDefaults, exportParamsJson } from '../config.js';
import { LAYER_NAMES } from '../world/tilemap.js';
import { LOG_CATEGORIES, LOG_LEVELS } from '../core/logger.js';
import { drawDebugOverlay, DEBUG_COLORS } from './debug-overlay.js';
import { ABILITIES } from '../entities/abilities.js';

const OVERLAYS = [
  ['hitboxes', 'Hitbox do jogador + contatos', DEBUG_COLORS.playerHitbox],
  ['entities', 'Entidades (checkpoints, mutações, vida)', DEBUG_COLORS.object],
  ['spriteBox', 'Retângulo da arte (sprite)', DEBUG_COLORS.spriteBox],
  ['transitions', 'Passagens (gatilhos)', DEBUG_COLORS.transition],
  ['solids', 'Tiles sólidos', DEBUG_COLORS.solid],
  ['platforms', 'Plataformas (atravessáveis)', DEBUG_COLORS.oneway],
  ['damage', 'Zonas de dano', DEBUG_COLORS.damage],
  ['roomBounds', 'Limites da sala', DEBUG_COLORS.roomBounds],
  ['cameraBounds', 'Limites da câmera', DEBUG_COLORS.cameraBounds],
];

const f1 = (n) => (Number.isFinite(n) ? n.toFixed(1) : '—');
const f0 = (n) => (Number.isFinite(n) ? String(Math.round(n)) : '—');

export function createDebugPanel({ game, config, logger, renderer, canvas = null, doc = document, win = (typeof window !== 'undefined' ? window : null) }) {
  // ---------- pequenas ferramentas de DOM ----------
  const h = (tag, props = {}, ...filhos) => {
    const el = doc.createElement(tag);
    for (const [k, v] of Object.entries(props)) { if (k === 'class') el.className = v; else if (k === 'text') el.textContent = v; else el[k] = v; }
    for (const f of filhos) if (f) el.appendChild(f);
    return el;
  };
  const botao = (texto, fn, titulo = '') => { const b = h('button', { text: texto, type: 'button', title: titulo, class: 'dbg-btn' }); b.addEventListener('click', fn); return b; };
  const secao = (titulo, aberta = false) => {
    const corpo = h('div', { class: 'dbg-body' });
    const det = h('details', {}, h('summary', { text: titulo }), corpo);
    det.open = aberta;
    return { det, corpo };
  };
  const checkbox = (texto, valor, aoMudar, cor = null) => {
    const input = h('input', { type: 'checkbox' }); input.checked = !!valor;
    input.addEventListener('change', () => aoMudar(input.checked));
    const marca = cor ? h('i', { class: 'dbg-swatch' }) : null; if (marca) marca.style.background = cor;
    const label = h('label', { class: 'dbg-check' }, input, marca, h('span', { text: texto }));
    return { label, input };
  };

  const painel = h('aside', { id: 'debug-panel', class: 'hidden' });
  const cabecalho = h('div', { class: 'dbg-head' }, h('b', { text: 'DEBUG · modo dev' }));
  const fechar = botao('✕', () => api.close(), 'Fechar'); cabecalho.appendChild(fechar);
  painel.appendChild(cabecalho);

  // ---------- 1. métricas ao vivo ----------
  const metr = secao('Métricas (ao vivo)', true);
  const LINHAS = [
    ['FPS', (g) => f0(g.metrics.fps)],
    ['Delta time (ms)', (g) => f1(g.metrics.dt * 1000)],
    ['Atualização (ms)', (g) => g.metrics.updateMs.toFixed(2)],
    ['Render (ms)', (g) => g.metrics.renderMs.toFixed(2)],
    ['Passos de física/quadro', (g) => `${g.metrics.stepsLastFrame} (total ${g.metrics.totalSteps})`],
    ['Posição X, Y', (g) => `${f1(g.player.body.x)}, ${f1(g.player.body.y)}`],
    ['Velocidade X, Y', (g) => `${f1(g.player.vx)}, ${f1(g.player.vy)}`],
    ['Estado', (g) => g.player.state + (g.paused ? ' (JOGO PAUSADO)' : '')],
    ['Vida', (g) => `${g.player.life}/${g.player.maxLife}  invuln ${g.player.invuln.toFixed(2)}s`],
    ['Habilidades', (g) => Object.entries(g.player.abilities).filter(([, v]) => v).map(([k]) => k).join(', ') || '(nenhuma)'],
    ['Sala', (g) => (g.map ? `${g.map.id} (${g.map.width}x${g.map.height} tiles)` : 'nenhuma')],
    ['Tile do jogador', (g) => (g.map ? `${Math.floor(g.player.centerX / g.map.tileSize)}, ${Math.floor(g.player.centerY / g.map.tileSize)}` : '—')],
    ['Entidades ativas', (g) => `1 jogador + ${g.roomData ? g.roomData.entities.filter((e) => e.type !== 'playerStart').length : 0} objeto(s) + ${g.roomData ? g.roomData.connections.length : 0} passagem(ns). Inimigos: ${g.enemies ? g.enemies.length : 0}`],
    ['Checkpoint', (g) => (g.progress && g.progress.checkpoint ? `${g.progress.checkpoint.sala}.${g.progress.checkpoint.id}` : '(nenhum)')],
    ['Progresso', (g) => (g.progress ? `${g.progress.visited.size} sala(s) · ${g.progress.collected.size} item(ns) permanente(s)${g.sandbox ? ' · TESTE DO EDITOR (não salva)' : ''}` : '—')],
    ['Tiles visíveis', () => (renderer ? `${renderer.visibleTiles} desenhados / ${renderer.visibleCells} células` : '—')],
    ['Colisões (E D C B)', (g) => { const c = g.player.contacts; return `${c.left ? 'E' : '-'} ${c.right ? 'D' : '-'} ${c.up ? 'C' : '-'} ${g.player.onGround ? 'B' : '-'}`; }],
    ['Chão', (g) => (g.player.groundInfo ? `${g.player.groundInfo.tile.name} (atrito ${g.player.groundInfo.tile.friction})` : 'no ar')],
    ['Coyote / buffer (s)', (g) => `${g.player.coyote.toFixed(2)} / ${g.player.jumpBuffer.toFixed(2)}`],
    ['Investida', (g) => `${g.player.dashing ? 'ATIVA' : 'pronta'} · recarga ${g.player.dashCooldown.toFixed(2)}s · ar ${g.player.airDashesLeft}`],
    ['Câmera X, Y', (g) => `${f1(g.camera.x)}, ${f1(g.camera.y)}`],
    ['Escala da tela', () => (renderer && renderer.displayInfo ? `${renderer.displayInfo.scale.toFixed(2)}× ${renderer.displayInfo.integer ? '(inteira)' : '(fracionária)'}` : '—')],
    ['Último erro de carregamento', () => { const e = logger.lastError('carregamento'); return e ? e.message : 'nenhum'; }],
    ['Último erro de salvamento', () => { const e = logger.lastError('salvamento'); return e ? e.message : 'nenhum'; }],
    ['Último erro de transição', () => { const e = logger.lastError('transicoes'); return e ? e.message : 'nenhum'; }],
    ['Último erro geral', () => { const e = logger.lastError(); return e ? `[${e.category}] ${e.message}` : 'nenhum'; }],
  ];
  const celulas = LINHAS.map(([rotulo]) => {
    const valor = h('span', { class: 'dbg-val', text: '—' });
    metr.corpo.appendChild(h('div', { class: 'dbg-row' }, h('span', { text: rotulo }), valor));
    return valor;
  });
  painel.appendChild(metr.det);

  // ---------- 2. desenhos por cima do jogo ----------
  const ov = secao('Desenhos por cima do jogo');
  const checks = {};
  for (const [chave, texto, cor] of OVERLAYS) {
    const c = checkbox(texto, game.debug.overlays[chave], (v) => { game.debug.overlays[chave] = v; }, cor);
    checks[chave] = c; ov.corpo.appendChild(c.label);
  }
  ov.corpo.appendChild(h('div', { class: 'dbg-sub', text: 'Camadas do TileMap' }));
  for (const nome of LAYER_NAMES) ov.corpo.appendChild(checkbox(nome, game.debug.layers[nome], (v) => { game.debug.layers[nome] = v; }).label);
  painel.appendChild(ov.det);

  // ---------- 2b. diagnóstico de LINHAS/GRADE: cada fonte possível pode ser isolada separadamente ----------
  const dg = secao('Diagnóstico: de onde vêm as linhas?');
  const dd = game.debug; const marcar = (obj, chave) => (v) => { obj[chave] = v; };
  dg.corpo.appendChild(h('div', { class: 'dbg-sub', text: 'Desligue um por vez e veja qual camada some com a linha' }));
  dg.corpo.appendChild(checkbox('Grade do Editor', !!dd.editorGrid, marcar(dd, 'editorGrid')).label);
  dg.corpo.appendChild(checkbox('Grade de tiles sobre o jogo', dd.overlays.gridTiles, marcar(dd.overlays, 'gridTiles')).label);
  dg.corpo.appendChild(checkbox('Colisões (sólidos + plataformas + dano)', dd.overlays.solids && dd.overlays.platforms && dd.overlays.damage,
    (v) => { dd.overlays.solids = dd.overlays.platforms = dd.overlays.damage = v; }).label);
  dg.corpo.appendChild(checkbox('Bordas de autotile', dd.render.autotileBorders, marcar(dd.render, 'autotileBorders')).label);
  dg.corpo.appendChild(checkbox('Hitboxes', dd.overlays.hitboxes, marcar(dd.overlays, 'hitboxes')).label);
  dg.corpo.appendChild(checkbox('Entidades', dd.overlays.entities, marcar(dd.overlays, 'entities')).label);
  dg.corpo.appendChild(checkbox('Fundo orgânico contínuo', dd.render.organicBackground, marcar(dd.render, 'organicBackground')).label);
  dg.corpo.appendChild(checkbox('Decoração reativa (tiles animados)', dd.render.tileReacao, marcar(dd.render, 'tileReacao')).label);
  dg.corpo.appendChild(checkbox('Mundo vivo (clima, esporelitos, vida da flora)', dd.render.vida, marcar(dd.render, 'vida')).label);
  dg.corpo.appendChild(checkbox('Iluminação sombria', dd.render.lighting, marcar(dd.render, 'lighting')).label);
  dg.corpo.appendChild(checkbox('2.5D: volume dos tiles', dd.render.depthVolume, marcar(dd.render, 'depthVolume')).label);
  dg.corpo.appendChild(checkbox('2.5D: parallax em camadas', dd.render.depthParallax, marcar(dd.render, 'depthParallax')).label);
  dg.corpo.appendChild(checkbox('Debug visual (interruptor mestre)', dd.visual, marcar(dd, 'visual')).label);
  painel.appendChild(dg.det);

  // ---------- 3. ações ----------
  const ac = secao('Ações', true);
  const botaoPausa = botao('Pausar', () => { game.togglePause(); atualizarBotoes(); });
  const aviso = h('div', { class: 'dbg-note' });
  const acaoCheck = (texto, valor, fn) => { const c = checkbox(texto, valor, fn); ac.corpo.appendChild(c.label); return c; };
  ac.corpo.append(
    botaoPausa,
    botao('Passo (1 quadro)', () => { if (!game.paused) game.pause(); game.stepOnce(); atualizarBotoes(); }, 'Pausa e avança um passo de física'),
    botao('Reiniciar sala', () => { game.restartRoom(); }),
    botao('Restaurar vida', () => { game.restoreLife(); }),
    botao('Ir ao início', () => { game.teleportPlayer(game.spawn.x, game.spawn.y); }),
    botao('Sala experimental 2.5D', async () => {   // v1.38: carrega data/experimentais/raizes_profundidade.json (fora do índice: não mexe em mapa, rotas nem progressão)
      const ID = 'raizes_profundidade';
      try {
        if (!game.world.has(ID)) { const r = await fetch('data/experimentais/raizes_profundidade.json', { cache: 'no-cache' }); game.world.addRoom(await r.json()); }
        game.enterRoom(ID, { healFull: true });
      } catch (e) { aviso.textContent = `Sala 2.5D indisponível: ${e.message}`; }
    }, 'Raízes com parallax em 3 planos + tiles volumétricos'),
  );
  const invul = acaoCheck('Invulnerabilidade', game.player.godMode, (v) => { game.player.godMode = v; });
  const noclip = acaoCheck('Colisões desligadas (voar: ←→ e pulo/↓)', game.player.noclip, (v) => { game.player.noclip = v; });
  const tpClick = acaoCheck('Teleportar tocando no mapa', game.debug.teleportOnClick, (v) => { game.debug.teleportOnClick = v; });
  ac.corpo.appendChild(h('div', { class: 'dbg-sub', text: 'Teleportar para tile (x, y)' }));
  const tx = h('input', { type: 'number', value: '4', class: 'dbg-num' }); const ty = h('input', { type: 'number', value: '26', class: 'dbg-num' });
  ac.corpo.appendChild(h('div', { class: 'dbg-row' }, tx, ty, botao('Ir', () => {
    const x = Number(tx.value); const y = Number(ty.value);
    if (!game.map || !Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x >= game.map.width || y >= game.map.height) { aviso.textContent = 'Tile fora da sala.'; logger.warn('interface', `Teleporte inválido: (${tx.value}, ${ty.value}).`); return; }
    aviso.textContent = '';
    const ts = game.map.tileSize;
    game.teleportPlayer((x + 0.5) * ts - game.player.body.w / 2, (y + 1) * ts - game.player.body.h);
  })));
  ac.corpo.appendChild(aviso);
  
  if (game.world) {
    ac.corpo.appendChild(h('div', { class: 'dbg-sub', text: 'Trocar de sala (mantém vida e habilidades)' }));
    const selSala = h('select', { class: 'dbg-sel' }); for (const id of game.world.ids()) selSala.appendChild(h('option', { value: id, text: id }));
    ac.corpo.appendChild(h('div', { class: 'dbg-row' }, selSala, botao('Ir', () => { game.enterRoom(selSala.value); logger.info('transicoes', `Debug: foi para "${selSala.value}".`); })));
    ac.corpo.append(botao('Apagar salvamento', () => { game.saveStore?.apagar(); logger.info('salvamento', 'Debug: salvamento apagado.'); }));
  }

  ac.corpo.appendChild(h('div', { class: 'dbg-sub', text: 'Habilidades (mutações)' }));
  const habChecks = {};
  for (const id of Object.keys(game.player.abilities)) {
    habChecks[id] = checkbox(ABILITIES[id] && !ABILITIES[id].implementada ? `${id} (sem efeito ainda)` : id, game.player.abilities[id], (v) => { game.player.abilities[id] = v; logger.info('habilidades', `${id} ${v ? 'desbloqueada' : 'bloqueada'} pelo debug.`); });
    ac.corpo.appendChild(habChecks[id].label);
  }
  painel.appendChild(ac.det);

  // ---------- 4. parâmetros ----------
  const pa = secao('Parâmetros em tempo real');
  const entradas = [];
  let grupoAtual = '';
  for (const item of PARAM_SCHEMA) {
    if (item.grupo !== grupoAtual) { grupoAtual = item.grupo; pa.corpo.appendChild(h('div', { class: 'dbg-sub', text: grupoAtual })); }
    const input = h('input', { type: 'text', class: 'dbg-num', title: `${item.min} a ${item.max}` });
    input.setAttribute('inputmode', 'decimal');
    input.dataset.path = item.path;
    const erro = h('span', { class: 'dbg-erro' });
    const mostrar = () => { input.value = String(getByPath(config, item.path)); input.classList.remove('invalido'); erro.textContent = ''; };
    mostrar();
    input.addEventListener('change', () => {
      const r = validateParam(item, input.value);
      if (!r.ok) { input.classList.add('invalido'); erro.textContent = r.error; logger.warn('interface', `Parâmetro ${item.path} rejeitado: ${r.error}`); return; }
      input.classList.remove('invalido'); erro.textContent = '';
      setByPath(config, item.path, r.value);
      logger.info('interface', `${item.path} = ${r.value}`);
      game.applyConfigChanges();
    });
    pa.corpo.appendChild(h('div', { class: 'dbg-param' }, h('label', { text: `${item.label} (${item.unidade})` }), input, erro));
    entradas.push({ item, input, mostrar });
  }
  const saida = h('textarea', { class: 'dbg-export', readOnly: true });
  saida.setAttribute('rows', '5');
  pa.corpo.append(
    botao('Restaurar padrões', () => { resetToDefaults(config); entradas.forEach((e) => e.mostrar()); game.applyConfigChanges(); logger.info('interface', 'Parâmetros restaurados aos padrões.'); }),
    botao('Exportar JSON', async () => {
      const texto = exportParamsJson(config); saida.value = texto;
      try { await win?.navigator?.clipboard?.writeText(texto); logger.info('interface', 'Parâmetros copiados para a área de transferência.'); }
      catch (e) { logger.info('interface', 'JSON gerado abaixo (copie manualmente).'); }
    }),
    saida,
  );
  painel.appendChild(pa.det);

  // ---------- 5. console ----------
  const co = secao('Console de debug', true);
  const selCat = h('select', { class: 'dbg-sel' }); selCat.appendChild(h('option', { value: '', text: 'todas as categorias' }));
  for (const c of LOG_CATEGORIES) selCat.appendChild(h('option', { value: c, text: c }));
  const selNivel = h('select', { class: 'dbg-sel' });
  for (const n of Object.keys(LOG_LEVELS)) selNivel.appendChild(h('option', { value: n, text: `≥ ${n}` }));
  selNivel.value = 'info';
  const lista = h('div', { class: 'dbg-log' });
  let sujo = true;
  const desenharConsole = () => {
    sujo = false;
    const itens = logger.query({ category: selCat.value || null, minLevel: selNivel.value }).slice(-80);
    lista.replaceChildren(...itens.map((e) => {
      const hora = new Date(e.time).toISOString().slice(14, 19);
      return h('div', { class: `dbg-line ${e.level}`, text: `${hora} [${e.category}] ${e.message}${e.count > 1 ? `  ×${e.count}` : ''}` });
    }));
    lista.scrollTop = lista.scrollHeight;
  };
  selCat.addEventListener('change', desenharConsole); selNivel.addEventListener('change', desenharConsole);
  co.corpo.append(h('div', { class: 'dbg-row' }, selCat, selNivel),
    botao('Limpar', () => logger.clear()),
    botao('Copiar', async () => { try { await win?.navigator?.clipboard?.writeText(logger.toText(logger.query({ category: selCat.value || null, minLevel: selNivel.value }))); } catch (e) { /* sem permissão */ } }),
    lista);
  logger.subscribe(() => { sujo = true; });
  painel.appendChild(co.det);

  doc.body.appendChild(painel);

  // ---------- atualização periódica ----------
  const atualizarBotoes = () => { botaoPausa.textContent = game.paused ? 'Continuar' : 'Pausar'; };
  const refresh = () => {
    LINHAS.forEach(([, fn], i) => { let t; try { t = fn(game); } catch (e) { t = `erro: ${e.message}`; } if (celulas[i].textContent !== t) celulas[i].textContent = t; });
    invul.input.checked = game.player.godMode; noclip.input.checked = game.player.noclip;
    for (const [id, c] of Object.entries(habChecks)) c.input.checked = !!game.player.abilities[id];
    atualizarBotoes();
    if (sujo) desenharConsole();
  };

  let timer = null;
  const api = {
    element: painel,
    refresh,
    isOpen: () => !painel.classList.contains('hidden'),
    open() {
      painel.classList.remove('hidden'); doc.body.classList.add('debug-open'); refresh();
      if (!timer && win) timer = win.setInterval(refresh, config.debug.metricsIntervalMs);
    },
    close() {
      painel.classList.add('hidden'); doc.body.classList.remove('debug-open');
      if (timer && win) { win.clearInterval(timer); timer = null; }
    },
    toggle() { if (api.isOpen()) api.close(); else api.open(); },
  };

  // ---------- teleporte ao tocar no canvas ----------
  if (canvas) {
    canvas.addEventListener('pointerdown', (e) => {
      if (!game.debug.teleportOnClick || !game.map) return;
      const r = canvas.getBoundingClientRect();
      const x = ((e.clientX - r.left) / r.width) * config.render.internalWidth + Math.round(game.camera.x);
      const y = ((e.clientY - r.top) / r.height) * config.render.internalHeight + Math.round(game.camera.y);
      game.teleportPlayer(x - game.player.body.w / 2, y - game.player.body.h / 2);
    });
  }

  renderer?.addOverlay(drawDebugOverlay);
  logger.info('interface', 'Painel de debug carregado (modo dev).');
  return api;
}
