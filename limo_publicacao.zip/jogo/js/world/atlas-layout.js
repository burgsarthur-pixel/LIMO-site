// =====================================================================
// LAYOUT DO ATLAS EM GRADE DE TILES (1 tile = 1 célula do mapa).
// Regras: (1) duas salas nunca ocupam a mesma célula; (2) a porta de uma sala fica encostada na
// porta pareada da sala vizinha (mesma altura/coluna); (3) é determinístico: mesmo mundo = mesmo mapa.
// Só dados (sem DOM). Usado pelo atlas (ui/world-map.js) e pelo gerador procedural.
// =====================================================================
export const GAP = 2;   // espaço (tiles) entre salas vizinhas no atlas
const OPOSTO = { left: 'right', right: 'left', up: 'down', down: 'up' };

export function ladoDaPorta(d, t) {
  if (t.x === 0) return 'left'; if (t.x + t.w === d.width) return 'right';
  if (t.y === 0) return 'up'; if (t.y + t.h === d.height) return 'down';
  return null;   // gatilho fora da borda (dado legado): o atlas trata como ligação "solta"
}

/** Grade de ocupação: reserva retângulos de tiles e diz se um retângulo novo colide. */
export class GradeAtlas {
  constructor(margem = 1) { this.cel = new Set(); this.margem = margem; }
  _each(x, y, w, h, m, fn) { for (let j = y - m; j < y + h + m; j++) for (let i = x - m; i < x + w + m; i++) if (fn(i, j)) return true; return false; }
  livre(x, y, w, h) { return !this._each(x, y, w, h, 0, (i, j) => this.cel.has(i + ',' + j)); }
  ocupar(x, y, w, h) { this._each(x, y, w, h, 0, (i, j) => { this.cel.add(i + ',' + j); return false; }); }
}

/** Posição ideal de B para encostar sua porta `b` na porta `a` de A. Devolve { x, y, eixo } ou null. */
function posicaoIdeal(A, pa, ca, B, cb) {
  const sa = ladoDaPorta(A, ca.trigger); const sb = cb ? ladoDaPorta(B, cb.trigger) : null;
  if (!sa) return null;
  const ta = ca.trigger; const tb = cb ? cb.trigger : { x: B.width >> 1, y: B.height >> 1, w: 0, h: 0 };
  const cx = pa.x + ta.x + ta.w / 2; const cy = pa.y + ta.y + ta.h / 2;   // centro da porta de A no atlas
  const lado = sb === OPOSTO[sa] ? sa : sa;   // a sala nova sempre sai pelo lado de A; se o par for do mesmo lado, alinha pela borda
  if (lado === 'right' || lado === 'left') {
    const y = sb && ladoDaPorta(B, tb) ? Math.round(cy - (tb.y + tb.h / 2)) : Math.round(cy - B.height / 2);
    return { x: lado === 'right' ? pa.x + A.width + GAP : pa.x - GAP - B.width, y, eixo: 'h', dir: lado === 'right' ? 1 : -1 };
  }
  const x = sb && ladoDaPorta(B, tb) === OPOSTO[sa] ? Math.round(cx - (tb.x + tb.w / 2)) : Math.round(cx - B.width / 2);
  if (sb === sa) {   // portas do mesmo lado (ex.: poço): a sala vai ao lado, com as bordas alinhadas, para não sobrepor
    return { x: pa.x + A.width + GAP, y: lado === 'down' ? pa.y + A.height - B.height : pa.y, eixo: 'h', dir: 1 };
  }
  return { x: Math.round(x), y: lado === 'down' ? pa.y + A.height + GAP : pa.y - GAP - B.height, eixo: 'v', dir: lado === 'down' ? 1 : -1 };
}

/**
 * salas: Map id -> dados da sala; fixas: { id: {x,y} } (posições deliberadas, têm prioridade).
 * Devolve Map id -> {x,y} sem sobreposição. Salas sem posição entram por BFS a partir das já posicionadas.
 */
export function calcularLayoutAtlas(salas, fixas = {}) {
  const pos = new Map(); const grade = new GradeAtlas();
  const por = (id, p) => { pos.set(id, { x: p.x, y: p.y }); const d = salas.get(id); grade.ocupar(p.x, p.y, d.width, d.height); };
  for (const [id, p] of Object.entries(fixas)) if (salas.has(id)) por(id, p);
  // sem nenhuma fixa: começa pela primeira sala usando o mapPos dela (ou 0,0)
  if (!pos.size && salas.size) { const [id, d] = [...salas][0]; por(id, d.mapPos || { x: 0, y: 0 }); }
  const fila = [...pos.keys()];
  const ligacoes = (id) => { // saídas de id + entradas que apontam para id (grafo não direcionado)
    const out = []; const d = salas.get(id);
    for (const c of d.connections || []) if (salas.has(c.to)) out.push({ de: id, a: c.to, c, volta: (salas.get(c.to).connections || []).find((x) => x.id === c.toConnection) });
    for (const [oid, od] of salas) if (oid !== id) for (const c of od.connections || []) if (c.to === id) { const volta = (d.connections || []).find((x) => x.id === c.toConnection); if (volta) out.push({ de: id, a: oid, c: volta, volta: c }); }
    return out;
  };
  const posicionar = (de, a, c, volta) => {
    const A = salas.get(de); const B = salas.get(a); const pa = pos.get(de);
    const ideal = posicaoIdeal(A, pa, c, B, volta) || { x: pa.x + A.width + GAP, y: pa.y, eixo: 'h', dir: 1 };
    // 1) tenta o ideal; 2) desliza ao longo da borda; 3) afasta no eixo principal
    for (let afasta = 0; afasta < 80; afasta += 2) for (let desl = 0; desl < 60; desl += 2) for (const s of desl ? [1, -1] : [1]) {
      const p = ideal.eixo === 'h' ? { x: ideal.x + ideal.dir * afasta, y: ideal.y + s * desl } : { x: ideal.x + s * desl, y: ideal.y + ideal.dir * afasta };
      if (grade.livre(p.x - 1, p.y - 1, B.width + 2, B.height + 2)) return p;
    }
    return { x: pa.x, y: pa.y + A.height + 200 };   // último recurso: bem longe, nunca por cima
  };
  for (let i = 0; i < fila.length; i++) {
    for (const { de, a, c, volta } of ligacoes(fila[i])) {
      if (pos.has(a)) continue; por(a, posicionar(de, a, c, volta)); fila.push(a);
    }
  }
  for (const [id, d] of salas) if (!pos.has(id)) {   // ilhas sem ligação com o resto
    const maxX = Math.max(0, ...[...pos].map(([k, p]) => p.x + salas.get(k).width)); por(id, { x: maxX + GAP * 2, y: 0 });
  }
  return pos;
}

/** Auditoria: devolve lista de problemas (vazia = ok). Sobreposição, portas fora da borda, ida sem volta, portas desencontradas. */
export function auditarAtlas(salas, pos, { alinhamento = true } = {}) {
  const erros = []; const ids = [...salas.keys()];
  for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) {
    const A = salas.get(ids[i]); const B = salas.get(ids[j]); const a = pos.get(ids[i]); const b = pos.get(ids[j]);
    if (a && b && a.x < b.x + B.width && b.x < a.x + A.width && a.y < b.y + B.height && b.y < a.y + A.height) erros.push(`sobreposição: ${ids[i]} × ${ids[j]}`);
  }
  for (const [id, d] of salas) for (const c of d.connections || []) {
    const o = salas.get(c.to); if (!o) { erros.push(`${id}.${c.id}: destino inexistente ${c.to}`); continue; }
    const volta = (o.connections || []).find((x) => x.id === c.toConnection);
    if (!volta) { erros.push(`${id}.${c.id}: ${c.to} não tem a porta "${c.toConnection}"`); continue; }
    if (volta.to !== id || volta.toConnection !== c.id) { erros.push(`${id}.${c.id}: a volta em ${c.to}.${volta.id} aponta para ${volta.to}.${volta.toConnection}`); continue; }
    const sa = ladoDaPorta(d, c.trigger); const sb = ladoDaPorta(o, volta.trigger);
    if (!sa || !sb) { erros.push(`${id}.${c.id}: porta fora da borda da sala`); continue; }
    if (alinhamento && sb === OPOSTO[sa] && pos.get(id) && pos.get(c.to)) {
      const pa = pos.get(id); const pb = pos.get(c.to);
      const horiz = sa === 'left' || sa === 'right';
      const ca = horiz ? pa.y + c.trigger.y + c.trigger.h / 2 : pa.x + c.trigger.x + c.trigger.w / 2;
      const cb = horiz ? pb.y + volta.trigger.y + volta.trigger.h / 2 : pb.x + volta.trigger.x + volta.trigger.w / 2;
      if (Math.abs(ca - cb) > 1) erros.push(`${id}.${c.id} → ${c.to}: portas desalinhadas no atlas (${ca} vs ${cb})`);
    }
  }
  return erros;
}
