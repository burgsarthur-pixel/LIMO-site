// =====================================================================
// CARREGAMENTO DE SALAS E DO CATÁLOGO
// =====================================================================
import { TileCatalog, CatalogError } from './tile-catalog.js';
import { TileMap } from './tilemap.js';
import { validateRoomData } from './room-validation.js';

export class RoomLoadError extends Error {
  constructor(mensagem, detalhes = []) { super(mensagem); this.name = 'RoomLoadError'; this.details = detalhes; }
}

export async function defaultFetchJson(url) {
  let resposta;
  try { resposta = await fetch(url, { cache: 'no-cache' }); }
  catch (e) { throw new RoomLoadError(`Não foi possível ler "${url}". Abra o jogo por um servidor HTTP local.`, [String(e)]); }
  if (!resposta.ok) throw new RoomLoadError(`Arquivo "${url}" não encontrado (HTTP ${resposta.status}).`);
  try { return await resposta.json(); }
  catch (e) { throw new RoomLoadError(`O arquivo "${url}" não é um JSON válido.`, [String(e)]); }
}

export async function loadCatalog(config, logger, fetchJson = defaultFetchJson) {
  const dados = await fetchJson(config.rooms.tilesFile);
  try {
    const catalogo = new TileCatalog(dados);
    logger?.info('carregamento', `Catálogo de tiles carregado: ${catalogo.all().length} tiles.`);
    return catalogo;
  } catch (e) {
    if (e instanceof CatalogError) {
      logger?.error('carregamento', e.message, e.errors);
      throw new RoomLoadError(e.message, e.errors);
    }
    throw e;
  }
}

/** Posição em pixels (canto do corpo) para ficar de pé em cima do tile (tx,ty). */
export function tileToSpawnPx(tileSize, tx, ty, hitbox) {
  return { x: (tx + 0.5) * tileSize - hitbox.w / 2, y: (ty + 1) * tileSize - hitbox.h };
}

export function computeSpawn(dados, config) {
  const e = dados.entities.find((x) => x.type === 'playerStart');
  return tileToSpawnPx(dados.tileSize, e.x, e.y, config.player.hitbox);
}

export function extractEnemies(dados) {
  if (!Array.isArray(dados.entities)) return [];
  return dados.entities
    .filter((e) => e.type === 'enemy')
    .map((e) => ({
      type: e.type,
      x: e.x * dados.tileSize,
      y: e.y * dados.tileSize,
      tileX: e.x,
      tileY: e.y,
      speed: e.speed, life: e.life, damage: e.damage, facing: e.facing, kind: e.kind, name: e.name,
      bossId: e.kind === 'boss' ? `${dados.id}:${e.id}` : null,
    }));
}


export function buildRoom(dados, catalogo, config, logger = null, extra = {}) {
  const { errors, warnings } = validateRoomData(dados, catalogo, {
    playerHitbox: config.player.hitbox,
    view: { width: config.render.internalWidth, height: config.render.internalHeight },
    ...extra,
  });
  const nome = dados && dados.id ? dados.id : '(sem id)';
  for (const w of warnings) logger?.warn('carregamento', `Sala ${nome}: ${w}`);
  if (errors.length) {
    for (const e of errors) logger?.error('carregamento', `Sala ${nome}: ${e}`);
    throw new RoomLoadError(`A sala "${nome}" tem ${errors.length} erro(s): ${errors[0]}`, errors);
  }
  const mapa = new TileMap(dados, catalogo);
  const spawn = computeSpawn(dados, config);
  const enemies = extractEnemies(dados);

  logger?.info('carregamento', `Sala "${dados.id}" carregada.`);
  return { data: dados, map: mapa, spawn, enemies, warnings };
}

export async function loadRoomIndex(config, logger = null, fetchJson = defaultFetchJson) {
  try {
    const dados = await fetchJson(`${config.rooms.path}index.json`);
    if (!dados || !Array.isArray(dados.rooms)) return [];
    return dados.rooms;
  } catch (e) {
    return [];
  }
}
