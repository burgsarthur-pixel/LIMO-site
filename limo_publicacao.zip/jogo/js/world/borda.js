// =====================================================================
// BORDA DA SALA: a transição acontece quando o corpo TOCA O LIMITE da sala (v1.40.1).
//
// Antes, a troca disparava ao encostar no retângulo de tiles da passagem (o "buraco" na parede,
// 1–2 tiles de fundo). Agora o retângulo `trigger` só diz ONDE fica a abertura (o trecho do limite
// por onde se pode sair); quem decide a troca é o limite em pixels:
//   left  -> corpo.x <= 0                 right -> corpo.x + w >= largura da sala
//   up    -> corpo.y <= 0                 down  -> corpo.y + h >= altura da sala
// e, ao longo da borda, o corpo precisa cobrir ao menos parte do trecho da abertura.
// Só geometria (px do mundo), sem DOM: testável em Node.
// =====================================================================

/** Tolerância (px) para float; o jogador já é preso exatamente em x=0 / largura-w nas laterais. */
export const FOLGA_BORDA = 0.5;
const EPS = 1e-4;

/** Lado da sala em que o `trigger` (em tiles) está encostado. null = não está na borda. */
export function ladoDaBorda(dados, t) {
  if (!t) return null;
  if (t.x <= 0) return 'left';
  if (t.x + t.w >= dados.width) return 'right';
  if (t.y <= 0) return 'up';
  if (t.y + t.h >= dados.height) return 'down';
  return null;
}

/**
 * O corpo `{x,y,w,h}` (px) toca o limite da sala dentro do trecho da abertura `conn.trigger`?
 * `folga` (px) deixa a borda "pegar" um pouco antes (usado só para soltar o bloqueio da chegada).
 */
export function tocaBorda(dados, conn, corpo, folga = FOLGA_BORDA) {
  const t = conn?.trigger; const lado = ladoDaBorda(dados, t);
  if (!lado) return false;
  const ts = dados.tileSize; const W = dados.width * ts; const H = dados.height * ts;
  if (lado === 'left' || lado === 'right') {
    const a = t.y * ts; const b = (t.y + t.h) * ts;
    if (!(corpo.y < b - EPS && corpo.y + corpo.h > a + EPS)) return false;
    return lado === 'left' ? corpo.x <= folga : corpo.x + corpo.w >= W - folga;
  }
  const a = t.x * ts; const b = (t.x + t.w) * ts;
  if (!(corpo.x < b - EPS && corpo.x + corpo.w > a + EPS)) return false;
  return lado === 'up' ? corpo.y <= folga : corpo.y + corpo.h >= H - folga;
}
