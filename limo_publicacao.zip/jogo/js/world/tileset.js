// =====================================================================
// SPRITESHEETS (matemática pura, sem navegador)
// Um "tileset" é um PNG dividido em quadradinhos. Ele pode ter:
//   margin  = borda ao redor de TODA a região (px)
//   spacing = espaço ENTRE os quadradinhos (px)
//   region  = só uma parte da imagem {x,y,w,h} (opcional)
// Nunca presumimos spacing = 0.
// =====================================================================

export function validateTilesetDef(def, indice = 0) {
  const erros = []; const nome = `tileset ${def && def.id ? `"${def.id}"` : `#${indice}`}`;
  if (!def || typeof def !== 'object') return [`${nome}: deve ser um objeto.`];
  if (typeof def.id !== 'string' || !/^[a-z0-9_]+$/.test(def.id)) erros.push(`${nome}: id inválido (use minúsculas, números e "_").`);
  if (typeof def.image !== 'string' || !def.image) erros.push(`${nome}: falta o caminho da imagem ("image").`);
  for (const k of ['tileWidth', 'tileHeight']) if (!Number.isInteger(def[k]) || def[k] < 1) erros.push(`${nome}: ${k} deve ser inteiro >= 1.`);
  for (const k of ['margin', 'spacing']) if (def[k] !== undefined && (!Number.isInteger(def[k]) || def[k] < 0)) erros.push(`${nome}: ${k} deve ser inteiro >= 0.`);
  if (def.region !== undefined) {
    const r = def.region;
    if (!r || ![r.x, r.y, r.w, r.h].every(Number.isInteger) || r.x < 0 || r.y < 0 || r.w < 1 || r.h < 1) erros.push(`${nome}: region deve ter x,y,w,h inteiros (w,h >= 1).`);
  }
  return erros;
}

export function normalizeTileset(def) {
  return { id: def.id, image: def.image, tileWidth: def.tileWidth, tileHeight: def.tileHeight, margin: def.margin ?? 0, spacing: def.spacing ?? 0, region: def.region ?? null };
}

/** Retângulo de origem na imagem do quadradinho (coluna, linha). */
export function spriteSourceRect(set, col, row) {
  const ox = (set.region ? set.region.x : 0) + (set.margin || 0);
  const oy = (set.region ? set.region.y : 0) + (set.margin || 0);
  const sp = set.spacing || 0;
  return { sx: ox + col * (set.tileWidth + sp), sy: oy + row * (set.tileHeight + sp), sw: set.tileWidth, sh: set.tileHeight };
}

/** Quantas colunas/linhas cabem na região (descontando margem e espaçamento). */
export function tilesetGrid(set, imgW, imgH) {
  const r = set.region || { x: 0, y: 0, w: imgW, h: imgH };
  const m = set.margin || 0; const sp = set.spacing || 0;
  const cols = Math.floor((r.w - 2 * m + sp) / (set.tileWidth + sp));
  const rows = Math.floor((r.h - 2 * m + sp) / (set.tileHeight + sp));
  return { cols: Math.max(0, cols), rows: Math.max(0, rows) };
}

/** O quadradinho (col,row) existe dentro da imagem? */
export function spriteInsideImage(set, col, row, imgW, imgH) {
  if (col < 0 || row < 0) return false;
  const g = tilesetGrid(set, imgW, imgH);
  const r = spriteSourceRect(set, col, row);
  return col < g.cols && row < g.rows && r.sx + r.sw <= imgW && r.sy + r.sh <= imgH;
}

