// =====================================================================
// GERAÇÃO PROCEDURAL DE SALAS (estilo Dead Cells): a cada expedição o mundo é montado a partir de uma SEMENTE.
// Cada sala é uma "trilha" esquerda→direita com terreno de degraus (≤ 2 tiles, sempre pulável), fossos de espinhos de
// 2 tiles, plataformas que formam escadas, decoração e criaturas; a dificuldade e o bioma avançam sala a sala.
// Entrada e saída ficam sempre no chão plano da borda: o caminho principal é SEMPRE transponível com pulo (sem mutação).
// Só lógica de dados (sem DOM): a saída é JSON de sala no mesmo formato do jogo e passa por validateRoomData.
// =====================================================================

import { GAP } from './atlas-layout.js';

/** Gerador pseudoaleatório determinístico (mulberry32): mesma semente = mesma expedição. */
export function criarRng(semente) {
  let s = (typeof semente === 'string' ? [...semente].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7) : semente >>> 0) || 1;
  const next = () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  return { next, int: (a, b) => a + Math.floor(next() * (b - a + 1)), pick: (arr) => arr[Math.floor(next() * arr.length)], chance: (p) => next() < p };
}

/** Conjuntos de tiles por bioma (ids do data/tiles.json). */
export const TILES_BIOMA = {
  raizes: { piso: 2, miolo: 1, parede: 3, teto: 1, plataforma: 7, espinho: 9, fundo: [22, 22, 22, 23], veia: 21, deco: [12, 19, 27], pendente: 20, nome: 'Raízes da Carne' },
  jardim: { piso: 40, miolo: 40, parede: 40, teto: 40, plataforma: 42, espinho: 43, fundo: [46], veia: 21, deco: [44, 45, 28], pendente: 20, nome: 'Jardim das Vísceras' },
  nucleo: { piso: 50, miolo: 50, parede: 50, teto: 50, plataforma: 53, espinho: 52, fundo: [54, 54, 46], veia: 55, deco: [56], pendente: 56, nome: 'Núcleo do Deus' },
};
const BIOMAS_ORDEM = ['raizes', 'jardim', 'nucleo'];
const MUTACOES = ['wallJump', 'saltoElastico', 'membrana'];

/** Espécie de inimigo por dificuldade (0..1): começa simples e ganha variedade. */
function especies(rng, dif) {
  const pool = ['crawler', 'crawler', 'flyer']; if (dif > 0.3) pool.push('leaper'); if (dif > 0.55) pool.push('armored', 'leaper');
  return pool;
}

export function gerarSala(rng, indice, total, opcoes = {}) {
  const prefixo = opcoes.prefixo || 'exp'; const dif = total > 1 ? indice / (total - 1) : 0;
  const biome = BIOMAS_ORDEM[Math.min(2, Math.floor((indice / total) * 3))]; const T = TILES_BIOMA[biome];
  const W = rng.int(28, 40); const H = rng.int(19, 22); const gy = H - 3;                       // gy = linha da superfície no nível-base
  const nivelIn = indice > 0 ? rng.int(0, 2) : 0; const nivelOut = rng.int(0, 2);               // altura (em tiles) do chão sob a porta de entrada / saída
  const camada = () => Array.from({ length: H }, () => new Array(W).fill(0));
  const L = { backgroundFar: camada(), backgroundMid: camada(), decoBack: camada(), solid: camada(), platform: camada(), decoFront: camada(), interactive: camada(), foreground: camada() };
  // --- terreno: caminhada aleatória em degraus de no máximo 2 tiles; bordas planas (entrada/saída no nível-base) ---
  const alt = new Array(W).fill(nivelIn); let h = nivelIn; let x = 4;
  while (x < W - 5) {
    const seg = rng.int(3, 7); if (rng.chance(0.55)) h = Math.max(0, Math.min(3, h + rng.int(-2, 2)));
    for (let k = 0; k < seg && x < W - 5; k++, x++) alt[x] = h;
  }
  for (let c = W - 5; c < W; c++) alt[c] = nivelOut;
  const cl = (v, a, b) => Math.max(a, Math.min(b, v));
  for (let c = 4; c < W - 5; c++) alt[c] = cl(alt[c], alt[c - 1] - 2, alt[c - 1] + 2);            // degraus de no máximo 2 tiles (pulável)
  for (let c = W - 6; c >= 4; c--) alt[c] = cl(alt[c], alt[c + 1] - 2, alt[c + 1] + 2);
  const topo = alt.map((a) => gy - a);
  // --- teto ondulado (0..3 tiles extras), sempre com >= 6 tiles livres acima do chão; sem entalhes de 1 coluna ---
  const ext = new Array(W).fill(0); let ce = 0; let xc = 1;
  while (xc < W - 1) { const seg = rng.int(3, 7); ce = cl(ce + rng.pick([-1, 0, 1, 1]), 0, 3); for (let k = 0; k < seg && xc < W - 1; k++, xc++) ext[xc] = Math.min(ce, topo[xc] - 8); }
  for (let c = 1; c < W - 1; c++) ext[c] = Math.min(ext[c], (ext[c - 1] || 0) + 1, (ext[c + 1] || 0) + 1);
  for (let c = 2; c < W - 2; c++) if (ext[c] < ext[c - 1] && ext[c] < ext[c + 1]) ext[c] = Math.min(ext[c - 1], ext[c + 1]);
  const teto = ext.map((e) => 2 + e);                                                       // primeira linha livre de cada coluna
  for (let c = 0; c < W; c++) for (let r = 0; r < H; r++) {
    if (r < teto[c] || (r < 2)) L.solid[r][c] = T.teto; else if (c === 0 || c === W - 1) L.solid[r][c] = T.parede;
    else if (r === topo[c]) L.solid[r][c] = T.piso; else if (r > topo[c]) L.solid[r][c] = T.miolo;
  }
  // --- paredes de espessura variável (1..3) acima da faixa da porta: a abertura vira a boca de um túnel, não um furo reto ---
  for (const lado of [0, 1]) {
    const t0 = lado ? topo[W - 2] : topo[1]; let th = 1;
    for (let r = 2; r < t0 - 4;) { const seg = rng.int(2, 4); th = cl(th + rng.pick([-1, 0, 1, 1]), 1, 3);
      for (let k = 0; k < seg && r < t0 - 4; k++, r++) for (let q = 1; q < th; q++) { const c = lado ? W - 1 - q : q; if (!L.solid[r][c]) L.solid[r][c] = T.parede; } }
  }
  const ocupado = new Set();   // colunas já usadas por espinho/plataforma/entidade (evita sobreposição)
  const reservar = (a, b) => { for (let c = a; c <= b; c++) ocupado.add(c); };
  reservar(0, 5); reservar(W - 6, W - 1);
  // --- fossos de espinhos (2 tiles de largura, sobre trechos planos de 6+ tiles): pulo simples atravessa ---
  const nEsp = rng.int(0, 1 + Math.round(dif * 2));
  for (let t = 0, tent = 0; t < nEsp && tent < 40; tent++) {
    const c = rng.int(7, W - 10);
    if ([0, 1, 2, 3, 4, 5].every((k) => alt[c + k] === alt[c] && !ocupado.has(c + k))) { L.interactive[topo[c + 2] - 1][c + 2] = T.espinho; L.interactive[topo[c + 3] - 1][c + 3] = T.espinho; reservar(c, c + 5); t++; }
  }
  // --- plataformas em escada (cada degrau a 2-3 tiles do anterior) ---
  const plats = []; const nPl = rng.int(2, 4);
  for (let t = 0, tent = 0; t < nPl && tent < 40; tent++) {
    const c = rng.int(6, W - 12); const w = rng.int(3, 5); const base = Math.min(...topo.slice(c, c + w)); const r = Math.max(4, base - rng.int(2, 3));
    if (r < Math.max(...teto.slice(c, c + w)) + 3 || r < 4 || [...Array(w).keys()].some((k) => L.platform[r][c + k] || ocupado.has(c + k))) continue;
    for (let k = 0; k < w; k++) L.platform[r][c + k] = T.plataforma;
    plats.push({ c, w, r }); t++;
  }
  // --- entidades ---
  const ents = []; const idDe = (p, n) => `${p}_${n}`;
  const chao = (c) => topo[c] - 1;                                                       // linha livre logo acima do chão
  ents.push({ type: 'playerStart', x: 3, y: chao(3) });   // toda sala tem um (a entrada real vem das conexões)
  if (indice === 0 || indice === Math.floor(total / 2) || indice === total - 1) ents.push({ type: 'checkpoint', id: idDe('banco', 1), x: 7, y: chao(7) });
  const nIni = indice === 0 ? 1 : Math.round(2 + dif * 4);
  for (let n = 0; n < nIni; n++) {
    const kind = rng.pick(especies(rng, dif)); const c = rng.int(9, W - 8);
    if (kind === 'flyer') ents.push({ type: 'enemy', kind, id: idDe('voador', n + 1), x: c, y: Math.max(teto[c] + 2, topo[c] - rng.int(4, 6)) });
    else ents.push({ type: 'enemy', kind: kind === 'crawler' ? undefined : kind, id: idDe('inimigo', n + 1), x: c, y: chao(c) });
  }
  if (plats.length >= 2 && (rng.chance(0.7) || indice === total - 1)) {                     // recompensa em cima da escada de plataformas
    const alto = plats.reduce((a, b) => (b.r < a.r ? b : a)); ents.push({ type: 'vida', id: idDe('fragmento', 1), x: alto.c + 1, y: alto.r - 1 });
  }
  if (indice === 2 || indice === total - 2) { const m = MUTACOES[rng.int(0, MUTACOES.length - 1)]; ents.push({ type: 'mutation', id: idDe('mutacao', 1), ability: m, x: W - 8, y: chao(W - 8) }); }
  ents.forEach((e) => { if (e.kind === undefined) delete e.kind; });
  // --- decoração (sem colisão) ---
  for (let c = 1; c < W - 1; c++) {
    L.backgroundFar[0] && (() => { for (let r = 2; r < H - 1; r++) if (L.solid[r][c] === 0) L.backgroundFar[r][c] = rng.pick(T.fundo); })();
    if (rng.chance(0.07)) for (let r = 2; r < H - 2; r++) if (!L.solid[r][c]) L.backgroundMid[r][c] = T.veia;
    if (rng.chance(0.12) && !L.interactive[chao(c)][c] && !ocupado.has(c)) L.decoBack[chao(c)][c] = rng.pick(T.deco);
    if (rng.chance(0.08) && !L.solid[teto[c]][c]) L.decoBack[teto[c]][c] = T.pendente;
  }
  // --- conexões: oeste (volta) e leste (adiante); gatilhos de 3 tiles de altura no nível-base ---
  const id = `${prefixo}_${String(indice).padStart(2, '0')}`; const conexoes = [];
  if (indice > 0) conexoes.push({ id: 'oeste', to: `${prefixo}_${String(indice - 1).padStart(2, '0')}`, toConnection: 'leste', trigger: { x: 0, y: topo[1] - 3, w: 1, h: 3 }, requires: null });
  if (indice < total - 1) conexoes.push({ id: 'leste', to: `${prefixo}_${String(indice + 1).padStart(2, '0')}`, toConnection: 'oeste', trigger: { x: W - 1, y: topo[W - 2] - 3, w: 1, h: 3 }, requires: null });
  return { versao: 1, id, name: `Expedição · ${T.nome} · Sala ${indice + 1}`, biome, width: W, height: H, tileSize: 16, mapPos: { x: 0, y: 0 }, connections: conexoes, layers: L, entities: ents };
}

/** Monta uma expedição completa: devolve { semente, salas, inicio }. */
export function gerarExpedicao(semente = Date.now(), opcoes = {}) {
  const rng = criarRng(semente); const total = Math.max(3, opcoes.salas || 7);
  const salas = Array.from({ length: total }, (_, i) => gerarSala(rng, i, total, opcoes));
  // Atlas em grade de tiles: salas em fila, portas vizinhas na MESMA linha (a sala sobe/desce no mapa conforme a altura do chão)
  // e separadas por GAP em x, então nunca se sobrepõem, qualquer que seja a largura sorteada (28–40).
  let cursor = 0; let ant = null;
  for (const sala of salas) {
    // a porta oeste desta sala fica na MESMA linha do atlas que a porta leste da anterior (as alturas de chão variam)
    const y = ant ? ant.mapPos.y + ant.connections.find((c) => c.id === 'leste').trigger.y - sala.connections.find((c) => c.id === 'oeste').trigger.y : 0;
    sala.mapPos = { x: cursor, y }; cursor += sala.width + GAP; ant = sala;
  }
  return { semente, salas, inicio: salas[0].id };
}
