// =====================================================================
// TILEMAP: grade de células organizada em CAMADAS.
// O mundo é só dados (números). Quem decide "isto é sólido?" é o catálogo.
// Também guarda, por célula, a VARIANTE de autotiling (qual "pedaço" desenhar).
// =====================================================================
import { rawMask, variantFor, decoVariant } from './autotile.js';

// Ordem de desenho (de trás para frente), conforme o design do jogo.
export const LAYER_NAMES = [
  'backgroundFar',   // fundo distante
  'backgroundMid',   // fundo intermediário
  'decoBack',        // decoração de fundo (sem colisão)
  'solid',           // superfícies sólidas
  'platform',        // plataformas atravessáveis por baixo
  'decoFront',       // decoração próxima (sem colisão)
  'interactive',     // elementos interativos / zonas de dano
  'foreground',      // primeiro plano
];
// Só estas camadas participam da colisão (a decoração NUNCA bloqueia).
export const COLLIDING_LAYERS = ['solid', 'platform', 'interactive'];

const EPS = 1e-4;

// Tile virtual das barreiras (passagens seladas até o jogador ter a habilidade). Não existe no catálogo nem no JSON.
const TILE_BARREIRA = { id: -1, name: 'barreira', category: 'interativo', biome: 'todos', collision: 'solid', box: [0, 0, 1, 1], friction: 1, damage: 0, art: { style: 'block' }, sprite: null, autotile: null };

export class TileMap {
  /** @param dados  objeto da sala (já validado)  @param catalogo TileCatalog */
  constructor(dados, catalogo) {
    this.id = dados.id; this.name = dados.name; this.biome = dados.biome;
    this.width = dados.width; this.height = dados.height; this.tileSize = dados.tileSize;
    this.catalog = catalogo;
    this.layers = {};
    for (const nome of LAYER_NAMES) {
      const linhas = dados.layers[nome];
      if (!linhas) continue;
      const plana = new Uint16Array(this.width * this.height);
      for (let y = 0; y < this.height; y++) for (let x = 0; x < this.width; x++) plana[y * this.width + x] = linhas[y][x];
      this.layers[nome] = plana;
    }
    this._celula = { tx: 0, ty: 0, x: 0, y: 0, w: 0, h: 0, kind: '', tile: null, layer: '' };
    this.barriers = [];   // retângulos em px {x,y,w,h,connId} que bloqueiam como parede (ver setBarriers)
    this.autotile = {};
    this.revision = 0; // muda em cada edição; caches visuais podem se atualizar sem tocar na jogabilidade
    this.refreshAutotile();
  }

  get pixelWidth() { return this.width * this.tileSize; }
  get pixelHeight() { return this.height * this.tileSize; }

  inBounds(tx, ty) { return tx >= 0 && ty >= 0 && tx < this.width && ty < this.height; }

  getTileId(camada, tx, ty) {
    const arr = this.layers[camada];
    return arr && this.inBounds(tx, ty) ? arr[ty * this.width + tx] : 0;
  }

  /** Variante de autotiling da célula (0 se o tile não usa autotiling). */
  getVariant(camada, tx, ty) {
    const arr = this.autotile[camada];
    return arr && this.inBounds(tx, ty) ? arr[ty * this.width + tx] : 0;
  }

  /** Troca um tile e atualiza o desenho dos vizinhos (autotiling). Usado pelo editor e pelos testes. */
  setTileId(camada, tx, ty, id) {
    if (!LAYER_NAMES.includes(camada)) throw new Error(`Camada desconhecida: ${camada}`);
    if (!this.inBounds(tx, ty)) throw new Error(`Célula fora da sala: ${tx},${ty}`);
    if (id !== 0 && !this.catalog.has(id)) throw new Error(`Tile inexistente no catálogo: ${id}`);
    if (!this.layers[camada]) this.layers[camada] = new Uint16Array(this.width * this.height);
    this.layers[camada][ty * this.width + tx] = id;
    this.revision++;
    // Decorações dependem do que há embaixo/ao lado (chão, parede, teto): qualquer camada pode ter mudado a situação delas.
    const todas = Object.keys(this.layers);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) for (const nome of todas) this._atualizarVariante(nome, tx + dx, ty + dy);
  }


  /** Recalcula as variantes de autotiling (todas as camadas, ou só uma). */
  refreshAutotile(camada = null) {
    const estrutural = camada === 'solid' || camada === 'platform';   // decorações dependem do chão/parede/teto
    for (const nome of camada && !estrutural ? [camada] : Object.keys(this.layers)) {
      this.autotile[nome] = new Uint8Array(this.width * this.height);
      for (let y = 0; y < this.height; y++) for (let x = 0; x < this.width; x++) this._atualizarVariante(nome, x, y);
    }
  }

  _atualizarVariante(camada, tx, ty) {
    if (!this.inBounds(tx, ty)) return;
    const arr = this.layers[camada];
    if (!this.autotile[camada]) this.autotile[camada] = new Uint8Array(this.width * this.height);
    const i = ty * this.width + tx;
    const tile = this.catalog.get(arr[i]);
    if (!tile || !tile.autotile) { this.autotile[camada][i] = 0; return; }
    const at = tile.autotile;
    if (at.mode === 'deco') { this.autotile[camada][i] = decoVariant(this._fatosDeco(arr, at, tx, ty)); return; }
    const conectado = (dx, dy) => {
      const x = tx + dx; const y = ty + dy;
      if (!this.inBounds(x, y)) return at.edgeConnects;
      const t2 = this.catalog.get(arr[y * this.width + x]);
      return !!(t2 && t2.autotile && t2.autotile.group === at.group);
    };
    this.autotile[camada][i] = variantFor(at.mode, rawMask(conectado));
  }

  /** A célula é sólida ou plataforma (apoio para decoração)? Fora da sala conta como sólido: as salas são fechadas. */
  _apoioEm(x, y) {
    if (!this.inBounds(x, y)) return true;
    const i = y * this.width + x;
    for (const nome of ['solid', 'platform']) {
      const arr = this.layers[nome]; const id = arr ? arr[i] : 0;
      if (id) { const t = this.catalog.get(id); if (t && (t.collision === 'solid' || t.collision === 'oneway')) return true; }
    }
    return false;
  }

  _fatosDeco(arr, at, tx, ty) {
    const d = at.anchor === 'up' ? -1 : 1;   // d aponta para o lado do apoio
    const mesmo = (x, y) => {
      if (!this.inBounds(x, y)) return false;
      const t2 = this.catalog.get(arr[y * this.width + x]);
      return !!(t2 && t2.autotile && t2.autotile.mode === 'deco' && t2.autotile.group === at.group);
    };
    return {
      apoio: this._apoioEm(tx, ty + d), sobre: mesmo(tx, ty + d), afasta: mesmo(tx, ty - d),
      esq: mesmo(tx - 1, ty), dir: mesmo(tx + 1, ty), paredeEsq: this._apoioEm(tx - 1, ty), paredeDir: this._apoioEm(tx + 1, ty),
    };
  }

  /** Linhas (lista de listas) de uma camada, no formato do JSON. */
  toRows(camada) {
    const arr = this.layers[camada]; const linhas = [];
    for (let y = 0; y < this.height; y++) linhas.push(arr ? Array.from(arr.subarray(y * this.width, (y + 1) * this.width)) : new Array(this.width).fill(0));
    return linhas;
  }

  /** Cópia completa do conteúdo (para desfazer redimensionamentos). */
  snapshot() {
    const layers = {};
    for (const [k, v] of Object.entries(this.layers)) layers[k] = v.slice();
    return { width: this.width, height: this.height, layers };
  }

  restore(snap) {
    this.width = snap.width; this.height = snap.height; this.layers = {};
    for (const [k, v] of Object.entries(snap.layers)) this.layers[k] = v.slice();
    this.revision++;
    this.autotile = {}; this.refreshAutotile();
  }

  /** Muda o tamanho mantendo o canto superior esquerdo; áreas novas ficam vazias. */
  resize(novaLargura, novaAltura) {
    const antigo = this.snapshot();
    const w = Math.min(antigo.width, novaLargura); const h = Math.min(antigo.height, novaAltura);
    const novas = {};
    for (const [nome, arr] of Object.entries(antigo.layers)) {
      const n = new Uint16Array(novaLargura * novaAltura);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) n[y * novaLargura + x] = arr[y * antigo.width + x];
      novas[nome] = n;
    }
    this.width = novaLargura; this.height = novaAltura; this.layers = novas;
    this.autotile = {}; this.refreshAutotile();
    return antigo;
  }

  /**
   * Chama `cb` para cada tile COM COLISÃO que cruza o retângulo (x,y,w,h) em pixels.
   * O objeto passado é REUTILIZADO a cada chamada (não guarde a referência!).
   * Campos: tx, ty, x, y, w, h (caixa de colisão em px), kind, tile, layer.
   */
  forEachCollidable(x, y, w, h, cb) {
    const ts = this.tileSize;
    const tx0 = Math.max(0, Math.floor(x / ts));
    const tx1 = Math.min(this.width - 1, Math.floor((x + w - EPS) / ts));
    const ty0 = Math.max(0, Math.floor(y / ts));
    const ty1 = Math.min(this.height - 1, Math.floor((y + h - EPS) / ts));
    const c = this._celula;
    for (let ty = ty0; ty <= ty1; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) {
        for (let i = 0; i < COLLIDING_LAYERS.length; i++) {
          const arr = this.layers[COLLIDING_LAYERS[i]];
          if (!arr) continue;
          const id = arr[ty * this.width + tx];
          if (id === 0) continue;
          const tile = this.catalog.get(id);
          if (!tile || tile.collision === 'none') continue;
          c.tx = tx; c.ty = ty; c.layer = COLLIDING_LAYERS[i];
          c.x = tx * ts + tile.box[0] * ts; c.y = ty * ts + tile.box[1] * ts;
          c.w = tile.box[2] * ts; c.h = tile.box[3] * ts;
          c.kind = tile.collision; c.tile = tile;
          cb(c);
        }
      }
    }
    for (let i = 0; i < this.barriers.length; i++) {
      const b = this.barriers[i];
      if (b.x < x + w - EPS && b.x + b.w > x + EPS && b.y < y + h - EPS && b.y + b.h > y + EPS) {
        c.tx = Math.floor(b.x / ts); c.ty = Math.floor(b.y / ts); c.layer = 'barrier';
        c.x = b.x; c.y = b.y; c.w = b.w; c.h = b.h; c.kind = 'solid'; c.tile = TILE_BARREIRA;
        cb(c);
      }
    }
  }

  /** Define as barreiras (passagens seladas). Entram na MESMA consulta de colisão da física e do debug. */
  setBarriers(lista) { this.barriers = lista.map((b) => ({ x: b.x, y: b.y, w: b.w, h: b.h, connId: b.connId })); }

  /** O ponto (px,py) está dentro de um tile sólido? */
  isSolidPoint(px, py) {
    let achou = false;
    this.forEachCollidable(px, py, 0.01, 0.01, (c) => {
      if (c.kind === 'solid' && px >= c.x && px < c.x + c.w && py >= c.y && py < c.y + c.h) achou = true;
    });
    return achou;
  }
}
