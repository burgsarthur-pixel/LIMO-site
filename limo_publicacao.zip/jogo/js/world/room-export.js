// =====================================================================
// EXPORTAÇÃO DE SALAS: objeto do jogo -> JSON legível (uma fileira de tiles por linha).
// É o MESMO formato que o carregador lê e o validador confere (ida e volta sem perdas).
// =====================================================================
import { LAYER_NAMES } from './tilemap.js';

/** Monta o objeto da sala a partir de um TileMap + metadados. Camadas vazias são omitidas (menos "solid"). */
export function roomToJson({ id, name, biome, mapPos = null, depth = null, bossIntro = null, feixes = null, map, entities, connections }) {
  const layers = {};
  for (const nome of LAYER_NAMES) {
    const arr = map.layers[nome];
    const vazia = !arr || arr.every((v) => v === 0);
    if (nome === 'solid' || !vazia) layers[nome] = map.toRows(nome);
  }
  return {
    versao: 1, id, name, biome, width: map.width, height: map.height, tileSize: map.tileSize,
    ...(mapPos ? { mapPos: { x: mapPos.x, y: mapPos.y } } : {}),   // posição no mapa-múndi (opcional), logo depois do tamanho
    ...(depth ? { depth: JSON.parse(JSON.stringify(depth)) } : {}),   // v1.38: profundidade 2.5D (opcional; sala sem ela fica idêntica)
    layers, entities: entities.map((e) => ({ ...e })), connections: JSON.parse(JSON.stringify(connections || [])),
    ...(bossIntro ? { bossIntro: JSON.parse(JSON.stringify(bossIntro)) } : {}),   // gatilho da luta de chefe (opcional; sem ele a Tecelã nunca desperta)
    ...(feixes?.length ? { feixes: JSON.parse(JSON.stringify(feixes)) } : {}),   // v1.42: feixes de luz (opcional; sem eles a sala fica idêntica)
  };
}

/** Texto JSON bonito: metadados em linhas curtas e cada fileira do mapa em UMA linha. */
export function formatRoomJson(sala) {
  const linha = (fileira) => `[${fileira.map((n) => String(n).padStart(2)).join(',')}]`;
  const out = ['{'];
  out.push(`  "versao": ${sala.versao ?? 1},`);
  out.push(`  "id": ${JSON.stringify(sala.id)},`);
  out.push(`  "name": ${JSON.stringify(sala.name)},`);
  out.push(`  "biome": ${JSON.stringify(sala.biome)},`);
  out.push(`  "width": ${sala.width}, "height": ${sala.height}, "tileSize": ${sala.tileSize},`);
  if (sala.mapPos) out.push(`  "mapPos": { "x": ${sala.mapPos.x}, "y": ${sala.mapPos.y} },`);
  if (sala.depth) out.push(`  "depth": ${JSON.stringify(sala.depth)},`);
  out.push('  "layers": {');
  const nomes = Object.keys(sala.layers);
  nomes.forEach((nome, i) => {
    out.push(`    ${JSON.stringify(nome)}: [`);
    out.push(sala.layers[nome].map((f) => `      ${linha(f)}`).join(',\n'));
    out.push(`    ]${i < nomes.length - 1 ? ',' : ''}`);
  });
  out.push('  },');
  const lista = (arr) => (arr.length ? `[\n${arr.map((e) => `    ${JSON.stringify(e)}`).join(',\n')}\n  ]` : '[]');
  out.push(`  "entities": ${lista(sala.entities)},`);
  const extras = [];
  if (sala.bossIntro) extras.push(`  "bossIntro": ${JSON.stringify(sala.bossIntro)}`);
  if (sala.feixes?.length) extras.push(`  "feixes": ${lista(sala.feixes)}`);
  out.push(`  "connections": ${lista(sala.connections)}${extras.length ? ',' : ''}`);
  out.push(extras.join(',\n'));
  out.push('}');
  return `${out.filter((l) => l !== '').join('\n')}\n`;
}

/** Sala nova e válida: paredes, teto, chão de 3 tiles, fundo e o ponto de partida do jogador. */
export function blankRoomJson({ id, name, biome = 'raizes', width, height }, catalogo) {
  const solidos = catalogo.all().filter((t) => t.collision === 'solid');
  const chao = (catalogo.has(1) && catalogo.get(1).collision === 'solid') ? 1 : solidos[0].id;
  const parede = (catalogo.has(3) && catalogo.get(3).collision === 'solid') ? 3 : chao;
  const fundo = catalogo.all().find((t) => t.category === 'fundo');
  const grade = () => Array.from({ length: height }, () => Array(width).fill(0));
  const solid = grade(); const bg = grade();
  for (let x = 0; x < width; x++) { solid[0][x] = chao; for (let y = height - 3; y < height; y++) solid[y][x] = chao; }
  for (let y = 0; y < height; y++) { solid[y][0] = parede; solid[y][width - 1] = parede; }
  const layers = { solid };
  if (fundo) { for (let y = 0; y < height; y++) bg[y].fill(fundo.id); layers.backgroundFar = bg; }
  const ordem = {}; for (const n of LAYER_NAMES) if (layers[n]) ordem[n] = layers[n];
  return { versao: 1, id, name, biome, width, height, tileSize: catalogo.tileSize, layers: ordem,
    entities: [{ type: 'playerStart', x: Math.min(2, width - 2), y: height - 4 }], connections: [] };
}
