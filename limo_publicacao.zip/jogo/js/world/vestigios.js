// =====================================================================
// VESTÍGIOS (v1.38.0) — pictogramas dos murais, em dados puros (retângulos), sem DOM.
// Um mural é um painel de 48x32 px (3x2 tiles). Cada cena é uma lista de retângulos [x, y, w, h, cor]:
//   cor 0 = vazio/escuro · 1 = traço (osso) · 2 = acento (cor do bioma) · 3 = sombra/moldura
// A história, na ordem em que o jogo a mostra: o povo ergue o templo e canta para o Deus dormir → as raízes trazem fome →
// o Deus sonha cópias (uma é diferente) → a vida brota do sono → tentam fechar a ferida → o olho entreabre → uma cópia caminha até ele.
// =====================================================================
export const PAINEL = Object.freeze({ w: 48, h: 32 });

const R = (a, x, y, w = 1, h = 1, c = 1) => { a.push([Math.round(x), Math.round(y), w, h, c]); };

const G = {
  /** Olho amêndoa: aberto 0..1 (0 = fechado, com cílios; >0.3 mostra a íris). */
  olho(a, cx, cy, r = 4, aberto = 0, c = 1) {
    const rx = r * 2; const ry = Math.max(1, Math.round(r * (0.3 + 0.7 * aberto)));
    for (let dx = -rx; dx <= rx; dx++) { const h = Math.round(ry * Math.sqrt(1 - (dx / rx) ** 2)); R(a, cx + dx, cy - h, 1, 1, c); R(a, cx + dx, cy + h, 1, 1, c); }
    if (aberto > 0.3) { R(a, cx - 1, cy - 1, 3, 3, 2); R(a, cx, cy, 1, 1, 0); } else for (let i = -rx + 2; i <= rx - 2; i += 3) R(a, cx + i, cy + ry + 1, 1, 2, c);
  },
  /** Figura humana de palito; (x,y) = pés. */
  povo(a, x, y, pose = 'ergue', c = 1) {
    if (pose === 'ajoelha') { R(a, x, y - 6, 2, 2, c); R(a, x, y - 4, 1, 3, c); R(a, x - 1, y - 1, 4, 1, c); return; }
    R(a, x, y - 8, 2, 2, c); R(a, x, y - 6, 1, 4, c); R(a, x - 1, y - 2, 1, 2, c); R(a, x + 1, y - 2, 1, 2, c);
    if (pose === 'ergue') { R(a, x - 2, y - 8, 1, 2, c); R(a, x + 2, y - 8, 1, 2, c); } else { R(a, x - 1, y - 5, 3, 1, c); }
  },
  raiz(a, x, y, len, dir = 1, c = 1) {
    for (let i = 0; i < len; i++) { R(a, x + (((i >> 1) % 2) ? dir : 0), y + i, 1, 1, c); if (i % 6 === 5) { R(a, x + dir * 2, y + i, 1, 1, c); R(a, x + dir * 3, y + i + 1, 1, 1, c); } }
  },
  copia(a, x, y, acento = false) { const c = acento ? 2 : 1; R(a, x, y, 5, 3, c); R(a, x + 1, y - 1, 3, 1, c); R(a, x + 1, y + 1, 1, 1, 0); R(a, x + 3, y + 1, 1, 1, 0); },
  flor(a, x, y, h = 6) { R(a, x, y, 1, h, 1); R(a, x - 1, y - 2, 3, 3, 2); R(a, x, y - 1, 1, 1, 0); },
  fossil(a, x, y, len) {
    R(a, x, y, len, 1, 1);
    for (let i = 3; i < len - 2; i += 3) { R(a, x + i, y - 2, 1, 2, 1); R(a, x + i, y + 1, 1, 2, 1); }
    R(a, x + len, y - 2, 4, 4, 1); R(a, x + len + 1, y - 1, 1, 1, 0); R(a, x - 3, y, 3, 1, 3);
  },
  onda(a, cx, cy, n = 3, c = 2) { for (let k = 1; k <= n; k++) R(a, cx - k * 3, cy + k * 2, k * 6 + 1, 1, c); },
  arco(a, cx, base, w) {
    const r = w / 2;
    for (let dx = -r; dx <= r; dx++) R(a, cx + dx, base - Math.round(Math.sqrt(1 - (dx / r) ** 2) * r * 0.8), 1, 1, 1);
    R(a, cx - r, base - 3, 1, 3, 1); R(a, cx + r, base - 3, 1, 3, 1);
  },
  ponto(a, x, y, c = 2) { R(a, x, y, 1, 1, c); },
  estrelas(a, lista, c = 2) { for (const [x, y] of lista) R(a, x, y, 1, 1, c); },
  rachadura(a, x, y, len, dir = 1, c = 1) { for (let i = 0; i < len; i++) R(a, x + (i % 3 === 2 ? dir : 0) + (i >> 2) * dir, y + i, 1, 1, c); },
  sutura(a, x, y, len) { R(a, x, y, len, 1, 1); for (let i = 1; i < len - 1; i += 3) R(a, x + i, y - 1, 1, 3, 2); },
  chao(a, y = 29, c = 3) { R(a, 2, y, 44, 1, c); },
  fogueira(a, x, y) { R(a, x, y - 3, 3, 3, 2); R(a, x + 1, y - 5, 1, 2, 2); },
};

export const CENAS = Object.freeze({
  construtores: (a) => { G.arco(a, 24, 27, 34); G.olho(a, 24, 20, 3); G.estrelas(a, [[24, 7], [10, 10], [38, 9]]); for (const x of [6, 11, 37, 42]) G.povo(a, x, 28, 'ergue'); G.chao(a); },
  canto: (a) => { G.olho(a, 24, 8, 4); G.onda(a, 24, 14, 3); for (const x of [12, 19, 29, 36]) G.povo(a, x, 28, 'ajoelha'); G.chao(a); },
  raizes: (a) => { G.olho(a, 24, 7, 4); G.raiz(a, 10, 2, 22, 1); G.raiz(a, 38, 2, 22, -1); G.raiz(a, 24, 12, 10, 1, 2); G.povo(a, 20, 28, 'ergue'); G.povo(a, 28, 28, 'ajoelha'); G.chao(a); },
  copias: (a) => { G.olho(a, 24, 6, 3); for (const x of [5, 12, 19, 26, 33]) G.copia(a, x, 21); G.copia(a, 40, 21, true); G.ponto(a, 42, 15); G.estrelas(a, [[8, 13], [16, 12], [28, 13], [36, 12]], 3); G.chao(a, 27); },
  fossil: (a) => { G.fossil(a, 6, 16, 30); G.estrelas(a, [[6, 26], [10, 25], [14, 26], [18, 25], [22, 26], [26, 25]]); G.estrelas(a, [[8, 6], [24, 4], [40, 7]], 3); G.chao(a, 28); },
  flor: (a) => { G.olho(a, 24, 24, 4); G.flor(a, 24, 14, 6); G.flor(a, 15, 19, 4); G.flor(a, 33, 19, 4); G.estrelas(a, [[8, 8], [40, 6], [30, 9]]); G.chao(a, 29); },
  pastor: (a) => { G.povo(a, 24, 28, 'ergue'); R(a, 27, 17, 1, 11, 1); for (const [x, y] of [[6, 26], [12, 27], [34, 27], [40, 26]]) G.copia(a, x, y); G.estrelas(a, [[10, 8], [38, 8], [24, 5]]); G.chao(a, 30, 2); },
  sutura: (a) => { G.olho(a, 24, 10, 4); G.sutura(a, 8, 21, 32); G.povo(a, 8, 28, 'ergue'); G.povo(a, 40, 28, 'ergue'); G.ponto(a, 24, 17); G.chao(a); },
  olho: (a) => { G.olho(a, 24, 17, 6, 0.6); G.rachadura(a, 24, 5, 6, 1); G.rachadura(a, 14, 22, 8, -1); G.rachadura(a, 36, 22, 8, 1); G.estrelas(a, [[6, 6], [42, 8]], 3); G.chao(a); },
  limo: (a) => { G.copia(a, 6, 24, true); G.olho(a, 34, 12, 6, 0.9); G.estrelas(a, [[16, 22], [20, 20], [24, 18], [28, 16]]); G.chao(a, 29); },
  fundacao: (a) => { G.fogueira(a, 23, 27); for (const x of [10, 16, 31, 37]) G.povo(a, x, 28, 'ajoelha'); G.onda(a, 24, 8, 2); G.estrelas(a, [[6, 5], [14, 9], [34, 7], [42, 5]], 3); G.chao(a); },
  tumulo: (a) => { R(a, 19, 21, 10, 7, 3); R(a, 20, 22, 8, 1, 1); G.flor(a, 24, 14, 7); G.flor(a, 17, 22, 4); G.povo(a, 9, 28, 'ajoelha'); G.povo(a, 39, 28, 'ajoelha'); G.chao(a); },
  pulso: (a) => { G.olho(a, 24, 16, 5, 0.5); G.onda(a, 24, 3, 3); G.rachadura(a, 8, 8, 8, 1); G.rachadura(a, 40, 8, 8, -1); G.ponto(a, 24, 24); G.chao(a); },
});

/** Retângulos da cena, recortados ao painel (nada sai da moldura). Moldura de 1 px inclusa. */
export function cenaRects(nome) {
  const f = CENAS[nome]; if (!f) return [];
  const bruto = []; f(bruto);
  const out = [[0, 0, PAINEL.w, 1, 3], [0, PAINEL.h - 1, PAINEL.w, 1, 3], [0, 0, 1, PAINEL.h, 3], [PAINEL.w - 1, 0, 1, PAINEL.h, 3]];
  for (const [x, y, w, h, c] of bruto) {
    const x0 = Math.max(1, x); const y0 = Math.max(1, y); const x1 = Math.min(PAINEL.w - 1, x + w); const y1 = Math.min(PAINEL.h - 1, y + h);
    if (x1 > x0 && y1 > y0) out.push([x0, y0, x1 - x0, y1 - y0, c]);
  }
  return out;
}

/** Cor de cada índice no tema do bioma (rgb). 0 vazio, 1 osso, 2 acento do bioma, 3 sombra. */
export function paletaDoMural(biome) {
  const acento = { raizes: [232, 168, 96], jardim: [110, 255, 214], nucleo: [196, 140, 255] }[biome] || [232, 168, 96];
  return [[10, 6, 10], [226, 210, 176], acento, [58, 40, 44]];
}
