// =====================================================================
// VALIDAÇÃO DE SALAS
// Roda ANTES de carregar uma sala. Se houver erro, a sala não é carregada e o
// motivo aparece no console de debug (em vez de o jogo quebrar de forma estranha).
// =====================================================================
import { geneDe, GENE_IDS, normalizeRequerGene } from '../entities/genes.js';
import { LAYER_NAMES } from './tilemap.js';
import { ABILITY_IDS, ABILITIES, normalizeRequires } from '../entities/abilities.js';
import { validarDepth } from '../render/depth-config.js';   // dados puros (sem DOM)
import { validarFeixes } from '../render/feixes.js';        // dados puros (sem DOM)
import { IDS_NPC } from '../render/npc-art.js';             // dados puros (sem DOM)

export const BIOME_IDS = ['raizes', 'jardim', 'nucleo'];

// Tipos de entidades suportadas oficialmente pelo motor e editor do jogo
export const KNOWN_ENTITY_TYPES = ['playerStart', 'checkpoint', 'mutation', 'vida', 'echo', 'npc', 'enemy', 'door', 'cura', 'ferida', 'tendrilAnchor', 'tendrilObject', 'paredeFragil', 'gene', 'encaixe', 'presenca'];
export const KNOWN_ENEMY_KINDS = ['crawler', 'flyer', 'leaper', 'armored', 'boss'];

// Regex para garantir IDs estritos e limpos (letras minúsculas, números e underscore)
const ID_RE = /^[a-z0-9_]+$/;

/** 
 * Verifica se a célula (x,y) do tilemap possui algum tile sólido em camadas que causam colisão.
 */
function celulaSolida(dados, catalogo, x, y) {
  for (const nome of ['solid', 'platform', 'interactive']) {
    const t = catalogo.get(dados.layers[nome]?.[y]?.[x]);
    if (t && t.collision === 'solid') return true;
  }
  return false;
}

const MAX_ERROS_POR_CAMADA = 8; // Limite de relatórios de erro por camada para evitar spam no log

/**
 * Valida a estrutura completa de dados JSON de uma sala.
 * @returns {{errors: string[], warnings: string[]}}
 * @param dados O objeto JSON da sala a ser validado.
 * @param catalogo O catálogo de tiles ativos.
 * @param opcoes Opções adicionais de validação (hitbox do player, dimensões da tela, IDs conhecidos).
 */
export function validateRoomData(dados, catalogo, opcoes = {}) {
  const errors = []; 
  const warnings = [];
  
  if (!dados || typeof dados !== 'object') {
    return { errors: ['A sala precisa ser um objeto JSON.'], warnings };
  }

  // --- Validação dos Metadados Principais ---
  if (typeof dados.id !== 'string' || !ID_RE.test(dados.id)) {
    errors.push('id inválido: use letras minúsculas, números e "_".');
  }
  if (typeof dados.name !== 'string' || !dados.name.trim()) {
    errors.push('Falta o nome ("name") da sala.');
  }
  if (!BIOME_IDS.includes(dados.biome)) {
    errors.push(`Bioma inválido: "${dados.biome}" (use ${BIOME_IDS.join(', ')}).`);
  }

  const dimOk = (n, max) => Number.isInteger(n) && n >= 1 && n <= max;
  if (!dimOk(dados.width, 500)) errors.push(`Largura inválida: ${dados.width} (inteiro de 1 a 500 tiles).`);
  if (!dimOk(dados.height, 500)) errors.push(`Altura inválida: ${dados.height} (inteiro de 1 a 500 tiles).`);
  if (!dimOk(dados.tileSize, 128) || dados.tileSize < 4) {
    errors.push(`tileSize inválido: ${dados.tileSize} (inteiro de 4 a 128).`);
  }
  if (catalogo && Number.isInteger(dados.tileSize) && catalogo.tileSize !== dados.tileSize) {
    errors.push(`tileSize da sala (${dados.tileSize}) difere do catálogo de tiles (${catalogo.tileSize}).`);
  }
  
  if (errors.length) return { errors, warnings }; // Sem dimensões válidas, interrompe validações dependentes

  // --- Validação das Camadas do Tilemap ---
  if (!dados.layers || typeof dados.layers !== 'object') {
    errors.push('Faltam as camadas ("layers").');
    return { errors, warnings };
  }
  for (const nome of Object.keys(dados.layers)) {
    if (!LAYER_NAMES.includes(nome)) {
      errors.push(`Camada desconhecida: "${nome}". Válidas: ${LAYER_NAMES.join(', ')}.`);
    }
  }
  if (!dados.layers.solid) errors.push('A camada "solid" é obrigatória.');

  for (const nome of LAYER_NAMES) {
    const linhas = dados.layers[nome];
    if (linhas === undefined) continue;
    if (!Array.isArray(linhas) || linhas.length !== dados.height) {
      errors.push(`Camada "${nome}": esperava ${dados.height} linhas, veio ${Array.isArray(linhas) ? linhas.length : 'não-lista'}.`);
      continue;
    }
    let reportados = 0; 
    let total = 0;
    for (let y = 0; y < dados.height; y++) {
      const linha = linhas[y];
      if (!Array.isArray(linha) || linha.length !== dados.width) {
        errors.push(`Camada "${nome}", linha ${y}: esperava ${dados.width} colunas, veio ${Array.isArray(linha) ? linha.length : 'não-lista'}.`);
        continue;
      }
      for (let x = 0; x < dados.width; x++) {
        const id = linha[x];
        let problema = null;
        if (!Number.isInteger(id) || id < 0) problema = `valor inválido (${JSON.stringify(id)})`;
        else if (id !== 0 && catalogo && !catalogo.has(id)) problema = `tile inexistente (ID ${id})`;
        if (problema) {
          total++;
          if (reportados < MAX_ERROS_POR_CAMADA) {
            errors.push(`Camada "${nome}" em (${x},${y}): ${problema}.`);
            reportados++;
          }
        }
      }
    }
    if (total > reportados) errors.push(`Camada "${nome}": mais ${total - reportados} célula(s) com problema.`);
    
    // Aviso se tiles na camada platform não forem do tipo correto
    if (nome === 'platform' && catalogo) {
      for (let y = 0; y < dados.height; y++) {
        for (let x = 0; x < dados.width; x++) {
          const t = catalogo.get(linhas[y]?.[x]);
          const fungoDormente = t?.mecanica?.tipo === 'fungo';
          if (t && t.collision !== 'oneway' && !fungoDormente) {
            warnings.push(`Camada "platform" em (${x},${y}): o tile "${t.name}" não é do tipo plataforma.`);
            y = dados.height; 
            break;
          }
        }
      }
    }
  }

  // --- Posição opcional da sala no mapa-múndi ---
  if (dados.mapPos !== undefined && !(dados.mapPos && Number.isInteger(dados.mapPos.x) && Number.isInteger(dados.mapPos.y))) {
    errors.push('mapPos deve ser {"x": inteiro, "y": inteiro} (posição da sala no mapa, em tiles).');
  }
  { const d = validarDepth(dados.depth); errors.push(...d.errors); warnings.push(...d.warnings); }   // v1.38: bloco 2.5D opcional
  { const f = validarFeixes(dados.feixes, dados); errors.push(...f.errors); warnings.push(...f.warnings); }   // v1.42: feixes de luz (opcional)

  // --- Validação de Entidades (PlayerStart, Checkpoints, Inimigos e Portas) ---
  const entidades = dados.entities;
  const idsUsados = new Set();
  if (!Array.isArray(entidades)) {
    errors.push('"entities" deve ser uma lista.');
  } else {
    let inicios = 0;
    entidades.forEach((e, i) => {
      if (!e || typeof e.type !== 'string') {
        errors.push(`Entidade ${i}: falta "type".`);
        return;
      }
      if (!KNOWN_ENTITY_TYPES.includes(e.type)) {
        errors.push(`Entidade ${i}: tipo desconhecido "${e.type}" (existem: ${KNOWN_ENTITY_TYPES.join(', ')}).`);
        return;
      }
      if (!Number.isInteger(e.x) || !Number.isInteger(e.y) || e.x < 0 || e.y < 0 || e.x >= dados.width || e.y >= dados.height) {
        errors.push(`Entidade ${i} (${e.type}): posição (${e.x},${e.y}) fora da sala.`);
        return;
      }
      if (e.type === 'playerStart') { 
        inicios++; 
        return; 
      }
      
      const rot = `Entidade ${i} (${e.type}${typeof e.id === 'string' ? ` "${e.id}"` : ''})`;
      const idOpcional = e.type === 'enemy' && e.id === undefined && e.kind !== 'boss';   // chefes precisam de ID persistente
      if (idOpcional) {
        // ok: o id de inimigo é opcional
      } else if (typeof e.id !== 'string' || !ID_RE.test(e.id)) {
        errors.push(`${rot}: falta o "id" (letras minúsculas, números e "_").`);
      } else if (idsUsados.has(e.id)) {
        errors.push(`${rot}: id "${e.id}" repetido na sala.`);
      } else {
        idsUsados.add(e.id);
      }
      
      // Validação específica para mutações/habilidades
      if (e.type === 'mutation') {
        if (!ABILITY_IDS.includes(e.ability)) {
          errors.push(`${rot}: habilidade inválida "${e.ability}" (use ${ABILITY_IDS.join(', ')}).`);
        } else if (!ABILITIES[e.ability].implementada) {
          warnings.push(`${rot}: a habilidade "${e.ability}" ainda não tem efeito no jogo.`);
        }
        if (e.requiresBoss !== undefined && (typeof e.requiresBoss !== 'string' || !/^[a-z0-9_]+:[a-z0-9_]+$/.test(e.requiresBoss))) {
          errors.push(`${rot}: "requiresBoss" deve ser um ID de chefe no formato sala:chefe.`);
        }
      }

      if (e.type === 'gene') {   // gene a coletar: "gene" é o id do catálogo (entities/genes.js)
        const g = geneDe(e.gene);
        if (!g) errors.push(`${rot}: gene inválido "${e.gene}" (use um destes: ${GENE_IDS.join(', ')}).`);
        else if (!g.implementado) warnings.push(`${rot}: o espaço de gene "${e.gene}" ainda está reservado (sem efeito no jogo).`);
      }

      if (e.type === 'echo' && (typeof e.text !== 'string' || !e.text.trim() || e.text.length > 160)) {
        errors.push(`${rot}: memória precisa de "text" com 1 a 160 caracteres.`);
      }

      if (e.type === 'npc') {   // v1.43: personagem com fala; vive na lista de entidades da sala, como o eco
        if (!IDS_NPC.includes(e.npc)) errors.push(`${rot}: "npc" desconhecido "${e.npc}" (use um destes: ${IDS_NPC.join(', ')}).`);
        if (typeof e.nome !== 'string' || !e.nome.trim() || e.nome.length > 24) errors.push(`${rot}: "nome" precisa ter 1 a 24 caracteres.`);
        if (!Array.isArray(e.falas) || !e.falas.length || e.falas.length > 8 || e.falas.some((f) => typeof f !== 'string' || !f.trim() || f.length > 170)) errors.push(`${rot}: "falas" precisa ser uma lista de 1 a 8 textos de até 170 caracteres.`);
      }

      if (e.type === 'paredeFragil') {   // parede rachada: cede ao ataque básico; os tiles sólidos vêm da própria sala
        for (const k of ['w', 'h']) if (!(Number.isInteger(e[k]) && e[k] >= 1 && e[k] <= 12)) errors.push(`${rot}: "${k}" deve ser um inteiro de 1 a 12 (em tiles).`);
        if (e.hp !== undefined && !(Number.isInteger(e.hp) && e.hp >= 1 && e.hp <= 12)) errors.push(`${rot}: "hp" deve ser um inteiro de 1 a 12.`);
        if (Number.isInteger(e.w) && Number.isInteger(e.h) && Number.isInteger(e.x) && Number.isInteger(e.y) && (e.x + e.w > dados.width || e.y + e.h > dados.height)) errors.push(`${rot}: a parede passa dos limites da sala.`);
      }
      if (e.type === 'tendrilAnchor' || e.type === 'tendrilObject') {
        for (const k of ['w', 'h']) if (e[k] !== undefined && !(Number.isInteger(e[k]) && e[k] >= 1 && e[k] <= 4)) errors.push(`${rot}: "${k}" deve ser um inteiro de 1 a 4 (em tiles).`);
        if (e.text !== undefined && (typeof e.text !== 'string' || e.text.length > 160)) errors.push(`${rot}: "text" deve ter até 160 caracteres.`);
        if (e.type === 'tendrilObject' && e.abre !== undefined) {
          const ok = Array.isArray(e.abre) && e.abre.every((r) => r && ['x', 'y', 'w', 'h'].every((k) => Number.isInteger(r[k])) && r.x >= 0 && r.y >= 0 && r.w >= 1 && r.h >= 1 && r.x + r.w <= dados.width && r.y + r.h <= dados.height);
          if (!ok) errors.push(`${rot}: "abre" deve ser uma lista de retângulos {x,y,w,h} (em tiles) dentro da sala.`);
        }
      }

      if (e.type === 'ferida') {
        if (e.custo !== undefined && !(Number.isInteger(e.custo) && e.custo >= 1 && e.custo <= 9)) errors.push(`${rot}: "custo" deve ser um inteiro de 1 a 9.`);
        if (e.text !== undefined && (typeof e.text !== 'string' || e.text.length > 160)) errors.push(`${rot}: "text" deve ter até 160 caracteres.`);
        if (e.abre !== undefined) {
          const ok = Array.isArray(e.abre) && e.abre.every((r) => r && ['x', 'y', 'w', 'h'].every((k) => Number.isInteger(r[k])) && r.x >= 0 && r.y >= 0 && r.w >= 1 && r.h >= 1 && r.x + r.w <= dados.width && r.y + r.h <= dados.height);
          if (!ok) errors.push(`${rot}: "abre" deve ser uma lista de retângulos {x,y,w,h} (em tiles) dentro da sala.`);
        }
      }

      if (e.type === 'enemy') {
        if (e.kind !== undefined && !KNOWN_ENEMY_KINDS.includes(e.kind)) {
          errors.push(`${rot}: espécie inválida "${e.kind}" (use ${KNOWN_ENEMY_KINDS.join(', ')}).`);
        }
        for (const campo of ['speed', 'life', 'damage']) {
          if (e[campo] !== undefined && (!Number.isFinite(e[campo]) || e[campo] <= 0)) {
            errors.push(`${rot}: "${campo}" precisa ser um número positivo.`);
          }
        }
        if (e.kind === 'boss' && typeof e.name !== 'string') errors.push(`${rot}: chefe precisa de um "name" legível.`);
      }

      // Validação específica para portas manuais (door)
      if (e.type === 'door') {
        if (e.dir !== undefined && !['left', 'right', 'up', 'down'].includes(e.dir)) {
          errors.push(`${rot}: direção inválida "${e.dir}" (use left, right, up, down).`);
        }
        // Validação da sala de destino manual (targetRoom)
        if (e.targetRoom !== undefined && e.targetRoom !== '') {
          if (typeof e.targetRoom !== 'string') {
            errors.push(`${rot}: "targetRoom" deve ser uma string.`);
          } else if (opcoes.knownRoomIds && !opcoes.knownRoomIds.includes(e.targetRoom)) {
            errors.push(`${rot}: a sala de destino "${e.targetRoom}" não existe no projeto.`);
          }
        }
        // Validação da porta de destino manual (targetDoor)
        if (e.targetDoor !== undefined && e.targetDoor !== '') {
          if (typeof e.targetDoor !== 'string') {
            errors.push(`${rot}: "targetDoor" deve ser uma string.`);
          }
        }
      }

      if (e.type !== 'paredeFragil' && catalogo && celulaSolida(dados, catalogo, e.x, e.y)) {   // a parede rachada É um bloco sólido de propósito
        errors.push(`${rot}: está dentro de um tile sólido.`);
      }
    });
    
    if (inicios !== 1) {
      errors.push(`A sala precisa de exatamente 1 "playerStart" (achei ${inicios}).`);
    }
  }

  // --- Validação de Conexões Tradicionais (se aplicável) ---
  const dentro = (x, y) => Number.isInteger(x) && Number.isInteger(y) && x >= 0 && y >= 0 && x < dados.width && y < dados.height;
  if (!Array.isArray(dados.connections)) {
    errors.push('"connections" deve ser uma lista (pode ser vazia).');
  } else {
    const idsConexao = new Set();
    dados.connections.forEach((c, i) => {
      if (!c || typeof c !== 'object') {
        errors.push(`Conexão ${i}: deve ser um objeto.`);
        return;
      }
      const rot = `Conexão ${i}${typeof c.id === 'string' ? ` "${c.id}"` : ''}`;
      if (typeof c.id !== 'string' || !ID_RE.test(c.id)) {
        errors.push(`${rot}: falta o "id" (letras minúsculas, números e "_").`);
      } else if (idsConexao.has(c.id)) {
        errors.push(`${rot}: id "${c.id}" repetido na sala.`);
      } else {
        idsConexao.add(c.id);
      }
      
      if (typeof c.to !== 'string' || !c.to) {
        errors.push(`${rot}: falta o destino ("to").`);
      } else if (opcoes.knownRoomIds && !opcoes.knownRoomIds.includes(c.to)) {
        errors.push(`${rot}: a sala de destino "${c.to}" não existe.`);
      }
      
      if (typeof c.toConnection !== 'string' || !c.toConnection) {
        errors.push(`${rot}: falta "toConnection" (o id da passagem correspondente na sala de destino).`);
      }
      
      const t = c.trigger;
      const trigOk = !!t && [t.x, t.y, t.w, t.h].every(Number.isInteger) && t.w >= 1 && t.h >= 1;
      if (!trigOk) {
        errors.push(`${rot}: "trigger" deve ter x, y, w, h inteiros (a área da passagem, em tiles).`);
      } else if (t.x < 0 || t.y < 0 || t.x + t.w > dados.width || t.y + t.h > dados.height) {
        errors.push(`${rot}: o "trigger" sai da sala.`);
      }
      
      // "spawn" (opcional) é um tile da sala de DESTINO; só a forma é checada aqui. Se faltar, o jogo
      // posiciona o jogador ao lado da passagem "toConnection" da sala de destino (World.validate confere o resto).
      const sp = c.spawn;
      if (sp !== undefined && sp !== null && !(Number.isInteger(sp.x) && Number.isInteger(sp.y))) {
        errors.push(`${rot}: \"spawn\" deve ter x e y inteiros (um tile da sala de destino).`);
      }

      if (c.requerGene !== undefined && c.requerGene !== null) {   // Ressonância: gene que precisa estar EQUIPADO para a passagem abrir
        const lista = normalizeRequerGene(c.requerGene);
        const ruim = lista.filter((id) => !GENE_IDS.includes(id));
        if (ruim.length || lista.length === 0 || (typeof c.requerGene !== 'string' && !Array.isArray(c.requerGene))) errors.push(`${rot}: "requerGene" inválido (${JSON.stringify(c.requerGene)}). Use um destes ids: ${GENE_IDS.join(', ')}.`);
        for (const id of lista) if (geneDe(id) && !geneDe(id).implementado) warnings.push(`${rot}: o gene "${id}" ainda é um espaço reservado: a passagem nunca abrirá.`);
      }

      if (c.requires !== undefined && c.requires !== null) {
        const lista = normalizeRequires(c.requires);
        const ruim = lista.filter((id) => !ABILITY_IDS.includes(id));
        if (ruim.length || (typeof c.requires !== 'string' && !Array.isArray(c.requires))) {
          errors.push(`${rot}: "requires" inválido (${JSON.stringify(c.requires)}).`);
        }
      }
    });
  }

  // --- Posição inicial segura do jogador (não pode nascer preso na parede) ---
  if (errors.length === 0 && catalogo && opcoes.playerHitbox) {
    const e = entidades.find((x) => x.type === 'playerStart');
    const { w, h } = opcoes.playerHitbox;
    const ts = dados.tileSize;
    const px = (e.x + 0.5) * ts - w / 2; 
    const py = (e.y + 1) * ts - h;
    const camadasSolidas = ['solid', 'platform', 'interactive'];
    let dentroDeParede = false; 
    let temChao = false;
    
    for (let ty = Math.floor(py / ts); ty <= Math.floor((py + h - 1e-4) / ts); ty++) {
      for (let tx = Math.floor(px / ts); tx <= Math.floor((px + w - 1e-4) / ts); tx++) {
        for (const nome of camadasSolidas) {
          const t = catalogo.get(dados.layers[nome]?.[ty]?.[tx]);
          if (t && t.collision === 'solid') dentroDeParede = true;
        }
      }
    }
    for (let ty = e.y + 1; ty < dados.height && !temChao; ty++) {
      for (const nome of camadasSolidas) {
        const t = catalogo.get(dados.layers[nome]?.[ty]?.[e.x]);
        if (t && (t.collision === 'solid' || t.collision === 'oneway')) temChao = true;
      }
    }
    if (dentroDeParede) {
      errors.push(`playerStart em (${e.x},${e.y}) está dentro de um tile sólido.`);
    } else if (!temChao) {
      warnings.push(`playerStart em (${e.x},${e.y}) não tem chão embaixo: o jogador cairá para fora da sala.`);
    }
  }

  // --- Avisos de design de tela ---
  if (opcoes.view && Number.isInteger(dados.width) && Number.isInteger(dados.height)) {
    if (dados.width * dados.tileSize < opcoes.view.width || dados.height * dados.tileSize < opcoes.view.height) {
      warnings.push(`Sala menor que a tela (${dados.width * dados.tileSize}x${dados.height * dados.tileSize} px): ficará centralizada.`);
    }
  }
  
  return { errors, warnings };
}
