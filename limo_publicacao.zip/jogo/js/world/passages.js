// =====================================================================
// PASSAGENS VISÍVEIS: calcula onde desenhar o "buraco" na parede de cada conexão/porta.
// Só geometria (px do mundo); o desenho fica em render/renderer.js.
//   side: lado da sala onde está a abertura (left/right/up/down)
//   locked: passagem selada (exige mutação) -> desenhada como membrana fechada
// =====================================================================
// O retângulo do gatilho é o contrato único da passagem: arte, luz, colisão e transição
// usam exatamente a mesma área. Assim uma membrana nunca "escapa" pelo corredor nem abre
// um buraco maior que a passagem lógica.
function ladoDaPassagem(dados, t) {
  if (t.x === 0) return 'left';
  if (t.x + t.w === dados.width) return 'right';
  if (t.y === 0) return 'up';
  if (t.y + t.h === dados.height) return 'down';
  // Dados legados: conserva uma direção previsível, mas não estica a geometria até a parede.
  const d = { left: t.x, right: dados.width - (t.x + t.w), up: t.y, down: dados.height - (t.y + t.h) };
  return Object.keys(d).reduce((a, b) => (d[b] < d[a] ? b : a), 'left');
}

export function buildPassages(dados, trancadas = new Set(), coresDeGene = new Map()) {
  const ts = dados.tileSize; const lista = [];
  for (const c of dados.connections || []) {
    const t = c.trigger; if (!t) continue;
    lista.push({
      id: c.id, conn: true, side: ladoDaPassagem(dados, t), locked: trancadas.has(c.id), corGene: coresDeGene.get(c.id) || null,
      x: t.x * ts, y: t.y * ts, w: t.w * ts, h: t.h * ts,
    });
  }
  return lista;
}
