// =====================================================================
// CATÁLOGO DE TILES
// Lê data/tiles.json e responde: "o que é o tile de ID 7?"
// Cada tile tem colisão, atrito, caixa de colisão (fração do tile) e arte:
//   - arte provisória por código (campo "art"), ou
//   - quadradinho de um spritesheet PNG (campo "sprite"), ou
//   - autotiling (campo "autotile"), com ou sem spritesheet.
// =====================================================================
import { validateTilesetDef, normalizeTileset } from './tileset.js';
import { AUTOTILE_MODES, defaultColumns } from './autotile.js';
import { validarReacao } from '../render/tile-reacao.js';

export const COLLISION_KINDS = ['none', 'solid', 'oneway', 'damage'];
export const TILE_CATEGORIES = [
  'carne', 'osso', 'cartilagem', 'musculo', 'membrana', 'veia', 'raiz', 'planta',
  'fungo', 'liquido', 'espinho', 'escorregadio', 'plataforma', 'interativo', 'fundo',
];
export const BIOMES = ['raizes', 'jardim', 'nucleo', 'todos'];

export class CatalogError extends Error {
  constructor(mensagem, erros = []) { super(mensagem); this.name = 'CatalogError'; this.errors = erros; }
}

/** Devolve a lista de erros do JSON do catálogo (vazia = válido). */
export function validateCatalogData(dados) {
  const erros = [];
  if (!dados || typeof dados !== 'object') return ['O catálogo precisa ser um objeto JSON.'];
  if (!Number.isInteger(dados.tileSize) || dados.tileSize < 4) erros.push('tileSize deve ser um inteiro >= 4.');
  if (!Array.isArray(dados.tiles) || dados.tiles.length === 0) { erros.push('"tiles" deve ser uma lista não vazia.'); return erros; }

  const conjuntos = new Set();
  if (dados.tilesets !== undefined) {
    if (!Array.isArray(dados.tilesets)) erros.push('"tilesets" deve ser uma lista.');
    else dados.tilesets.forEach((d, i) => {
      erros.push(...validateTilesetDef(d, i));
      if (d && conjuntos.has(d.id)) erros.push(`tileset "${d.id}": id duplicado.`);
      if (d) conjuntos.add(d.id);
    });
  }

  const vistos = new Set();
  for (const t of dados.tiles) {
    const nome = `tile ${t && t.id !== undefined ? t.id : '?'}`;
    if (!t || !Number.isInteger(t.id) || t.id <= 0) { erros.push(`${nome}: id deve ser inteiro positivo (0 é reservado para "vazio").`); continue; }
    if (vistos.has(t.id)) erros.push(`${nome}: id duplicado.`);
    vistos.add(t.id);
    if (typeof t.name !== 'string' || !t.name) erros.push(`${nome}: falta "name".`);
    if (!TILE_CATEGORIES.includes(t.category)) erros.push(`${nome}: categoria inválida "${t.category}".`);
    if (!BIOMES.includes(t.biome)) erros.push(`${nome}: bioma inválido "${t.biome}".`);
    if (!COLLISION_KINDS.includes(t.collision)) erros.push(`${nome}: collision inválida "${t.collision}".`);
    if (t.box !== undefined) {
      const b = t.box;
      const ok = Array.isArray(b) && b.length === 4 && b.every((n) => typeof n === 'number' && n >= 0 && n <= 1)
        && b[2] > 0 && b[3] > 0 && b[0] + b[2] <= 1 + 1e-9 && b[1] + b[3] <= 1 + 1e-9;
      if (!ok) erros.push(`${nome}: "box" deve ser [x,y,largura,altura] em frações de 0 a 1 dentro do tile.`);
    }
    if (t.friction !== undefined && !(typeof t.friction === 'number' && t.friction > 0 && t.friction <= 2)) erros.push(`${nome}: friction deve estar entre 0 (exclusivo) e 2.`);
    if (!t.art || typeof t.art.style !== 'string') erros.push(`${nome}: falta art.style (arte provisória, usada também se o PNG falhar).`);
    erros.push(...validarReacao(nome, t.reacao));   // v1.28.0: reação visual opcional (balanco | esmaga | treme | nenhuma)
    if (t.sprite !== undefined) {
      const s = t.sprite;
      if (!s || !conjuntos.has(s.set)) erros.push(`${nome}: sprite.set "${s && s.set}" não existe em "tilesets".`);
      else if (!Number.isInteger(s.col) || !Number.isInteger(s.row) || s.col < 0 || s.row < 0) erros.push(`${nome}: sprite.col/row devem ser inteiros >= 0.`);
    }
    if (t.autotile !== undefined) {
      const a = t.autotile;
      if (!a || !AUTOTILE_MODES.includes(a.mode)) erros.push(`${nome}: autotile.mode deve ser ${AUTOTILE_MODES.join(' ou ')}.`);
      else {
        if (a.set !== undefined && !conjuntos.has(a.set)) erros.push(`${nome}: autotile.set "${a.set}" não existe em "tilesets".`);
        for (const k of ['col', 'row']) if (a[k] !== undefined && (!Number.isInteger(a[k]) || a[k] < 0)) erros.push(`${nome}: autotile.${k} deve ser inteiro >= 0.`);
        if (a.columns !== undefined && (!Number.isInteger(a.columns) || a.columns < 1)) erros.push(`${nome}: autotile.columns deve ser inteiro >= 1.`);
        if (a.group !== undefined && typeof a.group !== 'string') erros.push(`${nome}: autotile.group deve ser texto.`);
        if (a.anchor !== undefined && !['down', 'up'].includes(a.anchor)) erros.push(`${nome}: autotile.anchor deve ser "down" (chão) ou "up" (teto).`);
        if (a.mode === 'deco' && t.collision !== 'none') erros.push(`${nome}: autotile "deco" só vale para tiles sem colisão (decoração).`);
      }
    }
  }
  return erros;
}

export class TileCatalog {
  constructor(dados) {
    const erros = validateCatalogData(dados);
    if (erros.length) throw new CatalogError(`Catálogo de tiles inválido (${erros.length} erro(s)): ${erros[0]}`, erros);
    this.tileSize = dados.tileSize;
    this.tilesets = new Map((dados.tilesets || []).map((d) => [d.id, normalizeTileset(d)]));
    this._tiles = new Map();
    for (const t of dados.tiles) {
      const a = t.autotile;
      this._tiles.set(t.id, {
        id: t.id, name: t.name, category: t.category, biome: t.biome, collision: t.collision,
        box: t.box || [0, 0, 1, 1],
        friction: t.friction ?? 1,
        damage: t.collision === 'damage' ? (t.damage ?? 1) : 0,
        art: t.art,
        reacao: t.reacao || null,       // v1.28.0: como a decoração reage a Limo/inimigos (ver render/tile-reacao.js); padrão por art.style
        mecanica: t.mecanica || null,   // comportamento vivo: {tipo:'pulso'|'fungo', ...} (ver game._prepararVivos)
        sprite: t.sprite ? { set: t.sprite.set, col: t.sprite.col, row: t.sprite.row } : null,
        autotile: a ? {
          mode: a.mode, group: a.group ?? String(t.id), set: a.set ?? null,
          col: a.col ?? 0, row: a.row ?? 0, columns: a.columns ?? defaultColumns(a.mode),
          anchor: a.anchor ?? 'down',            // só modo deco: lado em que a decoração se prende ('down' = chão, 'up' = teto)
          edgeConnects: a.edgeConnects ?? true,   // fora da sala conta como "conectado" (paredes da sala fecham certinho)
        } : null,
      });
    }
  }
  get(id) { return this._tiles.get(id); }
  has(id) { return this._tiles.has(id); }
  all() { return [...this._tiles.values()]; }
}
