// =====================================================================
// MUNDO: todas as salas e as passagens entre elas.
// =====================================================================
import { buildRoom, loadRoomIndex, RoomLoadError, defaultFetchJson, tileToSpawnPx, computeSpawn } from './room-loader.js';
import { checkRequirement } from '../entities/abilities.js';
import { checkGenes, nomeDoGene } from '../entities/genes.js';

// Função utilitária para estruturar respostas de erro padronizadas
const falha = (reason, message) => ({ ok: false, reason, message });

export class World {
  constructor(config, catalog, logger = null) {
    this.config = config; 
    this.catalog = catalog; 
    this.logger = logger;
    this.rooms = new Map(); // Mapa de todas as salas carregadas no mundo (ID -> Dados JSON)
    this.loadErrors = [];   // Registo de erros de carregamento de salas
    this.currentRoomId = null;
  }

  // Carrega assincronamente todas as salas do jogo a partir do índice e dependências
  static async load(config, catalog, logger = null, fetchJson = defaultFetchJson) {
    const mundo = new World(config, catalog, logger);
    const indice = await loadRoomIndex(config, logger, fetchJson);   // lido uma única vez
    const fila = [...indice];
    if (!fila.includes(config.rooms.startRoom)) fila.unshift(config.rooms.startRoom);
    const vistos = new Set();
    
    while (fila.length) {
      const id = fila.shift();
      if (vistos.has(id)) continue;
      vistos.add(id);
      try {
        const dados = await fetchJson(`${config.rooms.path}${id}.json`);
        mundo.addRoom(dados);
        for (const c of dados.connections || []) {
          if (c && typeof c.to === 'string' && !vistos.has(c.to)) fila.push(c.to);
        }
      } catch (e) {
        mundo.loadErrors.push({ id, erro: e.message });
        logger?.warn('carregamento', `Sala \"${id}\" não carregou: ${e.message}`);
      }
    }
    
    if (!mundo.rooms.has(config.rooms.startRoom)) {
      throw new RoomLoadError(`A sala inicial "${config.rooms.startRoom}" não pôde ser carregada.`);
    }
    return mundo;
  }

  addRoom(dados) {
    buildRoom(dados, this.catalog, this.config, this.logger);
    this.rooms.set(dados.id, dados);
  }

  has(id) { return this.rooms.has(id); }
  get(id) { return this.rooms.get(id); }
  ids() { return [...this.rooms.keys()]; }
  build(id) { return buildRoom(this.rooms.get(id), this.catalog, this.config, this.logger); }

  // Calcula a posição em pixeis onde o jogador deve surgir com base nas coordenadas de tiles (spawn)
  spawnPx(dados, spawn) {
    return tileToSpawnPx(dados.tileSize, spawn.x, spawn.y, this.config.player.hitbox);
  }

  /**
   * Ponto de chegada calculado pela abertura correspondente na sala de destino.
   * O spawn da conexão de origem era priorizado e podia estar desatualizado,
   * fazendo o jogador surgir longe da passagem, inclusive fora da área visível.
   */
  _spawnDeChegada(destino, conn, progressoAbertura = null) {
    const par = (destino.connections || []).find((c) => c.id === conn.toConnection);
    if (par?.trigger) {
      const t = par.trigger;
      let tx = Math.round(t.x + (t.w - 1) / 2);
      let ty = Math.round(t.y + (t.h - 1) / 2);
      const dist = {
        left: t.x,
        right: destino.width - (t.x + t.w),
        up: t.y,
        down: destino.height - (t.y + t.h),
      };
      const lado = Object.keys(dist).reduce((a, b) => dist[b] < dist[a] ? b : a, 'left');
      if (lado === 'left') tx = t.x + t.w + 1;
      else if (lado === 'right') tx = t.x - 2;
      else if (lado === 'up') ty = t.y + t.h + 1;
      else ty = t.y - 2;
      tx = Math.max(1, Math.min(destino.width - 2, tx));
      ty = Math.max(1, Math.min(destino.height - 2, ty));
      const spawn = this.spawnPx(destino, { x: tx, y: ty });
      // Em portas laterais, mantém a mesma altura relativa em que o jogador
      // atravessou a abertura de origem, em vez de centralizar toda chegada.
      if ((lado === 'left' || lado === 'right') && Number.isFinite(progressoAbertura)) {
        const hitbox = this.config.player.hitbox;
        const inicioY = t.y * destino.tileSize;
        const fimY = (t.y + t.h) * destino.tileSize - hitbox.h;
        const centroDesejado = (t.y + Math.max(0, Math.min(1, progressoAbertura)) * t.h) * destino.tileSize;
        spawn.y = Math.max(inicioY, Math.min(fimY, centroDesejado - hitbox.h / 2));
      }
      return spawn;
    }
    // Compatibilidade com salas antigas sem conexão pareada.
    if (conn.spawn && Number.isFinite(conn.spawn.x) && Number.isFinite(conn.spawn.y)) {
      const tx = Math.max(1, Math.min(destino.width - 2, conn.spawn.x));
      const ty = Math.max(1, Math.min(destino.height - 2, conn.spawn.y));
      return this.spawnPx(destino, { x: tx, y: ty });
    }
    return computeSpawn(destino, this.config);
  }

  triggerRect(dados, conn) {
    const ts = dados.tileSize; 
    const t = conn.trigger;
    return { x: t.x * ts, y: t.y * ts, w: t.w * ts, h: t.h * ts };
  }

  /** Passagens da sala que estão seladas (exigem habilidade): viram barreiras físicas no mapa. */
  barrierRects(roomId, abilities, dados = this.rooms.get(roomId), genes = []) {
    const lista = [];
    if (!dados || !dados.connections) return lista;
    for (const c of dados.connections) {
      if ((c.requires && !checkRequirement(abilities, c.requires).ok) || !checkGenes(genes, c.requerGene).ok) {
        lista.push({ ...this.triggerRect(dados, c), connId: c.id });
      }
    }
    return lista;
  }


  // Resolve a transição automática por uma abertura de borda.
  resolveTransition(fromId, connId, abilities, origem = this.rooms.get(fromId), progressoAbertura = null, genes = []) {
    const conn = origem && origem.connections && origem.connections.find((c) => c.id === connId);
    if (!conn) return falha('conexao-inexistente', `A passagem "${connId}" não existe.`);
    const req = checkRequirement(abilities, conn.requires);
    if (!req.ok) return { ok: false, reason: 'bloqueada', missing: req.missing, message: `Passagem selada.` };
    const gen = checkGenes(genes, conn.requerGene);   // Ressonância: vale o gene equipado agora
    if (!gen.ok) return { ok: false, reason: 'bloqueada', missing: [], missingGenes: gen.missing, message: `Passagem selada: equipe ${gen.missing.map(nomeDoGene).join(' + ')} num Casulo de Repouso.` };
    const destino = this.rooms.get(conn.to);
    if (!destino) return falha('sala-inexistente', `Destino "${conn.to}" não existe.`);
    return { ok: true, toRoom: conn.to, toConnection: conn.toConnection || null, spawn: this._spawnDeChegada(destino, conn, progressoAbertura) };
  }

  analyzeProgression() {
    return { reached: new Set(this.rooms.keys()), abilities: {}, unreachable: [] };
  }

  /** Confere se cada passagem de borda aponta para uma sala e retorno válidos. */
  validate() {
    const errors = []; const warnings = [];
    for (const [id, d] of this.rooms) {
      for (const c of d.connections || []) {
        const dest = this.rooms.get(c.to);
        if (!dest) { errors.push(`${id}.${c.id}: a sala \"${c.to}\" não existe.`); continue; }
        if (c.spawn && !(c.spawn.x >= 0 && c.spawn.y >= 0 && c.spawn.x < dest.width && c.spawn.y < dest.height)) errors.push(`${id}.${c.id}: o spawn (${c.spawn.x},${c.spawn.y}) cai fora da sala \"${c.to}\".`);
        if (c.toConnection) {
          const par = (dest.connections || []).find((x) => x.id === c.toConnection);
          if (!par) errors.push(`${id}.${c.id}: "${c.to}" não tem a passagem "${c.toConnection}".`);
          else if (par.to !== id) warnings.push(`${id}.${c.id}: retorno ${dest.id}.${par.id} aponta para "${par.to}", não para "${id}".`);
        }
      }
    }
    return { errors, warnings };
  }
}
