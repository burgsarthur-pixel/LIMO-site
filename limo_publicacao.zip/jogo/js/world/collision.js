// =====================================================================
// COLISÃO (AABB contra o TileMap)
//
// Como funciona (explicado para quem está aprendendo):
//  1. Movemos o corpo SÓ no eixo X e resolvemos colisões; depois SÓ no eixo Y.
//     Mover um eixo por vez evita travar em quinas.
//  2. Nunca movemos mais que meio tile por vez. Assim, mesmo em velocidades
//     enormes (investida, queda), o corpo não "pula por cima" de uma parede fina.
//  3. Ao encostar num tile sólido, o corpo é empurrado para fora, colado na face.
//  4. Plataformas "oneway" só seguram quem vem de cima (e já estava acima delas).
// =====================================================================

const EPS = 1e-4;

export function rectsOverlap(ax, ay, aw, ah, bx, by, bw, bh) {
  return ax < bx + bw - EPS && ax + aw > bx + EPS && ay < by + bh - EPS && ay + ah > by + EPS;
}

export function createContacts() { return { left: false, right: false, up: false, down: false }; }

/**
 * Move `body` {x,y,w,h} por (dx,dy) respeitando o mapa.
 * @param opcoes.dropThrough  se true, ignora plataformas oneway (queda atravessando)
 * @returns contatos desta movimentação {left,right,up,down}
 */
export function moveBody(mapa, body, dx, dy, opcoes = {}, contatos = createContacts()) {
  contatos.left = contatos.right = contatos.up = contatos.down = false;
  const passoMax = Math.max(1, mapa.tileSize / 2);

  if (dx !== 0) {
    const n = Math.ceil(Math.abs(dx) / passoMax);
    const passo = dx / n;
    for (let i = 0; i < n; i++) {
      body.x += passo;
      let bloqueou = false;
      mapa.forEachCollidable(body.x, body.y, body.w, body.h, (c) => {
        if (c.kind !== 'solid') return;
        if (!rectsOverlap(body.x, body.y, body.w, body.h, c.x, c.y, c.w, c.h)) return;
        if (passo > 0) { body.x = c.x - body.w; contatos.right = true; } else { body.x = c.x + c.w; contatos.left = true; }
        bloqueou = true;
      });
      if (bloqueou) break;
    }
  }

  if (dy !== 0) {
    const n = Math.ceil(Math.abs(dy) / passoMax);
    const passo = dy / n;
    for (let i = 0; i < n; i++) {
      const pesAntes = body.y + body.h;
      body.y += passo;
      let bloqueou = false;
      mapa.forEachCollidable(body.x, body.y, body.w, body.h, (c) => {
        if (c.kind === 'solid') {
          if (!rectsOverlap(body.x, body.y, body.w, body.h, c.x, c.y, c.w, c.h)) return;
          if (passo > 0) { body.y = c.y - body.h; contatos.down = true; } else { body.y = c.y + c.h; contatos.up = true; }
          bloqueou = true;
        } else if (c.kind === 'oneway' && passo > 0 && !opcoes.dropThrough) {
          // só segura se os pés estavam acima do topo e há sobreposição horizontal
          const sobreposto = body.x < c.x + c.w - EPS && body.x + body.w > c.x + EPS;
          if (sobreposto && pesAntes <= c.y + 1e-3 && body.y + body.h > c.y) {
            body.y = c.y - body.h; contatos.down = true; bloqueou = true;
          }
        }
      });
      if (bloqueou) break;
    }
  }
  return contatos;
}

/**
 * Há chão logo abaixo dos pés (faixa de 1 px)? Devolve {kind, tile, x, y} ou null.
 * Usado para saber se o jogador está no chão mesmo sem ter se movido neste passo.
 */
export function probeGround(mapa, body, dropThrough = false) {
  let achado = null;
  const pes = body.y + body.h;
  mapa.forEachCollidable(body.x, pes, body.w, 1, (c) => {
    if (achado) return;
    if (!rectsOverlap(body.x, pes, body.w, 1, c.x, c.y, c.w, c.h)) return;
    if (c.kind === 'solid' || (c.kind === 'oneway' && !dropThrough && pes <= c.y + 1e-3)) {
      achado = { kind: c.kind, tile: c.tile, x: c.x, y: c.y };
    }
  });
  return achado;
}

/** O corpo toca alguma zona de dano? Devolve {tile, x, y, w, h} ou null. */
export function probeDamage(mapa, body) {
  let achado = null;
  mapa.forEachCollidable(body.x, body.y, body.w, body.h, (c) => {
    if (achado || c.kind !== 'damage') return;
    if (rectsOverlap(body.x, body.y, body.w, body.h, c.x, c.y, c.w, c.h)) achado = { tile: c.tile, x: c.x, y: c.y, w: c.w, h: c.h };
  });
  return achado;
}
