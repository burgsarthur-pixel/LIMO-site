// =====================================================================
// NPCs — FALAS POR PROGRESSO (v1.44.0) E ROTINA (v1.45.0) — dados e regras puros, sem DOM. Mesmo estilo de evolucao.js / vida-dados.js.
// O que o NPC diz depende do que o jogador JÁ FEZ, e isso é DERIVADO do progresso existente:
//   bossesDefeated · abilities · visited · collected (ecos) · descobertas (textos "npc:<id>:<marca>", guardados no save que já existia)
// Nada novo no salvamento, nada por quadro: a escolha roda UMA vez, ao abrir a conversa.
//
// Cada NPC tem uma lista ORDENADA de variantes: vale a primeira cujas condições (`quando`, todas) forem cumpridas.
// Sem variante válida, vale `falas` da própria entidade da sala (a fala original, sem mudança).
//
// ROTINA (v1.45): `rotinas` = lista ORDENADA de rotinas (vale a primeira cujo `quando` for cumprido; sem `quando` = padrão). Uma rotina é um ciclo
// de blocos (parado · caminha · trabalha · descansa) entre âncoras em tiles. A posição é uma FUNÇÃO PURA do tempo local (`estadoNoTempo`):
// sem integrar velocidade, sem deriva, impossível sair do chão. Quem anima e reage é `js/entities/npc-viva.js`.
// `marca` = o que registrar ao conversar (além de "conversou", que sempre é registrado) para a variante seguinte aparecer.
// =====================================================================
export const CHEFE_TECELA = 'raizes_guardiao:guardiao_raizes';   // "Tecelã das Raízes"

/** Condições conhecidas (cada uma recebe o valor do `quando` e o progresso). Chave desconhecida = variante nunca vale (e o teste reprova). */
const CONDICOES = Object.freeze({
  chefe: (v, p) => (p.bossesDefeated || []).includes(v),                 // chefe derrotado
  semChefe: (v, p) => !(p.bossesDefeated || []).includes(v),
  tem: (v, p) => !!p.descobertas?.has?.(v),                              // já registrou esta marca/descoberta
  nao: (v, p) => !p.descobertas?.has?.(v),
  habilidade: (v, p) => !!p.abilities?.[v],                              // já tem esta mutação
  visitou: (v, p) => !!p.visited?.has?.(v),                              // já passou por esta sala
  ecos: (v, p) => v.de.filter((k) => p.collected?.has?.(k)).length >= (v.min ?? v.de.length),   // v1.50.0: ouviu ao menos `min` dos ecos de `de`
  novo: (v, p) => !v || ((p.collected?.size || 0) === 0 && !(p.bossesDefeated || []).length),   // v1.50.0: jogo recém-começado
  eco: (v, p) => !!p.collected?.has?.(v),                                // já ouviu este eco de memória ("sala:id", a mesma chave de chaveItem)
});
export const CHAVES_DE_CONDICAO = Object.freeze(Object.keys(CONDICOES));

export const chaveNpc = (npc, marca) => `npc:${npc}:${marca}`;

// Âncoras e reações do Fio Solto (tiles; y = linha em que ele fica em pé). Chão contínuo medido em raizes_bosque: x 9–18 na linha 10.
const BASE_FIO_SOLTO = Object.freeze({
  ancoras: Object.freeze({ casa: Object.freeze({ x: 9, y: 10 }), banca: Object.freeze({ x: 12, y: 10 }) }), inicial: 'casa', ciclo: 40,
  // criaturaPerto: o Saltador patrulha o mesmo chão; 4 tiles (e não 5) para ele não nascer já "assustando" o NPC no início da sala
  reacoes: Object.freeze({ limoPerto: Object.freeze({ raioTiles: 3, maxSeg: 8 }), criaturaPerto: Object.freeze({ raioTiles: 4, durMin: 3 }) }),
});

// Jardineira Cega (Etapa 2.1, sem mudança de versão): o primeiro encontro e as conversas seguintes. Estátua viva: sem rotina.
// Ordem: vale a primeira variante cujas condições valem. Cada uma aparece uma vez (`marca`). Sem variante, vale a fala da sala.
// Lore (docs/NARRATIVA_JARDIM.md): ela não conhece a origem de Limo; percebe algo familiar nele sem dizer o que é.
const JARDINEIRA = Object.freeze({
  variantes: Object.freeze([
    { id: 'primeiro_encontro', quando: { nao: chaveNpc('jardineira', 'encontro') }, marca: 'encontro', falas: [
      'Você pisou nas raízes com cuidado. Quase ninguém faz isso por aqui.',
      'Não enxergo, mas sinto a terra. Quando uma raiz começa a cansar, eu sinto antes que ela murche.',
      'Quando as raízes enfraquecem, eu costuro, replanto e espero. Quase sempre elas voltam.',
      'O Esquecimento não é crueldade. É uma deterioração. A vida ainda insiste, e eu insisto com ela.',
      'Há algo familiar em você. Não sei dizer o que é, e prefiro não inventar uma resposta.',
    ] },
    { id: 'depois_casulos', quando: { tem: chaveNpc('jardineira', 'encontro'), nao: chaveNpc('jardineira', 'casulos'), ecos: { de: ['raizes_bercario:eco_casulo_nome', 'raizes_bercario:eco_casulo_cheiro', 'raizes_bercario:eco_casulo_cantiga'], min: 2 } }, marca: 'casulos', falas: [
      'Você ouviu os casulos vazios do Berçário. Eles guardam nomes que ninguém mais repete.',
      'Quando alguém lembra de quem se perdeu, as raízes ficam mais firmes. Obrigada por ter ouvido.',
    ] },
    { id: 'depois_tecela', quando: { tem: chaveNpc('jardineira', 'encontro'), chefe: CHEFE_TECELA, nao: chaveNpc('jardineira', 'tecela') }, marca: 'tecela', falas: [
      'A Tecelã tentava fechar uma ferida e acabou presa nela. As raízes sentiram isso. Eu também senti.',
      'Não a culpo pela deterioração. Ela só estava tentando segurar o que escorria.',
    ] },
    // v2.1 · curiosidade: uma habilidade específica (pseudópode). Ela percebe o gesto, sem explicar a origem.
    { id: 'pseudopode', quando: { tem: chaveNpc('jardineira', 'encontro'), habilidade: 'pseudopode', nao: chaveNpc('jardineira', 'pseudopode') }, marca: 'pseudopode', falas: [
      'Quando você estende aquela parte parecida com raiz, as raízes daqui se viram para você.',
      'Parece que reconhecem o gesto. Não sei explicar, e não quero inventar uma explicação.',
    ] },
    // v2.1 · cuidado: passou pelo Berçário (sala de origem dos casulos). Uma vez só.
    { id: 'bercario', quando: { tem: chaveNpc('jardineira', 'encontro'), visitou: 'raizes_bercario', nao: chaveNpc('jardineira', 'bercario') }, marca: 'bercario', falas: [
      'Você passou pelo Berçário. Algumas raízes de lá ainda estão frágeis.',
      'Se alguma delas afrouxar, eu sinto. Obrigada por ter passado com cuidado.',
    ] },
    // v2.1 · a sequência de "volta": três falas, cada uma uma vez, e depois uma fala calma que se repete.
    { id: 'volta_1', quando: { tem: chaveNpc('jardineira', 'encontro'), nao: chaveNpc('jardineira', 'volta_1') }, marca: 'volta_1', falas: [
      'Suas raízes estão firmes hoje. Siga o caminho que elas mostram.',
    ] },
    { id: 'volta_2', quando: { tem: chaveNpc('jardineira', 'volta_1'), nao: chaveNpc('jardineira', 'volta_2') }, marca: 'volta_2', falas: [
      'Às vezes eu fico aqui só ouvindo a terra. Ela conta quando alguém passa com cuidado.',
    ] },
    { id: 'volta_3', quando: { tem: chaveNpc('jardineira', 'volta_2'), nao: chaveNpc('jardineira', 'volta_3') }, marca: 'volta_3', falas: [
      'Quando você partir, algumas raízes vão se endireitar. Não é coincidência. É o jeito delas de agradecer.',
    ] },
    { id: 'volta', quando: { tem: chaveNpc('jardineira', 'encontro') }, falas: [
      'Continue com cuidado. As raízes percebem.',
    ] },
  ]),
});

// Pastor das Vísceras (Etapa 2.4.3.1): antes chefe do Jardim; agora NPC reservado. Usa só a fala que já existia na história. Sem rotina: fica parado.
const PASTOR_VISCERAS = Object.freeze({
  variantes: Object.freeze([
    { id: 'fala', quando: {}, falas: Object.freeze(['Nós sonhamos com uma forma que se perdeu. Você se parece com ela.']) },
  ]),
});

export const NPCS = Object.freeze({
  jardineira: JARDINEIRA,
  pastor_visceras: PASTOR_VISCERAS,
  fio_solto: {
    rotinas: Object.freeze([
      // Depois da Tecelã o lugar sossegou: ele trabalha pouco e descansa muito.
      {
        ...BASE_FIO_SOLTO, id: 'pos_tecela', quando: { chefe: CHEFE_TECELA },
        blocos: Object.freeze([
          { estado: 'parado', em: 'casa', dur: 4 }, { estado: 'caminha', de: 'casa', para: 'banca', dur: 4 }, { estado: 'trabalha', em: 'banca', dur: 4 },
          { estado: 'caminha', de: 'banca', para: 'casa', dur: 4 }, { estado: 'descansa', em: 'casa', dur: 24 },
        ]),
      },
      {
        ...BASE_FIO_SOLTO, id: 'padrao',
        blocos: Object.freeze([
          { estado: 'parado', em: 'casa', dur: 6 }, { estado: 'caminha', de: 'casa', para: 'banca', dur: 4 }, { estado: 'trabalha', em: 'banca', dur: 10 },
          { estado: 'caminha', de: 'banca', para: 'casa', dur: 4 }, { estado: 'descansa', em: 'casa', dur: 16 },
        ]),
      },
    ]),
    variantes: Object.freeze([
      // A Tecelã caiu e ele ainda não comentou: a reação grande, uma vez só.
      {
        id: 'pos_tecela', quando: { chefe: CHEFE_TECELA, nao: chaveNpc('fio_solto', 'pos_tecela') }, marca: 'pos_tecela',
        falas: [
          'Os fios ficaram quietos de repente... É como se o lugar tivesse soltado o ar.',
          'Foi você, não foi? Ela costurou estas raízes por tanto tempo. Acho que agora elas podem descansar.',
        ],
      },
      // Depois disso, uma frase só.
      { id: 'pos_tecela_repete', quando: { chefe: CHEFE_TECELA }, falas: ['As raízes estão calmas hoje. Quase dá para ouvir o Deus dormir.'] },
      // v1.50.0: depois do aviso, ele entrega o pedaço que guarda da Tecelã (uma vez). Na luta, o clarão de memória fica mais vivo.
      {
        id: 'pedaco_tecela', quando: { tem: chaveNpc('fio_solto', 'aviso_tecela'), nao: chaveNpc('fio_solto', 'pedaco_tecela') }, marca: 'pedaco_tecela',
        falas: [
          'Espere. Guardei uma coisa dela, de antes de os fios apertarem.',
          'Ela remendava a pele do Deus com uma agulha de osso e cantava baixinho para o corte não doer.',
          'Leve o pedaço. Quando a luta ficar dura, lembre: ela ainda está aí dentro, segurando.',
        ],
      },
      // Passou pela Antessala das Fibras: ele avisa sobre a Tecelã (uma vez, depois de já terem conversado).
      {
        id: 'aviso_tecela', quando: { tem: chaveNpc('fio_solto', 'conversou'), visitou: 'raizes_antecamara', nao: chaveNpc('fio_solto', 'aviso_tecela') }, marca: 'aviso_tecela',
        falas: [
          'Você passou pela Antessala, não foi? Sentiu os fios? Estão esticados demais, como se doessem.',
          'A Tecelã não prende ninguém por maldade. Ela segura o que está se soltando, e a mão dela já não obedece.',
          'Se for vê-la, lembre do que ela era antes. Eu guardo alguns pedaços disso.',
        ],
      },
      // Ouviu o eco do Berçário: ele fala dos fragmentos que guarda e do que não reconhece em Limo (sem revelar nada).
      {
        id: 'fragmentos', quando: { tem: chaveNpc('fio_solto', 'conversou'), eco: 'raizes_bercario:eco_raizes_bercario', nao: chaveNpc('fio_solto', 'fragmentos') }, marca: 'fragmentos',
        falas: [
          'Você ouviu os casulos do Berçário? Eu guardo o que as criaturas deixam cair: um nome, um cheiro, uma cantiga.',
          'Quase nunca vêm inteiros. Mas guardar pouco ainda é melhor do que deixar tudo se perder.',
          'Seu jeito de ser não combina com nenhum dos meus fragmentos. Não sei de onde veio. Talvez nem você.',
        ],
      },
      // v1.50.0: tocou nos casulos do Berçário: ele reconhece os restos (e a cantiga que liga a Tecelã).
      {
        id: 'reconhece', quando: { tem: chaveNpc('fio_solto', 'fragmentos'), ecos: { de: ['raizes_bercario:eco_casulo_nome', 'raizes_bercario:eco_casulo_cheiro', 'raizes_bercario:eco_casulo_cantiga'], min: 2 }, nao: chaveNpc('fio_solto', 'reconhece') }, marca: 'reconhece',
        falas: [
          'Esses casulos que você tocou... eu conheço esses restos. Um nome, um cheiro, um refrão.',
          'Segura o fio. Era a cantiga de quem remendava. Alguém lembrou isso por mim, sem saber.',
          'Obrigado por não deixar cair.',
        ],
      },
      // Já conversaram, a Tecelã ainda está de pé.
      {
        id: 'volta', quando: { tem: chaveNpc('fio_solto', 'conversou') },
        falas: ['Você voltou. Os fios continuam falando baixinho.', 'Se encontrar a Tecelã, diga que ainda lembro dela.'],
      },
    ]),
  },
});

/** Todas as condições da variante são cumpridas pelo progresso? (progresso nulo = só variantes sem condição) */
export function cumpre(quando, progresso) {
  const entradas = Object.entries(quando || {});
  if (!entradas.length) return true;
  if (!progresso) return false;
  return entradas.every(([k, v]) => !!CONDICOES[k] && CONDICOES[k](v, progresso));
}

/**
 * Escolhe o que o NPC diz agora. Devolve { id, falas, marcas }:
 *   id      'padrao' (a fala da sala) ou o id da variante
 *   marcas  chaves de descoberta a registrar depois de abrir a conversa ("conversou" + a `marca` da variante)
 * Sem progresso (editor/expedição), devolve a fala da sala e nenhuma marca.
 */
export function escolherFalas(entidade, progresso) {
  const padrao = { id: 'padrao', falas: entidade?.falas || [], marcas: [] };
  if (!progresso || !entidade?.npc) return padrao;
  const marcas = [chaveNpc(entidade.npc, 'conversou')];
  const v = (NPCS[entidade.npc]?.variantes || []).find((x) => cumpre(x.quando, progresso));
  if (v?.marca) marcas.push(chaveNpc(entidade.npc, v.marca));
  return { id: v ? v.id : 'padrao', falas: v ? [...v.falas] : padrao.falas, marcas };
}

export const ESTADOS_DE_ROTINA = Object.freeze(['parado', 'caminha', 'trabalha', 'descansa']);
export const MAX_NPCS_COM_ROTINA_POR_SALA = 3;

/** A rotina que vale agora para este NPC (a primeira cujo `quando` é cumprido). Sem progresso: só a rotina sem `quando`. null = NPC sem rotina (estátua). */
export function rotinaVigente(npcId, progresso) {
  return (NPCS[npcId]?.rotinas || []).find((r) => cumpre(r.quando, progresso)) || null;
}

/** Faixa de chão que a rotina percorre, em tiles: { x0, x1, y } (união de todas as rotinas do NPC). null = sem rotina. Usada pelo gerador de decoração. */
export function faixaDaRotina(npcId) {
  const rs = NPCS[npcId]?.rotinas; if (!rs?.length) return null;
  let x0 = Infinity; let x1 = -Infinity; let y = null;
  for (const r of rs) for (const a of Object.values(r.ancoras)) { x0 = Math.min(x0, a.x); x1 = Math.max(x1, a.x); y = a.y; }
  return { x0, x1, y };
}

/**
 * Rotina em pixels, pronta para `estadoNoTempo`: cada bloco ganha t0/t1, x0/x1 (px, canto esquerdo da célula), y (px, topo da célula) e `facing`.
 * Bloco parado/trabalha/descansa herda a direção do último bloco que andou (cíclico); sem nenhum, 1 (direita).
 */
export function compilarRotina(rot, ts = 16) {
  const A = rot.ancoras; let t = 0; const blocos = [];
  for (const b of rot.blocos) {
    const de = A[b.estado === 'caminha' ? b.de : b.em]; const para = A[b.estado === 'caminha' ? b.para : b.em];
    blocos.push({ estado: b.estado, t0: t, t1: t + b.dur, x0: de.x * ts, x1: para.x * ts, y: de.y * ts, facing: Math.sign(para.x - de.x) || 0 });
    t += b.dur;
  }
  for (let i = 0; i < blocos.length; i++) {
    if (blocos[i].facing) continue;
    let f = 1; for (let k = 1; k <= blocos.length; k++) { const q = blocos[(i - k + blocos.length * 2) % blocos.length]; if (q.facing) { f = q.facing; break; } }
    blocos[i].facing = f;
  }
  const ini = A[rot.inicial] || Object.values(A)[0];
  return { id: rot.id, ciclo: rot.ciclo, blocos, inicial: { x: ini.x * ts, y: ini.y * ts } };
}

/** Estado no instante t (s): escreve em `out` {estado, x, y, facing, prog} (reuso: sem alocação) e o devolve. Periódico em `ciclo`; x fica sempre entre as âncoras. */
export function estadoNoTempo(comp, t, out = {}) {
  let u = t % comp.ciclo; if (u < 0) u += comp.ciclo;
  let b = comp.blocos[comp.blocos.length - 1];
  for (let i = 0; i < comp.blocos.length; i++) if (u < comp.blocos[i].t1) { b = comp.blocos[i]; break; }
  const p = Math.min(1, Math.max(0, (u - b.t0) / (b.t1 - b.t0))); const e = b.estado === 'caminha' ? p * p * (3 - 2 * p) : 0;   // anda com partida e chegada suaves
  out.estado = b.estado; out.x = b.x0 + (b.x1 - b.x0) * e; out.y = b.y; out.facing = b.facing; out.prog = p; return out;
}

function problemasDaRotina(npc, r, erros) {
  const nome = `${npc}.rotina.${r.id}`; const A = r.ancoras || {};
  if (!r.id) erros.push(`${nome}: id ausente`);
  if (!Object.keys(A).length || Object.keys(A).length > 6 || Object.values(A).some((a) => !Number.isInteger(a?.x) || !Number.isInteger(a?.y))) erros.push(`${nome}: âncoras inválidas (1–6, tiles inteiros)`);
  if (!A[r.inicial]) erros.push(`${nome}: "inicial" não é uma âncora`);
  if (!Array.isArray(r.blocos) || !r.blocos.length) { erros.push(`${nome}: sem blocos`); return; }
  let soma = 0; let fim = null; let primeiro = null;
  for (const [i, b] of r.blocos.entries()) {
    if (!ESTADOS_DE_ROTINA.includes(b.estado)) { erros.push(`${nome}[${i}]: estado desconhecido "${b.estado}"`); continue; }
    if (!(b.dur > 0)) erros.push(`${nome}[${i}]: dur deve ser > 0`); soma += b.dur || 0;
    const de = A[b.estado === 'caminha' ? b.de : b.em]; const para = A[b.estado === 'caminha' ? b.para : b.em];
    if (!de || !para) { erros.push(`${nome}[${i}]: âncora inexistente`); continue; }
    if (de.y !== para.y) erros.push(`${nome}[${i}]: caminhar entre âncoras de linhas diferentes (só chão plano)`);
    if (b.estado === 'caminha' && de === para) erros.push(`${nome}[${i}]: caminha de uma âncora para ela mesma`);
    if (fim && (fim.x !== de.x || fim.y !== de.y)) erros.push(`${nome}[${i}]: o bloco não começa onde o anterior terminou (teleporte)`);
    primeiro ||= de; fim = para;
  }
  if (primeiro && fim && (primeiro.x !== fim.x || primeiro.y !== fim.y)) erros.push(`${nome}: o ciclo não fecha (termina fora de onde começa)`);
  if (Math.abs(soma - r.ciclo) > 1e-9) erros.push(`${nome}: os blocos somam ${soma} s mas o ciclo é ${r.ciclo} s`);
  const re = r.reacoes || {};
  if (re.limoPerto && !(re.limoPerto.raioTiles > 0)) erros.push(`${nome}: limoPerto.raioTiles inválido`);
  if (re.criaturaPerto && !(re.criaturaPerto.raioTiles > 0 && re.criaturaPerto.durMin >= 0)) erros.push(`${nome}: criaturaPerto inválido`);
  for (const [k] of Object.entries(r.quando || {})) if (!CHAVES_DE_CONDICAO.includes(k)) erros.push(`${nome}: condição desconhecida "${k}"`);
}

/** Problemas nos dados (usado pelo teste): condição desconhecida, fala vazia/longa, id repetido. */
export function problemasDosDados(npcs = NPCS, chefesConhecidos = null) {
  const erros = [];
  for (const [npc, def] of Object.entries(npcs)) {
    const ids = new Set(); const rids = new Set();
    for (const r of def.rotinas || []) { if (rids.has(r.id)) erros.push(`${npc}.rotina.${r.id}: id repetido`); rids.add(r.id); problemasDaRotina(npc, r, erros); }
    if ((def.rotinas || []).length && !(def.rotinas || []).some((r) => !r.quando)) erros.push(`${npc}: precisa de uma rotina padrão (sem \`quando\`)`);
    for (const v of def.variantes || []) {
      const nome = `${npc}.${v.id}`;
      if (!v.id || ids.has(v.id)) erros.push(`${nome}: id ausente ou repetido`); ids.add(v.id);
      if (!Array.isArray(v.falas) || !v.falas.length || v.falas.length > 8 || v.falas.some((f) => typeof f !== 'string' || !f.trim() || f.length > 170)) erros.push(`${nome}: falas inválidas (1–8 textos de até 170 caracteres)`);
      for (const [k, val] of Object.entries(v.quando || {})) {
        if (!CHAVES_DE_CONDICAO.includes(k)) erros.push(`${nome}: condição desconhecida "${k}"`);
        else if ((k === 'chefe' || k === 'semChefe') && chefesConhecidos && !chefesConhecidos.includes(val)) erros.push(`${nome}: chefe inexistente "${val}"`);
        else if (k === 'ecos' && !(Array.isArray(val?.de) && val.de.length && val.de.every((e) => /^[a-z0-9_]+:[a-z0-9_]+$/.test(String(e))) && (val.min === undefined || (val.min >= 1 && val.min <= val.de.length)))) erros.push(`${nome}: ecos inválido (esperado {de:[sala:id,...], min})`);
        else if (k === 'eco' && !/^[a-z0-9_]+:[a-z0-9_]+$/.test(String(val))) erros.push(`${nome}: eco "${val}" fora do padrão sala:id`);
        else if ((k === 'tem' || k === 'nao') && !String(val).startsWith(`npc:${npc}:`) && !/^(cri|evt|hist):/.test(String(val))) erros.push(`${nome}: marca "${val}" fora do padrão`);
      }
      if (v.marca !== undefined && !/^[a-z0-9_]+$/.test(v.marca)) erros.push(`${nome}: marca inválida`);
    }
  }
  return erros;
}
