// =====================================================================
// POSICIONAMENTO DE CHEGADA — encontra um piso seguro dentro da sala.
// Em uma porta na borda inferior, o jogador entra vindo de baixo; portanto,
// o piso de aterrissagem fica ACIMA da abertura (y menor), não abaixo dela.
// =====================================================================
import { probeGround, probeDamage, rectsOverlap } from './collision.js';

function caminhoLivre(map, body, inicio, fim, arco) {
  // Amostra a curva que o jogo vai animar. Impede que o surgimento atravesse
  // paredes sólidas ou espinhos, mesmo com a física suspensa.
  for (let i = 2; i <= 15; i++) {
    const u = i / 16;
    const suave = u * u * (3 - 2 * u);
    const x = inicio.x + (fim.x - inicio.x) * suave;
    const y = inicio.y + (fim.y - inicio.y) * suave - Math.sin(Math.PI * u) * arco;
    if (x < 0 || y < 0 || x + body.w > map.pixelWidth || y + body.h > map.pixelHeight) return false;
    let bloqueado = false;
    map.forEachCollidable(x, y, body.w, body.h, (c) => {
      if ((c.kind === 'solid' || c.kind === 'damage') && rectsOverlap(x, y, body.w, body.h, c.x, c.y, c.w, c.h)) {
        bloqueado = true;
      }
    });
    if (bloqueado) return false;
  }
  return true;
}

/**
 * Procura uma plataforma/piso seguro próximo de uma abertura inferior.
 * `spawn` é o ponto de entrada calculado a partir da conexão pareada.
 * Retorna { x, y, groundInfo } ou null quando a sala não oferece pouso local.
 */
export function findSafeVerticalLanding(map, body, spawn, trigger, direction = 'up') {
  if (!map || !body || !spawn || !trigger) return null;

  const ts = map.tileSize;
  const passo = Math.max(2, Math.floor(ts / 4));
  const raioX = Math.min(map.pixelWidth, Math.max(ts * 7, (trigger.w + 2) * ts));
  const minX = Math.max(0, Math.min(map.pixelWidth - body.w, spawn.x - raioX));
  const maxX = Math.max(0, Math.min(map.pixelWidth - body.w, spawn.x + raioX));
  const maxDy = direction === 'up' ? Math.max(0, spawn.y) : Math.max(0, map.pixelHeight - body.h - spawn.y);
  const candidatos = [];

  // Varre posições horizontais da abertura para fora, em passos pequenos.
  // Isso permite alcançar uma plataforma próxima mesmo quando ela não está
  // exatamente alinhada ao centro da porta.
  const xs = [];
  for (let x = Math.max(minX, spawn.x - raioX); x <= Math.min(maxX, spawn.x + raioX) + 0.001; x += passo) xs.push(x);
  if (!xs.some((x) => Math.abs(x - spawn.x) < 0.001)) xs.push(Math.max(minX, Math.min(maxX, spawn.x)));
  xs.sort((a, b) => Math.abs(a - spawn.x) - Math.abs(b - spawn.x));

  for (const x of xs) {
    // Entrada inferior: pousa acima; entrada superior: cai até o piso abaixo.
    for (let dy = 0; dy <= maxDy; dy += passo) {
      const y = spawn.y + (direction === 'up' ? -dy : dy);
      if (y < 0 || y + body.h > map.pixelHeight) continue;
      const candidato = { x, y, w: body.w, h: body.h };
      const groundInfo = probeGround(map, candidato);
      if (!groundInfo) continue;
      if (probeDamage(map, candidato)) continue;

      let sobrepoeSolido = false;
      map.forEachCollidable(candidato.x, candidato.y, candidato.w, candidato.h, (c) => {
        if (c.kind === 'solid' && rectsOverlap(candidato.x, candidato.y, candidato.w, candidato.h, c.x, c.y, c.w, c.h)) {
          sobrepoeSolido = true;
        }
      });
      if (sobrepoeSolido) continue;

      const dx = Math.abs(x - spawn.x);
      const arco = direction === 'up' ? Math.min(15, Math.max(8, Math.abs(spawn.y - y) * 0.12)) : 0;
      if (!caminhoLivre(map, body, spawn, { x, y }, arco)) continue;
      // Dá peso maior à proximidade horizontal da porta para favorecer um
      // bloco sólido ao lado da abertura, sem escolher um pouso absurdamente
      // distante na vertical quando a coluna alinhada não tem piso próximo.
      const score = dy + dx * 4;
      candidatos.push({ x, y, groundInfo, dx, dy, score });
      break; // primeiro piso seguro acima da porta para esta coluna
    }
  }

  if (!candidatos.length) return null;
  candidatos.sort((a, b) => a.score - b.score || a.dx - b.dx || a.dy - b.dy);
  const { x, y, groundInfo } = candidatos[0];
  return { x, y, groundInfo };
}
