// =====================================================================
// PERSONALIDADE DAS SALAS (dados puros, sem DOM): o que faz cada sala parecer um LUGAR dentro do corpo de uma entidade colossal.
//
// Por que fica aqui e não no JSON da sala: o exportador do editor só preserva os campos que conhece, então qualquer campo novo
// na sala seria apagado ao salvar. Este módulo é indexado pelo id da sala; sala sem entrada usa o padrão do bioma.
//
// Cada personalidade tem:
//   tema      rótulo curto do lugar
//   historia  o que a sala conta SEM diálogo (documentação e testes; ver docs/historico/CORPO_COLOSSAL_v1.33.0.md)
//   escala    silhuetas gigantes no fundo, em parallax (render/colosso.js): costelas, coluna, palpebra, orgao, membrana,
//             raizesGigantes, tendoes, veiaGigante — dão a medida do tamanho do corpo
//   motes     partículas de ar da sala: cinza | esporo | brasa | fio | bolha
//   respira   0..1: quanto o corpo "respira" nesta sala (silhuetas se movem, o ar escurece/clareia devagar)
//   props     adereços narrativos que tools/decorar_salas.mjs coloca nas camadas de decoração
//   vegetacao vegetação/fungos/raízes de enchimento (chão e teto) com densidade
// =====================================================================

/** Ids dos tiles de decoração usados pelas regras (iguais aos de data/tiles.json). */
export const TILE = Object.freeze({
  planta: 12, fungo: 19, raizPendurada: 20, hera: 44, fungoLanterna: 45, veiaExposta: 56, coral: 78, flor: 79, lampada: 80,
  estalactite: 81, cipo: 82, bolhaMuco: 83, fossil: 84, concha: 85,
  // v1.33.0 — narrativos e orgânicos novos
  casulo: 88, restos: 89, abraco: 90, costela: 91, vertebras: 92, sutura: 93, ovos: 94, palpebra: 95, prateleira: 96, cortina: 97, musgo: 98, bulbo: 99,
});
const T = TILE;

/** Tipos de silhueta aceitos em `escala` (o teste confere contra render/colosso.js). */
export const TIPOS_ESCALA = Object.freeze(['costelas', 'coluna', 'palpebra', 'orgao', 'membrana', 'raizesGigantes', 'tendoes', 'veiaGigante']);
export const TIPOS_MOTE = Object.freeze(['cinza', 'esporo', 'brasa', 'fio', 'bolha']);

const veg = (chao, teto, densidade) => ({ chao, teto, densidade });

/** Padrão por bioma (salas novas, criadas no editor, herdam isto; não ganham adereços automáticos). */
export const PADRAO_BIOMA = Object.freeze({
  raizes: { tema: 'Ossuário', historia: '', escala: [{ tipo: 'costelas', de: 'base', n: 4, prof: 0.08 }], motes: { tipo: 'cinza', n: 10 }, respira: 0.5, props: [], vegetacao: veg([], [], 0) },
  jardim: { tema: 'Jardim', historia: '', escala: [{ tipo: 'membrana', prof: 0.1 }], motes: { tipo: 'esporo', n: 12 }, respira: 0.5, props: [], vegetacao: veg([], [], 0) },
  nucleo: { tema: 'Santuário', historia: '', escala: [{ tipo: 'orgao', prof: 0.07 }], motes: { tipo: 'brasa', n: 10 }, respira: 0.8, props: [], vegetacao: veg([], [], 0) },
});

export const PERSONALIDADES = Object.freeze({
  // ============================ RAÍZES · ossuário, carne envelhecida, raízes olivas ============================
  raizes_02: {
    tema: 'Chaminé de raízes', historia: 'Raízes enormes descem procurando parede para subir; duas delas seguram restos pequenos e não largam.',
    escala: [{ tipo: 'raizesGigantes', n: 3, prof: 0.1 }], motes: { tipo: 'fio', n: 10 }, respira: 0.5,
    props: [{ tile: T.abraco, n: 2, zona: 'baixo' }, { tile: T.cortina, n: 3, onde: 'teto' }],
    vegetacao: veg([[T.planta, 3], [T.fungo, 2], [T.prateleira, 1]], [[T.raizPendurada, 2], [T.cipo, 1]], 0.1),
  },
  raizes_antecamara: {
    tema: 'Fibras tensas', historia: 'Fios tensos cruzam o ar como tendões esticados; costuras no chão mostram que alguém já tentou fechar o que se rasga aqui.',
    escala: [{ tipo: 'tendoes', n: 8, prof: 0.14 }], motes: { tipo: 'cinza', n: 10 }, respira: 0.6,
    props: [{ tile: T.sutura, n: 3, grupo: [1, 2] }, { tile: T.cortina, n: 3, onde: 'teto' }, { tile: T.abraco, n: 1 }],
    vegetacao: veg([[T.planta, 2], [T.fungo, 2]], [[T.raizPendurada, 2], [T.cortina, 2]], 0.08),
  },
  raizes_ascensao: {
    tema: 'Caixa torácica', historia: 'A subida acontece por dentro de uma caixa torácica: costelas gigantes curvam-se sobre você e vértebras caídas marcam o caminho de quem subiu antes.',
    escala: [{ tipo: 'costelas', de: 'base', n: 5, prof: 0.08 }, { tipo: 'coluna', x: 0.8, prof: 0.06 }], motes: { tipo: 'cinza', n: 12 }, respira: 0.7,
    props: [{ tile: T.costela, n: 4 }, { tile: T.vertebras, n: 2 }, { tile: T.sutura, n: 1 }],
    vegetacao: veg([[T.planta, 2], [T.fungo, 2], [T.coral, 1]], [[T.estalactite, 2], [T.raizPendurada, 1]], 0.1),
  },
  raizes_bercario: {
    tema: 'Memorial calcificado', historia: 'Fileiras de casulos vazios, ovos calcificados e uma criatura murcha, parecida com Limo: o Deus tentou lembrar uma forma perdida muitas vezes, e cada tentativa ficou guardada aqui.',
    escala: [{ tipo: 'costelas', de: 'base', n: 4, prof: 0.08, intensidade: 0.8 }], motes: { tipo: 'cinza', n: 14 }, respira: 0.35,
    props: [{ tile: T.casulo, n: 7, grupo: [1, 2] }, { tile: T.ovos, n: 2 }, { tile: T.restos, n: 2 }, { tile: T.vertebras, n: 1 }],
    vegetacao: veg([[T.fungo, 2], [T.coral, 1]], [[T.estalactite, 2]], 0.05),
  },
  raizes_bosque: {
    tema: 'Bosque fúngico', historia: 'O bosque cresceu bonito demais: fungos-prateleira e musgo cobrem cascas murchas de criaturas parecidas com Limo, escondidas à vista.',
    escala: [{ tipo: 'raizesGigantes', n: 3, prof: 0.1 }], motes: { tipo: 'esporo', n: 16 }, respira: 0.5,
    props: [{ tile: T.restos, n: 2 }, { tile: T.prateleira, n: 6, grupo: [1, 2] }, { tile: T.musgo, n: 4, grupo: [2, 3] }],
    vegetacao: veg([[T.planta, 3], [T.fungo, 3], [T.prateleira, 2], [T.fungoLanterna, 1]], [[T.raizPendurada, 2], [T.cortina, 2], [T.cipo, 1]], 0.18),
  },
  raizes_camara: {
    tema: 'Ferida quente', historia: 'A ferida pulsa quente; costuras abandonadas ao redor mostram tentativas de fechá-la, e uma raiz ainda abraça quem tentou.',
    escala: [{ tipo: 'orgao', prof: 0.09 }], motes: { tipo: 'brasa', n: 12 }, respira: 0.8,
    props: [{ tile: T.sutura, n: 4, grupo: [1, 2] }, { tile: T.bulbo, n: 2 }, { tile: T.abraco, n: 1, perto: 'checkpoint' }],
    vegetacao: veg([[T.planta, 2], [T.fungo, 2]], [[T.raizPendurada, 2]], 0.08),
  },
  raizes_coroa: {
    tema: 'Coroa de costelas', historia: 'Costelas descem do teto em círculo como uma coroa, abertas para uma luz que ainda não aprendeu o seu nome; no chão, uma pálpebra dorme.',
    escala: [{ tipo: 'costelas', de: 'topo', n: 6, prof: 0.07 }], motes: { tipo: 'esporo', n: 12 }, respira: 0.6,
    props: [{ tile: T.costela, n: 5 }, { tile: T.vertebras, n: 1 }, { tile: T.palpebra, n: 1 }],
    vegetacao: veg([[T.planta, 2], [T.fungo, 2]], [[T.estalactite, 2], [T.raizPendurada, 1]], 0.1),
  },
  raizes_guardiao: {
    tema: 'Ninho de fios', historia: 'A guardiã teceu fios por toda parte; suturas e raízes que abraçam restos mostram que ela mantinha o corpo unido, não o ferido.',
    escala: [{ tipo: 'tendoes', n: 9, prof: 0.12 }], motes: { tipo: 'fio', n: 14 }, respira: 0.5,
    props: [{ tile: T.abraco, n: 3 }, { tile: T.sutura, n: 4, grupo: [1, 2] }, { tile: T.casulo, n: 2 }],
    vegetacao: veg([[T.planta, 2], [T.fungo, 2]], [[T.cortina, 2], [T.raizPendurada, 1]], 0.06),
  },
  raizes_nicho: {
    tema: 'Suspiro escondido', historia: 'Um nicho minúsculo onde o ar sobe e desce devagar: uma pálpebra fechada, ovos e musgo. O Deus respira aqui.',
    escala: [{ tipo: 'orgao', prof: 0.05, intensidade: 0.9 }], motes: { tipo: 'bolha', n: 8 }, respira: 1,
    props: [{ tile: T.palpebra, n: 1, zona: 'centro' }, { tile: T.ovos, n: 1 }, { tile: T.musgo, n: 3, grupo: [2, 3] }],
    vegetacao: veg([[T.fungo, 2], [T.musgo, 2]], [[T.raizPendurada, 1]], 0.1),
  },
  raizes_santuario: {
    tema: 'Instante guardado', historia: 'Uma gruta mínima onde o corpo do Deus guardou, num casulo vazio, o intervalo entre a ferida e o fechar-se dela. O ar quase não se move.',
    escala: [{ tipo: 'orgao', prof: 0.05, intensidade: 0.8 }], motes: { tipo: 'bolha', n: 6 }, respira: 0.3,
    props: [{ tile: T.casulo, n: 1, zona: 'centro' }, { tile: T.bulbo, n: 1 }, { tile: T.musgo, n: 3, grupo: [2, 3] }],
    vegetacao: veg([[T.fungo, 2], [T.musgo, 2]], [[T.raizPendurada, 1]], 0.1),
  },
  raizes_teste: {
    tema: 'Galeria do tronco', historia: 'Uma galeria longa dentro do tronco do corpo: ossos de escala impossível, casulos vazios e raízes que seguram o que restou.',
    escala: [{ tipo: 'costelas', de: 'base', n: 6, prof: 0.08 }, { tipo: 'coluna', x: 0.3, prof: 0.05 }], motes: { tipo: 'cinza', n: 14 }, respira: 0.6,
    props: [{ tile: T.vertebras, n: 5 }, { tile: T.costela, n: 8 }, { tile: T.abraco, n: 3 }, { tile: T.casulo, n: 4, grupo: [1, 2] }, { tile: T.restos, n: 2 }, { tile: T.sutura, n: 2 }],
    vegetacao: veg([[T.planta, 3], [T.fungo, 2], [T.coral, 1], [T.prateleira, 1]], [[T.estalactite, 2], [T.raizPendurada, 2], [T.cortina, 1]], 0.07),
  },
  raizes_tuneis: {
    tema: 'Veias antigas', historia: 'Os túneis foram veias: ainda há costuras, vértebras e cortinas de raiz onde o sangue passava.',
    escala: [{ tipo: 'veiaGigante', n: 1, prof: 0.1 }, { tipo: 'tendoes', n: 5, prof: 0.15 }], motes: { tipo: 'cinza', n: 10 }, respira: 0.6,
    props: [{ tile: T.vertebras, n: 2 }, { tile: T.sutura, n: 2 }, { tile: T.cortina, n: 4, onde: 'teto' }, { tile: T.abraco, n: 1 }],
    vegetacao: veg([[T.planta, 2], [T.fungo, 2]], [[T.raizPendurada, 2], [T.cipo, 1]], 0.08),
  },
  raizes_veia: {
    tema: 'Vaso colossal', historia: 'Uma veia colossal cruza a sala e pulsa; bulbos inchados mostram onde o corpo ainda tenta se curar.',
    escala: [{ tipo: 'veiaGigante', n: 2, prof: 0.1 }], motes: { tipo: 'brasa', n: 10 }, respira: 0.9,
    props: [{ tile: T.bulbo, n: 3 }, { tile: T.sutura, n: 1 }, { tile: T.abraco, n: 1 }],
    vegetacao: veg([[T.planta, 2], [T.fungo, 1]], [[T.raizPendurada, 2]], 0.06),
  },

  // ============================ JARDIM · flora sepulcral, lanternas, criaturas parecidas com Limo ============================
  jardim_copa: {
    tema: 'Copa e ninho', historia: 'A copa das lanternas abriga um ninho esquecido: ovos luminosos e uma casca murcha lembram que aqui já nasceu algo.',
    escala: [{ tipo: 'membrana', prof: 0.1 }], motes: { tipo: 'esporo', n: 16 }, respira: 0.5,
    props: [{ tile: T.ovos, n: 2 }, { tile: T.restos, n: 1 }, { tile: T.musgo, n: 4, grupo: [2, 3] }],
    vegetacao: veg([[T.hera, 3], [T.fungoLanterna, 2], [T.flor, 2], [T.lampada, 1], [T.planta, 1]], [[T.cipo, 2], [T.raizPendurada, 1]], 0.16),
  },
  jardim_entrada: {
    tema: 'Refúgio de lanternas', historia: 'Lanternas gentis guardam o calor de quem já não tem corpo: uma raiz abraça os restos de uma criatura, ao lado do ponto de descanso.',
    escala: [{ tipo: 'membrana', prof: 0.1 }], motes: { tipo: 'esporo', n: 14 }, respira: 0.4,
    props: [{ tile: T.restos, n: 1, perto: 'checkpoint' }, { tile: T.abraco, n: 1, perto: 'checkpoint' }, { tile: T.musgo, n: 5, grupo: [2, 3] }],
    vegetacao: veg([[T.hera, 3], [T.fungoLanterna, 2], [T.flor, 2], [T.lampada, 1]], [[T.cipo, 2]], 0.16),
  },
  jardim_galerias: {
    tema: 'Trilha do rebanho', historia: 'Uma fila de criaturas murchas marca o caminho onde o rebanho passou; ovos novos mostram que ele continua crescendo.',
    escala: [{ tipo: 'veiaGigante', n: 1, prof: 0.1 }, { tipo: 'membrana', prof: 0.12, intensidade: 0.8 }], motes: { tipo: 'bolha', n: 12 }, respira: 0.8,
    props: [{ tile: T.restos, n: 4 }, { tile: T.ovos, n: 3 }, { tile: T.sutura, n: 1 }],
    vegetacao: veg([[T.hera, 2], [T.fungoLanterna, 2], [T.bolhaMuco, 2]], [[T.cipo, 2]], 0.1),
  },
  jardim_lago: {
    tema: 'Berçário do rebanho', historia: 'O lago de muco é o berçário do rebanho do Pastor: ovos em fileira e cascas caídas na margem.',
    escala: [{ tipo: 'membrana', prof: 0.1 }], motes: { tipo: 'bolha', n: 14 }, respira: 0.7,
    props: [{ tile: T.ovos, n: 5, grupo: [1, 2] }, { tile: T.restos, n: 3 }, { tile: T.bulbo, n: 2 }],
    vegetacao: veg([[T.bolhaMuco, 3], [T.hera, 1], [T.fungoLanterna, 1], [T.musgo, 3]], [[T.cipo, 1]], 0.12),
  },
  jardim_nicho: {
    tema: 'Confissão', historia: 'O que o Deus escondeu de si mesmo: uma pálpebra fechada, um casulo vazio e uma ferida costurada às pressas.',
    escala: [{ tipo: 'membrana', prof: 0.06 }], motes: { tipo: 'bolha', n: 8 }, respira: 0.9,
    props: [{ tile: T.palpebra, n: 1, zona: 'centro' }, { tile: T.casulo, n: 1 }, { tile: T.sutura, n: 1 }],
    vegetacao: veg([[T.hera, 1], [T.fungoLanterna, 1]], [[T.cipo, 1]], 0.08),
  },
  jardim_poco_ancora: {
    tema: 'Poço de raízes', historia: 'Algo paciente puxa as plantas para cima por raízes enormes; vértebras e raízes que abraçam restos mostram quem já foi levado.',
    escala: [{ tipo: 'raizesGigantes', n: 4, prof: 0.09 }, { tipo: 'coluna', x: 0.85, prof: 0.05 }], motes: { tipo: 'fio', n: 12 }, respira: 0.5,
    props: [{ tile: T.cortina, n: 6, onde: 'teto' }, { tile: T.vertebras, n: 2 }, { tile: T.abraco, n: 2 }],
    vegetacao: veg([[T.hera, 2], [T.planta, 1], [T.fungoLanterna, 1]], [[T.cipo, 2], [T.raizPendurada, 1]], 0.08),
  },
  jardim_secreto: {
    tema: 'Ninho do primeiro esporo', historia: 'Cascas de outras criaturas em círculo: houve outras antes, e todas terminaram aqui.',
    escala: [{ tipo: 'membrana', prof: 0.1 }], motes: { tipo: 'esporo', n: 16 }, respira: 0.6,
    props: [{ tile: T.restos, n: 5, zona: 'centro' }, { tile: T.ovos, n: 2 }, { tile: T.musgo, n: 4, grupo: [2, 3] }],
    vegetacao: veg([[T.hera, 2], [T.fungoLanterna, 2], [T.flor, 2]], [[T.cipo, 1]], 0.12),
  },
  jardim_sutura: {
    tema: 'Câmara da costura', historia: 'Um membro foi costurado à copa com fio de cirurgião: pontos por toda a sala, e a raiz que ainda o segura.',
    escala: [{ tipo: 'tendoes', n: 7, prof: 0.13 }, { tipo: 'veiaGigante', n: 1, prof: 0.1 }], motes: { tipo: 'bolha', n: 10 }, respira: 0.6,
    props: [{ tile: T.sutura, n: 6, grupo: [1, 2] }, { tile: T.abraco, n: 1 }, { tile: T.bulbo, n: 2 }],
    vegetacao: veg([[T.hera, 2], [T.fungoLanterna, 1]], [[T.cipo, 2]], 0.08),
  },

  // ============================ NÚCLEO · santuário violeta, o coração do Deus ============================
  nucleo_condutos: {
    tema: 'Condutos eternos', historia: 'Condutos que nunca param de fluir: bulbos inchados e ossos fossilizados nas margens do que corre.',
    escala: [{ tipo: 'veiaGigante', n: 3, prof: 0.1 }, { tipo: 'tendoes', n: 5, prof: 0.15 }], motes: { tipo: 'brasa', n: 12 }, respira: 0.8,
    props: [{ tile: T.vertebras, n: 2 }, { tile: T.bulbo, n: 3 }, { tile: T.fossil, n: 2 }],
    vegetacao: veg([[T.fossil, 1], [T.bulbo, 2], [T.fungo, 1]], [[T.veiaExposta, 3], [T.cipo, 1]], 0.06),
  },
  nucleo_coracao: {
    tema: 'Câmara do coração', historia: 'O coração residual dorme sob uma pálpebra gigante, cercado por uma caixa de costelas; costuras e uma casca murcha de forma parecida com a sua.',
    escala: [{ tipo: 'orgao', prof: 0.06, intensidade: 1.3 }, { tipo: 'palpebra', prof: 0.04 }], motes: { tipo: 'brasa', n: 16 }, respira: 1,
    props: [{ tile: T.palpebra, n: 2 }, { tile: T.costela, n: 4 }, { tile: T.sutura, n: 2 }, { tile: T.restos, n: 1 }],
    vegetacao: veg([[T.bulbo, 2], [T.fossil, 1]], [[T.veiaExposta, 2]], 0.04),
  },
  nucleo_fissura: {
    tema: 'Fenda de ritmo', historia: 'A fenda ensina a carne a suportar o próprio ritmo: costuras tentam fechá-la e ossos antigos ficaram presos nas bordas.',
    escala: [{ tipo: 'membrana', prof: 0.1, intensidade: 0.9 }, { tipo: 'veiaGigante', n: 1, prof: 0.1 }], motes: { tipo: 'brasa', n: 10 }, respira: 0.9,
    props: [{ tile: T.sutura, n: 2 }, { tile: T.vertebras, n: 1 }, { tile: T.fossil, n: 2 }, { tile: T.bulbo, n: 2 }],
    vegetacao: veg([[T.fossil, 1], [T.bulbo, 2]], [[T.veiaExposta, 2]], 0.05),
  },
  nucleo_salao: {
    tema: 'Salão do coração', historia: 'O salão do coração: costelas em arco ao redor de um órgão que ainda bate depois que o Mastigador cai.',
    escala: [{ tipo: 'orgao', prof: 0.06, intensidade: 1.4 }, { tipo: 'costelas', de: 'topo', n: 5, prof: 0.07 }], motes: { tipo: 'brasa', n: 14 }, respira: 1,
    props: [{ tile: T.costela, n: 5 }, { tile: T.vertebras, n: 2 }, { tile: T.bulbo, n: 2 }],
    vegetacao: veg([[T.bulbo, 2], [T.fossil, 1]], [[T.veiaExposta, 2]], 0.04),
  },
  // ============================ v1.34.0 — rotas e segredos ============================
  raizes_costelas: {
    tema: 'Nave de costelas', historia: 'Uma nave de costelas gigantes liga duas regiões do corpo: quem passou antes empilhou vértebras como degraus, e uma raiz ainda abraça os ossos de um viajante que não terminou a travessia.',
    escala: [{ tipo: 'costelas', de: 'base', n: 6, prof: 0.08 }, { tipo: 'coluna', x: 0.2, prof: 0.06 }], motes: { tipo: 'cinza', n: 14 }, respira: 0.6,
    props: [{ tile: T.costela, n: 5 }, { tile: T.vertebras, n: 3 }, { tile: T.abraco, n: 2 }, { tile: T.casulo, n: 2 }],
    vegetacao: veg([[T.planta, 2], [T.fungo, 2], [T.coral, 1]], [[T.estalactite, 2], [T.raizPendurada, 1]], 0.08),
  },
  jardim_pomar: {
    tema: 'Pomar suspenso', historia: 'Frutos de esporo pendem de galhos que ninguém poda: o pomar continua dando, mesmo sem ninguém para colher, e um ninho de ovos balança no galho mais baixo à espera de quem já foi embora.',
    escala: [{ tipo: 'raizesGigantes', n: 4, prof: 0.1 }, { tipo: 'membrana', prof: 0.12, intensidade: 0.8 }], motes: { tipo: 'esporo', n: 18 }, respira: 0.5,
    props: [{ tile: T.prateleira, n: 5, grupo: [1, 2] }, { tile: T.ovos, n: 2 }, { tile: T.musgo, n: 5, grupo: [2, 3] }, { tile: T.restos, n: 1 }],
    vegetacao: veg([[T.hera, 3], [T.fungoLanterna, 3], [T.flor, 2], [T.lampada, 1]], [[T.cipo, 2], [T.cortina, 2]], 0.16),
  },
  nucleo_aqueduto: {
    tema: 'Aqueduto de válvulas', historia: 'O sangue do Deus passava aqui em duas batidas; as válvulas ainda trabalham sozinhas, e ossos pequenos presos nelas contam quantos tentaram atravessar antes de você.',
    escala: [{ tipo: 'veiaGigante', n: 2, prof: 0.1 }, { tipo: 'orgao', prof: 0.08, intensidade: 1.1 }], motes: { tipo: 'bolha', n: 12 }, respira: 0.95,
    props: [{ tile: T.vertebras, n: 3 }, { tile: T.bulbo, n: 3 }, { tile: T.restos, n: 1 }, { tile: T.sutura, n: 1 }],
    vegetacao: veg([[T.bulbo, 2], [T.fossil, 1]], [[T.veiaExposta, 2]], 0.05),
  },
  raizes_ossario: {
    tema: 'Ossário escondido', historia: 'Um cômodo escondido desde o primeiro minuto do jogo: ossos arrumados com cuidado e uma criatura parecida com Limo curvada sobre eles, como quem guardou um segredo para o próximo.',
    escala: [{ tipo: 'costelas', de: 'base', n: 4, prof: 0.08, intensidade: 0.8 }], motes: { tipo: 'cinza', n: 8 }, respira: 0.3,
    props: [{ tile: T.restos, n: 2 }, { tile: T.vertebras, n: 2 }, { tile: T.casulo, n: 2 }, { tile: T.costela, n: 1 }],
    vegetacao: veg([[T.fungo, 2], [T.coral, 1]], [[T.estalactite, 2]], 0.05),
  },
});

/** Personalidade de uma sala: a dela, ou o padrão do bioma (nunca null). */
export function personalidadeDaSala(id, biome) {
  return PERSONALIDADES[id] || PADRAO_BIOMA[biome] || PADRAO_BIOMA.raizes;
}
