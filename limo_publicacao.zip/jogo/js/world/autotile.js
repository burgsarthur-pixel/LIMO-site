// =====================================================================
// AUTOTILING: escolhe a "variante" visual de um tile conforme os vizinhos.
//
// Bits da máscara:  bordas  N=1 E=2 S=4 W=8   |   cantos  NE=16 SE=32 SW=64 NW=128
// mask4  : 16 variantes (só as 4 bordas). Índice da variante = máscara.
// blob47 : 47 variantes (bordas + cantos). Um canto só importa se as DUAS bordas vizinhas
//          a ele estão conectadas; as máscaras resultantes, em ordem crescente, formam o índice.
// =====================================================================

export const AUTOTILE_MODES = ['mask4', 'blob47', 'deco'];

// ---------------------------------------------------------------------
// MODO 'deco': autotile de DECORAÇÕES (plantas, fungos, raízes pendentes...). Em vez de "quais vizinhos são do mesmo
// material" (blob), a variante responde "em que situação esta decoração está?":
//   apoio  = há tile sólido/plataforma do lado onde ela se prende (chão para anchor 'down', teto para 'up')
//   sobre  = a decoração do mesmo grupo está no lado do apoio (ela pende/cresce de outra)
//   afasta = a decoração do mesmo grupo está do lado oposto ao apoio (pilha/cordão que continua)
//   esq/dir = vizinha do mesmo grupo ao lado;  paredeEsq/paredeDir = sólido ao lado
// ---------------------------------------------------------------------
export const DECO = Object.freeze({
  SOLO: 0, PONTA_ESQ: 1, MEIO: 2, PONTA_DIR: 3, PAREDE_ESQ: 4, PAREDE_DIR: 5, ESPREMIDA: 6, SOLTA: 7, BASE_PILHA: 8, MEIO_PILHA: 9, TOPO_PILHA: 10,
});
export const DECO_NOMES = Object.keys(DECO).map((k) => k.toLowerCase());

/** Variante da decoração a partir dos fatos da vizinhança (ver bloco acima). */
export function decoVariant(f) {
  if (f.afasta && f.sobre) return DECO.MEIO_PILHA;           // cordão/pilha: continua dos dois lados
  if (f.afasta) return DECO.BASE_PILHA;                      // início da pilha (continua para longe do apoio)
  if (f.sobre && !f.apoio) return DECO.TOPO_PILHA;           // ponta da pilha (só tem a irmã do lado do apoio)
  if (!f.apoio) return DECO.SOLTA;                           // sem onde se prender
  if (f.paredeEsq && f.paredeDir) return DECO.ESPREMIDA;
  if (f.paredeEsq && !f.dir) return DECO.PAREDE_ESQ;
  if (f.paredeDir && !f.esq) return DECO.PAREDE_DIR;
  if (f.esq && f.dir) return DECO.MEIO;
  if (f.dir) return DECO.PONTA_ESQ;
  if (f.esq) return DECO.PONTA_DIR;
  return DECO.SOLO;
}

export function reduceMask(mascara) {
  let m = mascara & 15;
  if ((mascara & 16) && (mascara & 1) && (mascara & 2)) m |= 16;     // NE
  if ((mascara & 32) && (mascara & 2) && (mascara & 4)) m |= 32;     // SE
  if ((mascara & 64) && (mascara & 4) && (mascara & 8)) m |= 64;     // SW
  if ((mascara & 128) && (mascara & 8) && (mascara & 1)) m |= 128;   // NW
  return m;
}

/** As 47 máscaras reduzidas possíveis, em ordem crescente. */
export const BLOB47 = (() => {
  const s = new Set();
  for (let m = 0; m < 256; m++) s.add(reduceMask(m));
  return [...s].sort((a, b) => a - b);
})();
const INDICE_BLOB = new Map(BLOB47.map((m, i) => [m, i]));

export const variantCount = (modo) => (modo === 'mask4' ? 16 : modo === 'deco' ? DECO_NOMES.length : BLOB47.length);
export const defaultColumns = (modo) => (modo === 'mask4' ? 16 : modo === 'deco' ? DECO_NOMES.length : 12);

/** Máscara bruta (8 bits) a partir de uma função "o vizinho em (dx,dy) está conectado?". */
export function rawMask(conectado) {
  return (conectado(0, -1) ? 1 : 0) | (conectado(1, 0) ? 2 : 0) | (conectado(0, 1) ? 4 : 0) | (conectado(-1, 0) ? 8 : 0)
    | (conectado(1, -1) ? 16 : 0) | (conectado(1, 1) ? 32 : 0) | (conectado(-1, 1) ? 64 : 0) | (conectado(-1, -1) ? 128 : 0);
}

export function variantFor(modo, mascaraBruta) {
  if (modo === 'deco') return DECO.SOLO;   // decoração usa decoVariant(fatos), não máscara
  return modo === 'mask4' ? (mascaraBruta & 15) : INDICE_BLOB.get(reduceMask(mascaraBruta));
}

/** Máscara de desenho de uma variante (para a arte provisória). */
export function variantMask(modo, indice) { return modo === 'mask4' ? indice : modo === 'deco' ? 0 : BLOB47[indice]; }

/** Variante "miolo" (todos os vizinhos conectados): usada em prévias da paleta. */
export function previewVariant(modo) { return modo === 'mask4' ? 15 : modo === 'deco' ? DECO.SOLO : BLOB47.length - 1; }

/** Posição (coluna, linha) da variante no spritesheet. */
export function variantCell(autotile, indice) {
  return { col: autotile.col + (indice % autotile.columns), row: autotile.row + Math.floor(indice / autotile.columns) };
}
