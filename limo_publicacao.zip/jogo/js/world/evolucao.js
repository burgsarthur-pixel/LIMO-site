// =====================================================================
// MUNDO QUE EVOLUI (v1.39.0) — dados e regras puros, sem DOM.
// Derrotar um chefe muda o corpo do Deus PARA SEMPRE. Nada é guardado à parte: o estado é DERIVADO de
// progress.bossesDefeated (que já é salvo), então salvar/carregar/migrar saves antigos funciona sem campo novo.
// Quando uma sala é instalada, `aplicarNoMapa` refaz as mudanças e `ajustarInimigos` refaz as criaturas.
//
// Tipos de mudança no mapa:
//   abrir    células "raiz selada" (tile 105, sólido) viram ar: um caminho/atalho que não existia
//   crescer  células de ar ganham um cipó (tile 106, plataforma de mão única): uma rota nova
// Criaturas: temperamento (muda o comportamento: manso, sentinela, sonolento), migração (sai de uma sala, aparece em outra)
// e novos (nascem onde antes não havia).
// O que a sala diz na primeira visita após a mudança é o aviso "algo mudou" (ver game.js + catálogo `evt:<id>`).
// =====================================================================
export const TILE_RAIZ_SELADA = 105;
export const TILE_CIPO = 106;

export const EVOLUCAO = Object.freeze({
  'raizes_guardiao:guardiao_raizes': {
    id: 'raizes_recuam', chefe: 'raizes_guardiao:guardiao_raizes', titulo: 'As raízes recuam',
    texto: 'Sem a Tecelã, as raízes pararam de lutar contra si mesmas. Elas afrouxam, e as criaturas das Raízes se acalmam.',
    aviso: 'As raízes afrouxam em algum lugar do corpo.', dicaBusca: 'Volte às Costelas: procure um chão de raízes.',
    mudancas: [
      { sala: 'raizes_costelas', tipo: 'abrir', celulas: [[21, 6], [21, 7]], descricao: 'As Costelas: um buraco se abre no chão de raízes, ligando o corredor alto ao grande salão.' },
    ],
    criaturas: {
      temperamentos: [{ bioma: 'raizes', temperamento: 'manso' }],
      migracoes: [{ de: { sala: 'raizes_bercario', kind: 'crawler', x: 13 }, para: { sala: 'jardim_entrada', x: 8, y: 15 } }],
      novos: [],
      descricao: 'Os Rastejantes das Raízes ficam mansos; um deles migra para o Jardim.',
    },
  },
  'nucleo_salao:mastigador_pulso': {
    id: 'pulso_responde', chefe: 'nucleo_salao:mastigador_pulso', titulo: 'O pulso responde',
    texto: 'O ritmo do coração agora responde a Limo. Uma raiz selada cede nos aquedutos, e os Couraçados viram sentinelas que vigiam uma área menor.',
    aviso: 'O pulso do Núcleo mudou de ritmo.', dicaBusca: 'Volte ao Aqueduto: o chão ficou oco.',
    mudancas: [
      { sala: 'nucleo_aqueduto', tipo: 'abrir', celulas: [[21, 15], [21, 16]], descricao: 'O Aqueduto: uma raiz selada cede, abrindo um atalho entre os níveis.' },
    ],
    criaturas: { temperamentos: [{ bioma: 'nucleo', kind: 'armored', temperamento: 'sentinela' }], migracoes: [], novos: [], descricao: 'Os Couraçados do Núcleo vigiam uma área menor.' },
  },
  'nucleo_coracao:coracao_residual': {
    id: 'deus_dorme', chefe: 'nucleo_coracao:coracao_residual', titulo: 'O Deus volta a dormir',
    texto: 'Com o Coração Residual calado, todo o organismo desacelera. As criaturas dormem mais fundo e ouvem menos.',
    aviso: 'O organismo inteiro desacelera.', dicaBusca: 'Qualquer região: tudo está mais quieto.',
    mudancas: [],
    criaturas: { temperamentos: [{ bioma: '*', temperamento: 'sonolento' }], migracoes: [], novos: [], descricao: 'Todas as criaturas ficam sonolentas.' },
  },
});

const ativas = (derrotados) => Object.entries(EVOLUCAO).filter(([chefe]) => derrotados.includes(chefe)).map(([, v]) => v);
export const evolucoesAtivas = (derrotados = []) => ativas(derrotados);

export function mudancasDaSala(salaId, derrotados = []) {
  const out = []; for (const evo of ativas(derrotados)) for (const m of evo.mudancas) if (m.sala === salaId) out.push({ evo, m }); return out;
}

export const chaveVista = (evoId, sala) => `vis:${evoId}:${sala}`;   // em progress.descobertas: "o jogador já viu esta mudança nesta sala"

/** Aplica UMA mudança (idempotente). Devolve os efeitos para animar: [{tipo, x, y, id, v, evo}]. */
export function aplicarMudanca(mapa, evo, m) {
  const efeitos = [];
  for (const [x, y] of m.celulas) {
    if (m.tipo === 'abrir') {
      const id = mapa.getTileId('solid', x, y); if (!id) continue;
      efeitos.push({ tipo: 'abrir', x, y, id, v: mapa.getVariant('solid', x, y), evo: evo.id }); mapa.setTileId('solid', x, y, 0);
    } else if (m.tipo === 'crescer') {
      if (mapa.getTileId('solid', x, y) || mapa.getTileId('platform', x, y)) continue;
      mapa.setTileId('platform', x, y, TILE_CIPO); efeitos.push({ tipo: 'crescer', x, y, id: TILE_CIPO, v: 0, evo: evo.id });
    }
  }
  return efeitos;
}

/**
 * Refaz as mudanças do mapa ao instalar a sala. As que o jogador JÁ viu (`vistas` tem a chave) entram em silêncio;
 * as novas ficam `pendentes` e o jogo as aplica, com efeito e aviso, na hora em que entram na tela (ver game.js).
 * Sem `vistas`, aplica tudo.
 */
export function aplicarNoMapa(mapa, salaId, derrotados = [], vistas = null) {
  const efeitos = []; const pendentes = [];
  for (const { evo, m } of mudancasDaSala(salaId, derrotados)) {
    if (vistas && !vistas.has(chaveVista(evo.id, salaId))) pendentes.push({ evo, m }); else efeitos.push(...aplicarMudanca(mapa, evo, m));
  }
  return { efeitos, pendentes };
}

/** Temperamento de uma criatura (espécie + bioma da sala). O mais "adormecido" vence. */
const FORCA = { normal: 0, manso: 1, sentinela: 2, sonolento: 3 };
export function temperamentoPara(kind, bioma, derrotados = []) {
  let melhor = 'normal';
  for (const evo of ativas(derrotados)) for (const t of evo.criaturas.temperamentos) {
    if ((t.bioma === '*' || t.bioma === bioma) && (!t.kind || t.kind === kind) && FORCA[t.temperamento] > FORCA[melhor]) melhor = t.temperamento;
  }
  return melhor;
}

/** Ajusta a lista de criaturas da sala: tira as que migraram, põe as que chegaram/nasceram. Não muda a lista de entrada. */
export function ajustarInimigos(spawns, salaId, derrotados = [], tileSize = 16) {
  let lista = spawns.map((s) => ({ ...s }));
  for (const evo of ativas(derrotados)) {
    for (const mg of evo.criaturas.migracoes) {
      if (mg.de.sala === salaId) { const i = lista.findIndex((s) => s.kind === mg.de.kind && s.tileX === mg.de.x && !s.bossId); if (i >= 0) lista.splice(i, 1); }
      if (mg.para.sala === salaId) lista.push(novoSpawn(mg.de.kind, mg.para.x, mg.para.y, tileSize, evo.id));
    }
    for (const n of evo.criaturas.novos) if (n.sala === salaId) lista.push(novoSpawn(n.kind, n.x, n.y, tileSize, evo.id));
  }
  return lista;
}
const novoSpawn = (kind, x, y, ts, origem) => ({ type: 'enemy', x: x * ts, y: y * ts, tileX: x, tileY: y, kind, facing: 1, bossId: null, origemEvolucao: origem });

/** Evoluções cujo efeito aparece nesta sala (mudança de mapa, criatura que chegou ou temperamento). Para o aviso "algo mudou aqui". */
export function evolucoesVisiveisNaSala(salaId, derrotados = []) {
  return ativas(derrotados).filter((evo) => evo.mudancas.some((m) => m.sala === salaId)
    || evo.criaturas.novos.some((n) => n.sala === salaId) || evo.criaturas.migracoes.some((m) => m.para.sala === salaId || m.de.sala === salaId));
}
