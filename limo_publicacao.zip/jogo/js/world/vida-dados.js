// =====================================================================
// DADOS DO MUNDO VIVO (v1.38.0) — puros, sem DOM. Ficam num módulo (e não no JSON da sala) pelo mesmo motivo de
// personalidade.js: o exportador do editor só preserva campos que conhece.
//
//  TILES_FALSOS  tile sólido original -> tile "falso" (mesma arte e mesmo grupo de autotile, mas collision "none").
//                Uma câmara secreta é feita desses tiles: parece rocha, deixa o Limo atravessar e some ao ser descoberta.
//  SEGREDOS      câmaras escondidas por sala. modo "toque" = encostar na rocha falsa revela; modo "parede" = a boca
//                é uma parede rachada (entidade paredeFragil) e a câmara se revela quando ela cede.
//  MURAIS        pinturas de pictogramas que contam a história do Deus adormecido sem diálogo (cenas em js/world/vestigios.js).
// O verificador tools/segredos_organicos.mjs aplica SEGREDOS nos JSON das salas (idempotente); tests/mundo-vivo.test.mjs confere tudo.
// =====================================================================

export const TILES_FALSOS = Object.freeze({ 1: 100, 2: 101, 3: 102, 40: 103, 50: 104 });
export const IDS_FALSOS = Object.freeze(Object.values(TILES_FALSOS));

const camara = (x, y) => ({ x, y, w: 3, h: 2 });

export const SEGREDOS = Object.freeze({
  jardim_copa: [{
    id: 'camara_copa', modo: 'toque', texto: 'Uma passagem escondida na rocha viva.',
    falsos: [camara(1, 14), { x: 4, y: 15, w: 2, h: 1 }], boca: { x: 6, y: 15 }, camara: camara(1, 14),
    itens: [
      { type: 'echo', id: 'eco_camara_copa', x: 2, y: 15, text: 'Alguém selou este canto com carne viva. Não para esconder um tesouro: para que a lembrança não esfriasse.' },
      { type: 'cura', id: 'seiva_camara_copa', x: 3, y: 15 },
    ],
  }],
  jardim_entrada: [{
    id: 'camara_entrada', modo: 'toque', texto: 'A rocha cede: há um nicho atrás dela.',
    falsos: [camara(33, 14), { x: 31, y: 15, w: 2, h: 1 }], boca: { x: 30, y: 15 }, camara: camara(33, 14),
    itens: [
      { type: 'echo', id: 'eco_camara_entrada', x: 34, y: 15, text: 'O jardim guardou este nicho como se guarda um dente de leite: pequeno, e de alguém.' },
      { type: 'cura', id: 'seiva_camara_entrada', x: 33, y: 15 },
    ],
  }],
  nucleo_fissura: [{
    id: 'camara_fissura', modo: 'toque', texto: 'O pulso da parede falha aqui: era oca.',
    falsos: [camara(35, 14), { x: 33, y: 15, w: 2, h: 1 }], boca: { x: 32, y: 15 }, camara: camara(35, 14),
    itens: [
      { type: 'echo', id: 'eco_camara_fissura', x: 36, y: 15, text: 'Nesta fissura o pulso do Deus falha uma vez a cada respiração. É quando ele quase acorda.' },
      { type: 'cura', id: 'seiva_camara_fissura', x: 35, y: 15 },
    ],
  }],
  raizes_ascensao: [{
    id: 'camara_ascensao', modo: 'parede', texto: 'A parede cede. Alguém guardou algo aqui.',
    parede: { id: 'parede_camara_ascensao', x: 19, y: 21, w: 2, h: 1, hp: 3, text: 'A carne cede. Atrás dela, um cômodo que o Deus esqueceu.' },
    falsos: [{ x: 21, y: 20, w: 3, h: 2 }], boca: { x: 18, y: 21 }, camara: { x: 21, y: 20, w: 3, h: 2 },
    itens: [
      { type: 'echo', id: 'eco_camara_ascensao', x: 22, y: 21, text: 'Quem subiu antes de você deixou isto. Sobrar não era o plano. Mesmo assim, sobrou.' },
      { type: 'cura', id: 'seiva_camara_ascensao', x: 23, y: 21 },
    ],
  }],
  nucleo_salao: [{
    id: 'camara_salao', modo: 'parede', texto: 'A parede de carne cede ao golpe.',
    parede: { id: 'parede_camara_salao', x: 4, y: 15, w: 2, h: 1, hp: 3, text: 'A parede de carne se abre para um cômodo que ainda respira.' },
    falsos: [{ x: 1, y: 14, w: 3, h: 2 }], boca: { x: 6, y: 15 }, camara: { x: 1, y: 14, w: 3, h: 2 },
    itens: [
      { type: 'echo', id: 'eco_camara_salao', x: 2, y: 15, text: 'O Deus ainda sonha com você aqui, no fundo do salão. Cada raiz que o prendeu também o abraçou.' },
      { type: 'cura', id: 'seiva_camara_salao', x: 3, y: 15 },
    ],
  }],
});

/** Murais 3x2 tiles (x,y = canto superior esquerdo). `cena` está em js/world/vestigios.js. Os 3 últimos ficam DENTRO das câmaras secretas. */
export const MURAIS = Object.freeze([
  { id: 'm_construtores', sala: 'raizes_antecamara', x: 16, y: 8, cena: 'construtores', legenda: 'Ergueram o templo ao redor do sono do Deus.' },
  { id: 'm_canto', sala: 'raizes_ascensao', x: 16, y: 8, cena: 'canto', legenda: 'Cantaram, para que ele nunca acordasse.' },
  { id: 'm_raizes', sala: 'raizes_bosque', x: 16, y: 4, cena: 'raizes', legenda: 'Das raízes veio a fome. O povo encolheu.' },
  { id: 'm_copias', sala: 'raizes_bercario', x: 16, y: 6, cena: 'copias', legenda: 'O Deus sonhou cópias. Uma delas era diferente.' },
  { id: 'm_fossil', sala: 'raizes_ossario', x: 13, y: 9, cena: 'fossil', legenda: 'Antes do povo, algo enorme já dormia aqui.' },
  { id: 'm_flor', sala: 'jardim_entrada', x: 15, y: 12, cena: 'flor', legenda: 'Do sono do Deus, a vida continuou brotando.' },
  { id: 'm_pastor', sala: 'jardim_lago', x: 18, y: 9, cena: 'pastor', legenda: 'Um pastor guiou o rebanho até a água escura.' },
  { id: 'm_sutura', sala: 'jardim_sutura', x: 14, y: 11, cena: 'sutura', legenda: 'Tentaram fechar a ferida. Faltou fio.' },
  { id: 'm_olho', sala: 'nucleo_condutos', x: 19, y: 8, cena: 'olho', legenda: 'O olho do Deus entreabre. A rachadura sobe.' },
  { id: 'm_limo', sala: 'nucleo_coracao', x: 16, y: 10, cena: 'limo', legenda: 'Uma cópia caminha até o olho. Ninguém sabe o que ela diz.' },
  { id: 'm_fundacao', sala: 'jardim_copa', x: 1, y: 14, cena: 'fundacao', legenda: 'No começo havia só um canto, e um povo cantando.', secreto: true },
  { id: 'm_tumulo', sala: 'jardim_entrada', x: 33, y: 14, cena: 'tumulo', legenda: 'Plantaram um jardim sobre o primeiro túmulo.', secreto: true },
  { id: 'm_pulso', sala: 'nucleo_fissura', x: 35, y: 14, cena: 'pulso', legenda: 'O pulso falha. O Deus quase vê.', secreto: true },
]);

export const chaveMural = (id) => `mural_${id}`;   // sufixo do id guardado em progress.collected (chaveItem(sala, chave))
export const murais = (salaId) => MURAIS.filter((m) => m.sala === salaId);
export const segredos = (salaId) => SEGREDOS[salaId] || [];
