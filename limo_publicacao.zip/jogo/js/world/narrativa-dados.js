// =====================================================================
// NARRATIVA DAS RAÍZES (v1.50.0, Etapa 1 "O despertar"). Dados puros: quem fala, onde e quando. Quem executa: js/core/narrativa.js.
// Regras (docs/NARRATIVA_RAIZES.md): NÃO revelar a origem de Limo; o Esquecimento não é vilão consciente; a Tecelã não é cruel.
// Cada acontecimento aparece UMA vez (marca `hist:<id>` em progress.descobertas: sem campo novo no save).
//   quando   gatilho: { entrar:true } | { perto:{x,y,raio} } (tiles) | { fase:{chefe, frac} } (vida do chefe <= frac, avisada pelo Game)
//   requer   condições de js/world/npc-dados.js#cumpre (tem, nao, chefe, visitou, eco, ecos, novo...)
//   atraso   segundos com o gatilho valendo antes de apresentar     grupo   só o primeiro do grupo que valer é apresentado
//   apresenta { balao:{quem, falas[], dur, espera?}, toast, lembranca:{linhas, dur}, pulso, despertar:{dur} }
//     quem: 'limo' | { npc:'fio_solto' } | { presenca:'presenca_tecela' }
// =====================================================================
export const SEG_BALAO = 2.8;
const CHEFE = 'raizes_guardiao:guardiao_raizes';
const PEDACO = 'npc:fio_solto:pedaco_tecela';

export const BEATS = Object.freeze([
  // 1 · Câmara da Ferida Aberta: o primeiro instante. Sem texto: só reticências e um fio novo aparecendo no chão (rastro `camara`).
  { id: 'acordar', sala: 'raizes_camara', quando: { entrar: true }, requer: { novo: true }, atraso: 0.4, apresenta: { despertar: { dur: 3.6 }, balao: { quem: 'limo', falas: ['…'], dur: 2.4, espera: 1.2 } } },
  // 2 · Veia de Retorno: alguém cuida daqui (os fios recém-costurados são o rastro `veia`).
  { id: 'ponto_fresco', sala: 'raizes_veia', quando: { entrar: true }, atraso: 3, apresenta: { balao: { quem: 'limo', falas: ['Estes pontos ainda estão úmidos. Alguém esteve aqui há pouco.'], dur: 3.4 } } },
  // 4 · Bosque Fúngico: o murmúrio de Fio Solto antes de qualquer conversa.
  { id: 'murmurio_fio', sala: 'raizes_bosque', quando: { perto: { x: 11, y: 10, raio: 9 } }, requer: { nao: 'npc:fio_solto:conversou' }, apresenta: { balao: { quem: { npc: 'fio_solto' }, falas: ['…esta cantiga tinha mais um verso.', 'Não. Era assim: segura o fio, segura o fio…', '…quem está aí? Pode chegar. Eu só guardo.'], dur: 3 } } },
  // 6 · Antessala das Fibras: a Tecelã, ainda sem rosto, fala com a própria ferida (não com Limo).
  { id: 'voz_tecela', sala: 'raizes_antecamara', quando: { perto: { x: 9, y: 4, raio: 10 } }, apresenta: { balao: { quem: { presenca: 'presenca_tecela' }, falas: ['Só mais um ponto.', 'Aperta, e talvez feche.', 'Fecha. Por favor, fecha.'], dur: 3.2 } } },
  // 8 · Ninho da Tecelã: na virada da luta, um clarão de memória (mais vivo se Limo recebeu o pedaço de Fio Solto). Só um dos dois.
  { id: 'lembranca_pedaco', sala: 'raizes_guardiao', grupo: 'lembranca_tecela', quando: { fase: { chefe: CHEFE, frac: 0.5 } }, requer: { tem: PEDACO }, apresenta: { lembranca: { linhas: ['Uma agulha de osso, uma pele ainda só ferida.', 'Ela cantava baixinho, para o corte não doer.'], dur: 4.6 } } },
  { id: 'lembranca_fio', sala: 'raizes_guardiao', grupo: 'lembranca_tecela', quando: { fase: { chefe: CHEFE, frac: 0.5 } }, requer: { nao: PEDACO }, apresenta: { lembranca: { linhas: ['Um fio se solta de uma mão cansada.'], dur: 3.2 } } },
  // 9 · Chaminé da Muda: depois da Tecelã, algo mais fundo responde (sem explicar). Gancho para o Jardim.
  { id: 'pulso_distante', sala: 'raizes_02', quando: { entrar: true }, requer: { chefe: CHEFE }, atraso: 2.2, apresenta: { pulso: true, toast: 'Algo mais fundo respondeu. Não era voz: era um pulso, longe demais para ser lembrança.' } },
  // 10 · Jardim das Lanternas: a Jardineira percebe Limo ao chegar perto (balão dela, sem texto de Limo).
  { id: 'jardineira_chegada', sala: 'jardim_entrada', quando: { perto: { x: 13, y: 12, raio: 9 } }, requer: { nao: 'npc:jardineira:encontro' }, atraso: 0.6, apresenta: { balao: { quem: { npc: 'jardineira' }, falas: ['Você passou sem quebrar a raiz nova.'], dur: 3 } } },
  // 11 · Depois da primeira conversa, ela costura raízes no chão perto de si (rastro `jardineira_costura`).
  { id: 'jardineira_costura', sala: 'jardim_entrada', quando: { perto: { x: 13, y: 12, raio: 10 } }, requer: { tem: 'npc:jardineira:encontro' }, atraso: 1, apresenta: { toast: 'Ela reforçou a raiz que estava cedendo, com fios novos.' } },
]);

// Rastros de fios (item 1, 2 e 6): linhas de pontos costurados que seguem o chão. Desenhados por js/render/narrativa-art.js.
//   trechos: faixas de colunas [x0,x1] medidas a partir da linha y0 (sobe até achar ar, desce até achar chão)   fios: quantas linhas paralelas   tensao: 0 frouxo … 1 esticado
export const RASTROS = Object.freeze([
  { id: 'camara', sala: 'raizes_camara', trechos: [{ x0: 6, x1: 26, y0: 9 }, { x0: 27, x1: 32, y0: 7 }], fios: 1, tensao: 0, revela: 'acordar' },
  { id: 'veia', sala: 'raizes_veia', trechos: [{ x0: 2, x1: 35, y0: 5 }], fios: 2, tensao: 0.3 },
  { id: 'antecamara', sala: 'raizes_antecamara', trechos: [{ x0: 1, x1: 24, y0: 12 }], fios: 3, tensao: 1 },
  { id: 'jardineira_costura', sala: 'jardim_entrada', trechos: [{ x0: 9, x1: 17, y0: 13 }], fios: 2, tensao: 0.4, revela: 'jardineira_costura' },
]);

export const CHAVE_BEAT = (id) => `hist:${id}`;

// v1.51.0 · Casulos vazios: os 3 ecos do Berçário que guardam o que o Deus tentou lembrar. Só recebem destaque visual (js/entities/entity-art.js) e um aviso mais longo ao coletar; o texto continua o do próprio eco no JSON da sala.
export const CASULOS = Object.freeze({ raizes_bercario: Object.freeze(['eco_casulo_nome', 'eco_casulo_cheiro', 'eco_casulo_cantiga']) });
export const ehCasulo = (salaId, id) => !!CASULOS[salaId]?.includes(id);
