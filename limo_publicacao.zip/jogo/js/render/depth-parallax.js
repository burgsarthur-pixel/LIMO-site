// =====================================================================
// PARALLAX 2.5D: camadas de fundo, meio e primeiro plano com velocidade horizontal (vx) e vertical (vy) próprias.
//  - Cada camada é desenhada UMA vez num canvas (ladrilhável na horizontal) com a paleta e a névoa do bioma já embutidas.
//  - Por quadro: 1–2 drawImage por camada (posição inteira = pixel art nítida). Nenhum filtro, nenhum gradiente, nada de alocação.
//  - vx/vy < 1 = mais longe que o mapa (move menos); vx/vy > 1 = primeiro plano (move mais que o mapa).
// Só visual: não depende de colisão, física ou câmera (só LÊ a posição da câmera).
// =====================================================================

const TILE_W = 384;       // largura de repetição da camada (> largura da tela de 320)
const MAX_ALTURA = 960;   // teto de memória por camada (Android)

const hexRgb = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(c || ''); if (!m) return [20, 12, 14]; const n = parseInt(m[1], 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const mix = (a, b, k) => [Math.round(a[0] + (b[0] - a[0]) * k), Math.round(a[1] + (b[1] - a[1]) * k), Math.round(a[2] + (b[2] - a[2]) * k)];
const css = (c, al = 1) => (al >= 1 ? `rgb(${c[0]},${c[1]},${c[2]})` : `rgba(${c[0]},${c[1]},${c[2]},${al.toFixed(3)})`);
const semear = (s) => { let a = (s * 2654435761) >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };

/** Pincel que repete o desenho nas bordas esquerda/direita: a camada emenda sem costura ao rolar. */
function pincel(cx, Wl) {
  return (x, y, w, h) => {
    x = Math.round(x); y = Math.round(y); cx.fillRect(x, y, w, h);
    if (x < 0 || x + w > Wl) { cx.fillRect(x + Wl, y, w, h); cx.fillRect(x - Wl, y, w, h); }
  };
}

/** Disco de pixels (círculo em linhas horizontais). */
function disco(c, cx, cy, raio, cor) { for (let dy = -raio; dy <= raio; dy++) { const w = Math.round(Math.sqrt(raio * raio - dy * dy + raio * 0.6)); c.px(cx - w, cy + dy, w * 2, 1, cor); } }

const MOTIVOS_GERADORES = {
  // troncos colossais: colunas escuras e largas, com a quina iluminada à esquerda
  troncos(c) {
    const n = Math.max(1, Math.round(4 * c.dens)); const passo = c.Wl / n;
    for (let i = 0; i < n; i++) {
      const cxm = i * passo + passo * (0.25 + c.r() * 0.5); const larg = 20 + ((c.r() * 18) | 0); const fase = c.r() * 6;
      for (let y = 0; y < c.Hc; y += 4) {
        const dx = Math.round(Math.sin(y * 0.03 + fase) * 5); const l = larg + (((y / 4 + i) % 3) | 0);
        c.px(cxm + dx - l / 2, y, l, 4, c.escuro);
        c.px(cxm + dx - l / 2, y, 2, 4, c.luz); c.px(cxm + dx + l / 2 - 3, y, 3, 4, c.sombra);
        if (c.r() < 0.35) c.px(cxm + dx - l / 2 + 4 + ((c.r() * (l - 10)) | 0), y, 1, 4 + ((c.r() * 8) | 0), c.sombra);   // sulcos de casca
      }
    }
  },
  // costelas gigantes: arcos de osso que atravessam o fundo
  costelas(c) {
    const n = Math.max(1, Math.round(5 * c.dens));
    for (let i = 0; i < n; i++) {
      const x0 = i * (c.Wl / n) + c.r() * 20; const y0 = 24 + c.r() * (c.Hc - 90); const comp = 70 + c.r() * 70; const alt = 14 + c.r() * 22; const grossura = 4 + ((c.r() * 3) | 0);
      for (let u = 0; u <= comp; u += 2) {
        const k = u / comp; const y = y0 + Math.sin(k * Math.PI) * -alt + k * 26;
        c.px(x0 + u, y, 2, grossura, c.escuro); c.px(x0 + u, y, 2, 1, c.luz); c.px(x0 + u, y + grossura - 1, 2, 1, c.sombra);
      }
    }
  },
  // raízes pendentes + cordões verticais finos
  raizes(c) {
    const n = Math.max(1, Math.round(9 * c.dens));
    for (let i = 0; i < n; i++) {
      let x = (i + c.r()) * (c.Wl / n); let y = c.r() < 0.5 ? 0 : c.r() * c.Hc * 0.6; const comp = 50 + c.r() * Math.min(c.Hc * 0.7, 190); let larg = 4 + ((c.r() * 3) | 0);
      for (let k = 0; k < comp; k += 3) {
        x += c.r() < 0.4 ? (c.r() < 0.5 ? -1 : 1) : 0; larg = Math.max(1, larg - (k % 24 === 0 ? 1 : 0));
        c.px(x, y + k, larg, 3, c.escuro); c.px(x, y + k, 1, 3, c.luz);
        if (c.r() < 0.05 && larg > 1) { const s = c.r() < 0.5 ? -1 : 1; for (let b = 1; b < 12; b++) c.px(x + s * b, y + k + b, 1, 1, c.sombra); }
      }
    }
  },
  // nódulos bioluminescentes presos a fios: pontos de luz que dão leitura de distância
  nodulos(c) {
    const n = Math.max(1, Math.round(12 * c.dens));
    for (let i = 0; i < n; i++) {
      const x = c.r() * c.Wl; const y = 16 + c.r() * (c.Hc - 32); const rr = 2 + ((c.r() * 3) | 0);
      for (let f = 0; f < 14 + c.r() * 24; f++) c.px(x + Math.round(Math.sin(f * 0.5) * 1.5), y - f, 1, 1, c.sombra);   // haste
      disco(c, x, y, rr + 3, c.brilho1); disco(c, x, y, rr + 1, c.brilho2); disco(c, x, y, rr, c.nucleo); c.px(x - 1, y - rr + 1, 1, 1, c.luz);   // discos de pixels (nada de caixas)
    }
    for (let i = 0; i < Math.round(5 * c.dens); i++) { const x = c.r() * c.Wl; const y = c.r() * c.Hc; c.px(x, y, 3 + ((c.r() * 4) | 0), 2, c.luz); c.px(x + 1, y + 2, 2, 1, c.sombra); }   // fragmentos de osso
  },
  // primeiro plano: raízes escuras que pendem do teto e brotam do chão, rarefeitas para não esconder o jogo
  raizesFrente(c) {
    const n = Math.max(1, Math.round(4 * c.dens));
    for (let i = 0; i < n; i++) {
      let x = (i + 0.2 + c.r() * 0.6) * (c.Wl / n); const comp = 34 + c.r() * 70; let larg = 5 + ((c.r() * 3) | 0);
      for (let k = 0; k < comp; k += 2) { x += c.r() < 0.3 ? (c.r() < 0.5 ? -1 : 1) : 0; if (k % 20 === 0) larg = Math.max(2, larg - 1); c.px(x, k, larg, 2, c.escuro); c.px(x, k, 1, 2, c.luz); }
    }
    for (let i = 0; i < n; i++) {
      let x = (i + c.r()) * (c.Wl / n); const comp = 26 + c.r() * 52; let larg = 6;
      for (let k = 0; k < comp; k += 2) { x += c.r() < 0.3 ? (c.r() < 0.5 ? -1 : 1) : 0; if (k % 18 === 0) larg = Math.max(2, larg - 1); c.px(x, c.Hc - k - 2, larg, 2, c.escuro); c.px(x + larg - 1, c.Hc - k - 2, 1, 2, c.sombra); }
    }
  },
};
MOTIVOS_GERADORES.veias = MOTIVOS_GERADORES.raizes;

export class ParallaxDepth {
  /** @param fabrica (w,h)=>canvas */
  constructor(fabrica) { this.fabrica = fabrica; this.camadas = []; this._chave = ''; this.stats = { camadas: 0, pixels: 0, msBuild: 0 }; }

  /**
   * Prepara (ou reaproveita) as camadas. `cfgParallax` já normalizado; `tema` = biome-theme; `view` = {W,H}; `sala` = {W,H} em px.
   * Só refaz se mudar a config, o tema ou o tamanho da sala.
   */
  preparar(cfgParallax, tema, view, sala) {
    const chave = JSON.stringify([cfgParallax.camadas, cfgParallax.substituiFundo, tema.fundo, tema.tons[0], view.W, view.H, sala.H]);
    if (chave === this._chave) return this;
    const t0 = typeof performance !== 'undefined' ? performance.now() : 0;
    this._chave = chave; this.camadas = []; let px = 0;
    const maxCamY = Math.max(0, sala.H - view.H); let primeiraFundo = true;
    for (const cfg of cfgParallax.camadas) {
      const range = Math.ceil(maxCamY * cfg.vy); const Hc = Math.min(MAX_ALTURA, view.H + range);
      const cv = this.fabrica(TILE_W, Hc); const cx = cv.getContext('2d'); if (!cx) continue;
      const opaca = primeiraFundo && cfg.plano === 'fundo' && cfgParallax.substituiFundo; if (cfg.plano === 'fundo') primeiraFundo = false;
      this._desenhar(cx, cfg, tema, TILE_W, Hc, opaca);
      this.camadas.push({ cfg, canvas: cv, Hc, range: Hc - view.H, opaca });
      px += TILE_W * Hc;
    }
    this.stats = { camadas: this.camadas.length, pixels: px, msBuild: (typeof performance !== 'undefined' ? performance.now() : 0) - t0 };
    return this;
  }

  /** A primeira camada de fundo é opaca: o renderer pode dispensar o drawBackground antigo. */
  get cobreFundo() { return this.camadas.some((c) => c.opaca); }

  _desenhar(cx, cfg, T, Wl, Hc, opaca) {
    const fundo = hexRgb(T.fundo); const nevoa = cfg.nevoa; const longe = (cor) => mix(cor, fundo, nevoa);
    if (opaca) {   // base do abismo: faixas de tom (sem gradiente por quadro: tudo pré-calculado)
      cx.fillStyle = css(fundo); cx.fillRect(0, 0, Wl, Hc);
      const r0 = semear(cfg.semente * 7 + 3); const tons = T.tons.map(hexRgb);
      for (let i = 0; i < Math.round((Wl * Hc) / 1100); i++) {
        const x = r0() * Wl; const y = r0() * Hc; const raio = 6 + r0() * 22; cx.fillStyle = css(mix(tons[(r0() * tons.length) | 0], fundo, 0.35));
        for (let k = 0; k < raio * 1.2; k++) { const a = r0() * 6.283; const d = Math.sqrt(r0()) * raio; cx.fillRect(Math.round(x + Math.cos(a) * d), Math.round(y + Math.sin(a) * d * 0.7), 1 + ((r0() * 4) | 0), 1 + ((r0() * 3) | 0)); }
      }
    }
    const r = semear(cfg.semente); const tons = T.tons.map(hexRgb); const base = mix(tons[tons.length - 1], hexRgb(T.borda), 0.35); const bolha = T.bolha.split(',').map(Number);
    const frente = cfg.plano === 'frente';
    const c = {
      Wl, Hc, r, dens: cfg.densidade, px: pincel(cx, Wl),
      escuro: null, luz: null, sombra: null, nucleo: null, brilho1: null, brilho2: null,
    };
    const corpo = frente ? mix(fundo, [0, 0, 0], 0.7) : longe(mix(base, fundo, 0.45));
    const set = (k, col) => { c[k] = col; };
    set('escuro', corpo); set('luz', longe(mix(hexRgb(T.borda), [235, 214, 170], frente ? 0.1 : 0.25))); set('sombra', mix(corpo, [0, 0, 0], 0.45));
    set('nucleo', longe(mix(bolha, [255, 255, 255], 0.35))); set('brilho1', longe(mix(bolha, fundo, 0.8))); set('brilho2', longe(mix(bolha, fundo, 0.6)));
    // cores viram strings rápidas: px(x,y,w,h,cor) troca fillStyle só quando muda
    let ult = null; const raw = c.px; c.px = (x, y, w, h, cor) => { const s = typeof cor === 'string' ? cor : css(cor); if (s !== ult) { cx.fillStyle = s; ult = s; } raw(x, y, w, h); };
    (MOTIVOS_GERADORES[cfg.motivo] || MOTIVOS_GERADORES.troncos)(c);
  }

  _blit(ctx, cam, camX, camY, W, H, pulso) {
    const { cfg, canvas, Hc, range } = cam; const Wl = TILE_W;
    const ox = -Math.round(camX * cfg.vx); const oy = Math.max(-range, Math.min(0, -Math.round(Math.max(0, camY) * cfg.vy)));
    let x = ox % Wl; if (x > 0) x -= Wl; const al = cfg.alfa * (cfg.motivo === 'nodulos' ? 1 + 0.18 * pulso : 1);
    ctx.globalAlpha = Math.min(1, al);
    for (; x < W; x += Wl) ctx.drawImage(canvas, 0, 0, Wl, Hc, x, oy, Wl, Hc);
  }

  /** Planos atrás do mapa (fundo e meio). */
  atras(ctx, camX, camY, W, H, pulso = 0) {
    const a = ctx.globalAlpha;
    for (const c of this.camadas) if (c.cfg.plano !== 'frente') this._blit(ctx, c, camX, camY, W, H, pulso);
    ctx.globalAlpha = a;
  }

  /** Primeiro plano (por cima de tudo, antes da iluminação). */
  frente(ctx, camX, camY, W, H, pulso = 0) {
    const a = ctx.globalAlpha;
    for (const c of this.camadas) if (c.cfg.plano === 'frente') this._blit(ctx, c, camX, camY, W, H, pulso);
    ctx.globalAlpha = a;
  }
}
