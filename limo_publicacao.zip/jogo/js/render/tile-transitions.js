// =====================================================================
// TRANSIÇÕES ORGÂNICAS ENTRE MATERIAIS
// Passe exclusivamente visual: nunca altera tiles, máscaras ou colisões.
// Desenha pequenas fibras na borda compartilhada entre materiais compatíveis.
// =====================================================================

const PARES_COMPATIVEIS = new Set([
  'carne|osso', 'carne|cartilagem', 'carne|raiz', 'carne|musculo',
  'carne|membrana', 'carne|fungo', 'cartilagem|osso',
  'cartilagem|planta', 'cartilagem|raiz', 'fungo|raiz',
  'fungo|carne', 'musculo|osso', 'raiz|osso', 'raiz|cartilagem',
  'membrana|osso', 'membrana|raiz', 'planta|carne', 'planta|raiz',
  'planta|planta', 'fungo|fungo', 'raiz|raiz',
]);

function hash(x, y, a, b, k) {
  let n = Math.imul(x + 101, 73856093) ^ Math.imul(y + 307, 19349663)
    ^ Math.imul(a + 17, 83492791) ^ Math.imul(b + 29, 2654435761) ^ Math.imul(k + 1, 1597334677);
  n = Math.imul(n ^ (n >>> 16), 2246822519);
  return (n ^ (n >>> 13)) >>> 0;
}

function categoria(tile) {
  if (!tile) return '';
  if (tile.category === 'musculo') return 'musculo';
  if (tile.category === 'membrana') return 'membrana';
  return tile.category;
}

function compativel(a, b) {
  const ca = categoria(a); const cb = categoria(b);
  if (!ca || !cb) return false;
  return PARES_COMPATIVEIS.has(`${ca}|${cb}`) || PARES_COMPATIVEIS.has(`${cb}|${ca}`);
}

function desenharBorda(ctx, x, y, ts, lado, semente, cor, corEscura) {
  // Linha quebrada de 1 px com pequenas fibras que entram no material (sem régua reta).
  const vertical = lado === 'left' || lado === 'right';
  const base = lado === 'left' ? x : lado === 'right' ? x + ts - 1 : lado === 'top' ? y : y + ts - 1;
  for (let i = 2; i < ts - 2; i++) {
    const h = hash(x / ts | 0, y / ts | 0, semente, lado.length, i);
    if ((h & 7) === 0) continue;
    const jitter = (h >>> 4) % 3 - 1;
    const along = i;
    const px = vertical ? base + (lado === 'left' ? Math.max(0, jitter + 1) : -Math.max(0, jitter + 1)) : x + along;
    const py = vertical ? y + along : base + (lado === 'top' ? Math.max(0, jitter + 1) : -Math.max(0, jitter + 1));
    ctx.fillStyle = (h & 3) === 0 ? corEscura : cor;
    ctx.fillRect(Math.round(px), Math.round(py), 1, 1);
    if ((h & 15) === 3) {
      ctx.fillStyle = corEscura;
      if (vertical) ctx.fillRect(Math.round(px + (lado === 'left' ? 1 : -1)), Math.round(py), 1, 1);
      else ctx.fillRect(Math.round(px), Math.round(py + (lado === 'top' ? 1 : -1)), 1, 1);
    }
  }
}

/** Desenha transições no tile atual contra vizinhos sólidos de outra família. */
export function drawOrganicTransitions(ctx, mapa, tx, ty, id, dx, dy, ts) {
  const atual = mapa.catalog.get(id);
  if (!atual || !atual.art) return;
  const dirs = [
    [-1, 0, 'left'], [1, 0, 'right'], [0, -1, 'top'], [0, 1, 'bottom'],
  ];
  const layer = mapa.layers.solid;
  if (!layer) return;
  const cor = atual.art.color2 || '#b18a75';
  const escura = atual.art.color3 || atual.art.color || '#39252a';
  const x = dx; const y = dy;
  ctx.save();
  ctx.globalAlpha = 0.72;
  for (const [ox, oy, lado] of dirs) {
    const nx = tx + ox; const ny = ty + oy;
    if (!mapa.inBounds(nx, ny)) continue;
    const vizinhoId = layer[ny * mapa.width + nx];
    if (!vizinhoId || vizinhoId === id) continue;
    const vizinho = mapa.catalog.get(vizinhoId);
    if (!vizinho || vizinho.collision === 'none' || !compativel(atual, vizinho)) continue;
    desenharBorda(ctx, x, y, ts, lado, id * 97 + vizinhoId * 13, cor, escura);
  }
  ctx.restore();
}

export const TRANSITION_COMPATIBILITY = PARES_COMPATIVEIS;
