// =====================================================================
// JARDINEIRA CEGA — arte procedural em pixels, sem imagens externas (Etapa 1.5; refinada na etapa de direção de arte).
// Figura de 16 × 28 px (pés na base). Flor-cabeça sem olhos (uma abertura central que pulsa e se abre ao falar/aproximar).
// Caule esguio (2–3 px), braços e pernas separados por vãos reais, raízes ramificadas nas mãos e nos pés,
// cipós e folhas nas costas, musgo e fungos em posições fixas. Luz vinda do alto-direita: borda de luz no lado direito.
// Paleta de 8 cores (7 + sombra). Cada variante é pintada UMA vez num canvas auxiliar; por quadro custa um drawImage.
// Sem canvas disponível (testes/headless), pinta direto.
// =====================================================================
export const LARG_JARDINEIRA = 16;
export const ALTURA_JARDINEIRA = 28;
const W = LARG_JARDINEIRA; const H = ALTURA_JARDINEIRA;

// Paleta da direção: verde-musgo, verde-oliva, marrom-escuro, bege e detalhes vermelho-rosados.
export const PALETA_JARDINEIRA = Object.freeze({
  borda: '#2a1d14',    // contorno (mais escuro que o fundo do Jardim)
  sombra: '#3a2a1e',   // sombra do caule, nós e cipós
  caule: '#5a4030',    // caule e raízes-pernas
  musgo: '#6b8a3e',    // musgo e folhas
  oliva: '#9aa35a',    // luz (borda direita e topo), folhas e pétalas externas
  bege: '#e6d4a8',     // raízes das mãos e dos pés, centro da flor, fungos
  rosa: '#d97a7e',     // bordas das pétalas e pontos de fungo
  vinho: '#5a2030',    // abertura da flor
});
const COR = PALETA_JARDINEIRA;

// Musgo e fungos em posições fixas (coordenadas do sprite, antes de virar): determinístico, não pisca.
const MUSGO = [[7, 13], [8, 13], [7, 16], [9, 17], [8, 18], [7, 21], [3, 15], [13, 16], [2, 20]];
const FUNGOS = [[10, 14], [5, 19], [11, 18]];
const BROTO = [[12, 1, 'musgo'], [12, 0, 'musgo'], [11, 0, 'oliva'], [13, 0, 'oliva']];   // brotinho com duas folhas, fora da flor
// Ornamentos discretos nos ombros e nas costas: só ocupam células vazias (nunca apagam o corpo).
const ORNAMENTOS = [
  [4, 10, 'oliva'], [4, 11, 'musgo'],                     // broto do ombro esquerdo
  [10, 10, 'oliva'], [11, 11, 'musgo'],                   // broto do ombro direito
  [0, 10, 'rosa'], [0, 11, 'bege'],                       // fungo nas costas, lado esquerdo
  [15, 11, 'rosa'], [15, 12, 'bege'],                     // fungo nas costas, lado direito
  [1, 27, 'bege'], [15, 25, 'bege'],                      // pontas extras das raízes das mãos
];   // cada fungo: pixel bege com um ponto rosado logo acima

// --- fabricação de canvas (injetável: navegador usa document; testes e render_check injetam outro) ---
const fabricaPadrao = (w, h) => (typeof document !== 'undefined' && document.createElement ? Object.assign(document.createElement('canvas'), { width: w, height: h }) : null);
let fabrica = fabricaPadrao;
const cache = new Map();
export function definirFabricaDeTelas(f) { fabrica = f || fabricaPadrao; cache.clear(); }
export function limparCacheJardineira() { cache.clear(); }

// --- formas ---
/** Cadeia de cápsulas por pontos (raio em cada ponto). Devolve { n, u } se o pixel está dentro; n = distância normalizada pelo raio. */
function cadeia(px, py, pts, rs) {
  let melhor = null;
  for (let i = 0; i < pts.length - 1; i++) {
    const [ax, ay] = pts[i]; const [bx, by] = pts[i + 1];
    const vx = bx - ax; const vy = by - ay; const L = vx * vx + vy * vy;
    let u = L ? ((px - ax) * vx + (py - ay) * vy) / L : 0; u = Math.max(0, Math.min(1, u));
    const d = Math.hypot(px - (ax + vx * u), py - (ay + vy * u));
    const r = rs[i] + (rs[i + 1] - rs[i]) * u; const n = d / Math.max(r, 0.01);
    if (n <= 1 && (!melhor || n < melhor.n)) melhor = { n, u: (i + u) / (pts.length - 1) };
  }
  return melhor;
}
/** Elipse: devolve a distância normalizada (≤ 1) ou null. */
function elipse(px, py, cx, cy, rx, ry) { const n = Math.hypot((px - cx) / rx, (py - cy) / ry); return n <= 1 ? n : null; }
const naLista = (lista, x, y) => lista.some(([a, b]) => a === x && b === y);

/**
 * Cor (chave de PALETA_JARDINEIRA) de um pixel, da frente para trás. null = vazio.
 * v = { ox (balanço da cabeça, −1..1), dedo (0 ou 0,5: raízes dos dedos), aberta (0|1) }
 */
function corDoPixel(x, y, v) {
  const px = x + 0.5; const py = y + 0.5;
  for (const [bx, by, bc] of BROTO) if (bx === x && by === y) return bc;
  // flor-cabeça: três camadas de pétalas (borda ondulada pelo ângulo) e a abertura central
  const hx = 8.5 + v.ox; const hy = 6.8;
  const pet = v.aberta && v.dedo ? 0.45 : 0;   // flor aberta (fala, pulso ou perto do Limo): pétalas se afastam e voltam, 0,45 px
  const hd = elipse(px, py, hx, hy, 5.1 + pet, 4.6 + pet * 0.8);
  if (hd !== null) {
    const th = Math.atan2(py - hy, px - hx);
    if (hd <= 0.84 + 0.16 * Math.cos(4 * th)) {
      const dx = px - hx; const dy = py - hy;
      if (hd > 0.72) return 'oliva';                                                         // pétalas externas
      if (hd > 0.38) return Math.cos(8 * th) > 0.75 ? 'rosa' : 'musgo';                      // pétalas do meio, com bordas rosadas
      // centro: sem fenda escura (não é boca nem viseira). Botão fechado = nervuras rosadas;
      // ao falar, as pétalas se afastam e mostram só luz bege no meio.
      if (v.aberta && Math.abs(dy) < 0.5 && Math.abs(dx) < 1.2) return 'bege';
      return Math.cos(6 * th) > 0.55 ? 'rosa' : 'bege';
    }
  }
  // braços compridos (separados do caule) e raízes ramificadas nas mãos
  const bracoE = cadeia(px, py, [[6, 12.5], [3.5, 17], [2, 22.5]], [0.9, 0.75, 0.6]);
  const bracoD = cadeia(px, py, [[10.5, 12.5], [13.5, 17.5], [14.5, 24]], [0.9, 0.75, 0.6]);
  const raizE = cadeia(px, py, [[2, 22.5], [0.5 + v.dedo, 26.5]], [0.5, 0.4]) || cadeia(px, py, [[2, 22.5], [3.5 - v.dedo, 26.5]], [0.5, 0.4]);
  const raizD = cadeia(px, py, [[14.5, 24], [14.5 + v.dedo, 27]], [0.5, 0.4]) || cadeia(px, py, [[14.5, 24], [12 - v.dedo, 26.5]], [0.5, 0.4]);
  if (raizE || raizD) return 'bege';
  // ramificações nas pontas dos braços (raízes vivas)
  if (cadeia(px, py, [[3.5, 17], [1.2, 18.6]], [0.35, 0.3]) || cadeia(px, py, [[2, 22.5], [0.6, 21]], [0.4, 0.3]) || cadeia(px, py, [[13.5, 17.5], [15.6, 16.6]], [0.35, 0.3])) return 'bege';
  if (cadeia(px, py, [[14.5, 24], [15.6, 22.6]], [0.4, 0.3]) || cadeia(px, py, [[2, 22.5], [1.2, 24.4]], [0.35, 0.3])) return 'bege';
  if (cadeia(px, py, [[14.5, 24], [13.2, 25.8], [12.5, 27]], [0.35, 0.25, 0.2]) || cadeia(px, py, [[2, 22.5], [3.2, 25.4], [3.6, 27]], [0.35, 0.25, 0.2])) return 'bege';
  if (bracoE) return bracoE.u > 0.8 ? 'bege' : 'caule';
  if (bracoD) return bracoD.u > 0.8 ? 'bege' : 'caule';
  // pernas: duas raízes separadas por um vão, listradas como raízes entrelaçadas
  const pernaE = cadeia(px, py, [[7, 20.5], [5, 24.5], [3.5, 27.5]], [1.0, 0.8, 0.6]);
  const pernaD = cadeia(px, py, [[9.5, 20.5], [11.5, 24.5], [12.5, 27.5]], [1.0, 0.8, 0.6]);
  if (pernaE || pernaD) return (x + y) % 3 === 0 ? 'oliva' : (y >= 25 ? 'sombra' : 'caule');
  // caule esguio com nós e sombra do lado direito
  const caule = cadeia(px, py, [[8.5, 11.5], [7.8, 20.5]], [1.9, 1.3]);
  if (caule) {
    if (naLista(FUNGOS, x, y)) return 'bege';
    if (naLista(FUNGOS, x, y + 1)) return 'rosa';                                // ponto rosado acima do fungo
    if (y === 15 || y === 19) return 'sombra';                                    // nós do caule
    if (naLista(MUSGO, x, y)) return 'musgo';
    return x >= 9 ? 'sombra' : 'caule';
  }
  // atrás de tudo: cipós em curva, folhas em gota e raízes pendentes
  if (cadeia(px, py, [[5.5, 15.5], [4.5, 22]], [0.45, 0.45]) || cadeia(px, py, [[11.5, 16.5], [12, 23]], [0.45, 0.45])) return 'sombra';
  if (cadeia(px, py, [[3.5, 8], [1.5, 12.5], [2.5, 17], [1.5, 21]], [0.6, 0.6, 0.6, 0.6]) || cadeia(px, py, [[12.5, 9], [14.5, 14], [13.5, 19], [14.5, 22]], [0.6, 0.6, 0.6, 0.6])) return 'sombra';
  if (cadeia(px, py, [[2.5, 12.5], [0.5, 14.5]], [0.9, 0.2]) || cadeia(px, py, [[13.5, 14], [15.5, 16]], [0.9, 0.2]) || cadeia(px, py, [[2.5, 17.5], [0.5, 19]], [0.8, 0.2])) return 'oliva';
  return null;
}

/** Grade completa: cor de cada pixel, borda de luz à direita, contorno escuro em volta da silhueta, espelhada se virada para a esquerda. */
function grade(v) {
  const g = [];
  for (let y = 0; y < H; y++) { g.push([]); for (let x = 0; x < W; x++) g[y].push(corDoPixel(x, y, v)); }
  for (const [ox_, oy_, oc] of ORNAMENTOS) if (g[oy_][ox_] === null) g[oy_][ox_] = oc;
  // o contorno é calculado sobre o desenho ORIGINAL (antes deste passe). Lendo g, que vai mudando no laço, o contorno se propagava em cascata.
  const o = g.map((linha) => linha.slice());
  const cheio = (x, y) => x >= 0 && y >= 0 && x < W && y < H && o[y][x] !== null;
  const corpo = new Set(['caule', 'musgo', 'sombra']);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (g[y][x] === null) { if (cheio(x - 1, y) || cheio(x + 1, y) || cheio(x, y - 1) || cheio(x, y + 1)) g[y][x] = 'borda'; }
    else if (corpo.has(g[y][x]) && !cheio(x + 1, y) && x >= 4 && x <= 11 && y >= 10 && y <= 21) g[y][x] = 'bege';   // borda de luz só no tronco (braços e pernas ficam limpos)
    else if (g[y][x] === 'caule' && !cheio(x, y - 1)) g[y][x] = 'oliva';          // topo iluminado
  }
  if (v.face < 0) for (const linha of g) linha.reverse();
  return g;
}

/** Pinta a grade no contexto em (ox, oy), até `linhas` linhas (o retrato usa só a cabeça). */
function pintar(ctx, ox, oy, g, linhas = H) {
  for (let y = 0; y < Math.min(linhas, H); y++) for (let x = 0; x < W; x++) {
    const k = g[y][x]; if (!k) continue;
    ctx.fillStyle = COR[k]; ctx.fillRect(ox + x, oy + y, 1, 1);
  }
}

/** Variante a partir do tempo: balanço da cabeça (−1..1), raízes dos dedos (2 quadros), abertura (fala, aproximação ou pulso lento). */
function variante(t, facing, falando, perto) {
  return {
    face: facing < 0 ? -1 : 1,
    ox: falando ? 0 : Math.round(Math.sin(t * 1.3)),   // fala: cabeça parada, quem se mexe são as pétalas
    dedo: Math.floor(t * (falando ? 2.5 : 2)) % 2 ? 0.5 : 0,
    aberta: falando || perto || (t % 4) > 3.4 ? 1 : 0,
  };
}

/** Canvas já pintado da variante (uma vez por chave), ou null sem canvas (pinta direto). */
function quadroDe(v) {
  const k = `${v.face}|${v.ox}|${v.dedo}|${v.aberta}`;
  if (cache.has(k)) return cache.get(k);
  const cv = fabrica(W, H);
  if (cv) { const cx = cv.getContext('2d'); cx.clearRect(0, 0, W, H); pintar(cx, 0, 0, grade(v)); }
  cache.set(k, cv || null); return cache.get(k);
}

/**
 * Desenha a Jardineira com o canto superior esquerdo da figura em (px, py). Mesma assinatura das outras artes de NPC.
 * `perto` (último argumento, opcional): o Limo está próximo, então a flor se abre um pouco mais.
 */
export function desenharJardineira(ctx, px, py, t = 0, falando = false, _estado = 'parado', facing = 1, perto = false) {
  const v = variante(t, facing, falando, perto);
  const cv = quadroDe(v);
  if (cv) ctx.drawImage(cv, px, py);
  else pintar(ctx, px, py, grade(v));
}

/** Retrato do diálogo: só a cabeça (14 linhas), desenhada no canto (x, y) já ampliada pelo diálogo. */
export function desenharRetratoJardineira(ctx, x, y, t = 0, falando = false) {
  const v = variante(t, 1, falando, falando);
  const cv = quadroDe(v);
  if (cv) ctx.drawImage(cv, 0, 0, W, 14, x, y, W, 14);
  else pintar(ctx, x, y, grade(v), 14);
}

/** Para testes e conferência: a grade (cor por pixel) de uma variante, sem pintar. */
export function gradeJardineira(t = 0, falando = false, facing = 1, perto = false) { return grade(variante(t, facing, falando, perto)); }
