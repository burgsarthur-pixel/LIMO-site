// =====================================================================
// TILES VOLUMÉTRICOS (2.5D): relevo, espessura, sombra e brilho por material, com luz fixa vinda do canto superior esquerdo.
//  - Roda DENTRO do cache de tiles (renderer._camadasEmCache): custo por quadro = zero. Só refaz quando o mapa muda.
//  - Autotile-consciente: só desenha quina onde a vizinhança NÃO se conecta (mesmo grupo de autotile = sem borda).
//    Entre materiais diferentes só entra uma oclusão suave (o de maior `elev` sombreia o outro), nunca uma "régua".
//  - A lista de retângulos de cada situação (material × vizinhança × variação) é calculada uma vez e reaproveitada.
// Só visual: não lê nem altera colisão, hitbox, física ou câmera.
// =====================================================================
import { perfilDoMaterial, mesmoGrupo } from './depth-config.js';

const TS = 16;
// índices de vizinhança: 0 N, 1 E, 2 S, 3 W, 4 NE, 5 SE, 6 SW, 7 NW
const DX = [0, 1, 0, -1, 1, 1, -1, -1]; const DY = [-1, 0, 1, 0, -1, 1, 1, -1];
export const AR = 0; export const LIGADO = 1; export const OUTRO = 2;   // estado do vizinho: ar, mesmo grupo (conecta), sólido de outro grupo

const ruido = (a, b) => { let n = Math.imul(a + 7, 73856093) ^ Math.imul(b + 13, 19349663); n = Math.imul(n ^ (n >>> 15), 2246822519); return (n ^ (n >>> 13)) >>> 0; };
const R = (x, y, w, h, cor, a) => [x, y, w, h, cor, a];

/**
 * Retângulos [x,y,w,h,"r,g,b",alfa] de UM tile sólido. Função pura (testável sem canvas).
 * @param perfil perfilDoMaterial(tile) · @param st 8 estados de vizinhança · @param altos máscara N=1,E=2,S=4,W=8 de vizinhos de outro grupo com `elev` maior
 * @param vari 0..3 (variação por posição) · @param e espessura 0..3 · @param f força 0..1.5 · @param amb liga oclusão ambiente
 */
export function retangulosDoTile(perfil, st, altos, vari, e, f, amb = true) {
  const out = []; if (!perfil || f <= 0) return out;
  const k = f * perfil.relevo * 1.4; const a = (v) => Math.min(0.95, v * k);
  const arN = st[0] === AR; const arE = st[1] === AR; const arS = st[2] === AR; const arW = st[3] === AR;
  const quebra = (i, mod = 7) => ruido(i, vari + perfil.id * 5) % mod === 0;   // pixels que faltam: nada de régua contínua
  // --- bordas expostas ao ar (lado da luz = N e W: brilho; lado oposto = S e E: sombra e espessura) ---
  if (arN) {
    const x0 = arW ? 1 : 0; const x1 = arE ? 15 : 16;
    for (let x = x0; x < x1; x++) if (!quebra(x)) out.push(R(x, 0, 1, 1, perfil.hi, a(0.85)));
    if (e > 0) out.push(R(x0, 1, x1 - x0, Math.min(e, 3), perfil.topo, a(0.3)));   // "face de cima": espessura visível do bloco
    if (e > 1) for (let x = x0 + 1; x < x1 - 1; x++) if (!quebra(x + 11, 4)) out.push(R(x, 1, 1, 1, perfil.hi, a(0.4)));   // bisel de 2 px (com falhas)
  }
  if (arW) { const y0 = arN ? 1 : 0; for (let y = y0; y < (arS ? 15 : 16); y++) if (!quebra(y + 31, 5)) out.push(R(0, y, 1, 1, perfil.hi, a(0.55))); }
  if (arS) {
    const x0 = arW ? 1 : 0; const x1 = arE ? 15 : 16;
    out.push(R(x0, 15, x1 - x0, 1, perfil.lo, a(0.8)));
    if (e > 0) out.push(R(x0, 15 - e, x1 - x0, e, perfil.lo, a(0.32)));
    if (perfil.umido) for (let x = x0; x < x1; x++) if (ruido(x, vari + 97) % 6 === 0) out.push(R(x, 13 - (e > 1 ? 1 : 0), 1, 1, perfil.ao, a(0.4)));   // gotejar
  }
  if (arE) {
    const y0 = arN ? 1 : 0; const y1 = arS ? 15 : 16;
    out.push(R(15, y0, 1, y1 - y0, perfil.lo, a(0.7)));
    if (e > 0) out.push(R(16 - Math.min(e, 3) - 1, y0, Math.min(e, 3), y1 - y0, perfil.lo, a(0.26)));
  }
  // --- quinas convexas: um pixel escuro arredonda o bloco (só onde as duas bordas são livres) ---
  if (arN && arW) out.push(R(0, 0, 1, 1, perfil.ao, a(0.55)));
  if (arN && arE) out.push(R(15, 0, 1, 1, perfil.ao, a(0.7)));
  if (arS && arW) out.push(R(0, 15, 1, 1, perfil.ao, a(0.7)));
  if (arS && arE) out.push(R(15, 15, 1, 1, perfil.ao, a(0.85)));
  // --- cantos côncavos: as duas bordas conectam mas a diagonal é ar → fresta com oclusão ambiente ---
  if (amb) {
    const conc = [[0, 3, 7, 0, 0], [0, 1, 4, 14, 0], [2, 1, 5, 14, 14], [2, 3, 6, 0, 14]];   // [borda A, borda B, diagonal, x, y]
    for (const [p, q, d, cx, cy] of conc) if (st[p] === LIGADO && st[q] === LIGADO && st[d] === AR) { out.push(R(cx, cy, 2, 2, perfil.ao, a(0.5))); out.push(R(cx === 0 ? 2 : 13, cy, 1, 2, perfil.ao, a(0.18))); }
    // contato com sólido de outro material: o de maior elevação sombreia este (mais forte do lado da luz)
    if (altos & 1) out.push(R(0, 0, 16, 2, perfil.ao, a(0.4)));
    if (altos & 8) out.push(R(0, 0, 2, 16, perfil.ao, a(0.4)));
    if (altos & 2) out.push(R(15, 0, 1, 16, perfil.ao, a(0.28)));
    if (altos & 4) out.push(R(0, 15, 16, 1, perfil.ao, a(0.28)));
  }
  // --- detalhe do material (sutil e sem emenda: colunas/linhas fixas contínuas entre tiles vizinhos) ---
  if (perfil.sulcos) for (const cx of [4, 11]) for (let y = 0; y < 16; y++) if (y === 0 || y === 15 || ruido(y + cx * 3, vari) % 5 !== 0) out.push(R(cx, y, 1, 1, perfil.lo, a(0.3)), R(cx + 1, y, 1, 1, perfil.hi, a(0.12)));
  if (perfil.estrias && vari % 2 === 0) for (const y of [5, 11]) out.push(R(0, y, 16, 1, perfil.lo, a(0.14)));
  if (perfil.lascas && vari > 0) { const x = 3 + vari * 3; const y = 4 + vari * 2; out.push(R(x, y, 2, 1, perfil.hi, a(0.4)), R(x + 1, y + 1, 1, 1, perfil.lo, a(0.35))); }
  if (perfil.umido && (vari === 0 || vari === 2)) out.push(R(5 + vari * 2, 3 + vari, 2, 1, perfil.hi, a(0.3)));
  if (perfil.translucido && arN) out.push(R(1, 2, 14, 1, perfil.hi, a(0.16)));
  if (perfil.fofo && arN) for (let x = 1; x < 15; x += 2) if (!quebra(x + 3, 3)) out.push(R(x, 1, 1, 1, perfil.hi, a(0.28)));
  return out;
}

export class VolumeTiles {
  constructor() { this._memo = new Map(); this._cfgKey = ''; this.stats = { tiles: 0, retangulos: 0, ms: 0 }; }

  _prep(cfg) { const k = `${cfg.forca}|${cfg.espessura}|${cfg.ambiente ? 1 : 0}`; if (k !== this._cfgKey) { this._memo.clear(); this._cfgKey = k; } }

  /** Tile sólido para efeito de volume (camada solid, colisão sólida). Fora da sala = sólido (salas fechadas, como no autotile). */
  _sol(mapa, catalogo, tx, ty) {
    if (!mapa.inBounds(tx, ty)) return null;
    const id = mapa.layers.solid ? mapa.layers.solid[ty * mapa.width + tx] : 0; if (!id) return null;
    const t = catalogo.get(id); return t && t.collision === 'solid' ? t : null;
  }

  /** Situação de vizinhança de uma célula sólida. Devolve { st, altos }. */
  vizinhanca(mapa, tx, ty, perfil, saida) {
    const cat = mapa.catalog; let altos = 0;
    for (let d = 0; d < 8; d++) {
      const x = tx + DX[d]; const y = ty + DY[d];
      if (!mapa.inBounds(x, y)) { saida[d] = LIGADO; continue; }
      const t = this._sol(mapa, cat, x, y);
      if (!t) { saida[d] = AR; continue; }
      const p = perfilDoMaterial(t);
      if (mesmoGrupo(perfil, p)) saida[d] = LIGADO;
      else { saida[d] = OUTRO; if (d < 4 && p.elev > perfil.elev) altos |= 1 << d; }
    }
    // OUTRO (sólido de outro grupo) não é "ar": a borda não ganha quina; o contato é tratado por `altos`.
    return altos;
  }

  /** Relevo de todos os tiles sólidos da janela (tiles tx0..tx1, ty0..ty1) em ctx, deslocado por (ox, oy) px. */
  relevo(ctx, mapa, cfg, tx0 = 0, ty0 = 0, tx1 = mapa.width - 1, ty1 = mapa.height - 1, ox = 0, oy = 0) {
    if (!cfg?.ativo || cfg.forca <= 0 || !mapa.layers.solid) return;
    this._prep(cfg); const t0 = typeof performance !== 'undefined' ? performance.now() : 0;
    const st = this._st || (this._st = new Uint8Array(8)); let ultimo = ''; let nT = 0; let nR = 0;
    const cat = mapa.catalog; const sol = mapa.layers.solid;
    for (let ty = Math.max(0, ty0); ty <= Math.min(mapa.height - 1, ty1); ty++) for (let tx = Math.max(0, tx0); tx <= Math.min(mapa.width - 1, tx1); tx++) {
      const id = sol[ty * mapa.width + tx]; if (!id) continue;
      const tile = cat.get(id); if (!tile || tile.collision !== 'solid') continue;
      const perfil = perfilDoMaterial(tile); const altos = this.vizinhanca(mapa, tx, ty, perfil, st);
      const vari = ((tx * 73856093) ^ (ty * 19349663)) & 3;
      let ch = id * 4 + vari; for (let d = 0; d < 8; d++) ch = ch * 3 + st[d]; ch = ch * 16 + altos;
      let lista = this._memo.get(ch);
      if (!lista) { lista = retangulosDoTile(perfil, st, altos, vari, cfg.espessura, cfg.forca, cfg.ambiente); this._memo.set(ch, lista); }
      if (!lista.length) continue;
      nT++; const bx = tx * TS + ox; const by = ty * TS + oy;
      for (let i = 0; i < lista.length; i++) {
        const r = lista[i]; const cor = `rgba(${r[4]},${r[5].toFixed(2)})`; if (cor !== ultimo) { ctx.fillStyle = cor; ultimo = cor; }
        ctx.fillRect(bx + r[0], by + r[1], r[2], r[3]); nR++;
      }
    }
    this.stats = { tiles: nT, retangulos: nR, ms: typeof performance !== 'undefined' ? performance.now() - t0 : 0 };
  }

  /** Sombra projetada pelos blocos sobre o fundo (luz NW → cai para baixo e para a direita). Fica ENTRE o fundo/decoBack e o sólido. */
  sombras(ctx, mapa, cfg, tx0 = 0, ty0 = 0, tx1 = mapa.width - 1, ty1 = mapa.height - 1, ox = 0, oy = 0) {
    if (!cfg?.ativo || !cfg.sombra || cfg.forca <= 0 || !mapa.layers.solid) return;
    const prof = 3 + cfg.espessura; const cat = mapa.catalog; let ultimo = '';
    const cor = (al) => { const c = `rgba(6,2,10,${al.toFixed(2)})`; if (c !== ultimo) { ctx.fillStyle = c; ultimo = c; } };
    const sol = (x, y) => !!this._sol(mapa, cat, x, y);
    for (let ty = Math.max(0, ty0); ty <= Math.min(mapa.height - 1, ty1); ty++) for (let tx = Math.max(0, tx0); tx <= Math.min(mapa.width - 1, tx1); tx++) {
      if (sol(tx, ty)) continue;
      const n = sol(tx, ty - 1); const w = sol(tx - 1, ty); const nw = sol(tx - 1, ty - 1);
      if (!n && !w && !nw) continue;
      const bx = tx * TS + ox; const by = ty * TS + oy; const A = 0.5 * cfg.forca;
      if (n) { cor(A); ctx.fillRect(bx, by, TS, prof); cor(A * 0.5); for (let x = (tx & 1); x < TS; x += 2) ctx.fillRect(bx + x, by + prof, 1, 1); }   // borda inferior pontilhada (meio-tom)
      if (w) { cor(A * 0.8); ctx.fillRect(bx, by + (n ? prof : 0), prof, TS - (n ? prof : 0)); cor(A * 0.4); for (let y = (ty & 1); y < TS; y += 2) ctx.fillRect(bx + prof, by + y, 1, 1); }
      if (nw && !n && !w) { cor(A * 0.7); ctx.fillRect(bx, by, prof, prof); }
    }
  }
}
