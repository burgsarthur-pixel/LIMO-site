// =====================================================================
// SISTEMA DE ILUMINAÇÃO (lógica pura, sem DOM — testável em Node).
// Cada fonte de luz é {x, y, raio, intensidade, cor, oclusao, chama}. O Limo é a "tocha" principal: a luz dele tem
// chama (oscila), é BLOQUEADA por paredes (polígono de visibilidade por raios) e deixa o resto da sala no escuro.
// =====================================================================

import { geneDe } from '../entities/genes.js';
import { chaveItem } from '../core/progress.js';
import { temaDoBioma } from './biome-theme.js';
import { luzesDeAviso } from './polimento.js';
import { pulsarLuzes } from '../entities/atmosfera.js';

/** Oscilação de tocha: soma de ondas incomensuráveis (determinística; sem Math.random, então não "pisca" aleatório entre quadros). */
export function chama(t, semente = 0, quantidade = 0.06) {
  return 1 + quantidade * (0.55 * Math.sin(t * 9.1 + semente) + 0.3 * Math.sin(t * 23.7 + semente * 2.3) + 0.15 * Math.sin(t * 41.3 + semente * 0.7));
}

const _opacos = new WeakMap();
const _luzesDecorativas = new WeakMap();
/** Mapa de opacidade (1 = tile sólido bloqueia luz). Espinhos/plataformas finas não bloqueiam. Calculado uma vez por mapa. */
function opacidade(mapa) {
  let o = _opacos.get(mapa); if (o && o.setTiles === mapa.layers.solid) return o;
  const dados = mapa.layers.solid; const arr = new Uint8Array(mapa.width * mapa.height);
  if (dados) for (let i = 0; i < arr.length; i++) { const id = dados[i]; if (id) { const t = mapa.catalog?.get ? mapa.catalog.get(id) : null; arr[i] = !t || t.collision === 'solid' ? 1 : 0; } }
  o = { arr, setTiles: mapa.layers.solid }; _opacos.set(mapa, o); return o;
}
/** Chame depois de editar tiles (editor) para recalcular a opacidade. */
export function invalidarOpacidade(mapa) { _opacos.delete(mapa); }

/**
 * Luzes passivas de decoração. O cache depende da revisão do TileMap, portanto o editor
 * as atualiza sem varrer a sala a cada quadro. Só estilos explicitamente luminosos entram aqui.
 */
function luzesDecorativas(mapa, t) {
  const revisao = mapa.revision ?? 0;
  let cache = _luzesDecorativas.get(mapa);
  if (!cache || cache.revisao !== revisao) {
    const pontos = []; const vistos = new Set(); const ts = mapa.tileSize;
    for (const arr of Object.values(mapa.layers || {})) {
      if (!arr) continue;
      for (let i = 0; i < arr.length; i++) {
        const id = arr[i]; if (!id) continue;
        const tile = mapa.catalog?.get?.(id);
        if (tile?.art?.style !== 'decoGlow' || vistos.has(i)) continue;
        vistos.add(i);
        const jardim = tile.biome === 'jardim';
        pontos.push({
          id: `deco-${id}-${i}`, x: ((i % mapa.width) + 0.5) * ts, y: (Math.floor(i / mapa.width) + 0.5) * ts,
          raio: jardim ? 20 : 22, intensidade: jardim ? 0.32 : 0.36,
          cor: jardim ? [213, 255, 131] : [244, 176, 232], tinta: jardim ? 0.10 : 0.12,
          semente: i * 0.173 + id,
        });
      }
    }
    cache = { revisao, pontos }; _luzesDecorativas.set(mapa, cache);
  }
  return cache.pontos.map((l) => ({ ...l, raio: l.raio * chama(t, l.semente, 0.025) }));
}

/** O ponto (px,py) está dentro de um tile que bloqueia luz? */
export function bloqueiaLuz(mapa, px, py) {
  const ts = mapa.tileSize; const tx = Math.floor(px / ts); const ty = Math.floor(py / ts);
  if (tx < 0 || ty < 0 || tx >= mapa.width || ty >= mapa.height) return true;
  return opacidade(mapa).arr[ty * mapa.width + tx] === 1;
}

const _trig = new Map();
/** Senos/cossenos dos `raios` raios, calculados uma vez por quantidade (antes: Math.cos/sin a cada raio, a cada chamada). */
function tabelaTrig(raios) {
  let t = _trig.get(raios);
  if (!t) { t = { cos: new Float64Array(raios), sin: new Float64Array(raios) }; for (let i = 0; i < raios; i++) { const a = (i / raios) * Math.PI * 2; t.cos[i] = Math.cos(a); t.sin[i] = Math.sin(a); } _trig.set(raios, t); }
  return t;
}
const _visao = new Map();   // últimos polígonos calculados: o mesmo quadro pede o polígono duas vezes (buraco de luz + tinta) e um Limo parado pede o mesmo todo quadro
const VISAO_MAX = 24;   // v1.41.0: a penumbra pede vários pontos de luz por quadro (amostras + halo)

/**
 * Polígono de visibilidade em volta de (x,y): `raios` raios; cada um para no primeiro tile sólido (ou no raio máximo).
 * Resultado em cache por (mapa, x, y, raio, raios, passo): o cache se invalida sozinho quando a grade de opacidade é recalculada
 * (troca de sala, editor, `invalidarOpacidade`). O array devolvido é compartilhado: quem chama só deve LER.
 */
export function poligonoDeVisao(mapa, x, y, raio, raios = 64, passo = 2) {
  const o = opacidade(mapa);
  const chave = `${x}|${y}|${raio}|${raios}|${passo}`;
  const hit = _visao.get(chave);
  if (hit && hit.arr === o.arr && hit.mapa === mapa) return hit.pts;
  const arr = o.arr; const ts = mapa.tileSize; const W = mapa.width; const H = mapa.height; const { cos, sin } = tabelaTrig(raios);
  const pts = new Array(raios);
  for (let i = 0; i < raios; i++) {
    const dx = cos[i]; const dy = sin[i]; let d = 0;
    while (d < raio) {
      const nd = Math.min(raio, d + passo); const tx = Math.floor((x + dx * nd) / ts); const ty = Math.floor((y + dy * nd) / ts);
      if (tx < 0 || ty < 0 || tx >= W || ty >= H || arr[ty * W + tx] === 1) break;   // mesma regra de bloqueiaLuz(), sem refazer a busca do mapa a cada passo
      d = nd;
    }
    pts[i] = { x: x + dx * d, y: y + dy * d };
  }
  _visao.set(chave, { mapa, arr, pts });
  if (_visao.size > VISAO_MAX) _visao.delete(_visao.keys().next().value);
  return pts;
}

/** Reúne as fontes de luz do quadro (a do Limo primeiro). Coordenadas em pixels do MUNDO. */
export function coletarLuzes(game, R, t, pulso = 0) {
  const luzes = []; const ts = game.map.tileSize;
  const p = game.player;
  if (p && p.life > 0) luzes.push({ id: 'limo', x: p.centerX, y: p.centerY - 1, raio: (R.lightRadius ?? 70) * chama(t, 0, R.lightFlicker ?? 0.06), intensidade: 1, cor: [130, 255, 170], oclusao: R.lightOcclusion !== false, tinta: 0.05 + (R.creatureLight ?? 0.16) * 0.3 });
  for (const e of game.roomData?.entities || []) {
    if (game.vivo?.oculta?.(e.x, e.y)) continue;   // v1.38.0: o que está numa câmara secreta fechada não vaza luz pela rocha
    const x = (e.x + 0.5) * ts; const y = (e.y + 0.5) * ts;
    if ((e.type === 'mutation' || e.type === 'vida' || e.type === 'encaixe') && game.progress?.collected?.has(chaveItem(game.roomId, e.id))) continue;   // item já coletado não brilha
    if (e.type === 'gene') { if (!game.progress?.genes?.has(e.gene)) { const g = geneDe(e.gene); const c = g ? [parseInt(g.cor.slice(1, 3), 16), parseInt(g.cor.slice(3, 5), 16), parseInt(g.cor.slice(5, 7), 16)] : [200, 255, 200]; luzes.push({ id: e.id, x, y, raio: 30 * chama(t, e.x, 0.06), intensidade: 0.8, cor: c, tinta: 0.22 }); } continue; }
    if (e.type === 'checkpoint') luzes.push({ id: e.id, x, y, raio: 40 * chama(t, e.x, 0.04), intensidade: 0.85, cor: [90, 210, 255], tinta: 0.2 + 0.05 * pulso });
    else if (e.type === 'mutation') luzes.push({ id: e.id, x, y, raio: 36 * chama(t, e.x, 0.05), intensidade: 0.9, cor: [255, 190, 90], tinta: 0.24 });
    else if (e.type === 'ferida' && !game.progress?.collected?.has(chaveItem(game.roomId, e.id))) luzes.push({ id: e.id, x, y, raio: 34 * chama(t, e.x, 0.08), intensidade: 0.75, cor: [255, 60, 70], tinta: 0.22 + 0.1 * pulso });
    else if (e.type === 'encaixe') luzes.push({ id: e.id, x, y, raio: 30 * chama(t, e.x, 0.05), intensidade: 0.8, cor: [90, 220, 255], tinta: 0.22 });
    else if (e.type === 'vida') luzes.push({ id: e.id, x, y, raio: 28 * chama(t, e.x, 0.05), intensidade: 0.8, cor: [255, 90, 130], tinta: 0.2 });
  }
  for (const en of game.enemies || []) {
    if (!en.alive) continue;
    if (en.cfg?.kind === 'boss') luzes.push({ id: 'chefe', x: en.centerX, y: en.centerY, raio: 56, intensidade: 0.9, cor: [255, 70, 90], tinta: 0.22 });
    else luzes.push({ id: 'criatura', x: en.centerX, y: en.centerY, raio: 20, intensidade: 0.3 + (R.creatureLight ?? 0.16), cor: [190, 120, 255], tinta: (R.creatureLight ?? 0.16) * 0.6 });
  }
  for (const f of game.fungos || []) if (f.t > 0) luzes.push({ id: 'fungo', x: (f.tx + 0.5) * ts, y: (f.ty + 0.5) * ts - 2, raio: 24, intensidade: 0.7 * Math.min(1, f.t / 0.8), cor: [150, 255, 170], tinta: 0.18 });
  // Micélios e esporos-lanterna são luz ambiente, não mecânica: não bloqueiam, não ferem e não chamam atenção demais.
  luzes.push(...pulsarLuzes(luzesDecorativas(game.map, t), { bioma: game.roomData?.biome, pulso, respira: game.ambience?.respira ?? 0.5, t, escuro: game.vivo?.atmosfera?.escuro ?? 0 }));   // v1.38.0: a luz bate com o corpo do Deus (cada bioma no seu ritmo)
  luzes.push(...(game.luzesFx?.lista?.() || []), ...luzesDeAviso(game.enemies));
  if (R.feixes?.ligado !== false) for (const fx of game.roomData?.feixes || []) luzes.push({ id: `fresta-${fx.id}`, x: fx.x * ts, y: fx.y * ts + 2, raio: 12 + (fx.largura ?? 14) * 0.9, intensidade: 0.55 * (fx.intensidade ?? 0.85), cor: fx.cor || [255, 230, 170], tinta: 0.14 });   // v1.42.0: a fresta no teto brilha
  for (const o of game.orbs || []) luzes.push({ id: 'orbe', x: o.x, y: o.y, raio: 16, intensidade: 0.7, cor: [255, 120, 150], tinta: 0.2 });
  for (const ps of game.passages || []) if (!ps.locked) luzes.push({ id: 'passagem', x: ps.x + ps.w / 2, y: ps.y + ps.h / 2, raio: 30, intensidade: 0.5, cor: temaDoBioma(game.roomData?.biome).passagem, tinta: 0.1 + 0.06 * pulso });
  return luzes;
}
