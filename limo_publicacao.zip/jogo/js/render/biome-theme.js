// =====================================================================
// TEMA POR BIOMA (inspirado no mapa-múndi): cada região do corpo do Deus tem paleta própria.
//  raizes = ossuário (carne envelhecida, osso, âmbar; roxo só residual) · jardim = flora sepulcral (verde/ciano/amarelo) · nucleo = santuário (roxo, ciano, dourado)
// Dados puros: veia/bolha/esporo/gota/tinta/passagem/ar. Usado pelo renderer (sem DOM).
// =====================================================================
export const TEMAS = {
  // OSSUÁRIO DAS RAÍZES: o corpo da divindade já apodrecido. Carne envelhecida (ocre/rosado pálido), osso amarelado,
  // raízes verde-oliva invadindo o templo, fungos âmbar. O roxo aparece só como resíduo: veios e gotas de sangue divino.
  raizes: {
    nome: 'Ossuário das Raízes', parede: 'rgba(196,150,110,0.20)', tons: ['#1f1410', '#2e1c17', '#171014', '#3a2420', '#241418', '#46302a'], fundo: '#0f0907', veia: [118, 70, 112], veiaPulso: [150, 118, 44], bolha: '232,192,122', bolhaA: 0.82,
    esporoA: 'rgba(236,200,120,0.40)', esporoB: 'rgba(176,150,232,0.30)', gota: '#c9a0e8', ar: [92, 60, 74, 0.10],
    luzLimo: [255, 214, 150], passagem: [236, 196, 110], borda: '#7a5a3c', fenda: '62,30,72', raios: 0, feixe: [255, 206, 140], neblina: 0.0,
  },
  // JARDIM SEPULCRAL: a vida que continuou depois da morte. Verdes orgânicos, fungos ciano luminosos, flores amarelas.
  jardim: {
    nome: 'Jardim Sepulcral', parede: 'rgba(70,220,170,0.28)', tons: ['#04201a', '#0a3a2c', '#10301c', '#06181a', '#124a38', '#1b3d1a'], fundo: '#010f0d', veia: [30, 160, 120], veiaPulso: [150, 170, 40], bolha: '120,255,220', bolhaA: 1.65,
    esporoA: 'rgba(120,255,226,0.42)', esporoB: 'rgba(255,230,110,0.34)', gota: '#7affd9', ar: [8, 100, 90, 0.12],
    luzLimo: [150, 255, 220], passagem: [120, 255, 200], borda: '#1f7a62', fenda: '10,110,100', raios: 2, feixe: [196, 255, 176], neblina: 0.075,
  },
  // NÚCLEO DO DEUS: o santuário onde o sangue divino ainda pulsa. Aqui o roxo domina, com ciano e dourado sagrados.
  nucleo: {
    nome: 'Núcleo do Deus', parede: 'rgba(130,70,230,0.28)', tons: ['#140a26', '#1b0f33', '#0f0a1f', '#20113a', '#0c0818'], fundo: '#0a0414', veia: [140, 60, 200], veiaPulso: [60, 170, 205], bolha: '200,150,255', bolhaA: 1.0,
    esporoA: 'rgba(214,156,255,0.38)', esporoB: 'rgba(110,232,255,0.32)', gota: '#c78cff', ar: [70, 22, 124, 0.14],
    luzLimo: [214, 164, 255], passagem: [200, 140, 255], borda: '#5a2f9a', fenda: '110,40,170', raios: 3, feixe: [190, 172, 255], neblina: 0.04,
  },
};
export function temaDoBioma(id) { return TEMAS[id] || TEMAS.raizes; }

/** Bioma limpo após o chefe: menos névoa e névoa de ar, mais brilho (estado pós-vitória). */
export const CHEFE_DO_BIOMA = { raizes: 'raizes_guardiao:guardiao_raizes', jardim: 'jardim_lago:devorador_flores', nucleo: 'nucleo_salao:mastigador_pulso' };
const LIMPOS = {};
export function temaLimpo(id) {
  return LIMPOS[id] ||= (() => { const t = temaDoBioma(id); return { ...t, ar: [t.ar[0], t.ar[1], t.ar[2], t.ar[3] * 0.25], neblina: 0, bolhaA: t.bolhaA * 1.6, raios: (t.raios || 0) + 1, parede: t.parede.replace(/[\d.]+\)$/, (m) => `${Math.min(0.5, parseFloat(m) * 1.6).toFixed(2)})`) }; })();
}
