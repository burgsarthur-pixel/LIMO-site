// =====================================================================
// ARTE PROCEDURAL DA TECELÃ DAS RAÍZES E DA MUDA ARACNÍDEA (Salto na Parede)
// Mesmo espírito do Limo: tudo desenhado por código em pixels nítidos, com CONTORNO PRETO por peça e POSES por situação.
// Proporções e paleta seguem a arte oficial: abdômen carmesim com treliça de raízes e cogumelos, rosto bege com olhos
// rosados e presas, patas grossas marrom→carmesim de ponta afiada.
// Só visual: lê attackState/attackTimer/hurtTimer da IA e nunca altera hitbox, zonas, timing ou estados.
// =====================================================================
import { tecelaColapso } from './tecela-sprite.js';
import { clamp01, lerp, suave } from '../core/math.js';

const C = {
  contorno: '#0a0307', corpo: '#9c2a4c', corpoEsc: '#5c1030', corpoLuz: '#c8466a', lobo: '#b0304c', loboLuz: '#d85a7a',
  raiz: '#8a5a40', raizLuz: '#c08a60', raizEsc: '#4a2a26', coxa: '#7a4a3a', coxaLuz: '#a46a50', coxaLonge: '#5e3430',
  tibia: '#8a2038', tibiaLuz: '#c03a58', tibiaLonge: '#6a1a2e', rosto: '#d2a88a', rostoEsc: '#8a5a4a', presa: '#f0dcc0',
  olho: '#fff0f0', iris: '#e0204a', cogu: '#f0d6b8', coguEsc: '#caa282', haste: '#a07a5a', musgo: '#6a7a3a', musgoLuz: '#8a9a4a',
  fio: '#e2b16d', flash: '#fff5ed', brilho: '#ffd27a',
  carne: '#a5304c', carneEsc: '#4a0e26', carneLuz: '#d05a78', carneBrilho: '#f0a0aa', veia: '#34081c', gordura: '#e0b0a0', ferida: '#ee7c88', tripa: '#c46a78', tripaPonta: '#e08a92',
};

/** Pose da Tecelã para o estado atual (equivalente ao LimoAnimator.pose). Função pura. */
export function tecelaPose(enemy, t = 0) {
  const e = enemy.attackState || ''; const c = enemy.cfg || {}; const timer = Math.max(0, enemy.attackTimer || 0);
  const prog = (dur) => (dur > 0 ? clamp01(1 - timer / dur) : 1);
  const respira = Math.sin(t * 2.2);
  const p = { sx: 1, sy: 1 + 0.03 * respira, ox: 0, oy: 0, marcha: 0, sentido: 1, vel: 11, ergue: 0, cravar: 0, abre: 0, tremor: 0,
    olho: 'normal', brilho: 0, rastro: 0, fio: 0, situacao: 'parada', agacha: 0 };
  const set = (sit, o) => { p.situacao = sit; Object.assign(p, o); };
  if (e === 'weaveTearWindup') { const k = prog(c.chargeWindup); set('tear_prep', { sx: 1 + 0.06 * k, sy: 1 - 0.14 * k, ox: -2 * k, agacha: 3 * k, ergue: 0.3 * k, brilho: k, olho: 'foco', tremor: k > 0.55 ? 1 : 0 }); }
  else if (e === 'weaveTear') set('tear', { sx: 1.1, sy: 0.82, ox: 2, agacha: 5, marcha: 1, vel: 26, rastro: 1, olho: 'foco', brilho: 0.6 });
  else if (e === 'weaveStitchWindup') { const k = suave(prog(c.stitchWindup)); set('costura_prep', { sy: 1 + 0.04 * k, ox: -2 * k, ergue: k, brilho: k, olho: 'foco', tremor: k > 0.8 ? 1 : 0 }); }
  else if (e === 'weaveStitch') { const k = prog(c.stitchDuration); set('costura', { sx: 1.04, sy: 0.9, ox: 1, agacha: 2, cravar: 1, brilho: 0.9, olho: 'foco', tremor: k < 0.25 ? 1 : 0 }); }
  else if (e === 'weaveReturnWindup') { const k = prog(c.returnWindup); set('retorno_prep', { sx: 1 + 0.04 * k, sy: 1 - 0.1 * k, ox: -2 * k, agacha: 2 * k, ergue: 0.5 * k, fio: k, brilho: 0.5 + 0.4 * k, olho: 'foco' }); }
  else if (e === 'weaveReturnOut') set('retorno_ida', { sx: 1.08, sy: 0.86, ox: 2, agacha: 4, marcha: 1, vel: 24, rastro: 1, fio: 1, olho: 'foco', brilho: 0.7 });
  else if (e === 'weaveReturnHook') set('retorno_gancho', { sx: 1.04, sy: 0.94, agacha: 1, ergue: 1, fio: 1, brilho: 1, olho: 'foco', tremor: 1 });
  else if (e === 'weaveReturnBack') set('retorno_volta', { sx: 1.06, sy: 0.88, ox: -1, agacha: 4, marcha: 1, sentido: -1, vel: 24, fio: 0.6, olho: 'foco', brilho: 0.6 });
  else if (e === 'weavePulseWindup') { const k = suave(prog(c.pulseWindup)); set('pulso_prep', { sx: 1 + 0.03 * k, sy: 1 + 0.1 * k, abre: k, brilho: k, olho: 'foco', tremor: k > 0.6 ? 1 : 0 }); }
  else if (e === 'weavePulse') set('pulso', { sx: 1.1, sy: 0.86, agacha: 3, abre: 1, brilho: 0.7 + 0.3 * Math.sin(t * 40), olho: 'foco', tremor: 1 });
  else if (e === 'recovery') set('recuperando', { sy: 0.9 + 0.03 * Math.sin(t * 1.4), agacha: 2, olho: 'cansado', brilho: 0 });
  else if (Math.abs(enemy.vx || 0) > 8) set('andando', { marcha: 0.6, vel: 9 + Math.min(10, Math.abs(enemy.vx) / 6) });
  if ((enemy.hurtTimer || 0) > 0) Object.assign(p, { olho: 'dor', tremor: 1, ergue: 0, cravar: 0 });
  return p;
}

// Patas em repouso (x para a frente = +, y negativo = para cima, chão = 0): raiz → joelho → pé, largura raiz/joelho.
const PERNAS = [
  { lado: -1, r: [-12, -17], k: [-27, -25], f: [-31, 0], w: 7 }, { lado: -1, r: [-8, -14], k: [-21, -20], f: [-24, 0], w: 6 }, { lado: -1, r: [-4, -13], k: [-14, -15], f: [-15, 0], w: 6 },
  { lado: 1, r: [8, -17], k: [25, -26], f: [31, -1], w: 7 }, { lado: 1, r: [6, -14], k: [20, -20], f: [25, 0], w: 6 }, { lado: 1, r: [3, -13], k: [13, -15], f: [17, 0], w: 6 },
  { lado: 2, r: [9, -10], k: [17, -9], f: [15, 0], w: 5 }, { lado: 2, r: [1, -10], k: [7, -9], f: [4, 0], w: 5 },
];

function desenhar(ctx, ax, base, d, t, pose, { hurt = false, alerta = false, alpha = 1, colapso = null, surge = null } = {}) {
  let ops = [];
  const R = (x, y, w, h, cor) => { ops.push([d > 0 ? ax + Math.round(x) : ax - Math.round(x) - w, base + Math.round(y), w, h, cor]); };
  const flush = (contorno = true) => {   // contorno preto de 1 px ao redor do conjunto (como o Limo), depois as cores
    if (contorno) { ctx.fillStyle = C.contorno; for (const o of ops) ctx.fillRect(o[0] - 1, o[1] - 1, o[2] + 2, o[3] + 2); }
    for (const o of ops) { ctx.fillStyle = o[4]; ctx.fillRect(o[0], o[1], o[2], o[3]); }
    ops = [];
  };
  const seg = (x0, y0, x1, y1, w0, w1, cor) => {   // segmento grosso e afilado
    const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1);
    for (let i = 0; i <= n; i++) { const k = i / n; const w = Math.max(1, Math.round(lerp(w0, w1, k))); R(lerp(x0, x1, k) - w / 2, lerp(y0, y1, k) - w / 2, w, w, cor); }
  };
  const F = (cor) => (hurt ? C.flash : cor);
  ctx.save(); ctx.globalAlpha = alpha;
  ctx.fillStyle = 'rgba(0,0,0,0.5)'; const sw = 38 + Math.round(10 * pose.abre); ctx.fillRect(ax - Math.floor(sw / 2), base, sw, 2);   // sombra no chão

  const kSurge = surge ? clamp01(surge.k) : 1; const eSurge = suave(clamp01(kSurge * 1.15));
  const sx = pose.sx * (surge ? lerp(0.78, 1, eSurge) : 1); const sy = pose.sy * (surge ? lerp(0.8, 1, eSurge) : 1); const ox = pose.ox; const baixo = (colapso ? colapso.baixo : 0) + pose.agacha + (surge ? lerp(11, 0, eSurge) : 0);
  const rxA = 15 * sx; const ryA = 11 * sy; const cx = Math.round(-3 + ox * 0.8); const cy = Math.round(-12 - ryA + baixo);
  const hx = Math.round(14 + ox + (colapso ? colapso.cabeca : 0)); const hy = Math.round(-11 + baixo * 1.05);
  const ph = t * pose.vel * pose.sentido; const bri = pose.brilho > 0.6 || alerta;

  // ---------- patas ----------
  const calcPerna = (i, pe) => {
    const lado = pe.lado; let [rx, ry] = pe.r; let [kx, ky] = pe.k; let [fx, fy] = pe.f;
    ry += baixo * 0.6; rx += ox * 0.4; const ab = pose.abre * 0.45;
    fx += (fx > rx ? 1 : -1) * Math.abs(fx - rx) * ab * 0.5; kx += (kx > rx ? 1 : -1) * Math.abs(kx - rx) * ab * 0.4; ky -= 2 * pose.abre;
    if (colapso) {   // desaba: joelho desce ao chão e o pé desliza para fora
      const e = colapso.dobra; ky = lerp(ky, -5, e); fy = lerp(fy, 0, e); fx = rx + (fx - rx) * lerp(1, 1.15, e); kx = lerp(kx, (kx + fx) / 2, e);
    } else if (pose.marcha) {
      const f = ph + i * Math.PI / 2 + (lado < 0 ? Math.PI : 0); fx += Math.round(Math.cos(f) * 3 * pose.marcha); fy -= Math.round(Math.max(0, Math.sin(f)) * 4 * pose.marcha); ky -= Math.round(Math.max(0, Math.sin(f)) * 2 * pose.marcha);
      if (pose.rastro) { fx -= 3; kx -= 2; }   // patas arrastam para trás na investida
    } else {
      fx += Math.round(Math.sin(t * 1.3 + i * 1.7) * 0.8); if (Math.sin(t * 1.6 + i * 2.1) > 0.88) fy -= 1;
    }
    if (i === 3) {   // pata da frente: ergue como foice, estica o gancho ou crava o ferrão
      if (pose.ergue > 0) { const k = pose.ergue; const gancho = pose.fio > 0.9; fx = lerp(fx, rx + (gancho ? 26 : 8), k); fy = lerp(fy, gancho ? -17 : -39, k); kx = lerp(kx, rx + (gancho ? 14 : 15), k); ky = lerp(ky, gancho ? -22 : -30, k); }
      if (pose.cravar) { fx = rx + 31; fy = 0; kx = rx + 17; ky = -30; }
    }
    if (i === 4 && pose.cravar) { fx = rx + 25; fy = 0; kx = rx + 15; ky = -25; }
    if (surge && kSurge < 1) {   // saindo do casulo: patas dobradas contra o corpo, desdobram e pousam em sequencia
      const u = suave(clamp01((kSurge * 1.3 - 0.08 - i * 0.075) / 0.5)); const sg = lado < 0 ? -1 : 1;
      const k0x = rx + sg * 4; const k0y = ry - 7; const f0x = rx + sg * 2; const f0y = ry - 3;
      const arco = Math.sin(u * Math.PI) * 9;   // a pata ergue em arco antes de cravar no chao
      kx = lerp(k0x, kx, u); ky = lerp(k0y, ky, u) - arco * 0.6; fx = lerp(f0x, fx, u); fy = lerp(f0y, fy, u) - arco;
    }
    return { rx, ry, kx, ky, fx, fy };
  };
  const desenharPerna = (i, pe, longe) => {
    const g = calcPerna(i, pe); const coxa = F(longe ? C.coxaLonge : C.coxa); const tibia = F(longe ? C.tibiaLonge : C.tibia);
    seg(g.rx, g.ry, g.kx, g.ky, pe.w, pe.w - 1, hurt ? '#e2aab4' : coxa);
    seg(g.kx, g.ky, g.fx, g.fy, pe.w - 1, 1, hurt ? '#e2aab4' : tibia);
    if (!hurt && !longe) { seg(g.rx, g.ry - pe.w / 2 + 1, g.kx, g.ky - pe.w / 2 + 1, 1, 1, C.coxaLuz); seg(g.kx - 1, g.ky + 1, g.fx - 1, g.fy - 1, 1, 1, C.tibiaLuz); }
    if (pe.lado !== 2 || true) R(g.fx - 1, g.fy - 1, 2, 2, F(longe ? C.tibiaLonge : C.tibiaLuz));
    flush();
  };
  for (let i = 0; i < 3; i++) desenharPerna(i, PERNAS[i], true);            // lado de trás (mais escuro)
  for (let i = 3; i < 6; i++) desenharPerna(i, PERNAS[i], false);

  // ---------- abdômen: massa de carne viva atravessada por raízes ----------
  const elipse = (x, y, a, b, cor) => { for (let dy = -Math.ceil(b); dy <= Math.ceil(b); dy++) { const f = 1 - (dy / b) * (dy / b); if (f <= 0) continue; const hw = Math.max(1, Math.round(a * Math.sqrt(f))); R(x - hw, y + dy, hw * 2, 1, cor); } };
  const curva = (x0, y0, qx, qy, x1, y1, w0, w1, cor) => {   // raiz curva e afilada (bezier quadratica)
    const n = 14; let px = x0; let py = y0;
    for (let i = 1; i <= n; i++) { const k = i / n; const x = (1 - k) * (1 - k) * x0 + 2 * (1 - k) * k * qx + k * k * x1; const y = (1 - k) * (1 - k) * y0 + 2 * (1 - k) * k * qy + k * k * y1; seg(px, py, x, y, lerp(w0, w1, (i - 1) / n), lerp(w0, w1, k), cor); px = x; py = y; }
  };
  const bal2 = Math.sin(t * 1.6); const pulsa = bri || pose.tremor ? 1 : 0;
  const luz = hurt ? C.flash : bri ? C.brilho : C.raizLuz;
  // silhueta irregular: massa principal + lóbulos de carne (traseira estufada, ventre caído, caroços no dorso)
  const lobos = [[0, 0, rxA, ryA], [-rxA * 0.55, ryA * 0.28, rxA * 0.5, ryA * 0.8], [-3, ryA * 0.78, rxA * 0.62, 4], [rxA * 0.35, -ryA * 0.8, rxA * 0.38, 4], [-rxA * 0.2, -ryA * 0.85, rxA * 0.3, 3]];
  for (const [dx, dy, a, b] of lobos) elipse(cx + dx, cy + dy, a, b, F(C.carneEsc));
  for (const [dx, dy, a, b] of lobos) elipse(cx + dx, cy + dy - 1, Math.max(1, a - 2), Math.max(1, b - 2), F(C.carne));
  elipse(cx - 3, cy - 3, rxA * 0.55, ryA * 0.45, F(C.carneLuz)); elipse(cx - 6, cy - 5, rxA * 0.25, ryA * 0.2, F(C.carneBrilho));   // carne úmida refletindo luz
  elipse(cx + 4, cy + ryA * 0.5, rxA * 0.7, ryA * 0.32, F(C.carneEsc));                                                               // ventre fundo
  flush();
  // veias e fibras musculares
  const veia = (pts, cor) => { for (let i = 1; i < pts.length; i++) seg(cx + pts[i - 1][0], cy + pts[i - 1][1], cx + pts[i][0], cy + pts[i][1], 1, 1, cor); };
  const vc = hurt ? '#e2aab4' : pulsa ? C.ferida : C.veia;
  veia([[-rxA + 3, -2], [-9, -1], [-6, 2], [-3, 1]], vc); veia([[-6, -6], [-3, -3], [0, -4], [3, -2]], vc); veia([[2, ryA - 4], [4, 3], [8, 2]], vc); veia([[-9, 4], [-6, 6], [-4, 8]], vc);
  R(cx + 5, cy - ryA + 4, 4, 3, F(C.gordura)); R(cx + 6, cy - ryA + 5, 2, 1, F(C.ferida)); R(cx - 10, cy + ryA - 5, 3, 2, F(C.gordura)); R(cx - 9, cy + ryA - 5, 1, 1, F(C.ferida));   // carne exposta
  flush(false);
  // raízes grossas que atravessam e prendem o corpo (contorno próprio = entram e saem da carne)
  const rz = (x0, y0, qx, qy, x1, y1, w0, w1) => curva(cx + x0, cy + y0, cx + qx, cy + qy, cx + x1, cy + y1, w0, w1, F(C.raiz));
  rz(-rxA + 2, 5, -4, -ryA - 3, rxA - 4, 2, 2, 2); rz(-7, -ryA + 3, 3, 0, rxA - 6, ryA - 4, 2, 1); rz(-rxA + 2, 0, -7, 4, -2, 7, 2, 1);
  flush();
  if (!hurt) { curva(cx - rxA + 1, cy + 3, cx - 2, cy - ryA - 7, cx + rxA - 3, cy + 2, 1, 1, luz); curva(cx - 8, cy - ryA + 2, cx + 1, cy - 2, cx + rxA - 5, cy + ryA - 4, 1, 1, luz); flush(false); }
  // traseira: raízes arrastando atrás do corpo, espinhos e tripas de carne penduradas
  const bx0 = cx - rxA; const ch = Math.round(baixo * 0.3);
  const cauda = (x0, y0, qx, qy, x1, y1, w) => { curva(x0, y0, qx, qy, x1, y1, w, 1, F(C.raiz)); R(x1 - 2, y1, 3, 1, F(C.raizEsc)); };
  cauda(bx0 + 3, cy + ryA - 4, bx0 - 7 + bal2 * 2, cy + ryA + 1, bx0 - 9 + bal2 * 3, -2 + ch, 2);
  cauda(bx0 + 1, cy + 3, bx0 - 10, cy + 3 + bal2, bx0 - 12 + bal2 * 2, cy + ryA - 3, 2);
  cauda(bx0 + 5, cy + ryA - 1, bx0 - 2, cy + ryA + 5, bx0 - 3 + bal2 * 2, -1 + ch, 2);
  seg(bx0 + 4, cy - 5, bx0 - 2, cy - 9, 2, 1, F(C.raizEsc));
  flush();
  const tripa = (x0, y0, dx) => { seg(x0, y0, x0 + dx + bal2, y0 + 6, 1, 1, F(C.tripa)); R(x0 + dx + bal2 - 1, y0 + 6, 2, 2, F(C.tripaPonta)); };
  tripa(cx - 4, cy + ryA - 2, -1); tripa(cx + 2, cy + ryA - 1, 1); flush();
  if (!hurt) { R(cx - rxA + 2, cy - 2, 3, 3, C.musgo); R(cx - rxA + 3, cy - 3, 2, 1, C.musgoLuz); R(cx - rxA + 2, cy + 2, 2, 2, C.musgo); }   // musgo atrás
  flush();

  // ---------- cogumelos e gravetos no dorso ----------
  const bal = Math.round(Math.sin(t * 1.8));
  const cogu = (mx, topo, larg) => { R(mx + bal * 0.5, topo + 2, 2, 5, F(C.haste)); R(mx - larg / 2 + 1 + bal, topo, larg, 3, F(C.cogu)); R(mx - larg / 2 + 1 + bal, topo + 2, larg, 1, F(C.coguEsc)); R(mx - larg / 2 + 2 + bal, topo - 1, Math.max(2, larg - 2), 1, F(C.cogu)); flush(); };
  const topoA = cy - Math.round(ryA);
  seg(cx - 11, topoA + 3, cx - 10, topoA - 3, 1, 1, F(C.raizEsc)); seg(cx - 10, topoA - 3, cx - 12, topoA - 5, 1, 1, F(C.raizEsc)); flush(false);
  cogu(cx - 6, topoA - 5, 4); cogu(cx + 1, topoA - 6, 4); cogu(cx + 9, topoA - 1, 6);

  // ---------- rosto bege: olhos rosados, chifres e presas ----------
  for (let i = 6; i < 8; i++) desenharPerna(i, PERNAS[i], false);               // pernas curtas da frente (atrás do rosto)
  const face = (x, y, a, b, cor) => elipse(x, y, a, b, cor);
  face(hx, hy, 9, 7 * sy, F(C.rostoEsc)); face(hx, hy - 1, 8, 6 * sy, F(C.rosto)); face(hx + 1, hy + 3, 6, 2, F(C.rostoEsc));
  seg(hx - 4, hy - 6, hx - 5, hy - 11, 2, 1, F(C.raiz)); seg(hx + 4, hy - 6, hx + 6, hy - 11, 2, 1, F(C.raiz));   // chifres
  if (!hurt) { R(hx - 7, hy - 7, 3, 2, C.musgo); R(hx - 6, hy - 8, 2, 1, C.musgoLuz); }
  flush();
  const piscar = Math.floor(t * 0.9) % 4 === 0 && (t * 0.9) % 1 < 0.1;
  const olhos = [[hx - 6, hy - 3], [hx - 1, hy - 4], [hx + 4, hy - 3], [hx - 3, hy + 1], [hx + 2, hy + 1]];
  for (const [ex, ey] of olhos) {   // olhos rosados em soquetes escuros (3 em cima, 2 embaixo), espaçados para não virar xadrez
    if (colapso || pose.olho === 'dor') { R(ex, ey, 1, 1, C.iris); R(ex + 1, ey + 1, 1, 1, C.iris); flush(); continue; }
    if (piscar || pose.olho === 'cansado') { R(ex, ey + 1, 3, 1, C.contorno); flush(false); continue; }
    R(ex, ey, 3, pose.olho === 'foco' ? 2 : 3, F(bri ? '#ffb02a' : C.iris)); R(ex, ey, 1, 1, F(C.olho)); flush();
  }
  seg(hx - 6, hy + 3, hx - 6, hy + 6, 2, 1, F(C.presa)); seg(hx + 6, hy + 3, hx + 6, hy + 6, 2, 1, F(C.presa)); flush();   // quelíceras curtas
  // ---------- fio esticado (Investida de Retorno) e rastro de velocidade ----------
  if (pose.fio > 0) { const len = Math.round(14 * pose.fio); R(hx + 9, hy + 3, len, 1, F(C.fio)); R(hx + 9 + len, hy, 1, 7, C.contorno); if (pose.fio > 0.9) R(hx + 9 + len, hy + 2, 1, 3, C.brilho); flush(false); }
  if (pose.rastro) { ctx.globalAlpha = alpha * 0.6; for (let i = 0; i < 3; i++) R(-34 - i * 3 + Math.round(ox), -24 + i * 6, 8 - i, 1, C.fio); flush(false); ctx.globalAlpha = alpha; }
  ctx.restore();
}

/** Desenha a Tecelã. (rx, ry) = canto da hitbox na tela; w/h = tamanho da hitbox; os pés pousam na base dela. */
export function drawTecelaProcedural(ctx, enemy, rx, ry, t, dir = 1) {
  const w = enemy.body.w; const h = enemy.body.h; const pose = tecelaPose(enemy, t); const hurt = (enemy.hurtTimer || 0) > 0;
  const telegrafando = /Windup$/.test(enemy.attackState || ''); const alerta = telegrafando && Math.floor((enemy.attackTimer || 0) * 16) % 2 === 0;
  desenhar(ctx, Math.round(rx + w / 2) + (pose.tremor ? (Math.floor(t * 50) % 2 ? 1 : -1) : 0), Math.round(ry + h), dir, t, pose, { hurt, alerta });
}

/** Corpo desabando (derrota): corpo afunda, patas deslizam para fora, olhos em X; depois some. fx = {t, dir, body}. */
export function drawTecelaColapsoProcedural(ctx, fx, camX, camY) {
  const c = tecelaColapso(fx.t); const k = clamp01(fx.t / 0.9); const e = suave(k);
  const pose = { sx: 1 + 0.12 * e, sy: 1 - 0.4 * e, ox: -2 * e, oy: 0, marcha: 0, sentido: 1, vel: 11, ergue: 0, cravar: 0, abre: 0.3 * e, tremor: 0, olho: 'dor', brilho: 0, rastro: 0, fio: 0, agacha: 0 };
  const ax = Math.round(fx.body.x + fx.body.w / 2 - camX) + (fx.t < 0.5 ? (Math.floor(fx.t * 50) % 2 ? 1 : -1) : 0); const base = Math.round(fx.body.y + fx.body.h - camY);
  desenhar(ctx, ax, base, fx.dir || 1, fx.t, pose, { alpha: c.alpha, colapso: { baixo: 4 * e, dobra: e, cabeca: -2 * e } });
}

// =====================================================================
// MUDA ARACNÍDEA (Salto na Parede) — seguindo a arte oficial: raízes enroladas numa gema verde sobre carne carmesim,
// cogumelos creme, musgo e contorno preto por peça (como o Limo). Gema pulsa, raízes balançam, esporos sobem.
// =====================================================================
// =====================================================================
// MUDA ARACNÍDEA — arte própria do criador, copiada pixel a pixel (19x19, 11 cores; fundo transparente).
// Fonte: assets/sprites/muda_aracnidea_19x19.png (e o original em 4096 px). Só a posição flutua; nenhum pixel é alterado.
// =====================================================================
const MUDA_PAL = [null, "#483c2c", "#74423b", "#401821", "#5b212d", "#7d5d4a", "#220f13", "#000006", "#000000", "#92a374", "#2c0010"];
const MUDA_LINHAS = [
  '.......1.23........',
  '.......45567.......',
  '.......8523..9.....',
  '....61625311292....',
  '.....615343212.....',
  '...14354521224.5...',
  '..633423295344795..',
  '..651A4236554344...',
  '.655514411622A4366.',
  '.22A45A11996233554.',
  '4364222699915355643',
  '36.A432219915253..3',
  '.6.953125114424A.66',
  '.63993462464233....',
  '...622443232316....',
  '....34734354A31....',
  '.....33.A42A.6.....',
  '......6.346........',
  '........3..........',
];
const MUDA_CHARS = '.123456789ABCDEFG';
export function drawMudaAracnidea(ctx, cx, cy, t) {
  const bob = Math.round(Math.sin(t * 2) * 0.7);   // leve flutuação, como um item
  const x0 = Math.round(cx) - 9; const y0 = Math.round(cy) - 9 + bob;
  for (let j = 0; j < MUDA_LINHAS.length; j++) {
    const linha = MUDA_LINHAS[j];
    for (let i = 0; i < linha.length; i++) {
      const cor = MUDA_PAL[MUDA_CHARS.indexOf(linha[i])]; if (!cor) continue;   // '.' = transparente
      ctx.fillStyle = cor; ctx.fillRect(x0 + i, y0 + j, 1, 1);
    }
  }
}

// =====================================================================
// CASULO DA TECELÃ + ANIMAÇÃO DE SAÍDA (cutscene de introdução)
// Antes: casulo = ovo de carne preso ao chão por raízes (silhueta arredondada, translucidez mostrando a aranha dentro,
// tremor e rachadura crescendo). Depois: a membrana rasga de cima para baixo, as patas dobradas atravessam, desdobram e
// pousam uma a uma, o corpo se ergue, a casca murcha em trapos no chão e se desfaz enquanto ela fala.
// Só visual: lê enemy.introT (segundos desde o gatilho, definido em game.js). Não toca hitbox, IA nem estados.
// =====================================================================
export const INTRO_TEMPO = { pre: 1.4, surge: 2.0, sumirIni: 7.2, sumirFim: 9.6 };
const K = {   // paleta do casulo
  contorno: '#0a0307', sombra: '#4a1530', base: '#7a2c48', luz: '#b4546e', janela: '#cc7a8c', janelaLuz: '#eaa8b0', dentro: '#3a0e26', cavidade: '#1a0610', borda: '#e8a0aa',
  raiz: '#8a5a40', raizLuz: '#c08a60', raizEsc: '#4a2a26', gosma: '#e8b8bc', cogu: '#f0d6b8', coguEsc: '#caa282', haste: '#a07a5a', esporo: '#c8f08a',
};
const HC = 34; const WC = 13;   // altura e meia-largura do casulo em pixels

/** Meia-largura relativa (0..1) do ovo; q = 0 no topo e 1 na base (base achatada, apoiada no chão). */
function perfilCasulo(q) { const c = 0.6; const u = q < c ? (c - q) / c : (q - c) / (1 - c); const f = Math.sqrt(Math.max(0, 1 - u * u)); return q < c ? f : Math.max(0.64, f); }

function pincel(ctx, ax, base) {
  let ops = [];
  const R = (x, y, w, h, cor) => { ops.push([ax + Math.round(x), base + Math.round(y), w, h, cor]); };
  const flush = (contorno = true) => { if (contorno) { ctx.fillStyle = K.contorno; for (const o of ops) ctx.fillRect(o[0] - 1, o[1] - 1, o[2] + 2, o[3] + 2); } for (const o of ops) { ctx.fillStyle = o[4]; ctx.fillRect(o[0], o[1], o[2], o[3]); } ops = []; };
  const seg = (x0, y0, x1, y1, w0, w1, cor) => { const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1); for (let i = 0; i <= n; i++) { const k = i / n; const w = Math.max(1, Math.round(lerp(w0, w1, k))); R(lerp(x0, x1, k) - w / 2, lerp(y0, y1, k) - w / 2, w, w, cor); } };
  const curva = (x0, y0, qx, qy, x1, y1, w0, w1, cor) => { const n = 12; let px = x0; let py = y0; for (let i = 1; i <= n; i++) { const k = i / n; const x = (1 - k) * (1 - k) * x0 + 2 * (1 - k) * k * qx + k * k * x1; const y = (1 - k) * (1 - k) * y0 + 2 * (1 - k) * k * qy + k * k * y1; seg(px, py, x, y, lerp(w0, w1, (i - 1) / n), lerp(w0, w1, k), cor); px = x; py = y; } };
  const elipse = (x, y, a, b, cor) => { for (let dy = -Math.ceil(b); dy <= Math.ceil(b); dy++) { const f = 1 - (dy / b) * (dy / b); if (f <= 0) continue; const hw = Math.max(1, Math.round(a * Math.sqrt(f))); R(x - hw, y + dy, hw * 2, 1, cor); } };
  return { R, flush, seg, curva, elipse };
}

/** Raízes que prendem o casulo ao chão (ficam depois da saída, como cicatriz do ninho). */
function raizesDoChao(P, sway, abertura = 0) {
  const { curva, R } = P;
  for (const lado of [-1, 1]) {
    curva(lado * (WC - 3), -2, lado * (WC + 4), -1, lado * (WC + 11 + abertura * 3), -1, 3, 1, K.raiz);
    curva(lado * (WC - 5), -1, lado * (WC + 1), 1, lado * (WC + 7 + abertura * 2), 0, 2, 1, K.raizEsc);
    R(lado * (WC + 11 + abertura * 3) - (lado < 0 ? 1 : 0), -2, 2, 2, K.raizEsc);
  }
}

function cogumeloCasulo(P, x, y, larg, bal) { const { R } = P; R(x, y + 2, 2, 4, K.haste); R(x - larg / 2 + 1 + bal, y, larg, 3, K.cogu); R(x - larg / 2 + 1 + bal, y + 2, larg, 1, K.coguEsc); R(x - larg / 2 + 2 + bal, y - 1, Math.max(2, larg - 2), 1, K.cogu); }

/** Casulo inteiro (antes da ruptura). s = 0..1 é a tensão: tremor, brilho, rachadura e a aranha se mexendo por dentro. */
function casuloInteiro(ctx, ax, base, t, s, alpha) {
  ctx.save(); ctx.globalAlpha = alpha;
  const tremor = s > 0.45 ? (Math.floor(t * 46) % 2 ? 1 : -1) * (s > 0.8 ? 1 : 0.5) : 0; const axT = Math.round(ax + tremor);
  const sc = 1 + 0.05 * Math.sin(t * (3.5 + 6 * s)) * (0.35 + s);   // pulsa como se respirasse; acelera com a tensão
  let P = pincel(ctx, ax, base);
  // raízes no chão e poça escura
  ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(ax - 17, base, 35, 2); P.flush(false);
  raizesDoChao(P, 0, 0); P.flush();
  // corpo do ovo: contorno único, depois sombra, base e luz por fileira
  P = pincel(ctx, axT, base); const { R, flush, seg, curva, elipse } = P;
  const bump = s > 0.3 ? Math.max(0, Math.sin(t * 9 + 1)) * Math.min(1, (s - 0.3) * 2.2) : 0;   // pata empurrando a membrana
  const bump2 = s > 0.5 ? Math.max(0, Math.sin(t * 7.3 + 2.4)) * Math.min(1, (s - 0.5) * 2.2) : 0;
  const hwDe = (r) => Math.max(1, Math.round(WC * sc * perfilCasulo(r / (HC - 1)) + Math.sin(r * 0.75 + 1.3) * 0.7));
  for (let r = 0; r < HC; r++) {
    const y = -HC + r; const hw = hwDe(r);
    R(-hw, y, hw * 2, 1, K.sombra); R(-hw + 1, y, hw * 2 - 2, 1, K.base);
    if (r > 3 && r < HC - 5) { R(-hw + 2, y, 2, 1, K.luz); R(hw - 3, y, 2, 1, K.sombra); }
  }
  if (bump > 0.2) { const y = -HC + 17; R(-hwDe(17) - 1, y, 3, 4, K.luz); R(-hwDe(17) - 2, y + 1, 1, 2, K.sombra); }
  if (bump2 > 0.2) { const y = -HC + 22; R(hwDe(22) - 2, y, 3, 4, K.luz); R(hwDe(22) + 1, y + 1, 1, 2, K.sombra); }
  flush();
  // janela translúcida: silhueta da aranha encolhida e olhos acendendo
  elipse(-2, -HC + 17, 6, 9, K.janela); elipse(-3, -HC + 15, 3, 5, K.janelaLuz); flush(false);
  elipse(0, -HC + 19, 4, 4, K.dentro); seg(-4, -HC + 21, -7, -HC + 25, 1, 1, K.dentro); seg(4, -HC + 21, 7, -HC + 25, 1, 1, K.dentro); seg(-3, -HC + 16, -6, -HC + 13, 1, 1, K.dentro); seg(3, -HC + 16, 6, -HC + 13, 1, 1, K.dentro); flush(false);
  const brilho = clamp01((s - 0.35) / 0.5); const pisca = Math.sin(t * 13) > -0.3;
  if (brilho > 0 && pisca) { for (const [ex, ey] of [[-3, -HC + 18], [1, -HC + 17], [3, -HC + 19]]) { R(ex, ey, 2, 1, brilho > 0.6 ? '#ff7090' : '#c04060'); } flush(false); }
  // tiras de raiz envolvendo o ovo (curvas que seguem o volume, não linhas retas)
  for (const [q, bow] of [[0.38, 3], [0.7, 3]]) {
    const y = -HC + Math.round(q * HC); const hw = hwDe(Math.round(q * HC));
    curva(-hw, y, 0, y + bow * 2, hw, y, 2, 1, K.raiz);
  }
  curva(-hwDe(8) + 2, -HC + 8, -3, -HC + 22, hwDe(26) - 3, -5, 1, 1, K.raiz);
  flush();
  // costura central: rachadura que cresce de cima para baixo e vaza luz rosada
  const comp = Math.round(lerp(4, 24, s)); let xz = 0;
  for (let i = 0; i < comp; i++) { xz += (i % 3 === 0) ? ((i & 1) ? 1 : -1) : 0; R(xz, -HC + 2 + i, 1, 1, K.cavidade); if (s > 0.45 && i % 2 === 0) R(xz + 1, -HC + 2 + i, 1, 1, K.borda); }
  flush(false);
  if (s > 0.6) { ctx.globalAlpha = alpha * (s - 0.6) * 0.7; R(-1, -HC + 2, 3, comp, K.borda); flush(false); ctx.globalAlpha = alpha; }
  // haste de raízes no topo, sumindo no escuro
  curva(0, -HC + 1, 1, -HC - 4, Math.sin(t * 1.4) * 1.5, -HC - 8, 2, 1, K.raiz); flush();
  ctx.globalAlpha = alpha * 0.55; curva(0, -HC - 7, -3, -HC - 10, -5, -HC - 14, 1, 1, K.raizEsc); curva(1, -HC - 7, 4, -HC - 10, 5, -HC - 15, 1, 1, K.raizEsc); flush(false); ctx.globalAlpha = alpha;
  // cogumelos nascendo na base
  const bal = Math.round(Math.sin(t * 1.8)); cogumeloCasulo(P, WC - 2, -9, 5, bal); cogumeloCasulo(P, -WC - 1, -6, 4, bal); flush();
  // esporos subindo
  for (let i = 0; i < 4; i++) { const f = (t * 0.5 + i / 4) % 1; ctx.globalAlpha = alpha * (1 - f) * 0.9; ctx.fillStyle = K.esporo; ctx.fillRect(ax + Math.round(Math.sin(t * 0.9 + i * 2.3) * 12), base - 10 - Math.round(f * 26), 1, 1); }
  ctx.restore();
}

/** Partes da casca durante a saída. parte = 'fundo' (cavidade atrás da aranha) ou 'frente' (abas rasgadas na frente dela). */
function cascaRasgada(ctx, ax, base, t, p, alpha, parte) {
  ctx.save(); ctx.globalAlpha = alpha; const P = pincel(ctx, ax, base); const { R, flush, curva, seg } = P;
  const abre = suave(clamp01(p / 0.4)); const queda = suave(clamp01((p - 0.45) / 0.5)); const Hf = Math.round(lerp(HC, 9, queda)); const desloca = Math.round(suave(clamp01((p - 0.08) / 0.5)) * 5 + queda * 11);
  if (parte === 'fundo') {
    const Hb = Math.round(lerp(HC, 13, queda));
    for (let r = 0; r < Hb; r++) { const q = r / (Hb - 1); const hw = Math.max(1, Math.round(WC * perfilCasulo(q))); R(-hw, -Hb + r, hw * 2, 1, K.sombra); R(-hw + 2, -Hb + r, Math.max(1, hw * 2 - 4), 1, K.cavidade); }
    flush();
    raizesDoChao(P, 0, abre); flush();
  }
  if ((parte === 'frente') === (p < 0.6)) {
    const flap = (lado) => {
      for (let r = 0; r < Hf; r++) {
        const q = r / Math.max(1, Hf - 1); const y = -Hf + r; const lean = Math.round((1 - q) * abre * 7 * (1 - queda * 0.6));
        const fora = Math.round(WC * perfilCasulo(q) + Math.sin(r * 0.8 + lado) * 0.6); const dentro = Math.round(abre * WC * 0.82 * (1 - 0.5 * q)) + ((r % 3 === 0) ? 1 : 0);
        if (fora <= dentro) continue;
        const x0 = lado * (dentro + desloca + lean); const x1 = lado * (fora + desloca + lean); const xa = Math.min(x0, x1); const larg = Math.abs(x1 - x0);
        R(xa, y, larg, 1, K.sombra); if (larg > 2) R(lado < 0 ? xa + 1 : xa, y, larg - 1, 1, K.base);
        if (larg > 4 && q > 0.1) R(lado < 0 ? xa + 2 : xa + larg - 3, y, 2, 1, lado < 0 ? K.luz : K.sombra);
        R(lado < 0 ? xa + larg - 1 : xa, y, 1, 1, K.borda);   // borda interna rasgada e úmida
      }
    };
    flap(-1); flap(1); flush();
    // tiras de raiz arrebentadas nas abas
    if (abre < 1) { for (const lado of [-1, 1]) { const y = -Hf + Math.round(Hf * 0.5); curva(lado * (WC + desloca), y, lado * (WC + desloca - 4), y + 2, lado * (WC + desloca - Math.round(8 * abre) - 2), y + 3 + Math.round(abre * 3), 2, 1, K.raiz); } flush(); }
    // fios de gosma esticados entre as abas, afinando e arrebentando
    if (p < 0.7) { const f = clamp01(p / 0.7); ctx.globalAlpha = alpha * (1 - f * f) * 0.85; const sag = 2 + Math.round(f * 7); const aberto = Math.round(abre * WC * 0.7);
      for (const [y, a] of [[-HC + 11, 1], [-HC + 17, 0.8], [-HC + 23, 0.6]]) { if (aberto < 3) continue; curva(-aberto, y, 0, y + sag * a, aberto, y, 1, 1, K.gosma); }
      flush(false); ctx.globalAlpha = alpha; }
    // gotas escorrendo das bordas
    for (let i = 0; i < 4; i++) { const f = (t * 0.9 + i * 0.27) % 1; if (p > 0.1 && p < 0.95) { ctx.globalAlpha = alpha * (1 - f); ctx.fillStyle = K.gosma; ctx.fillRect(ax + (i < 2 ? -1 : 1) * (WC - 3 + i) , base - HC + 12 + Math.round(f * 20) + i * 2, 1, 2); } }
  }
  ctx.restore();
}

function desenharIntroCompleta(ctx, ax, base, d, t, T, enemy) {
  const s = clamp01(T / INTRO_TEMPO.pre); const p = clamp01((T - INTRO_TEMPO.pre) / INTRO_TEMPO.surge);
  const sumir = 1 - clamp01((T - INTRO_TEMPO.sumirIni) / (INTRO_TEMPO.sumirFim - INTRO_TEMPO.sumirIni));
  if (p <= 0) { casuloInteiro(ctx, ax, base, t, s, 1); return; }
  ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(ax - 17, base, 35, 2);
  if (sumir > 0) cascaRasgada(ctx, ax, base, t, p, sumir, 'fundo');
  // clarão rosado vazando pela fenda no início
  if (p < 0.5 && sumir > 0) { ctx.save(); ctx.globalAlpha = 0.5 * (1 - p / 0.5); ctx.fillStyle = K.borda; ctx.fillRect(ax - 2 - Math.round(p * 8), base - HC + 3, 4 + Math.round(p * 16), Math.round(HC * 0.7)); ctx.restore(); }
  // a aranha: patas dobradas atravessando a casca e desdobrando uma a uma
  const pose = tecelaPose({ attackState: '', hurtTimer: 0 }, t); if (p < 0.75) pose.olho = 'foco';
  ctx.save();
  if (p < 1) { const meia = WC + 2 + Math.round(suave(clamp01(p / 0.55)) * 46); ctx.beginPath(); ctx.rect(ax - meia, base - 80, meia * 2, 90); ctx.clip(); }
  desenhar(ctx, ax, base, d, t, pose, { surge: p < 1 ? { k: p } : null });
  ctx.restore();
  if (sumir > 0) cascaRasgada(ctx, ax, base, t, p, sumir, 'frente');
  // poeira e esporos quando as patas pousam e o corpo cai no lugar
  if (p > 0.4 && p < 0.98) {
    const f = clamp01((p - 0.4) / 0.58); ctx.save();
    for (let i = 0; i < 8; i++) { const lado = i % 2 ? 1 : -1; const dist = 14 + (i >> 1) * 7 + f * 12; const alt = Math.round(Math.sin(f * Math.PI) * (3 + (i >> 1))); ctx.globalAlpha = (1 - f) * 0.7; ctx.fillStyle = i % 3 === 0 ? K.esporo : '#8a6a6a'; ctx.fillRect(ax + lado * Math.round(dist), base - 2 - alt, 2, 2); }
    ctx.restore();
  }
}

/** Desenha o casulo e a saída da Tecelã. (rx, ry) = canto da hitbox na tela; os pés pousam na base dela. */
export function drawTecelaIntro(ctx, enemy, rx, ry, t, dir = 1) {
  const w = enemy.body.w; const h = enemy.body.h;
  desenharIntroCompleta(ctx, Math.round(rx + w / 2), Math.round(ry + h), dir, t, Math.max(0, enemy.introT || 0), enemy);
}
