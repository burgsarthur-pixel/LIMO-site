// =====================================================================
// PASTOR DAS VÍSCERAS — forma base (Etapa 2.3, revisão 2: humanoide com cabeça de cervo). Sem forma monstruosa.
// Corpo bípede sob um manto de guardião (cor principal #9be36b); cabeça de cervo com galhada; cajado na mão da direção.
// Desenho procedural em retângulos, no mesmo estilo do chefe. A caixa de colisão é a do chefe (26 × 20): a galhada
// sobe um pouco acima dela, por isso o desenho começa em ry - 4.
// Cada golpe muda a postura (a mecânica é de combate.js):
//   CHAMADO    (aviso): os braços se abrem e o manto mostra luz por dentro.
//   CAVALGADA  (aviso): o corpo se agacha e o cajado recua; (ativo): o corpo avança e o manto fica para trás.
//   PISADA     (aviso): o cajado sobe sobre a cabeça; (ativo): o cajado desce e a ponta acende no chão.
// Só usa a paleta aprovada. Sem alocação por quadro.
// =====================================================================
export const PALETA_PASTOR = Object.freeze({
  manto: '#9be36b',     // principal
  fibra: '#2f5a4a',
  veia: '#30a078',
  nucleo: '#14291f',
  luz: '#b6e8c8',
  contorno: '#0b1a16',
});
const C = PALETA_PASTOR;

/**
 * Desenha o Pastor com o canto superior esquerdo da caixa de colisão em (rx, ry). A barra de vida e o nome ficam com o renderer.
 * `t`: tempo em segundos (pulso lento do núcleo e das veias).
 */
export function drawPastor(ctx, enemy, rx, ry, t = 0) {
  const w = enemy.body.w; const estado = enemy.attackState || '';
  const golpe = enemy.padraoAtual?.id || enemy.attackKind || '';
  const aviso = estado === 'padraoWindup'; const ativo = estado === 'padraoAtivo';
  const dir = (enemy.attackDir || enemy.facing || 1) >= 0 ? 1 : -1;
  const ferida = enemy.hurtTimer > 0;
  const pulso = 0.5 + 0.5 * Math.sin(t * 3);
  const manto = ferida ? '#ffffff' : C.manto;
  const cx = rx + Math.floor(w / 2);                    // eixo do corpo
  const agachado = aviso && golpe === 'cavalgada' ? 2 : 0;
  const inclina = ativo && golpe === 'cavalgada' ? dir * 2 : 0;   // o corpo avança no ativo da cavalgada
  const y0 = ry - 4 + agachado;                         // topo do desenho (a galhada fica acima da caixa)
  const ox = cx + inclina;                              // eixo do tronco (desloca no avanço)

  // ---- galhada e cabeça de cervo ----
  ctx.fillStyle = C.fibra;                               // galhada ramificada, larga na base
  ctx.fillRect(ox - 4, y0 + 1, 2, 4); ctx.fillRect(ox - 7, y0, 4, 1); ctx.fillRect(ox - 7, y0 - 2, 1, 3); ctx.fillRect(ox - 5, y0 - 3, 1, 2);
  ctx.fillRect(ox + 2, y0 + 1, 2, 4); ctx.fillRect(ox + 3, y0, 4, 1); ctx.fillRect(ox + 6, y0 - 2, 1, 3); ctx.fillRect(ox + 4, y0 - 3, 1, 2);
  ctx.fillStyle = manto; ctx.fillRect(ox - 7, y0 - 3, 1, 1); ctx.fillRect(ox + 6, y0 - 3, 1, 1); ctx.fillRect(ox - 5, y0 - 4, 1, 1); ctx.fillRect(ox + 4, y0 - 4, 1, 1);
  // crânio e focinho projetado para a direção do movimento
  ctx.fillStyle = C.contorno; ctx.fillRect(ox - 3, y0 + 4, 6, 4);
  ctx.fillStyle = manto; ctx.fillRect(ox - 2, y0 + 4, 4, 3);
  const mx = dir > 0 ? ox + 2 : ox - 6;                  // focinho: 4 px à frente, mais estreito na ponta
  ctx.fillStyle = C.contorno; ctx.fillRect(mx - 1, y0 + 5, 5, 3);
  ctx.fillStyle = manto; ctx.fillRect(mx, y0 + 5, 4, 2);
  ctx.fillStyle = C.fibra; ctx.fillRect(dir > 0 ? mx + 4 : mx - 1, y0 + 6, 1, 1);                // ponta do focinho
  ctx.fillStyle = C.fibra; ctx.fillRect(ox - 5, y0 + 4, 2, 1); ctx.fillRect(ox + 3, y0 + 4, 2, 1);   // orelhas laterais
  ctx.fillStyle = C.luz; ctx.globalAlpha = 0.5; ctx.fillRect(ox - 2, y0 + 5, 1, 1); ctx.fillRect(ox, y0 + 5, 1, 1); ctx.globalAlpha = 1;   // pontos sensíveis
  ctx.fillStyle = C.fibra; ctx.fillRect(ox - 1, y0 + 7, 3, 1);                                  // pescoço

  // ---- tronco e manto: afunila para baixo (guardião) ----
  const topoM = y0 + 8;
  ctx.fillStyle = C.contorno; ctx.fillRect(ox - 5, topoM - 1, 11, 4); ctx.fillRect(ox - 7, topoM + 3, 15, 4); ctx.fillRect(ox - 9, topoM + 7, 19, 4);
  ctx.fillStyle = manto; ctx.fillRect(ox - 4, topoM, 9, 3); ctx.fillRect(ox - 6, topoM + 3, 13, 4); ctx.fillRect(ox - 8, topoM + 7, 17, 4);
  if (aviso && golpe === 'chamado') {                    // CHAMADO: o manto se abre e mostra luz por dentro
    ctx.fillStyle = C.contorno; ctx.fillRect(ox - 9, topoM + 2, 2, 6); ctx.fillRect(ox + 8, topoM + 2, 2, 6);
    ctx.fillStyle = manto; ctx.fillRect(ox - 10, topoM + 3, 2, 4); ctx.fillRect(ox + 9, topoM + 3, 2, 4);
    ctx.fillStyle = C.luz; ctx.fillRect(ox - 3, topoM + 3, 6, 2);
  }
  ctx.fillStyle = C.fibra; ctx.fillRect(ox - 2, topoM + 8, 1, 3); ctx.fillRect(ox + 1, topoM + 8, 1, 3); ctx.fillRect(ox + 4, topoM + 8, 1, 3);   // franjas do manto
  ctx.fillStyle = C.veia; ctx.globalAlpha = 0.45 + 0.4 * pulso; ctx.fillRect(ox - 4, topoM + 1, 1, 3); ctx.fillRect(ox + 3, topoM + 2, 1, 3); ctx.globalAlpha = 1;
  ctx.fillStyle = C.nucleo; ctx.fillRect(ox - 2, topoM + 2, 4, 3);                              // núcleo no peito
  ctx.fillStyle = C.luz; ctx.globalAlpha = 0.5 + 0.5 * pulso; ctx.fillRect(ox - 1, topoM + 3, 2, 1); ctx.globalAlpha = 1;

  // ---- pernas (duas raízes-pernas, com pés escuros) ----
  const pernaH = agachado ? 2 : 4;
  const pernasY = topoM + 11;
  ctx.fillStyle = C.fibra; ctx.fillRect(ox - 5, pernasY, 2, pernaH); ctx.fillRect(ox + 2, pernasY, 2, pernaH);
  ctx.fillStyle = C.nucleo; ctx.fillRect(ox - 6, pernasY + pernaH, 3, 1); ctx.fillRect(ox + 2, pernasY + pernaH, 3, 1);

  // ---- braços e cajado ----
  ctx.fillStyle = C.fibra;
  if (aviso && golpe === 'chamado') {                    // braços abertos, mãos para fora
    ctx.fillRect(ox - 8, topoM + 2, 3, 2); ctx.fillRect(ox - 11, topoM + 4, 3, 2);
    ctx.fillRect(ox + 6, topoM + 2, 3, 2); ctx.fillRect(ox + 10, topoM + 4, 3, 2);
    ctx.fillStyle = manto; ctx.fillRect(ox - 13, topoM + 4, 2, 2); ctx.fillRect(ox + 12, topoM + 4, 2, 2);
  } else if (aviso && golpe === 'pisada') {              // mão direita sobe com o cajado
    ctx.fillRect(ox - 7, topoM + 2, 2, 5); ctx.fillRect(ox + 5, topoM + 2, 2, 3); ctx.fillRect(ox + dir * 6, topoM - 2, 2, 4);
  } else {                                               // braços ao lado do corpo
    ctx.fillRect(ox - 7, topoM + 2, 2, 5); ctx.fillRect(ox - 8, topoM + 6, 2, 3);
    ctx.fillRect(ox + 5, topoM + 2, 2, 5); ctx.fillRect(ox + 6, topoM + 6, 2, 3);
  }
  // cajado: sai da mão do lado da direção; muda de posição em cada golpe
  let sx; let sy; let sw; let sh; let nx; let ny; let brilho = 0.35 + 0.3 * pulso;
  if (aviso && golpe === 'pisada') { sx = ox + dir * 6; sy = topoM - 8; sw = 2; sh = 14; nx = sx - 1; ny = sy - 2; }   // vertical sobre a cabeça
  else if (ativo && golpe === 'pisada') { sx = ox + dir * 6; sy = topoM + 6; sw = 2; sh = 11; nx = sx - 1; ny = sy + sh - 2; brilho = 1; }   // desce até o chão
  else if (aviso && golpe === 'cavalgada') { sx = dir > 0 ? ox - 13 : ox + 9; sy = topoM + 5; sw = 6; sh = 2; nx = dir > 0 ? sx - 1 : sx + sw - 2; ny = sy - 1; }   // recua
  else { sx = dir > 0 ? ox + 6 : ox - 12; sy = topoM + 6; sw = 6; sh = 2; nx = dir > 0 ? sx + sw - 2 : sx - 1; ny = sy - 1; }   // ao lado
  ctx.fillStyle = C.fibra; ctx.fillRect(sx, sy, sw, sh);
  ctx.fillStyle = manto; ctx.fillRect(nx, ny, 3, 3);
  ctx.fillStyle = C.luz; ctx.globalAlpha = brilho; ctx.fillRect(nx + 1, ny + 1, 1, 1); ctx.globalAlpha = 1;

  // ---- cauda do manto (cavalgada ativa): o manto fica para trás ----
  if (ativo && golpe === 'cavalgada') {
    ctx.fillStyle = manto; ctx.fillRect(ox - dir * 10 - 2, topoM + 6, 4, 6);
    ctx.fillStyle = C.fibra; ctx.fillRect(ox - dir * 10 - 2, topoM + 6, 4, 1);
  }
}

/** Pastor como NPC: postura parada (sem golpe). Mesma arte do chefe, sem estados de combate. */
export function desenharPastorNpc(ctx, px, py, t = 0, falando = false, _estado = 'parado', facing = 1) {
  drawPastor(ctx, { body: { w: 26, h: 20 }, attackState: '', padraoAtual: null, attackDir: facing, facing, hurtTimer: 0 }, px, py, t);
}
