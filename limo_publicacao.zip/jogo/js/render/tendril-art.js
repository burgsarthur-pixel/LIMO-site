// =====================================================================
// TENDRIL · ARTE "GOSMA LANÇADA"
// A Tendril é um jato de gosma do próprio Limo: um fio de gel que nasce na borda do corpo, termina numa gota
// em forma de lágrima, achata ao grudar (splat), estica sob tensão, pinga quando afrouxa, estala quando falha
// e é reabsorvida ao recolher. SÓ desenha: nenhuma regra de jogo muda (a lógica continua em entities/tendril.js).
//
// Paleta: a mesma do Limo (js/render/player-art.js, COR) — nenhuma cor nova.
//
// Animações (todas derivadas do estado do TendrilController, sem estado de jogo próprio):
//   mira         (segurando o botão depois de uma falha) bolha se refazendo na borda do corpo e gotas marchando na direção
//                (opcional: `tendril.previa` = {x,y,tipo,meio} desenha colchetes no alvo; o controlador atual não a preenche)
//   lançamento   gota em lágrima + fio que chicoteia, pingando gotinhas pelo caminho
//   falha        a gota estoura no limite do alcance em respingos; o fio murcha (cor de gel sem força)
//   splat        ao grudar: gota achata contra a superfície, respinga para trás e o fio recebe um tranco
//   puxão        fio esticado (fino e reto) com pulsos de luz correndo para o Limo
//   pendurado    fio frouxo, com barriga caindo e pingando
//   objeto       splat com ondas de pulso ao ativar
//   inimigo      película de gosma envolve o alvo; pesado resiste (fio vibra, brilho amarelo de esforço)
//   interrupção  onda de choque quando corta o ataque do chefe
//   recolher     recuo elástico com a gota sendo reabsorvida; se o alvo se perdeu, o fio se parte em pingos
//   arremesso    ao soltar em movimento, o fio estala e deixa um rastro de gotas
// =====================================================================

// Mesmos valores de COR em player-art.js (o teste tendril-art-test.mjs confere).
import { clamp, lerp } from '../core/math.js';

export const PALETA_TENDRIL = Object.freeze({
  contorno: '#0b2514', corpo: '#55ce67', membrana: '#84ed77', luz: '#caff91', detalhe: '#ffe135',
  nucleo: '#f1c94f', branco: '#f4fff0', sombra: '#278843', profundo: '#176332',
});
const P = PALETA_TENDRIL;

const fracao = (v) => v - Math.floor(v);
const easeOutCubic = (u) => 1 - Math.pow(1 - clamp(u, 0, 1), 3);

/** Disco em pixels (linhas horizontais): leitura limpa em 320×240. */
function disco(ctx, cx, cy, r, cor) {
  ctx.fillStyle = cor;
  if (r <= 0) { ctx.fillRect(cx, cy, 1, 1); return; }
  for (let dy = -r; dy <= r; dy++) {
    const dx = Math.floor(Math.sqrt(r * r + r * 0.6 - dy * dy));
    ctx.fillRect(cx - dx, cy + dy, 2 * dx + 1, 1);
  }
}

/**
 * Desenha uma lista de peças em três passadas, para que o contorno forme UMA silhueta só:
 *  1) contorno de todas · 2) preenchimento · 3) brilhos e sombras.
 * peça: { k:'q'|'d', x, y, s|r, cor }   quadrado s×s (canto sup. esq.) ou disco de raio r (centro)
 */
function pintarPecas(ctx, pecas, detalhes) {
  for (const p of pecas) {
    if (p.sc) continue;   // raiz do fio: sem contorno, funde com o corpo do Limo
    if (p.k === 'q') { ctx.fillStyle = P.contorno; ctx.fillRect(p.x - 1, p.y - 1, p.s + 2, p.s + 2); } else disco(ctx, p.x, p.y, p.r + 1, P.contorno);
  }
  for (const p of pecas) {
    if (p.k === 'q') { ctx.fillStyle = p.cor; ctx.fillRect(p.x, p.y, p.s, p.s); } else disco(ctx, p.x, p.y, p.r, p.cor);
  }
  for (const d of detalhes) { ctx.fillStyle = d.cor; ctx.fillRect(d.x, d.y, d.w || 1, d.h || 1); }
}

/** Estado visual da Tendril (gotas soltas, tempos de fase). Um por jogo. */
export class TendrilGosma {
  constructor() { this.reset(); }

  reset() {
    this.gotas = []; this.faseAnt = 'idle'; this.razaoAnt = null; this.tFase = 0; this.mirandoT = 0;
    this.tipAnt = null; this.vel = { x: 0, y: 0 }; this.L0 = 0; this.splatT = 9; this.flashT = 0; this.interrompeuAnt = false;
    this.acGota = 0; this.acPinga = 0; this.ondas = []; this.tempo = 0;
  }

  /** Gota solta no mundo: respinga, cai e vira poça. */
  _gota(x, y, vx, vy, vida = 0.5, r = 1) { if (this.gotas.length < 80) this.gotas.push({ x, y, vx, vy, vida, max: vida, r, poca: false }); }

  _jorro(x, y, ax, ay, n, vel = 70, abertura = 1.1, r = 1) {   // leque de gotas em torno da direção (ax,ay)
    const base = Math.atan2(ay, ax);
    for (let i = 0; i < n; i++) {
      const a = base + (n === 1 ? 0 : (i / (n - 1) - 0.5) * abertura * 2); const v = vel * (0.7 + 0.5 * ((i * 37) % 10) / 10);
      this._gota(x, y, Math.cos(a) * v, Math.sin(a) * v - 25, 0.35 + 0.25 * ((i * 53) % 10) / 10, i % 3 === 0 ? r + 1 : r);
    }
  }

  _origem(player, alvo) {   // o fio nasce na borda do corpo, na direção do alvo
    const dx = alvo.x - player.centerX; const dy = alvo.y - player.centerY; const d = Math.hypot(dx, dy) || 1;
    return { x: player.centerX + (dx / d) * 4, y: player.centerY + (dy / d) * 4 };
  }

  update(dt, t, player, mapa = null) {
    this.tempo += dt; this.tFase += dt;
    const fase = t?.phase || 'idle';
    if (!player || !t) { this.gotas.length = 0; return; }

    // ---- gotas soltas: gravidade, atrito e poças ----
    for (const g of this.gotas) {
      g.vida -= dt;
      if (g.poca) continue;
      g.vy += 420 * dt; g.vx *= Math.exp(-1.2 * dt);
      const nx = g.x + g.vx * dt; const ny = g.y + g.vy * dt;
      if (mapa?.isSolidPoint?.(nx, ny)) { g.poca = true; g.vida = Math.min(g.vida, 0.35); g.max = 0.35; g.vx = 0; g.vy = 0; } else { g.x = nx; g.y = ny; }
    }
    this.gotas = this.gotas.filter((g) => g.vida > 0);
    this.flashT = Math.max(0, this.flashT - dt); this.splatT += dt;
    this.ondas = this.ondas.filter((o) => (o.t += dt) < 0.32);

    // ---- mira ----
    this.mirandoT = t.mirando && fase === 'idle' ? this.mirandoT + dt : 0;

    // ---- velocidade da ponta (a gota se estica contra o movimento) ----
    if (t.tip && this.tipAnt && dt > 0) {
      const vx = (t.tip.x - this.tipAnt.x) / dt; const vy = (t.tip.y - this.tipAnt.y) / dt;
      this.vel.x = lerp(this.vel.x, vx, 0.6); this.vel.y = lerp(this.vel.y, vy, 0.6);
    } else { this.vel.x *= 0.5; this.vel.y *= 0.5; }
    this.tipAnt = t.tip ? { x: t.tip.x, y: t.tip.y } : null;

    // ---- transições de fase ----
    if (fase !== this.faseAnt || (fase === 'retract' && t.reason !== this.razaoAnt)) {
      const alvoPt = t.tip || t.point || { x: player.centerX + t.aim.x * 20, y: player.centerY + t.aim.y * 20 };
      const o = this._origem(player, alvoPt);
      const ax = t.aim?.x || 1; const ay = t.aim?.y || 0;
      if (fase === 'extending' || fase === 'miss') { this.tFase = 0; this._jorro(o.x, o.y, ax, ay, 3, 60, 0.7); }
      if (fase === 'connected') {
        this.tFase = 0; this.splatT = 0;
        const d = Math.hypot((t.point?.x ?? 0) - o.x, (t.point?.y ?? 0) - o.y); this.L0 = d;
        const tx = t.point.x; const ty = t.point.y; const bx = o.x - tx; const by = o.y - ty; const bd = Math.hypot(bx, by) || 1;
        this._jorro(tx, ty, bx / bd, by / bd, 7, 85, 1.3);
        if (t.target?.tendrilKind === 'object') this.ondas.push({ x: tx, y: ty, t: 0 });
      }
      if (fase === 'retract') {
        this.tFase = 0;
        const origem = t._tipDe || alvoPt;
        if (t.reason === 'target-lost' || t.reason === 'blocked') {   // o fio se parte: pingos ao longo dele
          for (let i = 1; i <= 7; i++) { const u = i / 8; this._gota(lerp(o.x, origem.x, u), lerp(o.y, origem.y, u), (i % 2 ? 1 : -1) * 18, -10 + i * 3, 0.45 + 0.05 * i, i % 3 === 0 ? 2 : 1); }
        } else if (t.reason === 'miss') {
          this._jorro(origem.x, origem.y, -ax, -ay, 5, 55, 1.4);   // a gota estoura no limite do alcance
        } else if (t.reason === 'released' && (player.launchT || 0) > 0) {   // arremesso: rastro de gotas
          for (let i = 1; i <= 6; i++) { const u = i / 7; this._gota(lerp(o.x, origem.x, u), lerp(o.y, origem.y, u), -player.vx * 0.12, -player.vy * 0.12 - 10, 0.4, 1); }
        } else { this._gota(origem.x, origem.y, 0, -10, 0.4, 1); this._gota(origem.x + 2, origem.y, 10, -5, 0.35, 1); }
      }
      this.faseAnt = fase; this.razaoAnt = t.reason;
    }

    // ---- interrupção do chefe: onda de choque ----
    const interrompeu = !!t._interrompeu;
    if (interrompeu && !this.interrompeuAnt && t.point) { this.flashT = 0.3; this.ondas.push({ x: t.point.x, y: t.point.y, t: 0, forte: true }); }
    this.interrompeuAnt = interrompeu;

    // ---- gotas pelo caminho (lançamento) e pingos (fio frouxo) ----
    if ((fase === 'extending' || fase === 'miss') && t.tip) {
      this.acGota += dt; if (this.acGota > 0.022) { this.acGota = 0; this._gota(t.tip.x, t.tip.y, -this.vel.x * 0.06 + ((this.tempo * 997) % 10 - 5) * 3, -this.vel.y * 0.06 - 8, 0.3, 1); }
    }
    if (fase === 'connected' && t.point) {
      const o = this._origem(player, t.point); const d = Math.hypot(t.point.x - o.x, t.point.y - o.y);
      const folga = 1 - this._tensao(t, d);
      this.acPinga += dt;
      if (folga > 0.35 && this.acPinga > 0.2) { this.acPinga = 0; const mx = (o.x + t.point.x) / 2; const my = (o.y + t.point.y) / 2 + folga * 10; this._gota(mx, my, 0, 5, 0.7, 1); }
    }
  }

  /** 0 = frouxo (pendurado/perto) … 1 = esticado (puxando de longe). */
  _tensao(t, d) {
    const corda = t.config?.cordaRepouso ?? 16;
    return clamp((d - corda) / 60, 0, 1);
  }

  // ===================================================================
  draw(ctx, t, player, camX, camY, tempo) {
    if (!t || !player) return;
    const sx = (x) => Math.round(x - camX); const sy = (y) => Math.round(y - camY);
    this._gotasDesenhar(ctx, sx, sy);
    this._ondasDesenhar(ctx, sx, sy);
    const fase = t.phase;
    if (fase === 'idle') { if (t.mirando && player.hasAbility?.('tendril')) this._mira(ctx, t, player, sx, sy, tempo); return; }
    if (!t.tip) return;

    // recolher: recuo elástico (rápido no começo, assenta no fim) em vez de linear
    let tip = t.tip;
    if (fase === 'retract' && t._tipDe) { const u = easeOutCubic(t.t / t.config.tempoRetracao); tip = { x: lerp(t._tipDe.x, player.centerX, u), y: lerp(t._tipDe.y, player.centerY, u) }; }

    const o = this._origem(player, tip);
    const dx = tip.x - o.x; const dy = tip.y - o.y; const total = Math.hypot(dx, dy);
    if (total < 2) return;
    const ux = dx / total; const uy = dy / total; const nx = -uy; const ny = ux;
    const falha = fase === 'miss' || (fase === 'retract' && (t.reason === 'target-lost' || t.reason === 'blocked' || t.reason === 'miss'));
    const alvoInimigo = t.target?.tendrilKind === 'enemy' ? t.target.enemy : null;
    const resiste = fase === 'connected' && !!alvoInimigo && !alvoInimigo.tendrilPullable;
    const puxando = fase === 'connected' && (t.target?.tendrilKind === 'anchor' || (alvoInimigo && alvoInimigo.tendrilPullable));
    const tn = fase === 'connected' ? this._tensao(t, total) : fase === 'extending' ? 1 : 0.7;
    const corCorpo = falha ? P.sombra : P.corpo;

    // ---- fio ----
    const pecas = []; const det = [];
    const n = Math.max(3, Math.ceil(total / 2));
    const tf = this.tFase;
    for (let i = 0; i <= n; i++) {
      const u = i / n; const env = Math.sin(u * Math.PI);
      let ond;
      if (fase === 'extending') ond = Math.sin(tempo * 42 + u * 11) * (0.8 + 3.2 * (1 - clamp(tf / t.config.tempoExtensao, 0, 1))) * env;   // chicote
      else if (fase === 'miss') ond = Math.sin(tempo * 38 + u * 10) * 3.6 * env;
      else if (fase === 'retract') ond = Math.sin(tempo * 55 + u * 15) * (falha ? 3.2 : 2) * env * (1 - clamp(t.t / t.config.tempoRetracao, 0, 1) * 0.6);
      else ond = Math.sin(tempo * (resiste ? 70 : 18) + u * 12) * (resiste ? 1.7 : 0.35 + 0.7 * (1 - tn)) * env;
      const trancoSplat = fase === 'connected' ? Math.sin(tf * 55) * Math.max(0, 1 - tf / 0.2) * 2.5 * env : 0;   // tranco ao grudar
      const barriga = fase === 'connected' ? (1 - tn) * 10 * env : 0;                                              // frouxo: cai pela gravidade
      const px = lerp(o.x, tip.x, u) + nx * (ond + trancoSplat); const py = lerp(o.y, tip.y, u) + ny * (ond + trancoSplat) + barriga;
      // largura: raiz grossa, miolo fino quando esticado, pescoço antes da gota; contas de gel correm pelo fio
      let s = u < 0.16 ? 3 : (tn > 0.55 && u > 0.3 && u < 0.7 ? 2 : (falha ? 2 : 3));
      const sentido = puxando ? 1 : -1;   // contas vão para o Limo quando puxa, para a ponta quando lança
      for (let k = 0; k < 3; k++) { if (Math.abs(u - fracao(sentido * tempo * 0.9 + k / 3 + (sentido < 0 ? 1 : 0))) < 0.022) s = 4; }
      const x = Math.round(px - camX - Math.floor(s / 2)); const y = Math.round(py - camY - Math.floor(s / 2));
      pecas.push({ k: 'q', x, y, s, cor: corCorpo, sc: i <= 1 });
      if (!falha) {
        det.push({ x, y, w: 1, h: 1, cor: i % 4 === 0 ? P.luz : P.membrana });                                   // brilho do lado de cima
        if (s >= 3) det.push({ x: x + s - 1, y: y + s - 1, w: 1, h: 1, cor: P.sombra });                         // sombra do lado de baixo
      } else if (i % 3 === 0) det.push({ x, y, w: 1, h: 1, cor: P.profundo });
    }
    // pulsos de luz correndo pelo fio (puxão) · brilho de esforço amarelo (alvo pesado resiste)
    if (puxando || resiste) {
      for (let k = 0; k < 2; k++) {
        const u = resiste ? fracao(tempo * 5 + k * 0.5) : 1 - fracao(tempo * 2.2 + k * 0.5);
        const px = lerp(o.x, tip.x, u) + nx * 0; const py = lerp(o.y, tip.y, u) + (fase === 'connected' ? (1 - tn) * 10 * Math.sin(u * Math.PI) : 0);
        det.push({ x: Math.round(px - camX) - 1, y: Math.round(py - camY) - 1, w: 2, h: 2, cor: resiste ? P.detalhe : P.luz });
        det.push({ x: Math.round(px - camX) - 1, y: Math.round(py - camY) - 1, w: 1, h: 1, cor: P.branco });
      }
    }

    // ---- gota da ponta ----
    const tx = tip.x; const ty = tip.y;
    const vel = Math.hypot(this.vel.x, this.vel.y); const sp = clamp(vel / 450, 0, 1);
    const mvx = vel > 30 ? this.vel.x / vel : -ux; const mvy = vel > 30 ? this.vel.y / vel : -uy;   // sentido do movimento
    if (fase === 'connected') this._splat(pecas, det, t, tx, ty, ux, uy, nx, ny, camX, camY, alvoInimigo, resiste);
    else {
      const r = fase === 'retract' ? Math.max(1, Math.round(3 - 2 * clamp(t.t / t.config.tempoRetracao, 0, 1))) : 3;   // reabsorvida ao voltar
      const cx = Math.round(tx - camX); const cy = Math.round(ty - camY);
      for (let i = 3; i >= 1; i--) {   // cauda da lágrima: atrás, contra o movimento
        if (sp < 0.12 * i) continue;
        pecas.push({ k: 'd', x: Math.round(tx - mvx * (2 + i * 3 * (0.4 + sp)) - camX), y: Math.round(ty - mvy * (2 + i * 3 * (0.4 + sp)) - camY), r: Math.max(1, r - i + (sp > 0.5 ? 1 : 0)), cor: corCorpo });
      }
      pecas.push({ k: 'd', x: cx, y: cy, r, cor: corCorpo });
      if (!falha) { det.push({ x: cx - 1, y: cy - 1, w: 1, h: 1, cor: P.branco }); det.push({ x: cx - 2, y: cy - 1, w: 1, h: 1, cor: P.luz }); det.push({ x: cx + 1, y: cy + 1, w: 1, h: 1, cor: P.sombra }); }
      else det.push({ x: cx - 1, y: cy - 1, w: 1, h: 1, cor: P.membrana });
    }
    if (fase === 'connected' && alvoInimigo) this._pelicula(ctx, alvoInimigo, camX, camY, resiste);
    pintarPecas(ctx, pecas, det);

    // ---- brilho de interrupção: flash em volta do alvo ----
    if (this.flashT > 0 && t.point) {
      ctx.save(); ctx.globalAlpha = this.flashT / 0.3 * 0.7; ctx.fillStyle = P.branco;
      const fx = sx(t.point.x); const fy = sy(t.point.y); ctx.fillRect(fx - 7, fy, 15, 1); ctx.fillRect(fx, fy - 7, 1, 15); ctx.restore();
    }
  }

  /** Gota que gruda: achata contra a superfície, vira película no inimigo, onda no objeto. */
  _splat(pecas, det, t, tx, ty, ux, uy, nx, ny, camX, camY, inimigo, resiste) {
    const f = 1 + 0.7 * Math.max(0, 1 - this.splatT / 0.16);   // espremida ao bater, assenta em 0,16 s
    const X = (x) => Math.round(x - camX); const Y = (y) => Math.round(y - camY);
    const cor = P.corpo;
    if (inimigo) {   // película de gosma: a gota gruda no alvo e escorre sobre ele (desenhada à parte, ver _pelicula)
      pecas.push({ k: 'd', x: X(tx), y: Y(ty), r: 2, cor });
      det.push({ x: X(tx) - 1, y: Y(ty) - 1, w: 1, h: 1, cor: resiste ? P.detalhe : P.branco });
      return;
    }
    // panqueca perpendicular ao fio + calombo para o lado do Limo
    const ks = [[-4, 1], [-2, 2], [0, 3], [2, 2], [4, 1]];
    for (const [k, r] of ks) pecas.push({ k: 'd', x: X(tx + nx * k * f), y: Y(ty + ny * k * f), r: Math.max(1, Math.round(r * (1 + (f - 1) * 0.5))), cor });
    pecas.push({ k: 'd', x: X(tx - ux * 2), y: Y(ty - uy * 2), r: 2, cor });
    det.push({ x: X(tx) - 1, y: Y(ty) - 2, w: 2, h: 1, cor: P.luz }); det.push({ x: X(tx) - 2, y: Y(ty) - 1, w: 1, h: 1, cor: P.branco });
    det.push({ x: X(tx) + 1, y: Y(ty) + 2, w: 2, h: 1, cor: P.sombra });
  }

  /** Película translúcida sobre o inimigo, com escorridos; pesado = pisca amarelo de esforço. */
  _pelicula(ctx, en, camX, camY, resiste) {
    const b = en.body; const x = Math.round(b.x - camX); const y = Math.round(b.y - camY); const w = b.w; const h = b.h;
    const pul = 0.5 + 0.5 * Math.sin(this.tempo * (resiste ? 24 : 9));
    ctx.save(); ctx.globalAlpha = 0.42 + 0.14 * pul; ctx.fillStyle = P.corpo;
    ctx.fillRect(x - 1, y, w + 2, h); ctx.fillRect(x, y - 1, w, h + 2);   // cantos cortados: aspecto de gota
    ctx.globalAlpha = 0.85; ctx.fillStyle = resiste && pul > 0.6 ? P.detalhe : P.luz; ctx.fillRect(x + 1, y, Math.max(2, Math.floor(w / 2)), 1);
    ctx.fillStyle = P.sombra; ctx.fillRect(x, y + h, w, 1);
    for (const [fx, len] of [[0.25, 3], [0.7, 5]]) {   // escorridos
      const l = Math.round(len * (0.6 + 0.4 * Math.sin(this.tempo * 3 + fx * 9)));
      ctx.fillStyle = P.corpo; ctx.fillRect(x + Math.round(w * fx), y + h, 1, l); ctx.fillStyle = P.luz; ctx.fillRect(x + Math.round(w * fx), y + h + l, 1, 1);
    }
    ctx.restore();
  }

  _mira(ctx, t, player, sx, sy, tempo) {
    const ax = t.aim.x; const ay = t.aim.y; const c = t.config;
    const o = { x: player.centerX + ax * 4, y: player.centerY + ay * 4 };
    const k = clamp(this.mirandoT / 0.22, 0, 1);   // a bolha cresce enquanto segura o botão
    const r = Math.round(1 + 2 * easeOutCubic(k) + 0.4 * Math.sin(tempo * 12));
    const pecas = []; const det = [];
    const previa = t.previa;
    if (previa) {   // o alvo escolhido: a bolha estica um pescoço na direção dele
      const d = Math.hypot(previa.x - o.x, previa.y - o.y) || 1;
      for (let i = 1; i <= 3; i++) pecas.push({ k: 'd', x: sx(o.x + ((previa.x - o.x) / d) * (2 + i * 2.2 * k)), y: sy(o.y + ((previa.y - o.y) / d) * (2 + i * 2.2 * k)), r: Math.max(1, r - i), cor: P.corpo });
    }
    const bx = sx(o.x + ax * (r - 1)); const by = sy(o.y + ay * (r - 1));
    pecas.push({ k: 'd', x: bx, y: by, r: Math.max(1, r), cor: P.corpo });
    det.push({ x: bx - 1, y: by - 1, w: 1, h: 1, cor: P.branco }); if (r >= 2) det.push({ x: bx + 1, y: by + 1, w: 1, h: 1, cor: P.sombra });
    pintarPecas(ctx, pecas, det);
    ctx.save();   // gotas marchando na direção da mira (substituem os pontinhos)
    for (let i = 0; i < 3; i++) {
      const f = fracao(tempo * 1.1 + i / 3); const dist = c.alcance * (0.3 + 0.65 * f);
      ctx.globalAlpha = clamp(1.1 * (1 - f * 0.8) * (0.4 + 0.6 * k), 0, 1); const gx = sx(player.centerX + ax * dist); const gy = sy(player.centerY + ay * dist);
      ctx.fillStyle = P.contorno; ctx.fillRect(gx - 1, gy - 1, 3, 3); ctx.fillStyle = P.membrana; ctx.fillRect(gx - 1, gy - 1, 2, 2); ctx.fillStyle = P.luz; ctx.fillRect(gx - 1, gy - 1, 1, 1);
    }
    if (previa) {   // colchetes no alvo (amarelo = objeto interativo, verde = o resto)
      const pul = 0.55 + 0.45 * Math.sin(tempo * 9); ctx.globalAlpha = 0.5 + 0.5 * pul;
      const col = previa.tipo === 'object' ? P.detalhe : P.luz; const px = sx(previa.x); const py = sy(previa.y); const h = previa.meio || 7;
      ctx.fillStyle = col;
      for (const [qx, qy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) { ctx.fillRect(px + qx * h - (qx > 0 ? 1 : 0), py + qy * h, 2, 1); ctx.fillRect(px + qx * h, py + qy * h - (qy > 0 ? 1 : 0), 1, 2); }
    }
    ctx.restore();
  }

  _gotasDesenhar(ctx, sx, sy) {
    if (!this.gotas.length) return;
    ctx.save();
    for (const g of this.gotas) {
      ctx.globalAlpha = clamp(g.vida / Math.min(0.2, g.max), 0, 1);
      const x = sx(g.x); const y = sy(g.y);
      if (g.poca) { ctx.fillStyle = P.sombra; ctx.fillRect(x - 2, y, 5, 1); ctx.fillStyle = P.membrana; ctx.fillRect(x - 1, y - 1, 3, 1); continue; }
      if (g.r >= 2) { ctx.fillStyle = P.contorno; ctx.fillRect(x - 2, y - 2, 4, 4); ctx.fillStyle = P.corpo; ctx.fillRect(x - 1, y - 1, 2, 2); ctx.fillStyle = P.luz; ctx.fillRect(x - 1, y - 1, 1, 1); }
      else { ctx.fillStyle = P.corpo; ctx.fillRect(x, y, 2, 2); ctx.fillStyle = P.luz; ctx.fillRect(x, y, 1, 1); }
    }
    ctx.restore();
  }

  _ondasDesenhar(ctx, sx, sy) {
    if (!this.ondas.length) return;
    ctx.save();
    for (const o of this.ondas) {
      const u = clamp(o.t / 0.32, 0, 1); const r = Math.round(3 + (o.forte ? 11 : 7) * easeOutCubic(u)); ctx.globalAlpha = 0.8 * (1 - u);
      ctx.fillStyle = o.forte ? P.branco : P.detalhe; const x = sx(o.x); const y = sy(o.y);
      for (const [dx, dy] of [[r, 0], [-r, 0], [0, r], [0, -r], [Math.round(r * 0.7), Math.round(r * 0.7)], [-Math.round(r * 0.7), Math.round(r * 0.7)], [Math.round(r * 0.7), -Math.round(r * 0.7)], [-Math.round(r * 0.7), -Math.round(r * 0.7)]]) ctx.fillRect(x + dx, y + dy, 1, 1);
    }
    ctx.restore();
  }
}

/** Âncora ou objeto da Tendril como nódulo de gosma: bolha brilhante que pulsa e se estica para o Limo quando ele mira. */
export function drawNoGosma(ctx, x, y, { tipo = 'anchor', tempo = 0, fase = 0, esticar = null } = {}) {
  const pul = 0.5 + 0.5 * Math.sin(tempo * 3 + fase);
  const r = tipo === 'anchor' ? 3 : 4;
  const cor = tipo === 'anchor' ? P.corpo : P.nucleo; const luz = tipo === 'anchor' ? P.luz : P.detalhe; const sombra = tipo === 'anchor' ? P.sombra : P.profundo;
  const pecas = [{ k: 'd', x, y, r, cor }]; const det = [];
  if (esticar) pecas.push({ k: 'd', x: x + Math.round(esticar.x * (r + 1)), y: y + Math.round(esticar.y * (r + 1)), r: 1 + (pul > 0.5 ? 1 : 0), cor });   // bico apontado ao Limo
  det.push({ x: x - 2, y: y - 2, w: 2, h: 1, cor: luz }); det.push({ x: x - 2, y: y - 1, w: 1, h: 1, cor: P.branco });
  det.push({ x: x + 1, y: y + r - 1, w: 2, h: 1, cor: sombra });
  pintarPecas(ctx, pecas, det);
  ctx.save(); ctx.globalAlpha = 0.25 + 0.4 * pul; ctx.fillStyle = luz;   // pulso: pingos nas laterais
  ctx.fillRect(x - r - 3, y - 1, 1, 2); ctx.fillRect(x + r + 2, y - 1, 1, 2); ctx.restore();
}
