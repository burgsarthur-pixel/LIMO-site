// =====================================================================
// CARREGADOR DE SPRITESHEETS (PNG). Falha de uma imagem NÃO derruba o jogo:
// o tile usa a arte provisória e o problema vai para o console de debug.
// =====================================================================

export function defaultLoadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`não foi possível carregar a imagem "${src}"`));
    img.src = src;
  });
}

/** @returns Map(id -> {def, image, width, height, ok}) */
export async function loadTilesets(catalogo, logger = null, loadImage = defaultLoadImage) {
  const mapa = new Map();
  await Promise.all([...catalogo.tilesets.values()].map(async (def) => {
    try {
      const img = await loadImage(def.image);
      const largura = img.naturalWidth || img.width; const altura = img.naturalHeight || img.height;
      mapa.set(def.id, { def, image: img, width: largura, height: altura, ok: true });
      logger?.info('carregamento', `Spritesheet "${def.id}" carregado (${largura}x${altura}).`);
    } catch (e) {
      mapa.set(def.id, { def, image: null, width: 0, height: 0, ok: false });
      logger?.warn('carregamento', `Spritesheet "${def.id}" não carregou (${e.message}). Usando arte provisória.`);
    }
  }));
  return mapa;
}
