// =====================================================================
// ARTE DOS NPCs (v1.43.0) — pixel art procedural em retângulos, no mesmo padrão de entities/entity-art.js (casulo, eco, mutações).
// Sem imagens, sem gradientes, sem objetos novos por quadro; fundo transparente. Células de 1 px lógico (a tela é ampliada com pixels nítidos).
//
// FIO SOLTO — pequeno organismo filamentoso: corpo oval de fibras entrelaçadas (bege + rosa-pálido), dois olhinhos que piscam,
// fios soltos nas laterais que balançam, fiapos curtos como pés e uma ponta vermelha suave em cada fio.
// Idle discreto: respira (±1 px no alto do corpo), pisca a cada ~3,6 s, fios ondulam com fase própria.
// Em uma célula 16×16: o NPC ocupa ~14×14 e apoia os pés na última linha da célula (a que encosta no chão).
// =====================================================================
export const PALETA_FIO_SOLTO = {
  borda: '#4a2a2e',      // contorno marrom-avermelhado (mesma família do casulo: escuro, nunca preto puro)
  bege: '#e8d3ad',       // fibra clara
  begeEsc: '#c9ad82',    // fibra no sombreado
  rosa: '#f1c3c0',       // rosa-pálido (brilho/entrelaçamento)
  rosaEsc: '#d79a9c',
  vermelho: '#c95f66',   // vermelho suave (pontas dos fios, bochecha)
  vermelhoEsc: '#9c3f4b',
  olho: '#2b1720',
  brilho: '#fff7ea',
};

/** Corpo oval: [linha, xInicial, largura] em coordenadas da célula (16×16). */
const CORPO = [[1, 6, 4], [2, 5, 6], [3, 4, 8], [4, 3, 10], [5, 3, 10], [6, 3, 10], [7, 3, 10], [8, 3, 10], [9, 3, 10], [10, 4, 8], [11, 5, 6]];
/** Fios laterais: origem (x,y) no contorno do corpo e trajeto relativo [dx,dy] ponto a ponto (curvas que saem e CAEM, como fios soltos). */
const FIOS = [
  { x: 3, y: 5, p: [[-1, 0], [-2, 0], [-3, 1], [-3, 2], [-4, 3]], fase: 0.0 },
  { x: 3, y: 8, p: [[-1, 0], [-2, 1], [-3, 1], [-4, 0], [-5, -1]], fase: 1.7 },
  { x: 12, y: 5, p: [[1, 0], [2, -1], [3, -1], [3, 0], [4, 1]], fase: 2.4 },
  { x: 12, y: 8, p: [[1, 0], [2, 0], [3, 1], [3, 2], [3, 3]], fase: 0.9 },
];

/** Fio de trabalho (estado `trabalha`): sai do corpo para a frente e desce até o chão; a ponta vermelha balança. */
const FIO_TRABALHO = [[13, 8], [14, 8], [15, 9], [16, 10], [17, 11], [17, 12]];

/**
 * Desenha o Fio Solto com o canto superior esquerdo da célula em (px,py) (já em coordenadas de tela, inteiras).
 * `t` em segundos; `fala` (bool) deixa o corpo e os fios um pouco mais vivos enquanto conversa.
 * v1.45 — `estado` (rotina/reação) e `facing`:
 *   parado    o idle de sempre (respira, pisca)               descansa   agachado, olhos fechados, respiração lenta, fios caídos
 *   caminha   balança no passo, pés se alternam               atento     esticado, olhos grandes, sem piscar, franja reta
 *   trabalha  olha para baixo e tece: um fio faz arco à frente  assustado encolhido, treme, olhos arregalados, fios colados
 * `facing` −1 espelha o sprite dentro da célula (16 − x − w); o padrão (1) olha para a direita. Só retângulos de coordenadas inteiras, cores da paleta.
 */
export function desenharFioSolto(ctx, px, py, t = 0, fala = false, estado = 'parado', facing = 1) {
  const P = PALETA_FIO_SOLTO; const esp = facing < 0;
  const tremor = estado === 'assustado' ? (Math.floor(t * 14) % 2) : 0;   // sacode 1 px
  const R = (x, y, w, h, c) => { ctx.fillStyle = c; const xx = x + tremor; ctx.fillRect(px + (esp ? 16 - xx - w : xx), py + y + 2, w, h); };   // +2: os pés tocam a base da célula (chão)
  const andando = estado === 'caminha'; const dorme = estado === 'descansa'; const tece = estado === 'trabalha'; const alerta = estado === 'atento'; const medo = estado === 'assustado';
  const vivo = fala ? 1.8 : andando ? 1.7 : alerta ? 1.4 : dorme ? 0.4 : medo ? 2.6 : 1;
  const passo = Math.floor(t * 7) % 2;                                  // 0/1: quadro do passo
  const oy = dorme || medo ? 1 : alerta ? 0 : andando ? (passo ? 0 : 1) : (Math.sin(t * 1.7 * vivo) > 0.35 ? 0 : 1);   // vertical do corpo todo (pés fixos)
  const piscando = !dorme && !medo && !alerta && (t % 3.6) > 3.45;     // pisca ~150 ms a cada 3,6 s
  ctx.save();
  // --- fios soltos (atrás do corpo): curvas contínuas; só os pontos de fora ondulam (±1 px), a raiz fica presa ao corpo ---
  for (const [fi, f] of FIOS.entries()) {
    if (tece && fi === 3) continue;   // trabalhando: o fio lateral de baixo à direita vira o fio de trabalho
    let ax = f.x; let ay = f.y + oy; const pontos = medo ? f.p.slice(0, 3) : f.p;   // assustado: fios curtos, colados ao corpo
    pontos.forEach(([dx, dy], i) => {
      const amp = medo ? 0 : dorme ? 0.4 : Math.min(1, 0.2 + i * 0.28);
      const onda = Math.round(Math.sin(t * 2.0 * vivo + f.fase + i * 0.8) * amp);
      const x = f.x + dx; const y = Math.min(13, f.y + oy + dy + (i > 0 ? onda : 0) + (dorme && i > 1 ? 1 : 0) - (alerta && i > 1 ? 1 : 0)); const ponta = i === pontos.length - 1;
      R(x, y, 1, 1, ponta ? P.vermelho : (i % 2 ? P.rosaEsc : P.begeEsc));
      const lo = Math.min(y, ay); const hi = Math.max(y, ay); if (hi - lo > 1) R(ax, lo + 1, 1, hi - lo - 1, P.begeEsc);   // sem lacunas: o fio não "pula"
      ax = x; ay = y;
    });
    const [ux] = pontos[pontos.length - 1]; R(f.x + ux + (ux > 0 ? 1 : -1), Math.min(13, ay + 1), 1, 1, P.vermelhoEsc);   // pontinha desfiada
  }
  // --- fiapos curtos nos pés (caminhando, um pé levanta por vez) ---
  const peE = andando && passo === 0 ? 1 : 2; const peD = andando && passo === 1 ? 1 : 2;
  R(5, 12, 1, peE, P.begeEsc); R(10, 12, 1, peD, P.begeEsc); R(5, 13, 1, 1, P.rosaEsc); R(10, 13, 1, 1, P.vermelho); R(7, 12, 2, 1, P.begeEsc);   // tocos de fibra como pés
  // --- contorno do corpo (assustado: encolhido, sem a 1ª linha) ---
  const sem1 = medo ? 1 : 0;
  for (const [ly, lx, w] of CORPO) if (!(sem1 && ly === 1)) R(lx - 1, ly + oy, w + 2, 1, P.borda);
  R(5, (sem1 ? 1 : 0) + oy, 6, 1, P.borda); R(5, 12 + oy, 6, 1, P.borda);
  // --- preenchimento: fibras entrelaçadas — duas famílias de fios diagonais que se cruzam (rosa ↘, bege escuro ↗) sobre o bege ---
  for (const [ly, lx, w] of CORPO) { if (sem1 && ly === 1) continue; for (let i = 0; i < w; i++) {
    const x = lx + i; const a = (x - ly) & 3; const b = (x + ly) % 5;
    R(x, ly + oy, 1, 1, a === 0 ? P.rosa : b === 0 ? P.begeEsc : (a === 2 && b === 3 ? P.rosaEsc : P.bege));
  } }
  for (let x = 5; x < 11; x++) if ((x + 1) % 3 === 0) R(x, 9 + oy, 1, 1, P.rosaEsc);   // costura no ventre
  R(5, 3 + oy, 2, 1, P.brilho); R(4, 4 + oy, 1, 1, P.brilho);                          // brilho no alto à esquerda
  R(9, 10 + oy, 2, 1, P.begeEsc); R(8, 11 + oy, 2, 1, P.begeEsc);                      // sombreado embaixo à direita
  // --- rosto: dois olhos pequenos e expressivos + bochechas vermelhas suaves ---
  if (dorme || piscando) { R(5, 6 + oy, 2, 1, P.olho); R(9, 6 + oy, 2, 1, P.olho); }                                        // fechados
  else if (medo) { R(5, 5 + oy, 2, 3, P.brilho); R(9, 5 + oy, 2, 3, P.brilho); R(6, 6 + oy, 1, 2, P.olho); R(9, 6 + oy, 1, 2, P.olho); }   // arregalados
  else if (alerta) { R(5, 4 + oy, 2, 4, P.olho); R(9, 4 + oy, 2, 4, P.olho); R(5, 4 + oy, 1, 1, P.brilho); R(9, 4 + oy, 1, 1, P.brilho); }   // grandes, sem piscar
  else if (tece) { R(5, 6 + oy, 2, 2, P.olho); R(9, 6 + oy, 2, 2, P.olho); R(5, 6 + oy, 1, 1, P.brilho); R(9, 6 + oy, 1, 1, P.brilho); }  // olhando para baixo, concentrado
  else { R(5, 5 + oy, 2, 3, P.olho); R(9, 5 + oy, 2, 3, P.olho); R(5, 5 + oy, 1, 1, P.brilho); R(9, 5 + oy, 1, 1, P.brilho); }          // brilho dos olhos
  R(4, 8 + oy, 1, 1, P.vermelho); R(11, 8 + oy, 1, 1, P.vermelho);                      // bochechas
  if (medo) R(7, 8 + oy, 2, 2, P.vermelhoEsc); else R(7, 8 + oy, 2, 1, P.vermelhoEsc);   // boquinha (um "o" quando assustado)
  // --- fiozinho solto no topo (a "franja"): reta quando atento ---
  R(8, -1 + oy, 1, 1, P.rosaEsc); R(9, -2 + oy + (alerta ? 0 : Math.sin(t * 2.6) > 0 ? 0 : 1), 1, 1, P.vermelho);
  // --- trabalhando: um fio sai do corpo, faz arco à frente e cose pontinhos rosa no chão ---
  if (tece) {
    const bob = Math.round(Math.sin(t * 5)); const n = FIO_TRABALHO.length;   // a ponta balança de lado (a agulha trabalhando)
    FIO_TRABALHO.forEach(([x, y], i) => R(x + (i >= 4 ? bob : 0), Math.min(13, y + oy), 1, 1, i === n - 1 ? P.vermelho : (i % 2 ? P.rosa : P.begeEsc)));
    const pontos = 1 + (Math.floor(t * 0.8) % 3); for (let i = 0; i < pontos; i++) R(15 + i, 13, 1, 1, i % 2 ? P.rosa : P.rosaEsc);   // pontinhos aparecem um a um
  }
  ctx.restore();
}

/** Balão de interação sobre o NPC: três pontinhos que pulsam (aparece quando o Limo está perto). */
export function desenharConvite(ctx, px, py, t = 0) {
  const sobe = Math.round(Math.sin(t * 3) * 1);
  ctx.save();
  ctx.fillStyle = '#241420'; ctx.fillRect(px + 2, py - 12 + sobe, 12, 8); ctx.fillRect(px + 7, py - 4 + sobe, 2, 2);
  ctx.fillStyle = '#f6ead2'; ctx.fillRect(px + 3, py - 11 + sobe, 10, 6); ctx.fillRect(px + 7, py - 5 + sobe, 2, 1);
  for (let i = 0; i < 3; i++) { ctx.fillStyle = Math.floor(t * 3) % 3 === i ? '#c95f66' : '#8a6a5a'; ctx.fillRect(px + 5 + i * 3, py - 9 + sobe, 2, 2); }
  ctx.restore();
}

/** Disco feito de linhas de pixels (mesma técnica de entities/entity-art.js). */
function discoPixel(ctx, cx, cy, r, cor) {
  ctx.fillStyle = cor;
  for (let y = -r; y <= r; y++) { const w = Math.round(Math.sqrt(r * r - y * y)); ctx.fillRect(cx - w, cy + y, 2 * w + 1, 1); }
}

/**
 * Aura do Fio Solto enquanto ele ainda não conversou com Limo (v1.51.0): um halo rosado que respira e dois pontos girando.
 * Some na primeira conversa (a marca `npc:fio_solto:conversou` é gravada ao abrir o diálogo). Desenhada ANTES do NPC.
 */
export function desenharAuraFio(ctx, px, py, t = 0) {
  const cx = px + 8; const cy = py + 8; const pulso = 0.5 + 0.5 * Math.sin(t * 2.2);
  ctx.save();   // halo em discos de pixel com alfa (sem gradiente)
  ctx.globalAlpha = 0.07 + 0.04 * pulso; discoPixel(ctx, cx, cy, 9, PALETA_FIO_SOLTO.rosa);
  ctx.globalAlpha = 0.05 + 0.03 * pulso; discoPixel(ctx, cx, cy, 12, PALETA_FIO_SOLTO.rosa);
  ctx.globalAlpha = 0.03 + 0.02 * pulso; discoPixel(ctx, cx, cy, 15, PALETA_FIO_SOLTO.rosa);
  ctx.globalAlpha = 1;
  for (let i = 0; i < 2; i++) {
    const a = t * 0.9 + i * Math.PI; const x = Math.round(cx + Math.cos(a) * 11); const y = Math.round(cy + Math.sin(a) * 6 - 2);
    ctx.fillStyle = i ? PALETA_FIO_SOLTO.rosa : PALETA_FIO_SOLTO.brilho; ctx.fillRect(x, y, 1, 1);
  }
  ctx.restore();
}

/**
 * Nome do NPC sobre a cabeça, quando o Limo está perto mas ainda fora do convite (v1.51.0). Texto pequeno com contorno, sem caixa.
 * `alpha` (0–1) deixa o nome surgir e sumir com a distância.
 */
export function desenharNomeNpc(ctx, px, py, nome, alpha = 1) {
  if (alpha <= 0) return;
  ctx.save(); ctx.font = '6px monospace'; ctx.textAlign = 'center'; ctx.globalAlpha = alpha;
  const x = px + 8; const y = py - 3;
  ctx.fillStyle = 'rgba(8,4,12,0.9)';
  for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) ctx.fillText(nome, x + dx, y + dy);
  ctx.fillStyle = '#f1c3c0'; ctx.fillText(nome, x, y);
  ctx.restore();
}

/** Registro: tipo de arte por id do NPC (a sala só guarda `npc: "fio_solto"`). */
import { desenharJardineira, desenharRetratoJardineira, ALTURA_JARDINEIRA } from './jardineira-art.js';
import { desenharPastorNpc } from './pastor-art.js';   // v1.51.0 (Etapa 1.5)
export const ARTE_NPC = { fio_solto: desenharFioSolto, jardineira: desenharJardineira, pastor_visceras: desenharPastorNpc };
/** Retrato próprio (só a cabeça) para o diálogo; sem entrada, o diálogo usa a própria arte do mundo. */
export const ARTE_RETRATO = { jardineira: desenharRetratoJardineira };
/** Altura da figura em pixels (padrão 16 = uma célula). A base dos pés continua na célula da entidade. */
export const ALTURA_NPC = { jardineira: ALTURA_JARDINEIRA, pastor_visceras: 20 };
export const IDS_NPC = Object.keys(ARTE_NPC);
