// =====================================================================
// ARTE PROVISÓRIA DOS TILES (desenhada por código)
// Desenha cada tile UMA vez num "atlas" (um canvas grande); depois o renderer só copia
// pedaços (drawImage). Tiles com autotiling ganham todas as suas variantes (16 ou 47).
// Quando existe spritesheet PNG, o TileGraphics usa o PNG; esta arte vira reserva.
// =====================================================================
import { variantCount, variantMask, DECO } from '../world/autotile.js';

/** Gerador de números pseudoaleatórios determinístico (mesmo tile = mesma "textura"). */
export function aleatorio(semente) {
  let s = semente >>> 0;
  return () => {
    s = (s + 0x6D2B79F5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Manchas pequenas e irregulares (nunca linhas de ponta a ponta): é o que dá textura orgânica sem "quadrícula". */
function manchas(p, r, n, cores, maxW = 3) {
  for (let i = 0; i < n; i++) p((r() * 14) | 0, (r() * 14) | 0, 1 + ((r() * maxW) | 0), 1 + ((r() * 2) | 0), cores[(r() * cores.length) | 0]);
}

/** Poros, fibras curtas e brilho úmido, desenhados para continuar legíveis em 16 px. */
function texturaDeCarne(p, r, art, intensidade = 1) {
  const sombra = art.color3 || '#2a080f';
  for (let i = 0; i < 5 + intensidade * 2; i++) {
    const x = 1 + ((r() * 13) | 0); const y = 1 + ((r() * 13) | 0);
    p(x, y, r() < 0.55 ? 1 : 2, 1, r() < 0.6 ? sombra : art.color2);
    if (r() < 0.28) p(x + 1, y + 1, 1, 1, '#2a0710');
  }
  for (let i = 0; i < 2 + intensidade; i++) {
    const x = 1 + ((r() * 12) | 0); const y = 2 + ((r() * 11) | 0);
    p(x, y, 2 + ((r() * 3) | 0), 1, '#ffd0bb55');
  }
}

export const ESTILOS = {
  // Nenhum estilo desenha realce/sombra reta de 16px: a continuidade vem de cor e manchas; a silhueta vem das bordas irregulares do autotile.
  block(p, art, r) {
    p(0, 0, 16, 16, art.color);
    manchas(p, r, 9, [art.color2, art.color3 || '#00000033'], 3);
    texturaDeCarne(p, r, art);
    for (let i = 0; i < 2; i++) { const x = 2 + ((r() * 11) | 0); p(x, 1 + ((r() * 13) | 0), 1, 2, '#21070d88'); }
  },
  moss(p, art, r) {
    ESTILOS.block(p, art, r);
    for (let x = 0; x < 16; x++) { if (r() < 0.18) continue; const h = 1 + ((r() * 4) | 0); p(x, 0, 1 + (r() < 0.3 ? 1 : 0), h, art.color3); if (r() < 0.3) p(x, h, 1, 1, art.color2); }
    for (let i = 0; i < 3; i++) { const x = 2 + ((r() * 11) | 0); const y = 6 + ((r() * 7) | 0); p(x, y, 2, 1, art.color3); p(x + 1, y - 1, 1, 1, art.color2); }
  },
  bone(p, art, r) {
    p(0, 0, 16, 16, art.color);
    for (let i = 0; i < 5; i++) { const x = (r() * 15) | 0; const y = (r() * 12) | 0; p(x, y, 1, 2 + ((r() * 4) | 0), art.color2); }   // fibras curtas e quebradas
    manchas(p, r, 5, ['#00000022', art.color2], 2);
    for (let i = 0; i < 2; i++) p((r() * 14) | 0, (r() * 14) | 0, 2, 1, '#00000038');                                                    // poros
  },
  cartilage(p, art, r) {
    p(0, 0, 16, 16, art.color);
    manchas(p, r, 9, [art.color2, '#00000028'], 3);
  },
  muscle(p, art, r) {
    p(0, 0, 16, 16, art.color);
    for (let k = 0; k < 5; k++) {
      const x0 = 1 + ((r() * 13) | 0); const fase = r() * 6;
      for (let y = 0; y < 16; y++) if (r() > 0.18) {
        const x = x0 + Math.round(Math.sin(y * 0.45 + fase) * 1.4);
        p(x, y, 1, 1, k % 2 ? art.color2 : '#3d1018');
        if (k === 0 && y % 4 === 0) p(x + 1, y, 1, 1, '#ffc2b0');
      }
    }
    for (let i = 0; i < 3; i++) p(1 + ((r() * 13) | 0), 2 + ((r() * 11) | 0), 1, 1, '#5c1822');
  },
  root(p, art, r) {
    p(0, 0, 16, 16, art.color);
    for (let i = 0; i < 4; i++) {
      const x0 = (r() * 12) | 0;
      for (let k = 0; k < 14; k++) p(x0 + ((Math.sin(k) * 1) | 0), k, 2, 2, art.color2);
    }
  },
  platform(p, art, r) {
    // borda de carne: topo irregular (4-5 px de altura), contorno escuro quebrado e pingos por baixo; sem régua de 16 px
    for (let x = 0; x < 16; x++) {
      const h = 3 + ((r() * 3) | 0);
      p(x, 1 + ((r() * 2) | 0) * 0, 1, h, art.color);
      p(x, 0, 1, 1, r() < 0.7 ? art.color2 : art.color);
      p(x, h + 1, 1, 1, '#12060bcc');
      if (r() < 0.3) p(x, h + 2, 1, 1 + ((r() * 2) | 0), art.color);
    }
    manchas(p, r, 3, ['#00000030', art.color2], 2);
  },
  esfincter(p, art, r) {   // anel de carne fechado, com fenda no meio
    p(0, 0, 16, 16, art.color);
    for (let i = 0; i < 6; i++) p(1 + ((r() * 12) | 0), 1 + ((r() * 12) | 0), 2, 1, art.color2);
    for (let i = 0; i < 16; i++) { if (r() < 0.8) p(i, 0, 1, 1, '#12060b99'); if (r() < 0.8) p(i, 15, 1, 1, '#12060b99'); if (r() < 0.8) p(0, i, 1, 1, '#12060b99'); if (r() < 0.8) p(15, i, 1, 1, '#12060b99'); }   // contorno quebrado (sem régua reta)
    p(3, 7, 10, 2, '#1c0610'); p(4, 7, 8, 1, art.color2);
  },
  esfincterAberto(p, art) {   // só os cantos: dá para ver onde o músculo vai fechar
    for (const [x, y] of [[0, 0], [12, 0], [0, 12], [12, 12]]) { p(x, y, 4, 1, art.color); p(x, y, 1, 4, art.color); if (x) p(15, y, 1, 4, art.color); if (y) p(x, 15, 4, 1, art.color); }
    p(7, 7, 2, 2, art.color2);
  },
  fungoLuz(p, art, r) {   // chapéu brilhante (plataforma)
    for (let x = 0; x < 16; x++) { const h = 3 + ((r() * 2) | 0); p(x, 1, 1, h, art.color); p(x, 0, 1, 1, art.color2); }
    for (let x = 1; x < 15; x += 3) p(x, 5, 1, 2 + ((r() * 2) | 0), art.color);
    for (let i = 0; i < 4; i++) p(1 + ((r() * 13) | 0), 1, 1, 1, '#ffffff');
  },
  fungoLuzDormente(p, art, r) {   // brotinhos apagados: sinal de que a luz acorda isto
    for (let x = 1; x < 15; x += 3) { p(x, 1 + ((r() * 2) | 0), 1, 2, art.color); p(x, 0, 1, 1, art.color2); }
  },
  spikes(p, art, r) {
    // Silhuetas separadas, sem shader nem faixa cheia na base. Cada ponta nasce da membrana,
    // preservando transparência fora do espinho e evitando o "retângulo" visual no tile.
    const sombra = '#16070c';
    let x = 0;
    while (x < 16) {
      const w = 2 + ((r() * 3) | 0);
      const h = 6 + ((r() * 6) | 0);
      const incl = r() < 0.5 ? -1 : 1;
      for (let k = 0; k < h; k++) {
        const y = 15 - k;
        const largura = Math.max(1, Math.ceil(w * (1 - k / h)));
        const bruto = x + Math.round(incl * k * 0.16);
        const px = Math.max(0, Math.min(15, bruto));
        const ww = Math.max(1, Math.min(largura, 16 - px));
        p(px, y, ww, 1, k === 0 ? sombra : (k > h - 3 ? art.color2 : art.color));
      }
      // nódulo de origem curto e quebrado: sugere tecido vivo sem desenhar uma barra 16×2.
      if (r() < 0.72) p(Math.max(0, x - 1), 15, Math.min(3, 16 - Math.max(0, x - 1)), 1, art.color);
      x += w + 1 + ((r() * 2) | 0);
    }
  },
  vascular(p, art, r) {
    ESTILOS.block(p, art, r);
    for (let i = 0; i < 3; i++) {
      const x0 = 2 + ((r() * 11) | 0); const y0 = 1 + ((r() * 12) | 0);
      for (let k = 0; k < 5; k++) {
        const x = x0 + (k > 1 && r() < 0.45 ? 1 : 0); const y = y0 + k;
        p(x, y, 1 + (k === 2 ? 1 : 0), 1, k === 2 ? art.color2 : art.color3);
      }
      if (r() < 0.6) p(x0 - 1, y0 + 2, 2, 1, art.color2);
    }
  },
  membrane(p, art, r) {
    p(0, 0, 16, 16, art.color);
    for (let y = 1; y < 16; y += 3) {
      const desloc = ((r() * 3) | 0) - 1;
      for (let x = 0; x < 16; x += 3) {
        p(Math.max(0, x + desloc), y, 2, 1, art.color2);
        if (r() < 0.45) p(Math.max(0, x + desloc + 1), Math.min(15, y + 1), 1, 1, art.color3 || '#1a0710');
      }
    }
    for (let i = 0; i < 4; i++) p(1 + ((r() * 13) | 0), 1 + ((r() * 13) | 0), 1, 1, '#ffd7ba55');
  },
  decoGlow(p, art, r) {
    // Micélios luminosos: pixels e halo quadrado pequeno, nunca uma caixa preenchida.
    const x = 3 + ((r() * 8) | 0); const y = 6 + ((r() * 5) | 0);
    p(x - 2, y, 5, 1, `${art.color2}33`); p(x, y - 2, 1, 5, `${art.color2}33`);
    p(x - 1, y - 1, 3, 3, art.color); p(x, y, 1, 1, art.color2);
    for (let i = 0; i < 3; i++) { const sx = Math.max(0, Math.min(15, x + (((r() * 9) | 0) - 4))); const sy = Math.max(0, Math.min(15, y + (((r() * 9) | 0) - 4))); p(sx, sy, 1, 1, art.color2); }
  },
  slime(p, art, r) {
    p(0, 0, 16, 16, art.color);
    for (let x = 0; x < 16; x++) p(x, 0, 1 + (r() < 0.4 ? 1 : 0), r() < 0.5 ? 1 : 2 + ((r() * 3) | 0), art.color2);   // escorrido irregular
    manchas(p, r, 4, [art.color3 || '#00000033'], 2);
  },
  fungus(p, art, r) {
    ESTILOS.block(p, { ...art, color: art.color3 || art.color }, r);
    for (let i = 0; i < 3; i++) p(1 + ((r() * 11) | 0), 0, 2 + ((r() * 3) | 0), 1 + ((r() * 2) | 0), art.color2);
  },
  decoFungus(p, art, r) {
    for (let i = 0; i < 2; i++) {
      const x = 3 + i * 6;
      const h = 5 + i * 2;
      p(x + 1, 15 - h, 2, h, '#d8c8a8');
      p(x - 1, 14 - h, 6, 2, art.color);
      p(x, 13 - h, 4, 1, art.color2);
    }
  },
  decoRoot(p, art, r) {
    let x = 7;
    for (let y = 0; y < 16; y++) {
      if (r() < 0.25) x += r() < 0.5 ? -1 : 1;
      x = Math.max(1, Math.min(14, x));
      p(x, y, 3, 2, art.color);
      p(x + 1, y, 1, 1, art.color2);
    }
  },
  decoPlant(p, art, r) {
    for (let k = 0; k < 3; k++) {
      const x = 3 + k * 4;
      const altura = 8 + ((r() * 4) | 0);
      for (let y = 0; y < altura; y++) {
        p(x + ((y * (k - 1)) >> 2), 15 - y, 2, 1, y > altura - 3 ? art.color2 : art.color);
      }
      const y = 15 - Math.floor(altura * 0.55); const dir = k === 1 ? 1 : (k === 0 ? -1 : 1);
      p(x + dir, y, 3, 1, art.color2); p(x + dir * 2, y - 1, 2, 1, art.color2);
      if (k !== 1) p(x - dir, y + 3, 2, 1, art.color);
    }
  },
  vein(p, art, r) {
    let x = 7;
    for (let y = 0; y < 16; y++) {
      if (r() < 0.3) x += r() < 0.5 ? -1 : 1;
      x = Math.max(1, Math.min(14, x));
      p(x, y, 2, 2, art.color);
      p(x, y, 1, 1, art.color2);
    }
  },
  bg(p, art, r) {
    p(0, 0, 16, 16, art.color);
    for (let i = 0; i < 4; i++) p((r() * 15) | 0, (r() * 15) | 0, 1, 1, art.color2);
  },
  fgRoot(p, art, r) {
    for (let y = 0; y < 16; y++) {
      const offsetX = ((Math.sin(y / 2.5) * 2) | 0);
      p(6 + offsetX, y, 4, 2, art.color);
      p(7 + offsetX, y, 2, 1, art.color2);
    }
  },
  scarBlock(p, art, r) {
    p(0, 0, 16, 16, art.color);
    manchas(p, r, 8, [art.color2, art.color3 || '#30202a'], 3);
    for (let k=0;k<3;k++) { let x=2+((r()*10)|0), y=2+((r()*10)|0); for(let j=0;j<4;j++){ p(x+j,y+((j%2)?1:0),2,1,art.color3||'#30202a'); if(j===1||j===3)p(x+j,y-1,1,1,art.color2); } }
    texturaDeCarne(p,r,art,0.7);
  },
  glowFlesh(p, art, r) {
    p(0,0,16,16,art.color); manchas(p,r,7,[art.color3||'#30253a',art.color2],3);
    for(let i=0;i<4;i++){const x=2+((r()*12)|0),y=2+((r()*12)|0);p(x,y,2,1,art.color2);p(x+1,y-1,1,1,'#fff0df');}
  },
  porousBone(p, art, r) {
    p(0,0,16,16,art.color);
    for(let i=0;i<12;i++){const x=1+((r()*13)|0),y=1+((r()*13)|0);p(x,y,1+(r()<.25?1:0),1,art.color3||'#62584a');if(r()<.45)p(x+1,y+1,1,1,art.color2);}
    for(let i=0;i<4;i++){const x=2+((r()*10)|0);p(x,2+((r()*10)|0),2,1,art.color2);}
  },
  bark(p, art, r) {
    p(0,0,16,16,art.color);
    for(let x=1;x<16;x+=3){let off=((r()*3)|0)-1;for(let y=0;y<16;y+=2){p(Math.max(0,Math.min(15,x+off)),y,1,2,art.color2);if(r()<.5)p(Math.max(0,Math.min(15,x+off+1)),y+1,1,1,art.color3||'#30251d');}}
    manchas(p,r,5,[art.color3||'#30251d',art.color2],2);
  },
  mossStone(p, art, r) {
    p(0,0,16,16,art.color); manchas(p,r,8,[art.color3||'#263c38',art.color2],3);
    for(let i=0;i<5;i++){const x=(r()*15)|0,y=(r()*5)|0;p(x,y,2+(r()*3|0),1,art.color2);if(r()<.5)p(x+1,y+1,1,1,'#c6d68b');}
    for(let i=0;i<3;i++)p((r()*14)|0,8+(r()*7|0),2,1,art.color3||'#263c38');
  },
  fungalMat(p, art, r) {
    p(0,0,16,16,art.color); manchas(p,r,6,[art.color3||'#29253d',art.color2],3);
    for(let i=0;i<4;i++){let x=(r()*13)|0,y=(r()*13)|0;p(x,y,3,1,art.color2);p(x+1,y-1,1,1,'#eadcff');p(x+1,y+1,1,2,art.color3||'#29253d');}
  },
  veinWall(p, art, r) {
    p(0,0,16,16,art.color); manchas(p,r,5,[art.color3||'#38243d'],2);
    for(let i=0;i<3;i++){let x=2+(r()*10|0),y=0;for(let k=0;k<15;k++){if(r()<.28)x+=r()<.5?-1:1;x=Math.max(0,Math.min(15,x));p(x,y+k,2,1,art.color2);if(k%4===0)p(x+1,y+k,1,1,'#ffe0dc');}}
  },
  rootKnot(p, art, r) {
    p(0,0,16,16,art.color);
    for(let i=0;i<5;i++){let x=2+(r()*11|0),y=2+(r()*11|0);for(let k=0;k<5;k++){p(x+((Math.sin(k+i)*2)|0),y+k,2,2,art.color2);}}
    manchas(p,r,4,[art.color3||'#2d241b'],2);
  },
  coralDeco(p, art, r) {
    const base=14; for(let i=0;i<4;i++){let x=3+i*3,h=5+(r()*6|0),lean=(r()<.5?-1:1);for(let y=0;y<h;y++){p(x+Math.round(y*.18*lean),base-y,2,1,art.color);if(y%3===0)p(x+Math.round(y*.18*lean)+1,base-y,1,1,art.color2);}}
    p(2,14,12,2,art.color3||'#673947');
  },
  sporeFlower(p, art, r) {
    const x=8,y=7; p(7,8,2,7,art.color3||'#365f4b');
    for(const [dx,dy] of [[0,-4],[4,0],[0,4],[-4,0],[3,-3],[-3,-3],[3,3],[-3,3]])p(x+dx,y+dy,2,2,art.color);
    p(7,6,3,3,art.color2);p(8,7,1,1,'#fff5c5');
    for(let i=0;i<3;i++)p(2+(r()*12|0),2+(r()*10|0),1,1,art.color2);
  },
  sporeLamp(p, art, r) {
    p(7,8,2,7,art.color3||'#28414a');p(5,6,6,4,art.color);p(6,5,4,1,art.color2);p(7,7,2,2,art.color2);
    p(4,7,1,2,`${art.color2}88`);p(11,7,1,2,`${art.color2}88`);
    for(let i=0;i<4;i++)p(3+(r()*10|0),3+(r()*5|0),1,1,art.color2);
  },
  boneShard(p, art, r) {
    const x=5+(r()*4|0); for(let y=2;y<15;y++){const w=Math.max(1,Math.floor((y-1)/4));p(x-w,y,w*2,1,y<5?art.color2:art.color);}
    p(x-2,13,5,2,art.color3||'#635a4c');p(x,3,1,5,'#fff0d2');
  },
  forkedVine(p, art, r) {
    let x=7;for(let y=0;y<16;y++){if(r()<.2)x+=r()<.5?-1:1;x=Math.max(2,Math.min(13,x));p(x,y,2,2,art.color);p(x,y,1,1,art.color2);}
    for(const side of [-1,1])for(let k=0;k<5;k++)p(7+side*(k+1),5+k,2,1,art.color2);
  },
  mucusBubble(p, art, r) {
    const x=4+(r()*5|0),y=5+(r()*4|0),s=5+(r()*3|0);p(x+1,y,s-2,1,art.color2);p(x,y+1,s,Math.max(2,s-2),art.color);p(x+1,y+1,2,1,'#e5ffd0');p(x+1,y+s-1,s-2,1,art.color3||'#263f3a');
  },
  fossilDeco(p, art, r) {
    for(let i=0;i<5;i++){const x=3+i*2;p(x,4+i%2,2,2,art.color);p(x,6+i%2,1,3,art.color2);}
    p(3,12,10,2,art.color3||'#46384d');p(4,3,8,1,art.color2);
  },
  shellDeco(p, art, r) {
    for(let y=4;y<14;y++){const half=Math.max(1,Math.floor((y-2)/2));p(8-half,y,half*2,1,art.color);}
    for(let x=5;x<12;x+=2)p(x,6+(r()*5|0),1,5,art.color2);
    p(5,13,7,1,art.color3||'#493b3d');
  },

  // ---- v1.33.0 · elementos que contam histórias SEM diálogo, e vegetação/estruturas orgânicas novas ----
  // (ver docs/historico/CORPO_COLOSSAL_v1.33.0.md). Desenhados "de pé" (apoio em y=15); os de teto são espelhados pelo motor.
  casuloVazio(p, art, r) {   // casulo rachado e vazio: o Deus tentou lembrar uma forma e não deu certo
    for (let y = 2; y < 15; y++) {
      const hw = Math.max(1, Math.round(4.4 * Math.sin(((y - 1.5) / 13) * Math.PI)));
      p(8 - hw, y, 2, 1, art.color);                                              // parede da esquerda
      const miolo = Math.max(0, hw * 2 - 4); if (miolo) p(10 - hw, y, miolo, 1, y > 4 ? art.color3 : art.color);   // vazio por dentro (tampa fechada no alto)
      if (y < 7) p(6 + hw, y, 2, 1, art.color); else p(6 + hw + ((y - 7) >> 1), y, 2, 1, art.color2);          // direita inteira em cima, casca descascando embaixo
    }
    p(7, 1, 2, 1, art.color2); p(9, 5, 1, 4, art.color2);                            // rachadura clara
    p(4, 15, 9, 1, art.color3); p(2 + ((r() * 3) | 0), 14, 1, 1, art.color2);        // poça ressecada e uma lasca
  },
  restosDeLimo(p, art, r) {   // casca murcha de uma cópia de Limo: corpo caído para um lado, dois buracos onde havia olhos
    const meia = [1, 2, 3, 4, 5, 6, 6]; const caida = [0, 0, 1, 1, 2, 2, 2];   // a parte de cima desaba para a direita
    for (let i = 0; i < 7; i++) { const y = 8 + i; const w = meia[i]; const x = 8 - w + caida[i]; p(x, y, w * 2, 1, art.color); p(x, y, 1, 1, art.color3); p(x + w * 2 - 1, y, 1, 1, art.color3); }
    p(2, 14, 12, 1, art.color3);
    p(5, 10, 2, 2, '#0b120c'); p(9, 10, 2, 2, '#0b120c'); p(5, 10, 1, 1, art.color3); p(9, 10, 1, 1, art.color3);   // órbitas vazias, bem escuras
    p(7, 13, 3, 1, '#0b120c');                                                          // boca murcha
    p(4, 12, 2, 1, art.color3); p(10, 12, 2, 1, art.color3); p(7, 8, 3, 1, art.color2); p(6, 9, 1, 1, art.color2);   // rugas e brilho fosco
    p(13, 13, 3, 1, art.color); p(15, 12, 1, 1, art.color2);                            // braço caído
    p(0, 15, 16, 1, art.color3 + '99');                                                 // rastro seco
  },
  raizAbraco(p, art, r) {   // raízes enroladas num feixe de ossinhos: quem cuidou e não soltou
    p(6, 9, 4, 6, art.color3); p(7, 8, 2, 1, art.color3); p(5, 13, 1, 2, art.color3); p(10, 12, 1, 3, art.color3);
    for (let i = 0; i < 6; i++) { const y = 8 + i; const x = 4 + (i % 2) * 6; p(x, y, 3, 1, art.color); p(x + 1, y, 1, 1, art.color2); }
    for (const [x, h] of [[3, 10], [12, 9], [8, 6]]) for (let k = 0; k < h; k++) p(x + (k % 3 === 2 ? 1 : 0), 15 - k, 1, 1, k > h - 3 ? art.color2 : art.color);
    p(2, 15, 12, 1, art.color);
  },
  costelaArco(p, art, r) {   // costela gigante emergindo do chão e curvando-se: escala de corpo colossal
    for (let i = 0; i <= 34; i++) {
      const a = (i / 34) * Math.PI / 2; const x = Math.round(13 - 11 * Math.cos(a)); const y = Math.round(15 - 14 * Math.sin(a)); const e = i < 24 ? 2 : 1;
      p(x, y, e, 1, art.color); p(x, y, 1, 1, art.color2); if (i < 28) p(x, y + 1, e, 1, art.color);
    }
    p(1, 13, 4, 3, art.color3); p(2, 13, 2, 1, art.color);
  },
  vertebras(p, art, r) {   // três vértebras empilhadas e tortas, com o canal da medula vazio
    for (const [y, dx] of [[11, -1], [7, 0], [3, 1]]) {
      const x = 4 + dx; p(x, y, 8, 3, art.color); p(x + 1, y, 5, 1, art.color2); p(x + 3, y + 1, 2, 1, art.color3);
      p(x + 8, y + 1, 2, 1, art.color); p(x - 2, y + 1, 2, 1, art.color); p(x + 1, y + 3, 6, 1, art.color3);
    }
    p(3, 15, 10, 1, art.color3);
  },
  suturaFio(p, art, r) {   // ferida costurada com fio: alguém tentou fechar o corpo do Deus
    p(2, 12, 12, 1, art.color); p(2, 14, 12, 1, art.color); p(3, 13, 10, 1, art.color3);
    for (let i = 0; i < 5; i++) { const x = 3 + i * 2; p(x, 10, 1, 6, art.color2); p(x, 10, 1, 1, art.color); if (i % 2) p(x + 1, 11, 1, 1, art.color2); }
    p(14, 11, 1, 4, art.color2); p(15, 14, 1, 2, art.color2);
  },
  ovosDoRebanho(p, art, r) {   // ninho de ovos translúcidos com gema luminosa; um deles já rachou
    const ovo = (x, y, w, h, quebrado) => {
      p(x + 1, y, w - 2, 1, art.color); p(x, y + 1, w, h - 2, art.color); p(x + 1, y + h - 1, w - 2, 1, art.color);
      p(x + 1, y + 1, 1, 2, art.color2);
      if (quebrado) { p(x + (w >> 1), y, 1, 2, '#1a2a18'); p(x + 1, y + h - 2, w - 2, 1, '#1a2a18'); } else p(x + 1, y + (h >> 1), w - 2, 2, art.color3);
    };
    ovo(2, 9, 5, 6, false); ovo(8, 7, 5, 8, false); ovo(11, 11, 4, 4, true);
    p(10, 14, 1, 1, art.color2); p(0, 15, 16, 1, art.color3 + '55');
  },
  palpebraAdormecida(p, art, r) {   // pálpebra fechada de um olho gigante: o Deus dorme aqui
    for (let y = 4; y < 15; y++) { const t = (14 - y) / 11; const hw = Math.round(7 * Math.sqrt(Math.max(0, 1 - t * t))); p(8 - hw, y, hw * 2, 1, art.color); }
    p(4, 6, 6, 1, art.color2); p(3, 7, 1, 1, art.color2);                                // brilho do globo sob a pele
    p(3, 9, 10, 1, art.color2 + 'cc'); p(2, 10, 1, 1, art.color2 + 'cc'); p(13, 10, 1, 1, art.color2 + 'cc');   // dobra da pálpebra
    p(2, 11, 12, 1, art.color3); p(1, 12, 2, 1, art.color3); p(13, 12, 2, 1, art.color3);   // a fenda fechada
    for (const x of [4, 7, 10]) p(x, 12, 1, 1, art.color3);                              // cílios curtos
    p(2, 14, 12, 1, art.color3 + 'aa');
  },
  fungoPrateleira(p, art, r) {   // cogumelos-prateleira empilhados num toco
    p(7, 8, 3, 7, art.color3);
    for (const [y, w, dx] of [[13, 10, 0], [10, 8, 1], [7, 6, 0]]) { p(8 - (w >> 1) + dx, y, w, 2, art.color); p(8 - (w >> 1) + dx, y, w, 1, art.color2); p(9 - (w >> 1) + dx, y + 2, w - 2, 1, art.color3); }
  },
  cortinaDeRaizes(p, art, r) {   // (de teto) cortina de fios de raiz; a massa em y=13..15 é a que prende no teto depois do espelhamento
    for (const x of [2, 4, 6, 8, 10, 12, 13]) { const len = 6 + ((r() * 8) | 0); p(x, 15 - len, 1, len, x % 4 ? art.color : art.color2); p(x, 15 - len, 1, 1, art.color2); }
    p(1, 13, 14, 3, art.color3); p(2, 13, 12, 1, art.color);
  },
  musgoLuminoso(p, art, r) {   // tapete baixo de musgo com pontinhos que brilham
    for (let x = 0; x < 16; x++) { const h = 2 + (((Math.sin(x * 1.3) + 1) * 1.5) | 0) + (r() < 0.25 ? 1 : 0); p(x, 16 - h, 1, h, art.color); p(x, 16 - h, 1, 1, r() < 0.35 ? art.color2 : art.color3); }
  },
  bulboVeias(p, art, r) {   // bulbo orgânico cheio de veias, preso ao chão por um pedúnculo
    p(7, 12, 2, 4, art.color3);
    for (let y = 3; y < 13; y++) { const t = (y - 8) / 5; const hw = Math.round(5 * Math.sqrt(Math.max(0, 1 - t * t))); p(8 - hw, y, hw * 2, 1, art.color); }
    for (const x of [5, 8, 10]) for (let y = 4; y < 12; y++) if ((y + x) % 3) p(x + ((y >> 1) % 2), y, 1, 1, art.color3);
    p(6, 5, 2, 1, art.color2); p(5, 6, 1, 2, art.color2);
  },
};

// ---------------------------------------------------------------------
// DECORAÇÕES CONTEXTUAIS (autotile 'deco'): cada decoração tem uma arte para cada situação (ver DECO em world/autotile.js).
// O desenho é sempre feito "de pé" (apoio embaixo); decorações de teto (anchor 'up') são espelhadas na vertical.
// Os pedaços extras (cobertura rasteira, vinha de parede, caule) começam e terminam exatamente nas bordas do tile,
// então a decoração continua de um tile para o vizinho sem emenda.
// ---------------------------------------------------------------------
const ESTILOS_DE_ALTURA_TOTAL = new Set(['decoRoot', 'forkedVine', 'costelaArco', 'cortinaDeRaizes']);   // já ocupam o tile todo: nas pilhas só o caule continua

/** Cobertura rasteira ligando decorações vizinhas, de x0 a x1 (borda a borda). */
function tapete(p, art, r, x0, x1) {
  for (let x = x0; x < x1; x++) {
    p(x, 15, 1, 1, art.color);
    if (r() < 0.55) p(x, 14, 1, 1, art.color);
    if (r() < 0.2) p(x, 13, 1, 1, art.color2);
  }
}
/** Vinha subindo pela parede (lado 0 = esquerda, 1 = direita). */
function trepadeira(p, art, r, lado) {
  let x = 0; const alt = 7 + ((r() * 6) | 0);
  for (let y = 0; y < alt; y++) {
    if (r() < 0.3) x = 1 - x;
    p(lado ? 15 - x : x, 15 - y, 1, 1, art.color);
    if (y % 3 === 2) p(lado ? 14 - x : 1 + x, 15 - y, 1, 1, art.color2);   // folhinha
  }
}
/** Caule vertical que passa por x=7..8 nas duas bordas (liga com o tile de cima/baixo). */
function caule(p, art, r, y0, y1) {
  const bal = ((r() * 5) | 0) - 2;
  for (let y = y0; y <= y1; y++) {
    const x = 7 + Math.round(Math.sin((y / 15) * Math.PI) * bal);
    p(x, y, 2, 1, art.color); p(x, y, 1, 1, art.color2);
    if (y % 4 === 1 && y > y0 && y < y1) p(x + (y % 8 === 1 ? -2 : 2), y, 2, 1, art.color2);   // folhas alternadas
  }
}

export function desenharDeco(p, estilo, art, v, seed, nomeEstilo = '') {
  const r = aleatorio(seed ^ 0x5bd1e995);
  const base = (dx = 0, dy = 0) => estilo((x, y, w, h, c) => p(x + dx, y + dy, w, h, c), art, aleatorio(seed));   // mesma arte-base em todas as variantes
  const cheia = ESTILOS_DE_ALTURA_TOTAL.has(nomeEstilo);
  switch (v) {
    case DECO.PONTA_ESQ: base(); tapete(p, art, r, 8, 16); break;
    case DECO.MEIO: base(); tapete(p, art, r, 0, 16); break;
    case DECO.PONTA_DIR: base(); tapete(p, art, r, 0, 8); break;
    case DECO.PAREDE_ESQ: base(1, 0); trepadeira(p, art, r, 0); break;
    case DECO.PAREDE_DIR: base(-1, 0); trepadeira(p, art, r, 1); break;
    case DECO.ESPREMIDA: base(); trepadeira(p, art, r, 0); trepadeira(p, art, r, 1); break;
    case DECO.SOLTA:   // sem onde se prender: sobe um pouco e deixa fragmentos caídos no lugar do apoio
      base(0, -3); for (let i = 0; i < 4; i++) p(2 + ((r() * 12) | 0), 12 + ((r() * 4) | 0), 1, 1, i % 2 ? art.color2 : art.color); break;
    case DECO.BASE_PILHA: caule(p, art, r, 0, 15); if (!cheia) base(); break;
    case DECO.MEIO_PILHA: caule(p, art, r, 0, 15); break;
    case DECO.TOPO_PILHA: caule(p, art, r, 7, 15); if (!cheia) base(0, -5); else p(7, 6, 2, 1, art.color2); break;
    default: base();   // SOLO
  }
}

/** Contorno do autotile: IRREGULAR (falhas, 1-2 px de espessura, pontos de luz soltos), nunca uma moldura reta de 16px. */
function bordasAutotile(p, modo, mascara, art, r) {
  const escuro = '#12060bcc'; const luz = (art.color2 || '#ffffff') + '55';
  // CONTORNO da silhueta (como nas variantes do spritesheet PNG): contínuo nos lados SEM vizinho, mas ondulado (passeio
  // aleatório de 0-1 px e espessura 1-2 px), então delimita o terreno sem virar régua nem moldura quadrada nos lados conectados
  const lado = (exposto, f) => { if (!exposto) return; let o = 0; for (let i = 0; i < 16; i++) { const q = r(); if (q < 0.04) continue; if (r() < 0.22) o = 1 - o; f(i, q > 0.9 ? 2 : 1, o); } };
  lado(!(mascara & 1), (i, t, o) => p(i, o, 1, t, escuro));
  lado(!(mascara & 4), (i, t, o) => p(i, 16 - t - o, 1, t, escuro));
  lado(!(mascara & 8), (i, t, o) => p(o, i, t, 1, escuro));
  lado(!(mascara & 2), (i, t, o) => p(16 - t - o, i, t, 1, escuro));
  if (!(mascara & 1)) for (let i = 0; i < 4; i++) p((r() * 14) | 0, 1 + ((r() * 2) | 0), 1 + ((r() * 2) | 0), 1, luz);   // brilho esparso sob a borda de cima
  if (modo === 'blob47') {
    const canto = (x, y) => { p(x, y, 2, 1, escuro); p(x + (x ? 1 : 0), y + (y ? -1 : 1), 1, 1, escuro); };
    if ((mascara & 1) && (mascara & 2) && !(mascara & 16)) canto(14, 0);
    if ((mascara & 2) && (mascara & 4) && !(mascara & 32)) canto(14, 15);
    if ((mascara & 4) && (mascara & 8) && !(mascara & 64)) canto(0, 15);
    if ((mascara & 8) && (mascara & 1) && !(mascara & 128)) canto(0, 0);
  }
}

/**
 * Cria o atlas sem padding exagerado para garantir que o corte do drawImage seja 1:1 limpo.
 */
export const VARIACOES = 4;   // texturas alternativas por tile (escolhidas por posição) para quebrar a repetição de 16 px

export function createTileAtlas(catalogo, tamanhoTile, fabricaCanvas, opcoes = {}) {
  const bordas = opcoes.bordas !== false;
  const celulas = [];
  for (const tile of catalogo.all()) {
    const n = tile.autotile ? variantCount(tile.autotile.mode) : 1;
    for (let v = 0; v < n; v++) for (let k = 0; k < VARIACOES; k++) celulas.push({ tile, v, k });
  }
  
  const colunas = Math.max(1, Math.min(16, celulas.length));
  const linhas = Math.ceil(celulas.length / colunas);
  
  const stride = tamanhoTile;
  
  const canvas = fabricaCanvas(colunas * stride, linhas * stride);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  
  const indice = new Map();
  
  celulas.forEach(({ tile, v, k }, i) => {
    const col = i % colunas;
    const row = Math.floor(i / colunas);
    
    const ox = col * stride;
    const oy = row * stride;
    
    indice.set(tile.id * 64 + v + k * 1000000, { sx: ox, sy: oy });
    
    const u = tamanhoTile / 16;
    const p = (x, y, w, h, cor) => { 
      ctx.fillStyle = cor; 
      ctx.fillRect(ox + Math.round(x * u), oy + Math.round(y * u), Math.max(1, Math.round(w * u)), Math.max(1, Math.round(h * u))); 
    };
    
    // A célula do atlas é uma máscara rígida: nenhum pixel de uma silhueta pode invadir o tile vizinho.
    // Isso protege especialmente as pontas inclinadas dos espinhos e elimina vazamentos em forma de retângulo.
    ctx.save();
    ctx.beginPath(); ctx.rect(ox, oy, stride, stride); ctx.clip();
    const deco = tile.autotile && tile.autotile.mode === 'deco';
    const art = tile.autotile && !deco ? { ...tile.art, flat: true } : tile.art;
    const estilo = ESTILOS[art.style] || ESTILOS.block;
    if (deco) {   // decoração contextual: arte própria por situação; as de teto são espelhadas na vertical
      const pf = tile.autotile.anchor === 'up' ? (x, y, w, h, c) => p(x, 16 - y - h, w, h, c) : p;
      desenharDeco(pf, estilo, art, v, tile.id * 7919 + k * 104729, art.style);
    } else estilo(p, art, aleatorio(tile.id * 7919 + k * 104729));
    if (tile.autotile && !deco && bordas) bordasAutotile(p, tile.autotile.mode, variantMask(tile.autotile.mode, v), art, aleatorio(tile.id * 31 + v * 17 + k * 977));
    ctx.restore();
  });
  
  return { 
    canvas, 
    tileSize: tamanhoTile, 
    cols: colunas, 
    posicao: (id, variante = 0, variacao = 0) => indice.get(id * 64 + variante + (variacao % VARIACOES) * 1000000) 
  };
}
