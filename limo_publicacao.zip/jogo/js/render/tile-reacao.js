// =====================================================================
// TILES REATIVOS (v1.28.0) — a decoração se mexe quando o Limo ou um inimigo passa.
// SÓ VISUAL: nada aqui toca colisão, física, dano ou save. Quem não existir (editor, testes antigos) desenha como sempre.
//
// Como funciona
//  1) Células de decoração (decoBack, decoFront, foreground) com um "perfil" de reação são separadas do cache
//     estático da sala (o renderer pula essas células ao montar o cache) e desenhadas aqui, quadro a quadro.
//     Em repouso o desenho é IDÊNTICO ao do cache (mesmo tile, mesma variante, mesma textura).
//  2) Células coladas na vertical (cipó de vários tiles, pilha de fungos...) formam uma CADEIA com uma só mola:
//     o corpo todo se curva junto e as emendas entre tiles ficam contínuas.
//  3) Cada cadeia é uma mola amortecida. Corpos (Limo e inimigos) a empurram quando a atravessam: ela se
//     curva enquanto é empurrada e, ao soltar, volta com sobra (balança), como gelatina.
//  4) Cadeias vizinhas na horizontal recebem parte do impulso: forma-se uma ondinha pelo capim.
//
// Perfis (por art.style, ou por "reacao" no tiles.json):
//   balanco — plantas, raízes, cipós: curva-se com a ponta solta (a base fica presa)
//   esmaga  — fungos, bolhas, corais: amassa e estica como gelatina
//   treme   — ossos, fósseis, conchas: chacoalha curto, sem dobrar
//   (esporos: N — solta N grãozinhos luminosos ao ser tocado)
// =====================================================================

export const CAMADAS_REATIVAS = ['decoBack', 'decoFront', 'foreground'];

export const TIPOS_REACAO = ['balanco', 'esmaga', 'treme', 'nenhuma'];

// Constantes de mola por tipo: k = rigidez, c = amortecimento, amp = px na ponta de 1 tile com força 1.
const MOLAS = {
  balanco: { k: 85, c: 4.6, amp: 3.4 },
  pendulo: { k: 52, c: 3.0, amp: 4.4 },   // balanco de coisa pendurada no teto: mais lento e mais largo
  esmaga: { k: 150, c: 7.5, amp: 0 },
  treme: { k: 620, c: 13, amp: 1.5 },
};

/** Perfil padrão pelo estilo da arte. forca: 0..3 (1 = normal). */
export const PERFIS_POR_ESTILO = {
  decoPlant: { tipo: 'balanco', forca: 1 },
  sporeFlower: { tipo: 'balanco', forca: 1.1, esporos: 3 },
  decoRoot: { tipo: 'balanco', forca: 1 },
  forkedVine: { tipo: 'balanco', forca: 1.15 },
  fgRoot: { tipo: 'balanco', forca: 1.2 },
  decoGlow: { tipo: 'balanco', forca: 0.9, esporos: 3 },
  decoFungus: { tipo: 'esmaga', forca: 1, esporos: 2 },
  sporeLamp: { tipo: 'esmaga', forca: 0.8, esporos: 3 },
  coralDeco: { tipo: 'esmaga', forca: 0.7 },
  mucusBubble: { tipo: 'esmaga', forca: 1.3 },
  boneShard: { tipo: 'treme', forca: 1 },
  fossilDeco: { tipo: 'treme', forca: 0.7 },
  shellDeco: { tipo: 'treme', forca: 0.9 },
};

/** Perfil de um tile do catálogo ({tipo, forca, esporos, ancora, cor}) ou null se ele não reage. */
export function perfilDoTile(tile) {
  if (!tile || tile.collision !== 'none') return null;
  const estilo = tile.art?.style || '';
  if (estilo === 'bg' || estilo === 'vein' || tile.mecanica) return null;   // fundos e tiles com mecânica própria ficam de fora
  let p = tile.reacao || PERFIS_POR_ESTILO[estilo] || (tile.autotile?.mode === 'deco' ? { tipo: 'balanco', forca: 1 } : null);
  if (!p || p.tipo === 'nenhuma') return null;
  const ancora = tile.autotile?.anchor === 'up' ? 'up' : 'down';
  return { tipo: p.tipo, forca: p.forca ?? 1, esporos: p.esporos ?? 0, ancora, cor: tile.art?.color2 || tile.art?.color || '#caff91' };
}

/** Valida o campo opcional "reacao" de um tile do tiles.json. Devolve lista de erros. */
export function validarReacao(nome, r) {
  if (r === undefined) return [];
  const erros = [];
  if (!r || typeof r !== 'object') return [`${nome}: "reacao" deve ser um objeto.`];
  if (!TIPOS_REACAO.includes(r.tipo)) erros.push(`${nome}: reacao.tipo deve ser ${TIPOS_REACAO.join(', ')}.`);
  if (r.forca !== undefined && !(typeof r.forca === 'number' && r.forca >= 0 && r.forca <= 3)) erros.push(`${nome}: reacao.forca deve estar entre 0 e 3.`);
  if (r.esporos !== undefined && !(Number.isInteger(r.esporos) && r.esporos >= 0 && r.esporos <= 6)) erros.push(`${nome}: reacao.esporos deve ser inteiro de 0 a 6.`);
  return erros;
}

const limita = (v, a, b) => (v < a ? a : v > b ? b : v);
const REPOUSO = 0.012;

export class ReacaoTiles {
  /**
   * @param mapa TileMap  @param opcoes {ligado, maxEsporos, forca}
   * O objeto fica ligado a UM mapa; se o mapa mudar (editor, parede quebrada), `sincronizar()` reconstrói as cadeias.
   */
  constructor(mapa, opcoes = {}) {
    this.mapa = mapa;
    this.ligado = opcoes.ligado !== false;
    this.forcaGlobal = opcoes.forca ?? 1;
    this.maxEsporos = opcoes.maxEsporos ?? 36;
    this.esporos = [];
    this._rev = -1;
    this._ativas = new Set();
    this.cadeias = []; this._masc = {}; this._porCelula = new Map();
    this.sincronizar();
  }

  /** Reconstrói cadeias e máscaras quando o mapa foi editado (revision mudou). Barato: salas têm poucas dezenas de células. */
  sincronizar() {
    const m = this.mapa; if (!m || this._rev === m.revision) return;
    this._rev = m.revision; this._ativas.clear(); this.cadeias = []; this._masc = {}; this._porCelula = new Map();
    const w = m.width; const h = m.height; const ts = m.tileSize;
    for (const nome of CAMADAS_REATIVAS) {
      const dados = m.layers[nome]; if (!dados) continue;
      const masc = new Uint8Array(w * h); const perfis = new Array(w * h).fill(null);
      let algum = false;
      for (let i = 0; i < dados.length; i++) {
        if (!dados[i]) continue;
        const p = perfilDoTile(m.catalog.get(dados[i]));
        if (p) { perfis[i] = p; masc[i] = 1; algum = true; }
      }
      if (!algum) continue;
      this._masc[nome] = masc;
      // cadeia = sequência vertical de células reativas da mesma camada e do mesmo lado de apoio
      const visto = new Uint8Array(w * h);
      for (let x = 0; x < w; x++) {
        let y = 0;
        while (y < h) {
          const i0 = y * w + x;
          if (!masc[i0] || visto[i0]) { y++; continue; }
          let y1 = y; while (y1 + 1 < h && masc[(y1 + 1) * w + x] && perfis[(y1 + 1) * w + x].ancora === perfis[i0].ancora && perfis[(y1 + 1) * w + x].tipo === perfis[i0].tipo) y1++;
          const celulas = [];
          for (let yy = y; yy <= y1; yy++) {
            const i = yy * w + x; visto[i] = 1;
            const esq = x === 0 || this._solido(x - 1, yy); const dir = x === w - 1 || this._solido(x + 1, yy);
            celulas.push({ tx: x, ty: yy, i, nivel: 0, id: dados[i], esq, dir });
          }
          const p = perfis[i0]; const altura = celulas.length;
          celulas.forEach((c, k) => { c.nivel = p.ancora === 'down' ? altura - 1 - k : k; });   // 0 = célula presa ao apoio
          const mola = p.tipo === 'balanco' ? (p.ancora === 'up' ? MOLAS.pendulo : MOLAS.balanco) : MOLAS[p.tipo];
          const ch = { camada: nome, perfil: p, mola, celulas, altura, x: 0, v: 0, alvo: 0, tocando: false, tocouAntes: false, vizEsq: null, vizDir: null, amp: Math.min(6, mola.amp * p.forca * (0.75 + 0.25 * Math.min(altura, 3))) };
          for (const c of celulas) this._porCelula.set(nome + ':' + c.i, ch);
          this.cadeias.push(ch);
          y = y1 + 1;
        }
      }
    }
    // vizinhas na horizontal (para a ondinha): cadeia que ocupa uma coluna ao lado e se sobrepõe em altura
    for (const ch of this.cadeias) {
      const c0 = ch.celulas[0]; const y0 = ch.celulas[0].ty; const y1 = ch.celulas[ch.celulas.length - 1].ty;
      for (let yy = y0; yy <= y1; yy++) {
        const e = this._porCelula.get(ch.camada + ':' + (yy * w + c0.tx - 1)); const d = this._porCelula.get(ch.camada + ':' + (yy * w + c0.tx + 1));
        if (e && !ch.vizEsq) ch.vizEsq = e; if (d && !ch.vizDir) ch.vizDir = d;
      }
    }
    this.espessura = ts;
  }

  _solido(tx, ty) {
    const m = this.mapa;
    for (const n of ['solid', 'platform']) { const id = m.getTileId(n, tx, ty); if (id && m.catalog.get(id)?.collision !== 'none') return true; }
    return false;
  }

  /** Máscara (1 = reativa) da camada, para o renderer pular essas células no cache. null se a camada não tem nenhuma. */
  mascara(nome) { return this._masc[nome] || null; }

  /** Há alguma célula reativa nesta sala? */
  get temCelulas() { return this.cadeias.length > 0; }

  /** Quantas cadeias estão se mexendo agora (diagnóstico). */
  get ativas() { return this._ativas.size; }

  /** Empurra as cadeias com a força `f` (-1..1, o sinal é a direção). Também usado por testes e por efeitos externos. */
  empurrar(ch, f, forte = 1) {
    if (!ch) return;
    ch.v += f * 11 * forte * this.forcaGlobal * (ch.perfil.tipo === 'treme' ? 0.7 : 1);
    this._ativas.add(ch);
    if (ch.perfil.tipo === 'esmaga') { ch.s = ch.s || 0; ch.sv = (ch.sv || 0) + Math.abs(f) * 4.2 * forte; }
    if (ch.perfil.esporos && Math.abs(f) > 0.25) this._soltarEsporos(ch, Math.ceil(ch.perfil.esporos * Math.abs(f) * 0.7), f);
  }

  _soltarEsporos(ch, n, f) {
    const ts = this.mapa.tileSize; const c = ch.celulas[ch.celulas.length > 1 ? (ch.perfil.ancora === 'down' ? 0 : ch.celulas.length - 1) : 0];
    for (let k = 0; k < n && this.esporos.length < this.maxEsporos; k++) {
      this.esporos.push({
        x: c.tx * ts + 3 + Math.random() * (ts - 6), y: c.ty * ts + (ch.perfil.ancora === 'down' ? 3 : ts - 3) + Math.random() * 4 - 2,
        vx: f * (8 + Math.random() * 16) + (Math.random() - 0.5) * 10, vy: -(10 + Math.random() * 18),
        vida: 0.7 + Math.random() * 0.7, max: 1.4, cor: ch.perfil.cor, g: 7 + Math.random() * 6, fase: Math.random() * 6.28,
      });
    }
  }

  /**
   * Passo de lógica. `corpos` = [{x,y,w,h,vx,vy}] (Limo e inimigos vivos; só leitura).
   * Cada corpo que encosta numa cadeia a empurra na direção em que anda; ao ENTRAR dá um tranco (proporcional à velocidade).
   */
  atualizar(dt, corpos = []) {
    if (!this.ligado) return;
    this.sincronizar();
    if (!this.cadeias.length) return;
    dt = Math.min(dt, 1 / 30);
    const m = this.mapa; const ts = m.tileSize; const w = m.width;
    for (const ch of this._ativas) ch.alvo = 0;   // recalculado abaixo (só cadeias ativas ou tocadas)
    const tocadas = new Set();
    for (const b of corpos) {
      if (!b || !b.w) continue;
      const vx = b.vx || 0; const vy = b.vy || 0; const vel = Math.hypot(vx, vy);
      const tx0 = Math.max(0, Math.floor((b.x - 1) / ts)); const tx1 = Math.min(w - 1, Math.floor((b.x + b.w + 1) / ts));
      const ty0 = Math.max(0, Math.floor((b.y - 1) / ts)); const ty1 = Math.min(m.height - 1, Math.floor((b.y + b.h + 1) / ts));
      const peso = limita(b.w / 11, 0.8, 2);
      for (const nome of CAMADAS_REATIVAS) {
        const masc = this._masc[nome]; if (!masc) continue;
        for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
          const i = ty * w + tx; if (!masc[i]) continue;
          const ch = this._porCelula.get(nome + ':' + i); if (!ch) continue;
          tocadas.add(ch);
          if (vel < 14) continue;   // parado dentro da planta: ela só descansa
          const dir = Math.abs(vx) > 14 ? Math.sign(vx) : Math.sign((b.x + b.w / 2) - (tx * ts + ts / 2)) || 1;
          const forca = limita(vel / 150, 0, 1.5) * peso;
          ch.alvo = limita(ch.alvo + dir * forca * 0.9, -1.2, 1.2);   // enquanto encosta, a cadeia é segurada curvada
          this._ativas.add(ch);
          if (!ch.tocouAntes) {   // primeiro quadro de contato: tranco + ondinha nas vizinhas
            this.empurrar(ch, dir * limita(forca, 0.25, 1.4));
            if (ch.vizEsq) this.empurrar(ch.vizEsq, dir * forca * 0.35, 0.6);
            if (ch.vizDir) this.empurrar(ch.vizDir, dir * forca * 0.35, 0.6);
          }
          if (ch.perfil.tipo === 'esmaga') ch.sAlvo = Math.max(ch.sAlvo || 0, limita(Math.abs(vy) / 220 + forca * 0.25, 0, 0.6));
        }
      }
    }
    for (const ch of this.cadeias) { ch.tocouAntes = tocadas.has(ch); }
    for (const ch of this._ativas) {
      const { k, c } = ch.mola;
      ch.v += (-k * (ch.x - ch.alvo) - c * ch.v) * dt; ch.x += ch.v * dt;
      ch.x = limita(ch.x, -1.5, 1.5);
      if (ch.perfil.tipo === 'esmaga') {
        const alvo = tocadas.has(ch) ? (ch.sAlvo || 0) : 0; ch.sAlvo = 0;
        ch.sv = (ch.sv || 0) + (-MOLAS.esmaga.k * ((ch.s || 0) - alvo) - MOLAS.esmaga.c * (ch.sv || 0)) * dt;
        ch.s = limita((ch.s || 0) + ch.sv * dt, -0.4, 0.62);
      }
      const parado = Math.abs(ch.x) < REPOUSO && Math.abs(ch.v) < REPOUSO * 6 && Math.abs(ch.alvo) < REPOUSO && Math.abs(ch.s || 0) < REPOUSO && Math.abs(ch.sv || 0) < REPOUSO * 6;
      if (parado && !tocadas.has(ch)) { ch.x = ch.v = ch.alvo = 0; ch.s = ch.sv = 0; this._ativas.delete(ch); }
    }
    // esporos: sobem devagar, balançam e somem
    for (let k = this.esporos.length - 1; k >= 0; k--) {
      const e = this.esporos[k]; e.vida -= dt;
      if (e.vida <= 0) { this.esporos[k] = this.esporos[this.esporos.length - 1]; this.esporos.pop(); continue; }
      e.fase += dt * 7; e.vy += e.g * dt * 0.5 - 14 * dt; e.vx *= 1 - 1.8 * dt; e.vy *= 1 - 1.2 * dt;
      e.x += (e.vx + Math.sin(e.fase) * 6) * dt; e.y += e.vy * dt;
    }
  }

  /** Esquece o estado dinâmico (troca de sala, reinício). */
  reset() { for (const ch of this.cadeias) { ch.x = ch.v = ch.alvo = 0; ch.s = ch.sv = 0; ch.tocouAntes = false; } this._ativas.clear(); this.esporos.length = 0; }

  /**
   * Desenha as células reativas das camadas pedidas (ex.: ['decoBack','decoFront']) dentro da janela da câmera.
   * @param graphics TileGraphics (fonte(id, variante, vari))   @returns quantos tiles foram desenhados
   */
  desenhar(ctx, graphics, camX, camY, viewW, viewH, camadas) {
    if (!this.ligado) return 0;
    const m = this.mapa; const ts = m.tileSize; let n = 0;
    const x0 = camX - 8; const y0 = camY - 8; const x1 = camX + viewW + 8; const y1 = camY + viewH + 8;
    for (const ch of this.cadeias) {
      if (!camadas.includes(ch.camada)) continue;
      const c0 = ch.celulas[0]; const cN = ch.celulas[ch.celulas.length - 1];
      if (c0.tx * ts + ts < x0 || c0.tx * ts > x1 || c0.ty * ts + ts < y0 || cN.ty * ts > y1) continue;
      const ativa = this._ativas.has(ch);
      const variantes = m.autotile[ch.camada];
      for (const c of ch.celulas) {
        const px = c.tx * ts - camX; const py = c.ty * ts - camY;
        const vari = ((c.tx * 73856093) ^ (c.ty * 19349663)) & 3;
        const variante = variantes ? variantes[c.i] : 0;
        if (!ativa) { if (graphics.draw(ctx, c.id, variante, px, py, ts, vari)) n++; continue; }
        const f = graphics.fonte(c.id, variante, vari); if (!f) continue;
        n++;
        this._desenharCelula(ctx, f, ch, c, px, py, ts);
      }
    }
    return n;
  }

  _desenharCelula(ctx, f, ch, c, px, py, ts) {
    const tipo = ch.perfil.tipo; const baixo = ch.perfil.ancora === 'down';
    if (tipo === 'treme') {   // chacoalha sem dobrar: desloca o tile todo (inteiro, 1 a 2 px)
      const dx = Math.round(ch.x * ch.amp); ctx.drawImage(f.img, f.sx, f.sy, f.sw, f.sh, px + this._limitaLado(dx, c), py, ts, ts); return;
    }
    if (tipo === 'esmaga') {   // amassa em volta da base da cadeia (contínuo entre as células) e alarga um pouco
      const s = ch.s || 0; const escala = 1 - s; const larg = ts * (1 + s * 0.38);
      const yBase = baixo ? (py + ts * (c.nivel + 1)) : (py - ts * c.nivel);   // borda da célula presa ao apoio
      const altD = ts * escala; const topo = baixo ? yBase - (c.nivel + 1) * altD : yBase + c.nivel * altD;
      const dx = Math.round(ch.x * 0.9);
      const xl = px - (larg - ts) / 2 + (c.esq && dx < 0 ? 0 : (c.dir && dx > 0 ? 0 : dx));
      ctx.drawImage(f.img, f.sx, f.sy, f.sw, f.sh, Math.round(xl), Math.round(topo), Math.round(larg), Math.max(1, Math.round(altD) + 1));
      return;
    }
    // balanço: fatias horizontais deslocadas conforme a distância até o apoio (base parada, ponta solta)
    const alt = ch.altura * ts; let r0 = 0; let offAnt = null;
    const desloc = (r) => {
      const d = baixo ? ts - 1 - r + 0.5 : r + 0.5;   // px até a borda presa ao apoio
      const u = (c.nivel * ts + d) / alt;
      return this._limitaLado(Math.round(ch.x * ch.amp * Math.pow(u, 1.6)), c);
    };
    offAnt = desloc(0);
    for (let r = 1; r <= ts; r++) {
      const off = r < ts ? desloc(r) : null;
      if (off !== offAnt) { ctx.drawImage(f.img, f.sx, f.sy + r0, f.sw, r - r0, px + offAnt, py + r0, ts, r - r0); r0 = r; offAnt = off; }
    }
  }

  /** Não deixa a arte entrar na parede ao lado (a decoração é desenhada depois do cenário sólido). */
  _limitaLado(dx, c) { return (dx < 0 && c.esq) || (dx > 0 && c.dir) ? 0 : dx; }

  /** Grãos de esporo no mundo (desenhados na frente da decoração). */
  desenharEsporos(ctx, camX, camY) {
    for (const e of this.esporos) {
      const a = limita(e.vida / 0.5, 0, 1) * limita((e.max - e.vida) / 0.12 + 0.3, 0, 1);
      if (a <= 0.05) continue;
      ctx.globalAlpha = a; ctx.fillStyle = e.cor; ctx.fillRect(Math.round(e.x - camX), Math.round(e.y - camY), 1, 1);
    }
    ctx.globalAlpha = 1;
  }
}

/** Corpos que movem a decoração: o Limo e os inimigos vivos (cópias leves, sem tocar nas entidades). */
export function corposReativos(game) {
  const lista = [];
  const p = game.player;
  if (p && p.body && p.life > 0) lista.push({ x: p.body.x, y: p.body.y, w: p.body.w, h: p.body.h, vx: p.vx || 0, vy: p.vy || 0 });
  for (const e of game.enemies || []) if (e.alive && e.body && !e.intro) lista.push({ x: e.body.x, y: e.body.y, w: e.body.w, h: e.body.h, vx: e.vx || 0, vy: e.vy || 0 });
  return lista;
}
