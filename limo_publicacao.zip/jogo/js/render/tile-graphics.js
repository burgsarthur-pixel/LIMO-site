// =====================================================================
// GRÁFICOS DOS TILES: decide de onde vem a imagem de cada tile.
//  1) spritesheet PNG (autotile.set ou sprite), se a imagem carregou e o quadradinho existe;
//  2) senão, a arte provisória por código (atlas). Nada quebra se o PNG faltar.
// =====================================================================
import { spriteSourceRect, spriteInsideImage } from '../world/tileset.js';
import { variantCell } from '../world/autotile.js';
import { createTileAtlas } from './tile-art.js';

export class TileGraphics {
  /** @param tilesets Map(id -> {def, image, width, height, ok}) vindo do tileset-loader */
  constructor(catalogo, tamanhoTile, fabricaCanvas, tilesets = new Map(), logger = null, opcoes = {}) {
    this.catalog = catalogo; this.tileSize = tamanhoTile; this.tilesets = tilesets; this.logger = logger;
    this.fabrica = fabricaCanvas; this.opcoes = { bordas: opcoes.bordas !== false };
    this.atlas = createTileAtlas(catalogo, tamanhoTile, fabricaCanvas, this.opcoes);
    this._cache = new Map(); this._avisados = new Set();
  }

  _aviso(chave, texto) {
    if (this._avisados.has(chave)) return;
    this._avisados.add(chave); this.logger?.warn('tilemap', texto);
  }

  /** Liga/desliga os contornos de autotile da arte provisória (diagnóstico de linhas) e refaz o atlas. */
  setBordas(ligado) {
    if (this.opcoes.bordas === !!ligado) return;
    this.opcoes.bordas = !!ligado; this.atlas = createTileAtlas(this.catalog, this.tileSize, this.fabrica, this.opcoes); this._cache.clear();
  }

  _fonte(id, variante, vari = 0) {
    const chave = (id * 64 + variante) + (vari % 4) * 1000000;
    if (this._cache.has(chave)) return this._cache.get(chave);
    const tile = this.catalog.get(id);
    let fonte = null;
    if (tile) {
      let ref = null;
      if (tile.autotile && tile.autotile.set) { const c = variantCell(tile.autotile, variante); ref = { set: tile.autotile.set, col: c.col, row: c.row }; }
      else if (tile.sprite) ref = tile.sprite;
      if (ref) {
        const ts = this.tilesets.get(ref.set);
        if (ts && ts.ok && spriteInsideImage(ts.def, ref.col, ref.row, ts.width, ts.height)) fonte = { img: ts.image, ...spriteSourceRect(ts.def, ref.col, ref.row) };
        else this._aviso(`${id}:${ref.set}`, `Tile ${id} (${tile.name}): spritesheet "${ref.set}" indisponível ou quadradinho (${ref.col},${ref.row}) fora da imagem; usando arte provisória.`);
      }
    }
    if (!fonte) {
      const pos = this.atlas.posicao(id, tile && tile.autotile ? variante : 0, vari);
      if (pos) fonte = { img: this.atlas.canvas, sx: pos.sx, sy: pos.sy, sw: this.tileSize, sh: this.tileSize };
    }
    this._cache.set(chave, fonte);
    return fonte;
  }

  /** Desenha o tile (id, variante) em (dx,dy). Devolve false se o tile não existe. */
  draw(ctx, id, variante, dx, dy, tamanho = this.tileSize, vari = 0) {
    const f = this._fonte(id, variante, vari);
    if (!f) return false;
    ctx.drawImage(f.img, f.sx, f.sy, f.sw, f.sh, dx, dy, tamanho, tamanho);
    return true;
  }

  /** Origem da imagem do tile ({img,sx,sy,sw,sh}) ou null: usada pelos tiles reativos para desenhar em fatias. */
  fonte(id, variante, vari = 0) { return this._fonte(id, variante, vari); }

  /** Origem do desenho (para testes e depuração): 'sheet' ou 'procedural'. */
  sourceKind(id, variante = 0) { const f = this._fonte(id, variante); return !f ? 'none' : (f.img === this.atlas.canvas ? 'procedural' : 'sheet'); }
}
