// =====================================================================
// PERNA DE ARANHA em pixel art, no estilo da Tecelã (arte oficial): coxa grossa e iluminada no topo, joelho em destaque,
// tíbia que afina até uma ponta afiada e escurece rumo à garra, tudo com CONTORNO PRETO de 1 px por perna.
// Paleta em verde de Limo (mesmos tons do corpo), para a pata parecer feita da mesma gosma.
// Usada pela mutação "Salto na Parede" (Limo agarrado à parede) e pelo ícone antigo da Muda.
// =====================================================================

/** Tons da pata do Limo: coxa = verde do corpo, tíbia = sombra → profundo, brilho = membrana/luz do Limo. */
import { lerp } from '../core/math.js';

export const PALETA_PATA_LIMO = Object.freeze({
  contorno: '#0b2514', coxa: '#3fae52', coxaLuz: '#84ed77', tibia: '#278843', tibiaEsc: '#176332', joelho: '#caff91',
});


/** Células (retângulos w×w) ao longo de um segmento que afina de w0 para w1. */
function segmento(x0, y0, x1, y1, w0, w1) {
  const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1); const cel = [];
  for (let i = 0; i <= n; i++) {
    const k = i / n; const w = Math.max(1, Math.round(lerp(w0, w1, k)));
    cel.push({ x: Math.round(lerp(x0, x1, k)) - Math.floor(w / 2), y: Math.round(lerp(y0, y1, k)) - Math.floor(w / 2), w, k });
  }
  return cel;
}

/**
 * Perna grossa de aranha: raiz (rx,ry) → joelho (kx,ky) → pé (fx,fy). Coordenadas de tela, em pixels.
 * grossura = largura da coxa (2 num Limo pequeno, 3+ em corpos maiores). A tíbia começa na mesma grossura e termina em ponta de 1 px.
 * fase: 'tudo' (contorno + cor) · 'contorno' · 'cor'. Para várias patas juntas, desenhe TODAS em 'contorno' e depois TODAS em 'cor':
 * assim elas dividem uma só silhueta (como na arte da Tecelã) em vez de uma cortar a outra com o contorno.
 */
export function pernaGrossa(ctx, rx, ry, kx, ky, fx, fy, { grossura = 2, paleta = PALETA_PATA_LIMO, brilho = true, fase = 'tudo' } = {}) {
  const P = paleta;
  const coxa = segmento(rx, ry, kx, ky, grossura, grossura);
  const tibia = segmento(kx, ky, fx, fy, grossura, 1);
  if (fase !== 'cor') {                                                          // contorno por baixo de tudo
    ctx.fillStyle = P.contorno;
    for (const c of coxa) ctx.fillRect(c.x - 1, c.y - 1, c.w + 2, c.w + 2);
    for (const c of tibia) ctx.fillRect(c.x - 1, c.y - 1, c.w + 2, c.w + 2);
  }
  if (fase === 'contorno') return;
  for (const c of tibia) { ctx.fillStyle = c.k < 0.45 ? P.tibia : P.tibiaEsc; ctx.fillRect(c.x, c.y, c.w, c.w); }   // tíbia escurece rumo à ponta
  ctx.fillStyle = P.coxa; for (const c of coxa) ctx.fillRect(c.x, c.y, c.w, c.w);
  if (brilho) {
    ctx.fillStyle = P.coxaLuz; for (const c of coxa) ctx.fillRect(c.x, c.y, c.w, 1);                // borda de cima iluminada
    ctx.fillStyle = P.joelho; ctx.fillRect(Math.round(kx) - Math.floor(grossura / 2), Math.round(ky) - Math.floor(grossura / 2), 1, 1);   // joelho brilha
  }
}

/** Compatível com o formato antigo (cor/luz únicas): usa a perna grossa com tons derivados das duas cores. */
export function pernaAranha(ctx, rx, ry, kx, ky, fx, fy, cor = '#3fae52', luz = '#d8ffb0') {
  pernaGrossa(ctx, rx, ry, kx, ky, fx, fy, { paleta: { ...PALETA_PATA_LIMO, contorno: cor, joelho: luz } });
}
