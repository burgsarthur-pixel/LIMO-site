// =====================================================================
// SPRITES OFICIAIS DA TECELÃ DAS RAÍZES (só apresentação visual).
// Lê o estado da IA (attackState/attackTimer/hurtTimer) e escolhe um frame do atlas oficial.
// Não altera hitbox, zonas de dano, timing nem estados. Se o PNG falhar, devolve null e o
// renderer usa a silhueta procedural apenas como proteção técnica.
// =====================================================================
import { clamp01 } from '../core/math.js';

export const TECELA_ATLAS = { src: 'assets/sprites/tecela_raizes_oficial_atlas.png', cellW: 64, cellH: 40, cols: 5 };
export const ANIM = { idle: 0, windup: 5, charge: 10, collapse: 15 };
export const COLLAPSE = { frameTime: 0.18, hold: 1.3, fade: 0.6 };

const passo = (base, p) => base + Math.min(4, Math.floor(clamp01(p) * 5));

/** Escolhe o frame (0..19) para o estado atual. Função pura, testável sem canvas. */
export function tecelaFrame(enemy, t = 0) {
  const e = enemy.attackState || ''; const c = enemy.cfg || {}; const timer = Math.max(0, enemy.attackTimer || 0);
  const prog = (dur) => (dur > 0 ? 1 - timer / dur : 1);
  switch (e) {
    case 'weaveTearWindup': return passo(ANIM.windup, prog(c.chargeWindup));
    case 'weaveStitchWindup': return passo(ANIM.windup, prog(c.stitchWindup));
    case 'weaveReturnWindup': return passo(ANIM.windup, prog(c.returnWindup));
    case 'weavePulseWindup': return passo(ANIM.windup, prog(c.pulseWindup));
    case 'weaveTear': return passo(ANIM.charge, prog(c.chargeDuration));
    case 'weaveReturnOut': return passo(ANIM.charge, prog(c.returnOut));
    case 'weaveReturnBack': return passo(ANIM.charge, 1 - prog(c.returnBack) - 0.001); // volta pelos mesmos frames, de trás para frente
    case 'weaveStitch': case 'weaveReturnHook': case 'weavePulse': return ANIM.windup + 4; // pose de pata erguida, reutilizada (a folha não tem frame próprio)
    default: return ANIM.idle + (Math.floor(t * 7) % 5);
  }
}

/** Frame da animação de derrota para um tempo t (s) desde a morte; alpha cai no final. */
export function tecelaColapso(tempo) {
  const f = Math.min(4, Math.floor(tempo / COLLAPSE.frameTime));
  const fim = COLLAPSE.frameTime * 5 + COLLAPSE.hold;
  return { frame: ANIM.collapse + f, alpha: tempo <= fim ? 1 : clamp01(1 - (tempo - fim) / COLLAPSE.fade), done: tempo >= fim + COLLAPSE.fade };
}

export async function loadTecelaSprite(logger = null, loadImage, makeCanvas) {
  try {
    const img = await loadImage(TECELA_ATLAS.src);
    const w = img.naturalWidth || img.width; const h = img.naturalHeight || img.height;
    if (w !== TECELA_ATLAS.cellW * TECELA_ATLAS.cols || h !== TECELA_ATLAS.cellH * 4) throw new Error(`dimensões inesperadas ${w}x${h}`);
    const flash = makeCanvas(w, h); const fc = flash.getContext('2d');
    fc.drawImage(img, 0, 0); fc.globalCompositeOperation = 'source-in'; fc.fillStyle = '#fff5ed'; fc.fillRect(0, 0, w, h);   // silhueta do golpe recebido
    logger?.info('carregamento', `Sprites oficiais da Tecelã carregados (${w}x${h}).`);
    return { image: img, flash, ...TECELA_ATLAS };
  } catch (e) {
    logger?.warn('carregamento', `Sprites oficiais da Tecelã não carregaram (${e.message}). Usando silhueta procedural de proteção.`);
    return null;
  }
}

/** Desenha o frame ancorado no centro/base da hitbox (rx, ry = canto da hitbox na tela). */
export function drawTecelaFrame(ctx, sp, frame, rx, ry, w, h, dir, { flash = false, alpha = 1, brilho = 0 } = {}) {
  const sx = (frame % sp.cols) * sp.cellW; const sy = Math.floor(frame / sp.cols) * sp.cellH;
  const cx = Math.round(rx + w / 2); const dy = Math.round(ry + h - sp.cellH);
  ctx.save(); ctx.imageSmoothingEnabled = false; ctx.globalAlpha = alpha;
  ctx.translate(cx, 0); if (dir < 0) ctx.scale(-1, 1);
  const dx = -sp.cellW / 2;
  ctx.drawImage(flash ? sp.flash : sp.image, sx, sy, sp.cellW, sp.cellH, dx, dy, sp.cellW, sp.cellH);
  if (brilho > 0 && !flash) { ctx.globalAlpha = alpha * brilho; ctx.drawImage(sp.flash, sx, sy, sp.cellW, sp.cellH, dx, dy, sp.cellW, sp.cellH); }
  ctx.restore();
}
