// =====================================================================
// SINAIS DAS CRIATURAS (v1.39.0) — pistas visuais do que a criatura está fazendo, para o jogador LER o comportamento:
//   dormindo  "z" subindo · alerta (território) "!" que pulsa · fugindo risquinhos de velocidade · curioso "?" ·
//   espreita  olhos brilhando · manso/sonolento um brotinho claro (o Deus está calmo).
// Só retângulos (1–5 por criatura visível), sem gradientes. Lê `enemy.cerebro.modo` e `enemy.ia`.
// =====================================================================
const COR = { z: '190,215,255', alerta: '255,120,100', fuga: '255,255,255', curioso: '140,255,220', olho: '255,230,120', broto: '170,255,170' };

/** Devolve a lista de sinais ativos (puro, testável): [{tipo, x, y}] em coordenadas de TELA. */
export function sinaisDaCriatura(e, camX, camY, t) {
  const c = e.cerebro; if (!c || !e.alive || e.intro) return [];
  const x = Math.round(e.centerX - camX); const y = Math.round(e.body.y - camY); const out = [];
  if (e.ia?.repouso) { const f = (t * 0.8) % 1; out.push({ tipo: 'z', x: x + 3 + Math.round(f * 3), y: y - 3 - Math.round(f * 6), a: 1 - f }); }
  if (e.ia?.alerta || c.modo === 'alerta') out.push({ tipo: 'alerta', x, y: y - 8 - (Math.sin(t * 10) > 0 ? 1 : 0) });
  if (e.ia?.fugir) out.push({ tipo: 'fuga', x: x - Math.sign(e.facing || 1) * 6, y: y + Math.round(e.body.h / 2) });
  if (c.modo === 'curioso') out.push({ tipo: 'curioso', x, y: y - 7 });
  if (c.modo === 'espreita') out.push({ tipo: 'olho', x: x + (e.facing >= 0 ? 2 : -3), y: y + 2 });
  if (c.temperamento !== 'normal' && !e.ia?.repouso && Math.sin(t * 2 + x) > 0.2) out.push({ tipo: 'broto', x: x - 1, y: y - 5 });
  return out;
}

export function desenharSinais(ctx, e, camX, camY, t) {
  const ss = sinaisDaCriatura(e, camX, camY, t); if (!ss.length) return 0;
  ctx.save();
  for (const s of ss) {
    const a = s.a ?? 1;
    if (s.tipo === 'z') { ctx.fillStyle = `rgba(${COR.z},${(0.85 * a).toFixed(2)})`; ctx.fillRect(s.x, s.y, 3, 1); ctx.fillRect(s.x + 1, s.y + 1, 1, 1); ctx.fillRect(s.x, s.y + 2, 3, 1); }
    else if (s.tipo === 'alerta') { ctx.fillStyle = `rgba(${COR.alerta},0.95)`; ctx.fillRect(s.x, s.y, 2, 4); ctx.fillRect(s.x, s.y + 5, 2, 2); }
    else if (s.tipo === 'fuga') { ctx.fillStyle = `rgba(${COR.fuga},0.6)`; ctx.fillRect(s.x, s.y - 2, 4, 1); ctx.fillRect(s.x - 1, s.y + 1, 5, 1); }
    else if (s.tipo === 'curioso') { ctx.fillStyle = `rgba(${COR.curioso},0.9)`; ctx.fillRect(s.x - 1, s.y, 3, 1); ctx.fillRect(s.x + 1, s.y + 1, 1, 1); ctx.fillRect(s.x, s.y + 2, 1, 1); ctx.fillRect(s.x, s.y + 4, 1, 1); }
    else if (s.tipo === 'olho') { ctx.fillStyle = `rgba(${COR.olho},0.95)`; ctx.fillRect(s.x, s.y, 1, 1); }
    else { ctx.fillStyle = `rgba(${COR.broto},0.85)`; ctx.fillRect(s.x, s.y, 1, 2); ctx.fillRect(s.x - 1, s.y, 1, 1); ctx.fillRect(s.x + 1, s.y, 1, 1); }
  }
  ctx.restore(); return ss.length;
}
