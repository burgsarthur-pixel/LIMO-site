// =====================================================================
// RENDERIZADOR (Canvas 2D)
// Só desenha. Percorre APENAS os tiles visíveis pela câmera (mapas grandes não custam mais).
// =====================================================================
import { LAYER_NAMES } from '../world/tilemap.js';
import { drawDevorador } from './devorador-art.js';   // Etapa 2.4.2: visual do Devorador de Flores (inerte até existir um chefe com esse padrão)
import { drawPastor } from './pastor-art.js';   // Etapa 2.3: forma base do Pastor das Vísceras
import { TileGraphics } from './tile-graphics.js';
import { drawPlayer } from './player-art.js';
import { computeDisplaySize } from '../core/display.js';
import { drawEntities, drawMutacao } from '../entities/entity-art.js';
import { drawRastros, drawBaloes, drawLembranca, drawDespertar } from './narrativa-art.js';
import { aleatorio } from './tile-art.js';
import { coletarLuzes, poligonoDeVisao } from './lighting.js';
import { SistemaFeixes } from './feixes.js';
import { ABILITIES } from '../entities/abilities.js';
import { temaDoBioma, temaLimpo, CHEFE_DO_BIOMA } from './biome-theme.js';
import { desenharColosso, desenharMotes } from './colosso.js';
import { personalidadeDaSala } from '../world/personalidade.js';
import { tecelaFrame, tecelaColapso, drawTecelaFrame } from './tecela-sprite.js';
import { drawTecelaProcedural, drawTecelaColapsoProcedural, drawTecelaIntro } from './tecela-art.js';
import { TendrilGosma, drawNoGosma } from './tendril-art.js';
import { drawOrganicTransitions } from './tile-transitions.js';
import { CamadaFrontal } from './polimento.js';
import { desenharSinais } from './criatura-sinais.js';
import { desenharMurais, desenharDicas, desenharDissolucao, desenharNevoa, desenharAtmosfera, desenharEsporelitos } from './vida-art.js';   // v1.38.0: mundo vivo
import { normalizarDepth } from './depth-config.js';
import { VolumeTiles } from './depth-volume.js';
import { ParallaxDepth } from './depth-parallax.js';

// Função para desenhar o inimigo básico com sombreamento reforçado
function drawFlyer(ctx, enemy, rx, ry) {
  const f = enemy.hurtTimer > 0; const bat = Math.sin(enemy.t * 22) > 0 ? 0 : 1;      // asas batendo
  ctx.fillStyle = 'rgba(255,170,220,0.55)'; ctx.fillRect(rx - 2, ry - 1 + bat, 4, 2); ctx.fillRect(rx + enemy.body.w - 2, ry - 1 + bat, 4, 2);
  ctx.fillStyle = f ? '#ffffff' : '#7a2f9b'; ctx.fillRect(rx + 1, ry, enemy.body.w - 2, enemy.body.h); ctx.fillRect(rx, ry + 2, enemy.body.w, enemy.body.h - 4);
  ctx.fillStyle = f ? '#ffffff' : '#c27be0'; ctx.fillRect(rx + 2, ry + 1, enemy.body.w - 4, 1);
  ctx.fillStyle = '#ffe135'; ctx.fillRect(rx + (enemy.facing > 0 ? enemy.body.w - 4 : 2), ry + 3, 2, 2);
}

function drawLeaper(ctx, enemy, rx, ry) {
  const f = enemy.hurtTimer > 0; const w = enemy.body.w; const h = enemy.body.h;
  ctx.fillStyle = 'rgba(0,0,0,0.45)'; ctx.fillRect(rx + 1, ry + h, w - 2, 2);
  ctx.fillStyle = f ? '#fff' : '#c7d95a'; ctx.fillRect(rx + 1, ry + 2, w - 2, h - 2);
  ctx.fillStyle = f ? '#fff' : '#eef59a'; ctx.fillRect(rx + 3, ry, w - 6, 3);
  ctx.fillStyle = '#5a6b2b'; ctx.fillRect(rx + (enemy.facing > 0 ? w - 4 : 2), ry + 4, 2, 2);
  ctx.fillStyle = '#f6ffcf'; ctx.fillRect(rx + 2, ry + h - 1, 3, 2); ctx.fillRect(rx + w - 5, ry + h - 1, 3, 2);
}

function drawArmored(ctx, enemy, rx, ry) {
  const f = enemy.hurtTimer > 0; const w = enemy.body.w; const h = enemy.body.h;
  ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(rx + 1, ry + h, w - 2, 2);
  ctx.fillStyle = f ? '#fff' : '#80959a'; ctx.fillRect(rx + 1, ry + 2, w - 2, h - 2);
  ctx.fillStyle = f ? '#fff' : '#c4d7cb'; ctx.fillRect(rx + 2, ry, w - 4, 5);
  ctx.fillStyle = '#334b50'; ctx.fillRect(rx + 3, ry + 6, w - 6, 2);
  ctx.fillStyle = '#f5d77a'; ctx.fillRect(rx + (enemy.facing > 0 ? w - 5 : 3), ry + 7, 2, 2);
}

function drawBarraChefe(ctx, enemy, rx, w, ry) {
  drawBarraDeChefe(ctx, enemy, rx, ry, w);
}

/** Barra de vida e nome do chefe (compartilhada pelos ramos de chefe). */
function drawBarraDeChefe(ctx, enemy, rx, ry, w) {
  const bw = 42; const bx = rx + Math.floor((w - bw) / 2); const by = ry - 11;
  ctx.fillStyle = '#1a0712'; ctx.fillRect(bx - 1, by - 1, bw + 2, 5);
  ctx.fillStyle = '#59263b'; ctx.fillRect(bx, by, bw, 3);
  ctx.fillStyle = '#ff5578'; ctx.fillRect(bx, by, Math.max(0, Math.round(bw * enemy.life / enemy.maxLife)), 3);
  ctx.fillStyle = '#f4d8dd'; ctx.font = '5px monospace'; ctx.textAlign = 'center'; ctx.fillText(enemy.name || 'CHEFE', rx + Math.floor(w / 2), by - 2);
}

/** Tecelã com a arte oficial: só escolhe frame/espelhamento; hitbox e zonas continuam vindo da IA. */
function drawTecelaOficial(ctx, enemy, rx, ry, sp, t) {
  const w = enemy.body.w; const h = enemy.body.h; const estado = enemy.attackState || '';
  const atacando = estado.startsWith('weave'); const dir = (atacando ? enemy.attackDir : 0) || enemy.facing || 1;
  const telegrafando = /Windup$/.test(estado); const alerta = telegrafando && Math.floor(enemy.attackTimer * 16) % 2 === 0;
  ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(rx + Math.floor(w / 2) - 16, ry + h, 32, 2);   // sombra no chão, na base da hitbox
  const tremor = estado === 'weavePulse' ? (Math.floor(t * 40) % 2 ? 1 : -1) : 0;
  drawTecelaFrame(ctx, sp, tecelaFrame(enemy, t), rx + tremor, ry, w, h, dir, { flash: enemy.hurtTimer > 0, brilho: alerta ? 0.28 : 0 });
  drawBarraChefe(ctx, enemy, rx, w, ry - 20);
}

/** Tecelã procedural (padrão): poses próprias por estado, como o Limo. Hitbox e zonas continuam vindo da IA. */
function drawTecelaProc(ctx, enemy, rx, ry, t) {
  const estado = enemy.attackState || ''; const atacando = estado.startsWith('weave');
  const dir = (atacando ? enemy.attackDir : 0) || enemy.facing || 1;
  drawTecelaProcedural(ctx, enemy, rx, ry, t, dir);
  drawBarraChefe(ctx, enemy, rx, enemy.body.w, ry - 20);
}

/** Casulo orgânico + saída da Tecelã (arte em tecela-art.js; usa enemy.introT, em segundos). */
function drawCasuloTecela(ctx, enemy, rx, ry, t) {
  drawTecelaIntro(ctx, enemy, rx, ry, t, enemy.facing || 1);
}

function drawBossIntroDialogue(ctx, intro, width, height) {
  if (!intro?.quote) return;
  const y = height - 31; ctx.save();
  ctx.fillStyle = 'rgba(19,5,15,0.88)'; ctx.fillRect(8, y, width - 16, 22);
  ctx.strokeStyle = '#a84b61'; ctx.strokeRect(8, y, width - 16, 22);
  ctx.fillStyle = '#f4d8dd'; ctx.font = '6px monospace'; ctx.textAlign = 'center';
  const words = intro.quote.split(' '); let line = ''; const lines = [];
  for (const word of words) { const next = `${line}${line ? ' ' : ''}${word}`; if (next.length > 38) { lines.push(line); line = word; } else line = next; }
  if (line) lines.push(line); lines.slice(0, 2).forEach((text, i) => ctx.fillText(text, width / 2, y + 8 + i * 7));
  ctx.restore();
}

function drawBoss(ctx, enemy, rx, ry, sprites, t) {
  if (enemy.bossPattern === 'tecelã') { if (enemy.intro) drawCasuloTecela(ctx, enemy, rx, ry, t); else if (sprites?.tecela) drawTecelaOficial(ctx, enemy, rx, ry, sprites.tecela, t); else drawTecelaProc(ctx, enemy, rx, ry, t); return; }
  if (enemy.bossPattern === 'pastor') { drawPastor(ctx, enemy, rx, ry, t); drawBarraDeChefe(ctx, enemy, rx, ry, enemy.body.w); return; }
  if (enemy.bossPattern === 'devorador') { drawDevorador(ctx, enemy, rx, ry, t); drawBarraDeChefe(ctx, enemy, rx, ry, enemy.body.w); return; }
  const w = enemy.body.w; const h = enemy.body.h; const estado = enemy.attackState || '';
  const telegrafando = /Windup$/.test(estado) || estado === 'windup';
  const alerta = telegrafando && Math.floor(enemy.attackTimer * 16) % 2 === 0;
  const ferida = enemy.hurtTimer > 0; const dir = enemy.attackDir || enemy.facing || 1;
  const costura = estado.startsWith('weaveStitch'); const retorno = estado.startsWith('weaveReturn'); const pulso = estado.startsWith('weavePulse');
  const tear = estado.startsWith('weaveTear'); const frente = dir > 0 ? rx + w - 3 : rx + 2;
  const escuro = '#160914'; const sombra = '#3b1630'; const carne = ferida ? '#fff5ed' : alerta ? '#bd536a' : '#83384f';
  // Silhueta da Tecelã: abdômen-costura, máscara e oito raízes. A postura continua expondo o golpe antes do impacto.
  ctx.fillStyle = escuro;
  for (let lado = -1; lado <= 1; lado += 2) {
    for (let i = 0; i < 4; i++) {
      const sy = ry + 6 + i * 2; const joelho = rx + (lado < 0 ? 3 - (i & 1) : w - 4 + (i & 1));
      const ponta = joelho + lado * (5 + (i % 2) * 2);
      ctx.fillRect(joelho, sy, lado * 3, 2); ctx.fillRect(ponta, sy + 2 + (i & 1), lado * 3, 2);
    }
  }
  if (costura) { // raízes viram agulhas e apontam o chão que será costurado
    ctx.fillStyle = '#c65a73';
    for (let i = 0; i < 4; i++) { const ox = rx + 3 + i * 5; ctx.fillRect(ox, ry + h - 2, 2, 6 + (i & 1)); ctx.fillRect(ox + dir * 2, ry + h + 3, 3, 2); }
  } else if (retorno) { // fio esticado e nó legível antes da volta
    ctx.fillStyle = '#e2b16d'; ctx.fillRect(frente, ry + 7, dir * 10, 1);
    ctx.fillStyle = escuro; ctx.fillRect(frente + dir * 7, ry + 5, 3, 5);
    if (estado === 'weaveReturnHook') { ctx.fillStyle = '#ffd27a'; ctx.fillRect(frente + dir * 8, ry + 4, 3, 5); }
  } else if (pulso) {
    ctx.fillStyle = '#bd536a'; ctx.fillRect(rx - 2, ry + 6, 3, 8); ctx.fillRect(rx + w - 1, ry + 6, 3, 8);
  } else if (tear) {
    ctx.fillStyle = '#e2b16d'; ctx.fillRect(frente, ry + 7, dir * 8, 1); ctx.fillRect(frente + dir * 6, ry + 5, 2, 6);
  }
  // Abdômen em camadas: carapaça, fios cruzados e núcleo ocular.
  ctx.fillStyle = escuro; ctx.fillRect(rx + 2, ry + 3, w - 4, h - 1); ctx.fillRect(rx + 4, ry + 1, w - 8, h + 1);
  ctx.fillStyle = sombra; ctx.fillRect(rx + 3, ry + 4, w - 6, h - 4);
  ctx.fillStyle = carne; ctx.fillRect(rx + 5, ry + 3, w - 10, h - 5);
  ctx.fillStyle = '#d77686'; ctx.fillRect(rx + 7, ry + 2, w - 14, 2); ctx.fillRect(rx + 6, ry + 5, 2, h - 8);
  ctx.fillStyle = '#4a1d35'; ctx.fillRect(rx + w - 8, ry + 5, 2, h - 8);
  ctx.fillStyle = escuro; ctx.fillRect(rx + 8, ry + 7, w - 16, 7);
  ctx.fillStyle = pulso ? '#ffd27a' : alerta ? '#fff4a3' : '#8cfff0'; ctx.fillRect(rx + 10, ry + 8, 6, 4);
  ctx.fillStyle = '#fff'; ctx.fillRect(rx + (dir > 0 ? 13 : 11), ry + 9, 2, 2);
  // Carretel vivo no alto: só acende no telegráfico, sem encobrir a leitura das zonas.
  if (telegrafando) { ctx.fillStyle = '#281020'; ctx.fillRect(rx + 9, ry - 4, 8, 4); ctx.fillStyle = alerta ? '#ffd27a' : '#9b405e'; ctx.fillRect(rx + 10, ry - 5, 6, 2); ctx.fillStyle = '#f4d8dd'; ctx.fillRect(rx + 12, ry - 3, 2, 5); }
  const bw = 42; const bx = rx + Math.floor((w - bw) / 2); const by = ry - 11;
  ctx.fillStyle = '#1a0712'; ctx.fillRect(bx - 1, by - 1, bw + 2, 5);
  ctx.fillStyle = '#59263b'; ctx.fillRect(bx, by, bw, 3);
  ctx.fillStyle = '#ff5578'; ctx.fillRect(bx, by, Math.max(0, Math.round(bw * enemy.life / enemy.maxLife)), 3);
  ctx.fillStyle = '#f4d8dd'; ctx.font = '5px monospace'; ctx.textAlign = 'center'; ctx.fillText(enemy.name || 'CHEFE', rx + Math.floor(w / 2), by - 2);
}

/** Rastejante: lesma de carne segmentada (contorno escuro, dorso com crista, olho que aponta a direção, pezinhos que andam). */
function drawCrawler(ctx, enemy, rx, ry) {
  const w = enemy.body.w; const h = enemy.body.h; const f = enemy.hurtTimer > 0; const dir = enemy.facing >= 0 ? 1 : -1; const t = enemy.t || 0;
  // Rebanho do Pastor (Etapa 2.3): mesmo tipo `crawler`, com aparência própria e um salto visual; a mecânica não muda.
  const rebanho = !!enemy.dono && enemy.dono.bossPattern === 'pastor';
  if (rebanho) ry -= Math.max(0, Math.round(Math.sin(t * 9) * 2));
  const cor = f ? '#ffffff' : rebanho ? '#c9e6d6' : '#a8434f'; const sombra = f ? '#ffffff' : rebanho ? '#7fa98f' : '#7a2f3a'; const luz = f ? '#ffffff' : rebanho ? '#eefbf1' : '#d9707a';
  const cabeca = dir > 0 ? w - 5 : 0; const ond = Math.round(Math.sin(t * 8));
  ctx.fillStyle = '#12060b'; ctx.fillRect(rx + 1, ry + 1 + ond * 0, w - 2, h - 1); ctx.fillRect(rx, ry + 3, w, h - 4);                      // contorno
  ctx.fillStyle = cor; ctx.fillRect(rx + 2, ry + 2, w - 4, h - 3); ctx.fillRect(rx + 1, ry + 4, w - 2, h - 6);
  ctx.fillStyle = sombra; ctx.fillRect(rx + 1, ry + h - 3, w - 2, 2);                                                                      // barriga
  for (let x = 3 + (dir > 0 ? 0 : 3); x < w - 4; x += 3) { ctx.fillStyle = sombra; ctx.fillRect(rx + x, ry + 2, 1, 2 + ond * (x % 2)); }    // segmentos
  ctx.fillStyle = luz; ctx.fillRect(rx + 3, ry + 2, Math.max(2, w - 8), 1);                                                                // crista de luz
  ctx.fillStyle = '#12060b'; ctx.fillRect(rx + cabeca, ry + 3, 5, 5);                                                                       // cabeça
  ctx.fillStyle = cor; ctx.fillRect(rx + cabeca + 1, ry + 4, 3, 3);
  ctx.fillStyle = '#ffffff'; ctx.fillRect(rx + cabeca + (dir > 0 ? 2 : 1), ry + 4, 2, 2);
  ctx.fillStyle = '#12060b'; ctx.fillRect(rx + cabeca + (dir > 0 ? 3 : 1), ry + 5, 1, 1);
  ctx.fillStyle = '#12060b'; const p0 = Math.floor(t * 10) % 2;                                                                            // pezinhos
  ctx.fillRect(rx + 2 + p0, ry + h, 2, 1); ctx.fillRect(rx + w - 5 - p0, ry + h, 2, 1);
}

/** Arte 16-bit dos telegráficos. A cor e a forma identificam o golpe mesmo sem ler UI. */
function drawBossZones(ctx, enemy, camX, camY) {
  const estado = enemy.attackState || ''; const pulso = estado.startsWith('weavePulse');
  for (const z of enemy.attackZones || []) {
    const ativo = z.active; const cor = ativo ? '#ffe5a0' : (z.cor || '#d45d78');
    ctx.save(); ctx.globalAlpha = ativo ? 0.95 : 0.62; ctx.strokeStyle = cor; ctx.fillStyle = cor;
    if (z.tipo === 'ground') {
      const x = Math.round(z.x - camX); const y = Math.round(z.y - camY);
      // Costura: fio fino e agulhas vermelhas antes, raízes claras e curtas no impacto.
      ctx.fillRect(x, y + 4, z.w, ativo ? 3 : 1);
      for (let px = 4; px < z.w - 2; px += 8) {
        if (ativo) { ctx.fillRect(x + px, y - 3, 3, 7); ctx.fillStyle = '#ff7a79'; ctx.fillRect(x + px + 1, y - 5, 1, 2); ctx.fillStyle = cor; }
        else { ctx.fillRect(x + px, y + 1, 2, 2); ctx.fillRect(x + px + 2, y + 3, 3, 1); }
      }
      if (z.telegraph) { ctx.fillStyle = '#6b2943'; ctx.fillRect(x, y + 6, z.w, 1); }
    } else if (z.tipo === 'path') {
      const x = Math.round(z.x - camX); const y = Math.round(z.y - camY); const passo = estado.startsWith('weaveReturn') ? 7 : 5;
      // Investida de Tear é uma linha tensa; Retorno vira uma trança dupla.
      for (let px = 0; px < z.w; px += passo) {
        const sobe = estado.startsWith('weaveReturn') ? (Math.floor(px / passo) % 2) * 3 : 0;
        ctx.fillRect(x + px, y + sobe, Math.min(4, z.w - px), 2);
        if (estado.startsWith('weaveReturn')) ctx.fillRect(x + px + 2, y + 3 - sobe, 2, 1);
      }
      // Pequenas setas repetidas deixam o sentido da investida evidente no celular.
      const direcao = z.originX != null && z.x < z.originX ? -1 : 1;
      ctx.fillStyle = '#ffd27a';
      for (let px = 10; px < z.w - 4; px += 16) {
        const sx = x + px;
        ctx.fillRect(sx, y - 2, 2, 6);
        ctx.fillRect(sx + direcao * 2, y - 1, 2, 4);
      }
    } else if (z.tipo === 'coluna') {   // pilar do Coração: fio fino avisando → pilar aceso
      const x = Math.round(z.x - camX); const y = Math.round(z.y - camY);
      if (ativo) { ctx.fillRect(x, y, z.w, z.h); ctx.fillStyle = '#fff2c0'; ctx.fillRect(x + 6, y, 6, z.h); }
      else { ctx.fillRect(x + z.w / 2 - 1, y + 4, 2, z.h - 4); ctx.fillRect(x, y + z.h - 2, z.w, 2); }
    } else if (z.tipo === 'ring') {
      const cx = Math.round(z.x - camX); const cy = Math.round(z.y - camY); const r = Math.round(z.r);
      ctx.lineWidth = z.thickness || 2; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      // Espinhos radiais fazem o Pulso parecer uma ruptura de raiz, não uma aura genérica.
      const pontos = pulso ? 10 : 8;
      for (let i = 0; i < pontos; i++) {
        const a = (Math.PI * 2 * i) / pontos + (ativo ? (z.phase || 0) * .35 : 0);
        const px = Math.round(cx + Math.cos(a) * r); const py = Math.round(cy + Math.sin(a) * r);
        ctx.fillRect(px - 1, py - 1, 3, 3);
      }
      if (!ativo) { ctx.globalAlpha = 0.22; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(cx, cy, Math.max(8, r - 14), 0, Math.PI * 2); ctx.stroke(); }
    }
    ctx.restore();
  }
}

/** Anticipação, impacto e estados: envolve o desenho base sem tocar nos sprites. */
function drawEnemy(ctx, enemy, camX, camY, sprites = null, t = 0) {
  if (!enemy.alive) return;
  const boss = enemy.cfg.kind === 'boss'; const b = enemy.body;
  const rx = Math.round(b.x - camX); const ry = Math.round(b.y - camY);
  const f = enemy.telegrafoFracao || 0; const imp = enemy.impactoT || 0;
  ctx.save();
  if (!boss) {
    const pe = ry + b.h; const cx = rx + b.w / 2;
    ctx.translate(cx, pe);
    if (f > 0) {   // agacha, estica na largura e treme: o corpo "carrega" o golpe
      const sy = 1 - 0.28 * f; const sx = 1 + 0.18 * f; ctx.scale(sx, sy);
      ctx.translate(Math.sin(t * 70) * 0.8 * f, 0);
    }
    if (imp > 0) ctx.translate(enemy.impactoDir * -Math.min(3, imp * 18), 0);
    ctx.translate(-cx, -pe);
  }
  drawEnemyBase(ctx, enemy, camX, camY, sprites, t);
  ctx.restore();
  if (imp > 0.1 && !boss) { ctx.save(); ctx.globalAlpha = Math.min(0.8, imp * 4); ctx.fillStyle = '#fff'; ctx.fillRect(rx, ry, b.w, b.h); ctx.restore(); }
  ctx.save();
  if (f > 0 && !boss) {   // '!' piscando + trajetória do mergulho
    if (Math.floor(t * 18) % 2 === 0) { ctx.fillStyle = '#ff4d4d'; const x = rx + b.w / 2 - 1; ctx.fillRect(x, ry - 11, 2, 6); ctx.fillRect(x, ry - 4, 2, 2); }
    if (enemy.alvoMergulho && enemy.attackKind === 'mergulho') {
      ctx.fillStyle = 'rgba(255,90,90,0.7)'; const ax = enemy.alvoMergulho.x - camX; const ay = enemy.alvoMergulho.y - camY;
      for (let i = 1; i <= 7; i++) { const u = i / 8; ctx.fillRect(Math.round(rx + b.w / 2 + (ax - rx - b.w / 2) * u), Math.round(ry + b.h / 2 + (ay - ry - b.h / 2) * u), 2, 2); }
    }
  }
  if (enemy.cfg.kind === 'armored') {   // guarda: borda clara na frente; quebrada = rachada e apagada
    const g = enemy.guardaAtiva?.(); const x = enemy.facing > 0 ? rx + b.w : rx - 1;
    ctx.fillStyle = g ? '#cfe7ff' : '#5a6a7a'; ctx.globalAlpha = g ? 0.9 : 0.5; ctx.fillRect(x, ry + 1, 1, b.h - 2);
  }
  if (enemy.atordoado) {   // estrelinhas girando
    ctx.fillStyle = '#ffe36b';
    for (let i = 0; i < 3; i++) { const a = t * 6 + i * 2.1; ctx.fillRect(Math.round(rx + b.w / 2 + Math.cos(a) * 6), Math.round(ry - 5 + Math.sin(a) * 2), 2, 2); }
  }
  if (boss && enemy.anuncio && enemy.telegrafando) {   // faixa com o nome do ataque, na cor do chefe
    const txt = enemy.anuncio.texto; ctx.font = 'bold 8px monospace'; ctx.textAlign = 'center';
    const w = ctx.measureText(txt).width + 8; const x = Math.round(rx + b.w / 2); const y = ry - 14;
    ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fillRect(Math.round(x - w / 2), y - 8, Math.round(w), 11);
    ctx.fillStyle = enemy.anuncio.cor; ctx.fillText(txt, x, y);
  }
  if (boss && enemy.exposto && enemy.padraoAtual !== undefined && enemy.recuperando) {   // janela de contra-ataque
    ctx.strokeStyle = '#ffe36b'; ctx.globalAlpha = 0.5 + 0.3 * Math.sin(t * 14); ctx.strokeRect(rx - 1, ry - 1, b.w + 2, b.h + 2);
  }
  ctx.restore();
}

function drawEnemyBase(ctx, enemy, camX, camY, sprites = null, t = 0) {
  if (!enemy.alive) return;
  ctx.save();
  const rx = Math.round(enemy.body.x - camX);
  const ry = Math.round(enemy.body.y - camY);
  if (enemy.cfg.kind === 'flyer') { drawFlyer(ctx, enemy, rx, ry); ctx.restore(); return; }
  if (enemy.cfg.kind === 'boss') { drawBossZones(ctx, enemy, camX, camY); drawBoss(ctx, enemy, rx, ry, sprites, t); ctx.restore(); return; }
  if (enemy.cfg.kind === 'leaper') { drawLeaper(ctx, enemy, rx, ry); ctx.restore(); return; }
  if (enemy.cfg.kind === 'armored') { drawArmored(ctx, enemy, rx, ry); ctx.restore(); return; }

  // Sombra no chão mais marcada e nítida por baixo do inimigo
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fillRect(rx, ry + enemy.body.h, enemy.body.w, 2);

  drawCrawler(ctx, enemy, rx, ry);
  ctx.restore();
}

const hexRgb = (cor) => [1, 3, 5].map((k) => parseInt(cor.slice(k, k + 2), 16));

/**
 * Polígono de visão alargado: raios que bateram numa parede avançam `extra` px para dentro dela, então a face do tile
 * que olha para a luz recebe luz (e esmaece pela queda do sprite) em vez de ficar escura colada na fonte. Cache por polígono-base.
 */
const _lambe = new WeakMap();
function poligonoLambendo(pts, ox, oy, rp, extra) {
  let r = _lambe.get(pts); if (r) return r;
  r = pts.map((q) => { const dx = q.x - ox; const dy = q.y - oy; const d = Math.hypot(dx, dy); if (d < 1e-6 || d >= rp - 0.5) return q; const k = Math.min(rp, d + extra) / d; return { x: ox + dx * k, y: oy + dy * k }; });
  _lambe.set(pts, r); return r;
}

/** Pontos (em raios de suavidade) onde a luz com sombra é amostrada: o 1º é o centro; mais amostras = penumbra mais lisa. */
const LAMBE_PX = 6;   // quanto a luz entra na parede (px; menor que um tile, então não vaza por paredes finas)
const OFFS_PENUMBRA = [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [0.7, 0.7], [-0.7, 0.7], [0.7, -0.7], [-0.7, -0.7]];

export class Renderer {
  constructor(canvas, config, logger = null, doc = (typeof document !== 'undefined' ? document : null), win = (typeof window !== 'undefined' ? window : null)) {
    this.canvas = canvas; this.config = config; this.logger = logger; this.doc = doc; this.win = win;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.graphics = null;
    this.sprites = { tecela: null };   // sprites oficiais carregados (null = proteção procedural)
    this.overlays = [];            // funções extras de desenho (usadas pelo debug)
    this.insets = { left: 0, right: 0 }; // áreas da tela reservadas (ex.: painel do editor)
    this.visibleTiles = 0;         // quantos tiles foram desenhados no último quadro
    this.visibleCells = 0;
    this.displayInfo = null;
    this.setInternalSize();
  }

  setInternalSize() {
    this.canvas.width = this.config.render.internalWidth;
    this.canvas.height = this.config.render.internalHeight;
    this.ctx.imageSmoothingEnabled = false; // pixel art nítida
  }

  setTecelaSprite(sprite) { this.sprites.tecela = sprite || null; }
  setPauseMenu(menu) { this.pauseMenu = menu || null; }
  setStoryCard(storyCard) { this.storyCard = storyCard || null; }
  setGenesMenu(menu) { this.genesMenu = menu || null; }
  setCatalogoMenu(menu) { this.catalogoMenu = menu || null; }
  setDialogo(d) { this.dialogo = d || null; }   // v1.43: caixa de diálogo dos NPCs

  /** Corpo da Tecelã desabando (frames oficiais de derrota). Não colide nem interage. */
  drawVisualFx(ctx, game, camX, camY) {
    const sp = this.sprites.tecela; if (!game.visualFx?.length) return;
    if (!sp) { for (const fx of game.visualFx) drawTecelaColapsoProcedural(ctx, fx, camX, camY); return; }
    for (const fx of game.visualFx) {
      const c = tecelaColapso(fx.t);
      drawTecelaFrame(ctx, sp, c.frame, Math.round(fx.body.x - camX), Math.round(fx.body.y - camY), fx.body.w, fx.body.h, fx.dir, { alpha: c.alpha });
    }
  }

  /** Prepara os gráficos dos tiles (catálogo, tamanho do tile da sala e spritesheets já carregados). */
  useCatalog(catalogo, tamanhoTile, tilesets = new Map()) {
    const fabrica = (w, h) => { const c = this.doc.createElement('canvas'); c.width = w; c.height = h; return c; };
    this.graphics = new TileGraphics(catalogo, tamanhoTile, fabrica, tilesets, this.logger, { bordas: this.config.render.autotileBorders !== false });
    this._fundos = new WeakMap();
  }

  /** Ajusta o tamanho do canvas na tela, em escala inteira (descontando áreas reservadas). */
  resize() {
    if (!this.win) return null;
    const dpr = this.win.devicePixelRatio || 1;
    const vv = this.win.visualViewport;
    const larguraTotal = vv ? vv.width : this.win.innerWidth;
    const palco = this.canvas.parentElement;
    if (palco && palco.style) { palco.style.paddingLeft = `${this.insets.left}px`; palco.style.paddingRight = `${this.insets.right}px`; }
    const info = computeDisplaySize({
      availWidth: Math.max(50, larguraTotal - this.insets.left - this.insets.right), availHeight: vv ? vv.height : this.win.innerHeight, dpr,
      internalWidth: this.config.render.internalWidth, internalHeight: this.config.render.internalHeight,
      maxIntegerScale: this.config.render.maxIntegerScale, pixelPerfect: this.config.render.pixelPerfect !== false,
    });
    this.canvas.style.width = `${info.cssWidth}px`;
    this.canvas.style.height = `${info.cssHeight}px`;
    this.displayInfo = info;
    return info;
  }

  addOverlay(fn) { this.overlays.push(fn); }

  clear() {
    const cfg = this.config.render;
    
    // Fundo base com tom noturno clássico
    this.ctx.fillStyle = cfg.backgroundColor || '#181425';
    this.ctx.fillRect(0, 0, cfg.internalWidth, cfg.internalHeight);

    // Gradiente vertical de profundidade mais acentuado (simula iluminação de teto)
    const grad = this.ctx.createLinearGradient(0, 0, 0, cfg.internalHeight);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.45)'); // Sombra mais forte no topo
    grad.addColorStop(1, 'rgba(0, 0, 0, 0.1)');  // Leve escurecimento em baixo
    this.ctx.fillStyle = grad;
    this.ctx.fillRect(0, 0, cfg.internalWidth, cfg.internalHeight);
  }

  /** Escuridão atmosférica: o mundo permanece legível, mas a luz nasce dos elementos vivos. */
  drawDarkAtmosphere(ctx, width, height, pulso = 0) {
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.20)';
    ctx.fillRect(0, 0, width, height);
    const luz = ctx.createRadialGradient(width * 0.48, height * 0.5, height * 0.08, width * 0.48, height * 0.5, height * 0.72);
    luz.addColorStop(0, `rgba(103, 145, 103, ${(0.08 + pulso * 0.025).toFixed(3)})`);
    luz.addColorStop(0.45, 'rgba(25, 53, 39, 0.025)');
    luz.addColorStop(1, 'rgba(0, 0, 0, 0.34)');
    ctx.fillStyle = luz;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  /** Corpos que interceptam os feixes: o Limo é gel translúcido (verde absorve menos), inimigos são quase opacos. */
  _corposDeFeixe(game) {
    const out = []; const p = game.player;
    if (p && p.life > 0 && p.body) out.push({ x: p.body.x, y: p.body.y, w: p.body.w, h: p.body.h, sigma: 0.06, cor: [130, 255, 170] });
    for (const en of game.enemies || []) if (en.alive && en.body) out.push({ x: en.body.x, y: en.body.y, w: en.body.w, h: en.body.h, sigma: en.cfg?.kind === 'boss' ? 0.35 : 0.5, cor: [150, 70, 80] });
    return out;
  }

  /**
   * v1.41.0 — sprite de luz SUAVE (substitui os 4 círculos concêntricos). Gerado uma vez por cor, em ImageData:
   * queda contínua (1 − u²)² (sem degrau nenhum), núcleo que clareia em direção ao branco e dither de Bayer 4×4
   * no alfa (quebra as faixas de 8 bits em degradês largos). `rgb` null = máscara de furo (só alfa, usada em destination-out).
   * Depois é só `drawImage` escalado: raio livre (a chama oscila o raio todo quadro) a custo de um blit.
   */
  _spriteLuz(rgb) {
    const cache = this._spritesLuz ||= new Map(); const chave = rgb ? rgb.join(',') : 'furo';
    let c = cache.get(chave); if (c) return c;
    const N = 128; c = this.doc.createElement('canvas'); c.width = c.height = N;
    const cx = c.getContext('2d'); const img = cx.createImageData?.(N, N); const d = img?.data; const r = N / 2;
    if (!d) { cache.set(chave, c); return c; }   // contexto sem ImageData (ferramentas/testes): sprite vazio, sem luz
    const bayer = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
      const u = Math.hypot((x + 0.5 - r) / r, (y + 0.5 - r) / r); const k = 1 - u * u; const f = k <= 0 ? 0 : k * k;
      const o = (y * N + x) * 4; const limiar = (bayer[(y & 3) * 4 + (x & 3)] + 0.5) / 16 - 0.5;
      if (rgb) { const nucleo = Math.pow(1 - Math.min(1, u), 3) * 0.35; d[o] = rgb[0] + (255 - rgb[0]) * nucleo; d[o + 1] = rgb[1] + (255 - rgb[1]) * nucleo; d[o + 2] = rgb[2] + (255 - rgb[2]) * nucleo; }
      d[o + 3] = Math.max(0, Math.min(255, Math.round(f * 255 + limiar)));
    }
    cx.putImageData(img, 0, 0); cache.set(chave, c); return c;
  }

  /**
   * ILUMINAÇÃO (camada por cima da cena; não altera as cores base dos tiles). Mapa de luz: escurece a sala toda e "fura" a
   * escuridão em volta de cada fonte com um degradê contínuo. A luz do Limo é uma tocha: oscila e é bloqueada pelas paredes,
   * com PENUMBRA (várias amostras do ponto de luz dão sombra macia, como uma fonte com tamanho) e um halo largo de bruma.
   * Config: darknessOverlay, shadowDepth, vignetteStrength, ambientGlow, creatureLight, lightRadius, lightMapScale,
   * lightShadowSoftness, lightShadowSamples, lightHalo...
   */
  drawLighting(ctx, game, camX, camY, t, pulso) {
    const R = this.config.render; const W = R.internalWidth; const H = R.internalHeight;
    if (this._dbg && this._dbg.lighting === false) return;
    const esc = Math.max(0.25, Math.min(1, R.lightMapScale ?? 0.5));   // mapa de escuridão em resolução menor: o bilinear ao subir já esfumaça tudo (1 = resolução cheia)
    const LW = Math.max(1, Math.round(W * esc)); const LH = Math.max(1, Math.round(H * esc));
    if (!this._lightmap || this._lightmap.width !== LW || this._lightmap.height !== LH) { this._lightmap = this.doc.createElement('canvas'); this._lightmap.width = LW; this._lightmap.height = LH; }
    const lm = this._lightmap.getContext('2d');
    const luzes = coletarLuzes(game, R, t, pulso);
    const escuro = Math.min(0.94, (R.darknessOverlay ?? 0.18) + (R.shadowDepth ?? 0.5) + (game.feridasAbertas > 0 ? (this.config.mecanicas?.ferida?.escuridao ?? 0.2) : 0));   // ferida aberta = sala mais escura
    const ALCANCE = 1.18;   // a queda suave chega a zero na borda: o sprite é um pouco maior para a luz não parecer encolhida
    const suav = Math.max(0, R.lightShadowSoftness ?? 3); const amostras = suav > 0 ? Math.max(1, Math.min(OFFS_PENUMBRA.length, Math.round(R.lightShadowSamples ?? 5))) : 1;
    const haloK = R.lightHalo ?? 0.34;
    // v1.42.0: feixes de luz físicos (campo em baixa resolução + poeira); a sala sem `feixes` não paga nada
    const FX = R.feixes || {}; let campo = null; let graos = null; const celF = FX.celula ?? 4;
    if (FX.ligado !== false && this._dbg?.feixes !== false && game.roomData?.feixes?.length) {
      const sis = this._feixes ||= new SistemaFeixes();
      if (sis.preparar(game.roomData, game.map, FX.raios ?? 32)) {
        const dtF = Math.min(0.1, Math.max(0, t - (this._tFeixe ?? t))); this._tFeixe = t;
        const corpos = this._corposDeFeixe(game); sis.atualizarPoeira(dtF, t, FX.poeira ?? 14);
        campo = sis.campo({ camX, camY, W, H, celula: celF, t, corpos, volume: FX.volume ?? 0.22, superficie: FX.superficie ?? 0.75, quique: FX.quique ?? 0.35 });
        graos = sis.graos(t, corpos);
        const tela = (nome) => { const k = `_cvFx${nome}`; let c = this[k]; if (!c || c.width !== campo.GW || c.height !== campo.GH) { c = this[k] = this.doc.createElement('canvas'); c.width = campo.GW; c.height = campo.GH; } return c; };
        const cvT = tela('Tinta'); const cvF = tela('Furo'); const cxT = cvT.getContext('2d'); const cxF = cvF.getContext('2d');
        const imgT = cxT.createImageData?.(campo.GW, campo.GH); const imgF = cxF.createImageData?.(campo.GW, campo.GH);
        if (imgT?.data && imgF?.data) { SistemaFeixes.pixels(campo, imgT.data, imgF.data, FX.furo ?? 1.6); cxT.putImageData(imgT, 0, 0); cxF.putImageData(imgF, 0, 0); campo.cvT = cvT; campo.cvF = cvF; } else campo = null;
      } else campo = null;
    }
    const caminho = (c, pts) => { c.beginPath(); pts.forEach((q, k) => (k ? c.lineTo(q.x - camX, q.y - camY) : c.moveTo(q.x - camX, q.y - camY))); c.closePath(); };
    // 1) mapa de luz: escuridão total e, depois, buracos de luz (destination-out remove escuridão)
    lm.setTransform(1, 0, 0, 1, 0, 0); lm.globalCompositeOperation = 'source-over'; lm.globalAlpha = 1; lm.clearRect(0, 0, LW, LH);
    const corEscura = R.darknessColor || [5, 2, 9];
    lm.fillStyle = `rgba(${corEscura[0]},${corEscura[1]},${corEscura[2]},${escuro.toFixed(3)})`; lm.fillRect(0, 0, LW, LH);
    lm.setTransform(LW / W, 0, 0, LH / H, 0, 0);   // daqui em diante, coordenadas em px internos
    lm.globalCompositeOperation = 'destination-out'; lm.imageSmoothingEnabled = true;
    const furo = this._spriteLuz(null);
    const amb = (R.ambientGlow ?? 0.08) * (1 + 0.25 * pulso);
    { const rA = H * 0.62; lm.globalAlpha = 1 - Math.pow(1 - Math.min(0.95, amb * 1.6), 3); lm.drawImage(furo, W * 0.5 - rA, H * 0.46 - rA, rA * 2, rA * 2); }
    const furar = (l) => {
      const rv = l.raio * ALCANCE; const x = l.x - camX; const y = l.y - camY; if (x < -rv || y < -rv || x > W + rv || y > H + rv) return;
      const pico = 1 - Math.pow(1 - Math.min(0.95, l.intensidade * 0.58), 4);   // mesmo centro de antes; só o perfil ficou contínuo
      if (l.oclusao && game.map) {
        const alvo = 1 - Math.pow(1 - pico, 1 / amostras);   // N furos seguidos somam o pico
        const rp = Math.ceil(rv / 8) * 8;
        for (let k = 0; k < amostras; k++) {
          const ox = l.x + OFFS_PENUMBRA[k][0] * suav; const oy = l.y + OFFS_PENUMBRA[k][1] * suav;
          const pts = poligonoLambendo(poligonoDeVisao(game.map, ox, oy, rp, 72), ox, oy, rp, LAMBE_PX);
          lm.save(); caminho(lm, pts); lm.clip(); lm.globalAlpha = alvo; lm.drawImage(furo, x - rv, y - rv, rv * 2, rv * 2); lm.restore();
        }
      } else { lm.globalAlpha = pico; lm.drawImage(furo, x - rv, y - rv, rv * 2, rv * 2); }
    };
    for (const l of luzes) furar(l);
    if (campo) { lm.globalAlpha = 1; lm.drawImage(campo.cvF, 0, 0, campo.GW, campo.GH, 0, 0, campo.GW * celF, campo.GH * celF); }   // o feixe também clareia a escuridão
    lm.globalAlpha = 1; lm.globalCompositeOperation = 'source-over';
    ctx.save();
    ctx.imageSmoothingEnabled = true;   // sobe o mapa de escuridão com bilinear (borda macia); o resto do jogo continua nítido
    ctx.drawImage(this._lightmap, 0, 0, LW, LH, 0, 0, W, H);
    // 2) cor da luz: tinta aditiva com núcleo quente + halo largo de bruma, só onde a luz chega (mesma visão recortada)
    ctx.globalCompositeOperation = 'lighter';
    if (campo) ctx.drawImage(campo.cvT, 0, 0, campo.GW, campo.GH, 0, 0, campo.GW * celF, campo.GH * celF);   // cor do feixe (ar + poças + luz indireta)
    for (const l of luzes) {
      const rv = l.raio * ALCANCE; const x = l.x - camX; const y = l.y - camY; const rh = rv * 1.8;
      if (x < -rh || y < -rh || x > W + rh || y > H + rh) continue;
      const sp = this._spriteLuz(l.cor); const tinta = l.tinta * 1.15;
      if (l.oclusao && game.map) {
        const rp = Math.ceil(rv / 8) * 8;
        const amT = Math.min(amostras, 3);   // a tinta é fraca: 3 amostras bastam para a borda não ficar dura
        for (let k = 0; k < amT; k++) {
          const ox = l.x + OFFS_PENUMBRA[k][0] * suav; const oy = l.y + OFFS_PENUMBRA[k][1] * suav;
          const pts = poligonoLambendo(poligonoDeVisao(game.map, ox, oy, rp, 72), ox, oy, rp, LAMBE_PX);
          ctx.save(); caminho(ctx, pts); ctx.clip(); ctx.globalAlpha = tinta / amT; ctx.drawImage(sp, x - rv, y - rv, rv * 2, rv * 2); ctx.restore();
        }
        if (haloK > 0) { const rph = Math.ceil(rh / 8) * 8; const pts = poligonoLambendo(poligonoDeVisao(game.map, l.x, l.y, rph, 72), l.x, l.y, rph, LAMBE_PX); ctx.save(); caminho(ctx, pts); ctx.clip(); ctx.globalAlpha = l.tinta * haloK; ctx.drawImage(sp, x - rh, y - rh, rh * 2, rh * 2); ctx.restore(); }
      } else {
        ctx.globalAlpha = tinta; ctx.drawImage(sp, x - rv, y - rv, rv * 2, rv * 2);
        if (haloK > 0) { ctx.globalAlpha = l.tinta * haloK; ctx.drawImage(sp, x - rh, y - rh, rh * 2, rh * 2); }
      }
    }
    if (graos) { ctx.imageSmoothingEnabled = false; for (const g of graos) { ctx.globalAlpha = g.a; ctx.fillStyle = `rgb(${Math.round(255 * (0.55 + 0.45 * g.r))},${Math.round(255 * (0.55 + 0.45 * g.g))},${Math.round(255 * (0.55 + 0.45 * g.b))})`; ctx.fillRect(Math.round(g.x - camX), Math.round(g.y - camY), g.tam, g.tam); } }   // poeira: só brilha dentro do feixe (Tyndall)
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    // 3) vinheta contínua (borda escura "respira" com o batimento): degradê com curva suave, sem faixas
    const forca = Math.min(0.92, (R.vignetteStrength ?? 0.68) * (1 + 0.05 * Math.sin(t * 1.4) + 0.08 * pulso));
    const g = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, H * 0.95); const passos = 14;
    for (let k = 0; k <= passos; k++) { const u = k / passos; const e = u * u * (3 - 2 * u); g.addColorStop(u, `rgba(0,0,0,${(forca * Math.pow(e, 1.35)).toFixed(3)})`); }
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }

  /** Vinheta de sombreamento retrô mais pronunciada nas bordas */
  drawRetroVignette(ctx, width, height, t = 0, pulso = 0) {
    ctx.save();
    const grad = ctx.createRadialGradient(width / 2, height / 2, height * 0.25, width / 2, height / 2, height * 0.85);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
    grad.addColorStop(1, `rgba(0, 0, 0, ${(0.6 + 0.1 * Math.sin(t * 1.4) + 0.14 * pulso).toFixed(3)})`); // borda escura que "respira" (batida lenta do deus)
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  render(game) {
    const ctx = this.ctx; const cfg = this.config.render;
    this.clear();
    const dbgR = game.debug.render || {}; this._dbg = dbgR;
    this.graphics?.setBordas(dbgR.autotileBorders !== false && this.config.render.autotileBorders !== false);
    const t = game._tempoJogo || 0; const amb = game.ambience; const pulso = amb ? amb.pulse : 0;
    const mapa = game.map;
    if (!mapa || !this.graphics) return;
    { const b = game.roomData?.biome; this._tema = (game.progress?.bossesDefeated || []).includes(CHEFE_DO_BIOMA[b]) ? temaLimpo(b) : temaDoBioma(b); }

    const dep = this._profundidade(game.roomData?.depth, this._tema, dbgR, { W: mapa.pixelWidth, H: mapa.pixelHeight });
    this._feixesReais = cfg.feixes?.ligado !== false && !!game.roomData?.feixes?.length;
    if (!dep?.par?.cobreFundo) this.drawBackground(ctx, game.camera.x, game.camera.y, t, pulso);   // com parallax opaco o fundo antigo seria todo coberto: poupa ~150 fillRect por quadro
    // v1.33.0: personalidade da sala + silhuetas colossais que respiram (js/render/colosso.js, js/world/personalidade.js)
    const resp = amb ? amb.respira : 0; this._pers = personalidadeDaSala(game.roomData?.id, game.roomData?.biome);
    if (dbgR.colosso !== false) desenharColosso(ctx, this._pers, { W: cfg.internalWidth, H: cfg.internalHeight, camX: game.camera.x, camY: game.camera.y, t, pulso, resp, tema: this._tema });
    // --- Usa a posição final da câmara com o Screen Shake aplicado ---
    const camPos = game.camera.getRenderPosition();
    const camX = camPos.x;
    const camY = camPos.y;
    dep?.par?.atras(ctx, camX, camY, cfg.internalWidth, cfg.internalHeight, pulso);   // parallax: fundo e meio
    
    const reacoes = game.reacaoTiles && game.reacaoTiles.mapa === mapa && game.reacaoTiles.ligado && game.reacaoTiles.temCelulas ? game.reacaoTiles : null;   // v1.28.0: decoração reativa
    this._depAtual = dep;
    const vivoOn = dbgR.vida !== false;
    const vivo = game.vivo && dbgR.vida !== false && game.vivo.nivel !== undefined ? game.vivo : null;   // v1.38.0 (murais e dicas valem em qualquer nível; o resto só com nivel > 0)
    const criar = this._criarTela ||= (this.doc ? (w, h) => { const c = this.doc.createElement('canvas'); c.width = w; c.height = h; return c; } : null);
    this.drawMapLayers(mapa, camX, camY, cfg.internalWidth, cfg.internalHeight, game.debug.layers, cfg.playerDrawsAfterLayer,
      () => {
        if (vivo) { desenharMurais(ctx, vivo, camX, camY, cfg.internalWidth, cfg.internalHeight, t, criar); desenharDicas(ctx, vivo, camX, camY, t, resp, this._tema); }
        this.drawPassages(ctx, game.passages, camX, camY, t);
        this.drawAvisoPulso(ctx, game, camX, camY, t);
        this.drawDrips(ctx, amb, camX, camY);
        this.drawVisualFx(ctx, game, camX, camY);   // derrota da Tecelã (só visual)
        drawRastros(ctx, game, camX, camY, t);   // v1.50.0: fios costurados no chão (Raízes)
        drawEntities(ctx, game, camX, camY);   // checkpoints e mutações a coletar
        this.drawTendrilAlvos(ctx, game, camX, camY);
        this.drawParedesFrageis(ctx, game, camX, camY);
        this.drawOrbs(ctx, game.orbs, camX, camY, t);
        // Desenha o jogador
        drawPlayer(ctx, game.player, camX, camY, this.config);
        this.drawTendril(ctx, game, camX, camY);
        this.drawMelee(ctx, game, camX, camY);
        this.drawFoco(ctx, game, camX, camY, t);
        
        // Desenha todos os inimigos ativos na sala
        if (game.enemies) {
          for (const enemy of game.enemies) {
            drawEnemy(ctx, enemy, camX, camY, this.sprites, t);
            if (enemy.cerebro && vivoOn) desenharSinais(ctx, enemy, camX, camY, t);   // v1.39.0: o jogador lê o que a criatura faz
          }
        }
        if (vivo) desenharDissolucao(ctx, this.graphics, vivo, mapa.tileSize, camX, camY);
      }, reacoes);
    this._depAtual = null;
    dep?.par?.frente(ctx, camX, camY, cfg.internalWidth, cfg.internalHeight, pulso);   // parallax: primeiro plano (antes da luz)

    // Aplica a vinheta de sombreamento retrô intensificada
    if (this._pers?.motes && dbgR.colosso !== false) desenharMotes(ctx, this._pers.motes, { W: cfg.internalWidth, H: cfg.internalHeight, camX, camY, t, tema: this._tema }); else this.drawSpores(ctx, t, camX, camY);   // cada sala tem suas partículas de ar
    if (vivo?.nivel > 0) { desenharNevoa(ctx, vivo.atmosfera, t, camX, cfg.internalWidth, cfg.internalHeight); desenharAtmosfera(ctx, vivo.atmosfera, camX, camY); }   // clima do bioma (antes da luz)
    { const a = this._tema.ar; ctx.fillStyle = `rgba(${a[0]},${a[1]},${a[2]},${(a[3] + 0.04 * pulso + 0.035 * resp * (this._pers?.respira ?? 0.5)).toFixed(3)})`; ctx.fillRect(0, 0, cfg.internalWidth, cfg.internalHeight); }   // tinta do ar do bioma
    // Véu frio de luto: uma gradação Canvas 2D barata. As fontes coloridas são aplicadas depois e viram o contraste emocional da cena.
    { const m = cfg.melancholyTint || [44, 25, 70]; const alpha = (cfg.melancholyStrength ?? 0.11) * (1 + 0.12 * pulso); ctx.fillStyle = `rgba(${m[0]},${m[1]},${m[2]},${alpha.toFixed(3)})`; ctx.fillRect(0, 0, cfg.internalWidth, cfg.internalHeight); }
    this.drawLighting(ctx, game, camX, camY, t, pulso);
    { // v1.36: partículas em primeiro plano (parallax > 1) por cima da luz: dão profundidade sem esconder o jogo
      const b = game.roomData?.biome; if (this._frontalBioma !== b) { this._frontalBioma = b; this._frontal = new CamadaFrontal(b, 11); }
      if (dbgR.colosso !== false) this._frontal.draw(ctx, t, camX, camY, cfg.internalWidth, cfg.internalHeight);
    }
    if (vivo?.nivel > 0) desenharEsporelitos(ctx, vivo, camX, camY, t, this._tema, cfg.internalWidth, cfg.internalHeight);   // brilham por cima da escuridão
    this.drawTransition(ctx, game.transition, t);
    this.drawTitle(ctx, game.areaTitle);
    this.drawToast(ctx, game.canvasToast);
    drawDespertar(ctx, game, camX, camY, cfg.internalWidth, cfg.internalHeight);   // v1.51.0: escuridão que se abre ao acordar (antes dos balões)
    drawBaloes(ctx, game, camX, camY, cfg.internalWidth, cfg.internalHeight); drawLembranca(ctx, game, cfg.internalWidth, cfg.internalHeight);   // v1.50.0
    drawBossIntroDialogue(ctx, game.bossIntro, cfg.internalWidth, cfg.internalHeight);
    this.drawCutscene(ctx, game.cutscene);
    if (game.avisoSalvo > 0) { ctx.save(); ctx.globalAlpha = Math.min(1, game.avisoSalvo / 0.5) * 0.85; const sx = cfg.internalWidth - 14; ctx.fillStyle = '#0a1a10'; ctx.fillRect(sx - 1, 5, 10, 10); ctx.fillStyle = '#9be36b'; ctx.fillRect(sx, 6, 8, 8); ctx.fillStyle = '#0a1a10'; ctx.fillRect(sx + 2, 6, 4, 3); ctx.fillStyle = '#ffffff'; ctx.fillRect(sx + 2, 11, 4, 3); ctx.restore(); }
    if (game.instante?.ativo) { const k = game.instante.intensidade; if (k > 0.01) { ctx.save(); ctx.globalAlpha = 0.16 * k; ctx.fillStyle = '#7fe8bf'; ctx.fillRect(0, 0, cfg.internalWidth, cfg.internalHeight); ctx.restore(); } }   // v1.40.0: véu verde-água enquanto o mundo hesita (1 retângulo; sem custo extra fora do instante)
    if (game.flash > 0) { ctx.save(); ctx.globalAlpha = Math.min(1, game.flash / 0.7) * 0.75; ctx.fillStyle = '#eaffd8'; ctx.fillRect(0, 0, cfg.internalWidth, cfg.internalHeight); ctx.restore(); }

    // Interfaces no mesmo espaço lógico da cena: nunca extrapolam a área do jogo.
    this.pauseMenu?.draw(ctx);
    this.storyCard?.draw(ctx);
    this.genesMenu?.draw(ctx);
    this.catalogoMenu?.draw(ctx);   // v1.39.0
    this.dialogo?.draw(ctx);        // v1.43.0
    for (const fn of this.overlays) fn(ctx, game, camX, camY);
  }

  /** Golpe de PSEUDÓPODE: um braço de gelatina brota do corpo, estica até o alcance e termina num punho (o 3º golpe é mais grosso, com brilho dourado). */
  drawMelee(ctx, game, camX, camY) {
    const m = game.melee; const p = game.player; if (!m || !p || !m.fase || m.fase === 'idle') return;
    const c = m.cfgPasso; const fim = c.fim ?? 0.1; const u = m.fase === 'ativo' ? Math.min(1, (m.t - c.inicio) / c.ativo) : 0;
    let L;   // comprimento do braço em px, por fase
    if (m.fase === 'inicio') L = 3 * Math.min(1, m.t / c.inicio);                                   // só um calombo antes do golpe
    else if (m.fase === 'ativo') L = 3 + (c.alcance - 3) * (1 - (1 - u) * (1 - u));                 // dispara rápido e desacelera
    else L = c.alcance * Math.max(0, 1 - (m.t - c.inicio - c.ativo) / fim);                          // recolhe
    if (L < 2) return;
    const vert = m.direcao === 'cima' ? -1 : m.direcao === 'baixo' ? 1 : 0;   // golpe vertical: braço sai da cabeça (↑) ou da base (↓)
    const forte = !vert && m.passo === 2; const grosso = forte ? 5 : 3; const dir = vert ? 1 : m.dir; const b = p.body;
    const x0 = vert ? p.centerX : dir > 0 ? b.x + b.w - 2 : b.x + 2; const y0 = vert ? (vert < 0 ? b.y + 2 : b.y + b.h - 2) : p.centerY + (m.passo === 1 ? 3 : m.passo === 0 ? -2 : 0);
    const tempo = game._tempoJogo || 0; const COR_C = '#0f2a14'; const COR_B = forte ? '#7be07b' : '#5fd35f'; const COR_L = '#d8ffb0';
    ctx.save();
    const ponto = vert
      ? (i) => ({ x: Math.round(x0 + Math.sin(i * 0.55 + tempo * 40) * 0.8 - camX), y: Math.round(y0 + vert * i - camY) })
      : (i) => ({ x: Math.round(x0 + dir * i - camX), y: Math.round(y0 + Math.sin(i * 0.55 + tempo * 40) * 0.8 - camY) });
    for (let i = 0; i <= L; i += 2) { const q = ponto(i); const t = grosso - Math.round((i / Math.max(1, L)) * (grosso > 3 ? 2 : 1)); ctx.fillStyle = COR_C; ctx.fillRect(q.x - Math.floor(t / 2) - 1, q.y - Math.floor(t / 2) - 1, t + 2, t + 2); }
    for (let i = 0; i <= L; i += 2) { const q = ponto(i); const t = grosso - Math.round((i / Math.max(1, L)) * (grosso > 3 ? 2 : 1)); ctx.fillStyle = COR_B; ctx.fillRect(q.x - Math.floor(t / 2), q.y - Math.floor(t / 2), t, t); }
    if (L > 6) {   // punho na ponta
      const q = ponto(L); const r = forte ? 4 : 3;
      ctx.fillStyle = COR_C; ctx.fillRect(q.x - r - 1, q.y - r - 1, 2 * r + 2, 2 * r + 2); ctx.fillStyle = COR_B; ctx.fillRect(q.x - r, q.y - r, 2 * r, 2 * r);
      ctx.fillStyle = COR_L; ctx.fillRect(q.x - r + 1, q.y - r + 1, 2, 2);
      if (forte && m.fase === 'ativo') { ctx.fillStyle = '#ffe135'; ctx.fillRect(q.x + dir * (r + 1) - 1, q.y - 1, 2, 2); ctx.fillRect(q.x + dir * (r + 1) - 1, q.y - r, 1, 1); ctx.fillRect(q.x + dir * (r + 1) - 1, q.y + r - 1, 1, 1); }   // faíscas do golpe forte
    }
    ctx.restore();
  }

  /** Foco: partículas de material biológico convergem para Limo e um anel cresce até a cura; ao curar, um estouro de faíscas. */
  drawFoco(ctx, game, camX, camY, t = 0) {
    const f = game.foco; const p = game.player; if (!f || !p || (!f.ativo && !(f.flash > 0))) return;
    const cx = Math.round(p.centerX - camX); const cy = Math.round(p.centerY - camY);
    ctx.save();
    if (f.ativo) {
      const u = f.progresso; const R = 4 + Math.round(14 * (1 - u));   // anel que se fecha sobre Limo
      ctx.fillStyle = `rgba(255, 210, 90, ${0.25 + 0.5 * u})`;
      for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2 + t * 2; ctx.fillRect(Math.round(cx + Math.cos(a) * R), Math.round(cy + Math.sin(a) * R * 0.8), 1, 1); }
      for (let i = 0; i < 6; i++) {   // gotas de material subindo ao encontro do corpo
        const ph = (u * 3 + i / 6) % 1; const a = (i / 6) * Math.PI * 2 + t;
        const r = 20 * (1 - ph); ctx.fillStyle = ph > 0.7 ? '#fff3b0' : '#ffd25a';
        ctx.fillRect(Math.round(cx + Math.cos(a) * r) - 1, Math.round(cy + Math.sin(a) * r * 0.8) - 1, 2, 2);
      }
    }
    if (f.flash > 0) {   // estouro da cura
      const k = 1 - f.flash / 0.4; ctx.fillStyle = `rgba(255, 243, 176, ${0.8 * (1 - k)})`;
      for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; const r = 6 + 20 * k; ctx.fillRect(Math.round(cx + Math.cos(a) * r), Math.round(cy + Math.sin(a) * r), 2, 2); }
    }
    ctx.restore();
  }

  /** Paredes rachadas: rachaduras em zigue-zague sempre visíveis (a dica); somam-se com os golpes e piscam ao serem acertadas. */
  drawParedesFrageis(ctx, game, camX, camY) {
    const lista = game._paredes; if (!lista?.length) return; const t = game._tempoJogo || 0;
    ctx.save();
    for (const w of lista) {
      const r = w.body; const x0 = Math.round(r.x - camX); const y0 = Math.round(r.y - camY);
      if (x0 > this.config.render.internalWidth || y0 > this.config.render.internalHeight || x0 + r.w < 0 || y0 + r.h < 0) continue;
      const dano = 1 - w.hp / w.hpMax; const n = 2 + Math.round(dano * 6);   // quantas rachaduras
      ctx.fillStyle = '#12060a';
      for (let i = 0; i < n; i++) {
        const cx = x0 + 2 + ((i * 7 + 3) % Math.max(3, r.w - 3)); let cy = y0 + 1 + ((i * 5) % Math.max(2, r.h - 6));
        for (let s = 0; s < 4 + Math.round(dano * 3); s++) { ctx.fillRect(cx + (s % 2), cy, 1, 2); cy += 2; if (cy > y0 + r.h - 2) break; }
      }
      ctx.fillStyle = 'rgba(255, 230, 200, 0.10)'; ctx.fillRect(x0, y0, r.w, r.h);   // brilho tênue: parece diferente do resto
      if (t - w.golpeEm < 0.12) { ctx.fillStyle = 'rgba(255, 255, 255, 0.55)'; ctx.fillRect(x0, y0, r.w, r.h); }
    }
    ctx.restore();
  }

  /** Âncoras e objetos da Tendril como nódulos de carne pulsantes (só aparecem para quem tem a mutação, ou sempre no editor). */
  drawTendrilAlvos(ctx, game, camX, camY) {
    const ents = game.roomData?.entities; if (!ents || !game.player?.hasAbility?.('tendril')) return;
    const ts = game.map.tileSize; const t = game._tempoJogo || 0; const W = this.config.render.internalWidth; const H = this.config.render.internalHeight;
    ctx.save();
    for (const e of ents) {
      if ((e.type !== 'tendrilAnchor' && e.type !== 'tendrilObject') || (e.type === 'tendrilObject' && game._feridaCurada?.(e))) continue;
      const x = Math.round((e.x + (e.w || 1) / 2) * ts - camX); const y = Math.round((e.y + (e.h || 1) / 2) * ts - camY);
      if (x < -8 || y < -8 || x > W + 8 || y > H + 8) continue;
      let esticar = null; const pl = game.player; const tn = game.tendril;
      if (tn?.mirando && tn.phase === 'idle') { const dx = pl.centerX - (e.x + (e.w || 1) / 2) * ts; const dy = pl.centerY - (e.y + (e.h || 1) / 2) * ts; const d = Math.hypot(dx, dy); if (d > 0 && d <= tn.config.alcance) esticar = { x: dx / d, y: dy / d }; }
      drawNoGosma(ctx, x, y, { tipo: e.type === 'tendrilAnchor' ? 'anchor' : 'object', tempo: t, fase: e.x, esticar });
    }
    ctx.restore();
  }

  /** Apêndice bio-orgânico em pixels quadrados: ondula, afina na ponta e termina num bulbo com ventosa. Também mostra a mira. */
  drawTendril(ctx, game, camX, camY) {
    const t = game.tendril; const p = game.player; if (!t || !p) return;
    const tempo = game._tempoJogo || 0;
    const g = (this._gosma ||= new TendrilGosma());
    const dt = this._gosmaT == null ? 0 : Math.max(0, Math.min(0.05, tempo - this._gosmaT)); this._gosmaT = tempo;
    g.update(dt, t, p, game.map);
    g.draw(ctx, t, p, camX, camY, tempo);
  }

  /** Esfíncteres prestes a trocar de estado piscam (a batida do deus avisa antes de fechar/abrir). */
  drawAvisoPulso(ctx, game, camX, camY, t) {
    const L = game.pulsos; if (!L || !L.length || ((t * 10) | 0) % 2) return;
    const ts = game.map.tileSize; const W = this.config.render.internalWidth; const H = this.config.render.internalHeight;
    ctx.save(); ctx.lineWidth = 1;
    for (const p of L) {
      if (!p.aviso) continue;
      const x = Math.round(p.tx * ts - camX); const y = Math.round(p.ty * ts - camY);
      if (x + ts < 0 || y + ts < 0 || x > W || y > H) continue;
      ctx.strokeStyle = p.estaFechado ? 'rgba(160,255,160,0.9)' : 'rgba(255,90,110,0.9)';   // verde: vai abrir · vermelho: vai fechar
      ctx.strokeRect(x + 0.5, y + 0.5, ts - 1, ts - 1);
    }
    ctx.restore();
  }

  /** Aberturas na parede: cavidade escura com borda de carne que pulsa; passagens seladas viram membrana. */
  drawPassages(ctx, lista, camX, camY, t) {
    if (!lista || !lista.length) return;
    const W = this.config.render.internalWidth; const H = this.config.render.internalHeight;
    const pulso = 0.5 + 0.5 * Math.sin(t * 2.2);
    for (const p of lista) {
      const x = p.x - camX; const y = p.y - camY;
      if (x + p.w < 0 || y + p.h < 0 || x > W || y > H) continue;
      const horiz = p.side === 'left' || p.side === 'right';
      ctx.save();
      if (p.locked) {
        const g = p.corGene ? hexRgb(p.corGene) : null;   // selada por GENE: fundo e fios na cor do gene que falta
        ctx.fillStyle = g ? `rgb(${g.map((v) => Math.round(v * 0.22)).join(',')})` : '#3a1226'; ctx.fillRect(x, y, p.w, p.h);
        ctx.fillStyle = g ? `rgba(${g.join(',')},${(0.3 + 0.3 * pulso).toFixed(2)})` : `rgba(217,87,99,${(0.25 + 0.25 * pulso).toFixed(2)})`;
        for (let i = 3; i < (horiz ? p.h : p.w); i += 6) { if (horiz) ctx.fillRect(x, y + i, p.w, 1); else ctx.fillRect(x + i, y, 1, p.h); }
        ctx.strokeStyle = g ? `rgb(${g.map((v) => Math.round(v * 0.6)).join(',')})` : '#7a1f3d'; ctx.lineWidth = 2; ctx.strokeRect(x + 1, y + 1, p.w - 2, p.h - 2);
        ctx.restore(); continue;
      }
      // cavidade: gradiente do fundo escuro (parede) para o brilho tênue (lado da sala)
      const g = horiz
        ? ctx.createLinearGradient(p.side === 'left' ? x : x + p.w, 0, p.side === 'left' ? x + p.w : x, 0)
        : ctx.createLinearGradient(0, p.side === 'up' ? y : y + p.h, 0, p.side === 'up' ? y + p.h : y);
      g.addColorStop(0, '#020103'); g.addColorStop(1, `rgba(${(this._tema || temaDoBioma('raizes')).fenda},${(0.55 + 0.25 * pulso).toFixed(2)})`);
      ctx.fillStyle = g; ctx.fillRect(x, y, p.w, p.h);
      // borda de carne: dobras (dentes) alternadas ao longo dos dois lados longos
      ctx.fillStyle = (this._tema || temaDoBioma('raizes')).borda;
      const n = horiz ? p.h : p.w;
      for (let i = 0; i < n; i += 4) {
        const f = 2 + ((i / 4) % 2) + Math.round(pulso);
        if (horiz) { ctx.fillRect(x, y + i, p.w, 1); ctx.fillRect(x, y - 1, p.w, 2); ctx.fillRect(x, y + p.h - 1, p.w, 2); if (i + 2 < n) { ctx.fillStyle = '#d95763'; ctx.fillRect(x, y + i, f, 2); ctx.fillStyle = '#7a1f3d'; } }
        else { ctx.fillRect(x + i, y, 1, p.h); ctx.fillRect(x - 1, y, 2, p.h); ctx.fillRect(x + p.w - 1, y, 2, p.h); if (i + 2 < n) { ctx.fillStyle = '#d95763'; ctx.fillRect(x + i, y, 2, f); ctx.fillStyle = '#7a1f3d'; } }
      }
      ctx.restore();
    }
  }

  /**
   * ORGANIC DEPTH (2.5D, v1.38): estado de profundidade da sala ou null (sala sem `depth`, ou desligada no debug).
   * Normaliza uma vez por objeto (WeakMap) e reaproveita as camadas de parallax enquanto config/tema/tamanho não mudam.
   * `semParallax` = só o volume dos tiles (vista do editor, que tem zoom próprio).
   */
  _profundidade(raw, tema, dbg, salaPx, semParallax = false) {
    if (!raw || typeof raw !== 'object' || this.config.render.depth === false) return null;
    if (!this._depNorm) this._depNorm = new WeakMap();
    let cfg = this._depNorm.get(raw); if (cfg === undefined) { cfg = normalizarDepth(raw); this._depNorm.set(raw, cfg); }
    if (!cfg) return null;
    const volOn = cfg.volume.ativo && (!dbg || dbg.depthVolume !== false); const parOn = !semParallax && cfg.parallax.ativo && (!dbg || dbg.depthParallax !== false);
    if (!volOn && !parOn) return null;
    let par = null;
    if (parOn && this.doc?.createElement) {
      if (!this._parallax) this._parallax = new ParallaxDepth((w, h) => { const c = this.doc.createElement('canvas'); c.width = w; c.height = h; return c; });
      par = this._parallax.preparar(cfg.parallax, tema, { W: this.config.render.internalWidth, H: this.config.render.internalHeight }, salaPx);
      if (!par.camadas.length) par = null;
    }
    if (!volOn && !par) return null;
    if (volOn && !this._volTiles) this._volTiles = new VolumeTiles();
    const omiteFar = !!(par && cfg.parallax.substituiFundo);   // o parallax assume o fundo distante: a camada de tiles backgroundFar fica de fora do cache
    return { cfg, vol: volOn ? cfg.volume : null, volTiles: this._volTiles, par, omiteFar, chave: `${volOn ? JSON.stringify(cfg.volume) : 0}|${omiteFar ? 1 : 0}` };
  }

  /** Fundo em parallax: veias gigantes que ondulam e brilham a cada batida do deus, com bolhas de luz ao longe. */
  drawBackground(ctx, camX, camY, t, pulso) {
    const W = this.config.render.internalWidth; const H = this.config.render.internalHeight;
    const T = this._tema || temaDoBioma('raizes');
    ctx.save();
    ctx.fillStyle = T.fundo; ctx.fillRect(0, 0, W, H);   // base de cor do bioma
    const [vr, vg, vb] = T.veia; const [pr, pg, pb] = T.veiaPulso;
    // Silhuetas distantes quebram o fundo plano: parecem costelas, raízes ou órgãos, sem disputar a leitura do mapa.
    for (let i = 0; i < 5; i++) {
      const x = (((i * 83 + 15 - camX * 0.07) % (W + 76)) + W + 76) % (W + 76) - 38;
      const largura = 15 + (i % 3) * 8;
      const y = 22 + (i * 37) % Math.max(46, H - 46);
      ctx.fillStyle = `rgba(${vr},${vg},${vb},${(0.055 + pulso * 0.035).toFixed(3)})`;
      for (let k = 0; k < 5; k++) ctx.fillRect(Math.round(x + Math.sin(k * 1.2 + i) * 5), y + k * 5, Math.max(3, largura - k * 3), 2);
    }
    for (let i = 0; i < 6; i++) {
      const base = (((i * 67 + 23 - camX * (0.18 + (i % 3) * 0.06)) % (W + 60)) + W + 60) % (W + 60) - 30;
      ctx.fillStyle = `rgba(${vr + Math.round(pulso * pr)},${vg + Math.round(pulso * pg)},${vb + Math.round(pulso * pb)},${(0.24 + 0.28 * pulso).toFixed(2)})`;
      const larg = 2 + (i % 3);
      for (let y = 0; y < H; y += 6) ctx.fillRect(Math.round(base + Math.sin(y * 0.045 + i * 1.9 + t * 0.5) * 6), y, larg, 6);
    }
    for (let i = 0; i < 4; i++) {   // bolhas de luz distantes
      const x = (((i * 97 + 40 - camX * 0.1 + Math.sin(t * 0.3 + i) * 10) % W) + W) % W; const y = 30 + i * 52 + Math.sin(t * 0.5 + i * 2) * 8;
      ctx.fillStyle = `rgba(${T.bolha},${(0.05 * T.bolhaA).toFixed(3)})`; ctx.fillRect(x - 6, y - 6, 12, 12);
      ctx.fillStyle = `rgba(${T.bolha},${(0.09 * T.bolhaA).toFixed(3)})`; ctx.fillRect(x - 3, y - 3, 6, 6);
    }
    for (let i = 0; i < (this._feixesReais ? 0 : T.raios); i++) {   // feixes DECORATIVOS do fundo (jardim/núcleo) — v1.42.0: só em salas sem feixes reais (data `feixes`)
      const x0 = (((i * 131 + 30 - camX * 0.22) % (W + 80)) + W + 80) % (W + 80) - 40; const a = 0.035 + 0.02 * Math.sin(t * 0.6 + i * 2);
      ctx.fillStyle = `rgba(${T.bolha},${a.toFixed(3)})`;
      for (let y = 0; y < H; y += 8) ctx.fillRect(Math.round(x0 + y * 0.22), y, 10 + i * 3, 8);
    }
    if (T.neblina) { const g = ctx.createLinearGradient(0, H * 0.55, 0, H); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(${T.bolha},${T.neblina})`); ctx.fillStyle = g; ctx.fillRect(0, H * 0.55, W, H * 0.45); }
    ctx.restore();
  }

  /** Gotas de ranho caindo do teto e os respingos no chão. */
  drawDrips(ctx, amb, camX, camY) {
    if (!amb) return;
    ctx.fillStyle = (this._tema || temaDoBioma('raizes')).gota;
    for (const d of amb.drops) ctx.fillRect(Math.round(d.x - camX), Math.round(d.y - camY), 1, 3);
    for (const s of amb.splashes) { ctx.globalAlpha = Math.max(0, s.vida / 0.35); ctx.fillRect(Math.round(s.x - camX), Math.round(s.y - camY), 1, 1); }
    ctx.globalAlpha = 1;
  }

  /** Orbes de vida soltos pelos inimigos: pulsam e piscam antes de sumir. */
  drawOrbs(ctx, orbs, camX, camY, t) {
    if (!orbs || !orbs.length) return;
    for (const o of orbs) {
      if (o.vida < 2 && Math.floor(t * 10) % 2) continue;
      const x = Math.round(o.x - camX); const y = Math.round(o.y - camY + Math.sin(t * 4 + o.x) * 2);
      ctx.fillStyle = 'rgba(255,120,150,0.35)'; ctx.fillRect(x - 4, y - 4, 8, 8);
      ctx.fillStyle = '#ff6f91'; ctx.fillRect(x - 2, y - 2, 4, 4);
      ctx.fillStyle = '#ffe6ee'; ctx.fillRect(x - 1, y - 1, 2, 2);
    }
  }

  /** Cena de nova mutação (estilo Hollow Knight): tela escurece, o ícone cresce no centro e o texto aparece aos poucos. */
  drawCutscene(ctx, c) {
    if (!c) return;
    const W = this.config.render.internalWidth; const H = this.config.render.internalHeight; const ab = ABILITIES[c.id] || {};
    const fade = (ini) => Math.max(0, Math.min(1, (c.t - ini) / 0.5));
    ctx.save();
    ctx.fillStyle = `rgba(4,0,2,${(Math.min(1, c.t / 0.7) * 0.88).toFixed(2)})`; ctx.fillRect(0, 0, W, H);
    // brilho pulsando atrás do ícone
    const g = ctx.createRadialGradient(W / 2, 88, 4, W / 2, 88, 70);
    g.addColorStop(0, `rgba(143,255,160,${(0.35 * fade(0.2) * (0.8 + 0.2 * Math.sin(c.t * 3))).toFixed(3)})`); g.addColorStop(1, 'rgba(143,255,160,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 10, W, 160);
    // ícone ampliado 3x (pixel art nítida)
    ctx.globalAlpha = fade(0.2); ctx.save(); ctx.scale(3, 3);
    drawMutacao(ctx, c.id, (W / 6 - 8) / 16, (88 / 3 - 8) / 16, 16, 0, 0, c.t);
    ctx.restore();
    ctx.textAlign = 'center';
    const txt = (s, y, fonte, cor, ini) => { ctx.globalAlpha = fade(ini); ctx.font = fonte; ctx.fillStyle = '#000'; ctx.fillText(s, W / 2 + 1, y + 1); ctx.fillStyle = cor; ctx.fillText(s, W / 2, y); };
    txt(ab.rotulo || 'MUTAÇÃO ADQUIRIDA', 140, '8px monospace', ab.rotulo ? '#9dffd2' : '#ff9eb5', 0.8);
    txt((ab.nome || c.id).toUpperCase(), 156, 'bold 12px monospace', '#eaffd8', 1.1);
    (ab.frases || [ab.descricao || '']).forEach((f, i) => txt(f, 174 + i * 11, '8px monospace', '#c8d8c8', 1.6 + i * 0.5));
    const n = (ab.frases || [ab.descricao || '']).length; let yy = 174 + n * 11 + 3;
    if (c.uso) { txt('COMO USAR', yy, 'bold 7px monospace', '#ffd27a', 2.0); txt(c.uso, yy + 10, '8px monospace', '#eaffd8', 2.1); yy += 22; }
    if (c.abre) txt(c.abre.length > 52 ? `${c.abre.slice(0, 51)}…` : c.abre, yy, '7px monospace', '#7be0ff', 2.3);
    if (c.t > 2.4 && Math.floor(c.t * 2) % 2) txt('— pule para continuar —', 232, '8px monospace', '#7fbf8f', 0);
    ctx.restore();
  }

  /** Mensagem curta no canvas (checkpoint, mutação, vida...): quebra em linhas, placa escura e fade. Sempre acima do jogo. */
  drawToast(ctx, tt) {
    if (!tt) return;
    const W = this.config.render.internalWidth; const H = this.config.render.internalHeight;
    const a = Math.max(0, Math.min(1, tt.t / 0.2, (tt.dur - tt.t) / 0.4)); if (a <= 0) return;
    ctx.save(); ctx.font = '8px monospace'; ctx.textAlign = 'center';
    if (tt._cacheTexto !== tt.texto) {   // quebra de linha e medidas só uma vez por mensagem (antes: measureText a cada quadro)
      const largura = W - 40; const mede = (s) => (ctx.measureText ? ctx.measureText(s).width : s.length * 4.8);
      const linhas = []; let atual = '';
      for (const palavra of String(tt.texto).split(/\s+/)) { const teste = atual ? `${atual} ${palavra}` : palavra; if (mede(teste) > largura && atual) { linhas.push(atual); atual = palavra; } else atual = teste; }
      if (atual) linhas.push(atual);
      const ls = linhas.slice(0, 3); tt._cacheTexto = tt.texto; tt._ls = ls; tt._w = Math.min(W - 16, Math.max(...ls.map(mede)) + 16);
    }
    const ls = tt._ls; const w = tt._w; const h = ls.length * 10 + 8; const x = Math.round((W - w) / 2); const y = H - h - 10;
    ctx.globalAlpha = a; ctx.fillStyle = 'rgba(5,2,9,0.88)'; ctx.fillRect(x, y, w, h);
    ctx.fillStyle = '#7a1f3d'; ctx.fillRect(x, y, w, 1); ctx.fillRect(x, y + h - 1, w, 1); ctx.fillRect(x, y, 1, h); ctx.fillRect(x + w - 1, y, 1, h);
    ctx.fillStyle = '#eaffd8'; ls.forEach((l, i) => ctx.fillText(l, W / 2, y + 12 + i * 10));
    ctx.restore();
  }

  /** Título da área na primeira visita (como em Hollow Knight / Symphony of the Night): surge, fica e some. */
  drawTitle(ctx, tit) {
    if (!tit) return;
    const a = Math.min(1, tit.t / 0.5, (2.8 - tit.t) / 0.6); if (a <= 0) return;
    const W = this.config.render.internalWidth;
    ctx.save(); ctx.globalAlpha = a; ctx.textAlign = 'center'; ctx.font = 'bold 10px monospace';
    ctx.fillStyle = '#000'; ctx.fillText(tit.texto, W / 2 + 1, 41); ctx.fillStyle = '#eaffd8'; ctx.fillText(tit.texto, W / 2, 40);
    ctx.fillStyle = '#7a1f3d'; const m = Math.min(110, tit.texto.length * 3 + 12); ctx.fillRect(W / 2 - m, 46, m * 2, 1);
    ctx.restore();
  }

  /** Esporos flutuando devagar (parallax leve): dá vida ao ar do corpo do deus. Poucas peças, sem alocação. */
  drawSpores(ctx, t, camX, camY) {
    const W = this.config.render.internalWidth; const H = this.config.render.internalHeight;
    ctx.save();
    for (let i = 0; i < 18; i++) {
      const v = 6 + (i % 4) * 3;
      const x = (((i * 73 + t * v - camX * 0.35) % W) + W) % W;
      const y = (((i * 41 - t * (4 + (i % 3) * 2) + Math.sin(t * 0.8 + i) * 6 - camY * 0.2) % H) + H) % H;
      const T = this._tema || temaDoBioma('raizes'); ctx.fillStyle = i % 3 ? T.esporoA : T.esporoB;
      ctx.fillRect(Math.round(x), Math.round(y), i % 5 ? 1 : 2, i % 5 ? 1 : 2);
    }
    ctx.restore();
  }

  /** Íris orgânica: escurece tudo fora de um círculo irregular que fecha/abre em volta do jogador. */
  drawTransition(ctx, tr, t) {
    const c = tr ? tr.cover : 0;
    if (c <= 0) return;
    const W = this.config.render.internalWidth; const H = this.config.render.internalHeight;
    ctx.save();
    ctx.fillStyle = '#0a0204';
    if (c >= 0.995) { ctx.fillRect(0, 0, W, H); ctx.restore(); return; }
    const R = Math.hypot(W, H) * (1 - c);
    const contorno = () => {
      ctx.moveTo(tr.cx + R, tr.cy);
      for (let i = 1; i <= 32; i++) {
        const a = (i / 32) * Math.PI * 2; const r = R * (1 + 0.05 * Math.sin(a * 5 + t * 3) + 0.03 * Math.sin(a * 9 - t * 2));
        ctx.lineTo(tr.cx + Math.cos(a) * r, tr.cy + Math.sin(a) * r);
      }
      ctx.closePath();
    };
    ctx.beginPath(); ctx.rect(0, 0, W, H); contorno(); ctx.fill('evenodd');
    ctx.beginPath(); contorno(); ctx.strokeStyle = tr.cor || '#7a1f3d'; ctx.lineWidth = tr.cor ? 4 : 3; ctx.globalAlpha = 0.5 + 0.5 * Math.sin(c * Math.PI); ctx.stroke(); if (tr.cor) { ctx.globalAlpha *= 0.35; ctx.lineWidth = 9; ctx.stroke(); }
    ctx.restore();
  }

  /**
   * Desenha as camadas do mapa que aparecem na janela (camX,camY,viewW,viewH em px do mundo).
   * `visivel` = {nomeDaCamada: bool}; `aoDesenhar` roda logo depois da camada `depoisDe` (ex.: desenhar o jogador).
   */
  drawMapLayers(mapa, camX, camY, viewW, viewH, visivel = null, depoisDe = null, aoDesenhar = null, reacoes = null) {
    this.visibleTiles = 0; this.visibleCells = 0;
    const idxApos = depoisDe ? LAYER_NAMES.indexOf(depoisDe) : -1;
    if (reacoes && reacoes.mapa !== mapa) reacoes = null;
    reacoes?.sincronizar();
    // Decoração reativa (v1.28.0): essas células saem do cache/da camada e são desenhadas por `reacoes` (idênticas em repouso).
    const reativas = (nomes) => { if (!reacoes) return; const ok = nomes.filter((n) => !visivel || visivel[n]); if (ok.length) this.visibleTiles += reacoes.desenhar(this.ctx, this.graphics, camX, camY, viewW, viewH, ok); };
    const cache = Number.isInteger(camX) && Number.isInteger(camY) ? this._camadasEmCache(mapa, visivel, idxApos, reacoes) : null;   // câmera fracionária (só fora do jogo normal, que arredonda) usa o caminho clássico: mesmo resultado, sem arriscar arredondamento diferente
    if (cache) {   // caminho rápido: 2 blits por quadro (camadas atrás do jogador / à frente), em vez de ~400 drawImage de 16 px
      this._blitGrupo(cache.atras, mapa, camX, camY, viewW, viewH);
      reativas(LAYER_NAMES.slice(0, idxApos >= 0 ? idxApos + 1 : LAYER_NAMES.length));
      if (depoisDe) aoDesenhar?.();
      if (cache.frente) { this._blitGrupo(cache.frente, mapa, camX, camY, viewW, viewH); reativas(LAYER_NAMES.slice(idxApos + 1)); }
      if (reacoes) reacoes.desenharEsporos(this.ctx, camX, camY);
      return;
    }
    const dep = this._depAtual; const ts0 = mapa.tileSize;
    const jan = [Math.max(0, Math.floor(camX / ts0)), Math.max(0, Math.floor(camY / ts0)), Math.floor((camX + viewW - 1) / ts0), Math.floor((camY + viewH - 1) / ts0)];
    for (let i = 0; i < LAYER_NAMES.length; i++) {   // caminho clássico (cacheTiles:false, ou sem canvas disponível)
      const nome = LAYER_NAMES[i];
      if (nome === 'backgroundFar' && dep?.omiteFar) { if (i === idxApos) aoDesenhar?.(); continue; }
      if (nome === 'solid' && dep?.vol) dep.volTiles.sombras(this.ctx, mapa, dep.vol, jan[0], jan[1], jan[2], jan[3], -camX, -camY);
      if (!visivel || visivel[nome]) { this._drawLayer(mapa, nome, camX, camY, viewW, viewH, this.ctx, null, reacoes?.mascara(nome) || null); reativas([nome]); }
      if (nome === 'solid' && dep?.vol && (!visivel || visivel.solid)) dep.volTiles.relevo(this.ctx, mapa, dep.vol, jan[0], jan[1], jan[2], jan[3], -camX, -camY);
      if (i === idxApos) aoDesenhar?.();
    }
    if (depoisDe && idxApos < 0) aoDesenhar?.();
    if (reacoes) reacoes.desenharEsporos(this.ctx, camX, camY);
  }

  /**
   * CACHE DOS TILES. As camadas de tiles só mudam quando o TileMap muda (`revision` sobe em todo setTileId: parede rachada,
   * fungo aceso, passagem abrindo, editor) e a arte do tile não depende do tempo. Então cada sala é desenhada UMA vez em dois
   * canvases — camadas atrás do jogador (até `playerDrawsAfterLayer`) e à frente dele — e cada quadro só copia a janela da câmera.
   * A ordem de desenho é a mesma de antes (entidades entram entre os dois grupos). Invalida por: revisão do mapa, máscara de camadas
   * visíveis, tinta do bioma (muda ao derrotar o chefe), fundo orgânico ligado/desligado, e troca de gráficos/atlas (contornos).
   * Desligue com config.render.cacheTiles = false (ou debug.render.cacheTiles = false) para voltar ao desenho tile a tile.
   */
  _camadasEmCache(mapa, visivel, idxApos, reacoes = null) {
    if (this.config.render.cacheTiles === false || (this._dbg && this._dbg.cacheTiles === false) || !this.doc?.createElement || !this.graphics) return null;
    if (!this._cacheCamadas) this._cacheCamadas = new WeakMap();
    const organico = this.config.render.organicBackground !== false && (!this._dbg || this._dbg.organicBackground !== false);
    const mascara = LAYER_NAMES.map((n) => (!visivel || visivel[n] ? 1 : 0)).join('');
    const chave = `${mapa.revision}|${mapa.width}x${mapa.height}|${mascara}|${idxApos}|${organico ? 1 : 0}|${this._tema?.parede || ''}|${reacoes ? 'r' + reacoes._rev : ''}|${this._depAtual?.chave || ''}`;
    const c = this._cacheCamadas.get(mapa); const dep = this._depAtual;
    if (c && c.chave === chave && c.graphics === this.graphics && c.atlas === this.graphics.atlas) return c;
    try {
      const W = mapa.pixelWidth; const H = mapa.pixelHeight; const ts = mapa.tileSize;
      const montar = (de, ate) => {
        const nomes = LAYER_NAMES.slice(de, ate + 1).filter((n) => (!visivel || visivel[n]) && mapa.layers[n]);
        if (!nomes.length) return null;
        const cv = this.doc.createElement('canvas'); cv.width = W; cv.height = H;
        const cx = cv.getContext('2d'); if (!cx) throw new Error('sem contexto 2d');
        cx.imageSmoothingEnabled = false;
        const marcas = new Uint8Array(mapa.width * mapa.height); const soma = new Int32Array((mapa.width + 1) * (mapa.height + 1));
        for (const n of nomes) {
          if (n === 'backgroundFar' && dep?.omiteFar) continue;   // 2.5D: o parallax faz o fundo distante
          if (n === 'solid' && dep?.vol) dep.volTiles.sombras(cx, mapa, dep.vol);   // sombra projetada sobre o fundo, ANTES do sólido
          marcas.fill(0); this._drawLayer(mapa, n, 0, 0, W, H, cx, marcas, reacoes?.mascara(n) || null);
          if (n === 'solid' && dep?.vol) dep.volTiles.relevo(cx, mapa, dep.vol);   // relevo/espessura/brilho por material, DEPOIS do sólido (uma vez, no cache)
 for (let y = 0; y < mapa.height; y++) for (let x = 0; x < mapa.width; x++) soma[(y + 1) * (mapa.width + 1) + x + 1] += marcas[y * mapa.width + x]; }
        for (let y = 1; y <= mapa.height; y++) for (let x = 1; x <= mapa.width; x++) { const k = y * (mapa.width + 1) + x; soma[k] += soma[k - 1] + soma[k - (mapa.width + 1)] - soma[k - (mapa.width + 1) - 1]; }   // soma acumulada 2D: conta tiles visíveis (painel de debug) em O(1)
        return { canvas: cv, camadas: nomes.length, soma };
      };
      const antes = [this.visibleTiles, this.visibleCells];
      const novo = { chave, graphics: this.graphics, atlas: this.graphics.atlas, atras: montar(0, idxApos >= 0 ? idxApos : LAYER_NAMES.length - 1), frente: idxApos >= 0 ? montar(idxApos + 1, LAYER_NAMES.length - 1) : null, ts };
      [this.visibleTiles, this.visibleCells] = antes;
      this._cacheCamadas.set(mapa, novo); return novo;
    } catch (e) {
      this.logger?.warn?.('render', `Cache de tiles indisponível (${e.message}); desenhando tile a tile.`);
      this._cacheCamadas.delete(mapa); this.config.render.cacheTiles = false; return null;
    }
  }

  /** Copia a janela da câmera de um grupo em cache. Mesma posição (inclusive fracionária, com tremor) do desenho tile a tile. */
  _blitGrupo(grupo, mapa, camX, camY, viewW, viewH) {
    if (!grupo) return;
    const W = mapa.pixelWidth; const H = mapa.pixelHeight; const ts = mapa.tileSize;
    const x0 = Math.max(0, Math.floor(camX)); const y0 = Math.max(0, Math.floor(camY));
    const x1 = Math.min(W, Math.ceil(camX + viewW)); const y1 = Math.min(H, Math.ceil(camY + viewH));
    if (x1 > x0 && y1 > y0) this.ctx.drawImage(grupo.canvas, x0, y0, x1 - x0, y1 - y0, x0 - camX, y0 - camY, x1 - x0, y1 - y0);
    // estatística do painel de debug, igual à do caminho clássico (células e tiles da janela, somados nas camadas do grupo)
    const tx0 = Math.max(0, Math.floor(camX / ts)); const tx1 = Math.min(mapa.width - 1, Math.floor((camX + viewW - 1) / ts));
    const ty0 = Math.max(0, Math.floor(camY / ts)); const ty1 = Math.min(mapa.height - 1, Math.floor((camY + viewH - 1) / ts));
    if (tx1 < tx0 || ty1 < ty0) return;
    const w = mapa.width + 1; const S = grupo.soma;
    this.visibleCells += grupo.camadas * (tx1 - tx0 + 1) * (ty1 - ty0 + 1);
    this.visibleTiles += S[(ty1 + 1) * w + tx1 + 1] - S[ty0 * w + tx1 + 1] - S[(ty1 + 1) * w + tx0] + S[ty0 * w + tx0];
  }

  /** Estilo ('bg', 'vein'...) da arte de um tile, com cache. */
  _estilo(id) { if (!this._estilos) this._estilos = new Map(); if (!this._estilos.has(id)) this._estilos.set(id, this.graphics.catalog.get(id)?.art?.style || ''); return this._estilos.get(id); }

  /**
   * Fundo orgânico CONTÍNUO da sala (desenhado uma vez): manchas de cor em tons de musgo, vinho, marrom e roxo, fibras e veias que
   * atravessam várias células. Os tiles de fundo só "recortam" daqui, então não existem emendas nem quadrados de 16 px.
   */
  _fundoOrganico(mapa) {
    let f = this._fundos.get(mapa); if (f) return f;
    const W = mapa.pixelWidth; const H = mapa.pixelHeight; const ts = mapa.tileSize;
    const fab = (w, h) => { const c = this.doc.createElement('canvas'); c.width = w; c.height = h; return c; };
    const far = fab(W, H); const mid = fab(W, H); const cf = far.getContext('2d'); const cm = mid.getContext('2d');
    const r = aleatorio((W * 131 + H * 7 + (mapa.layers.backgroundMid ? mapa.layers.backgroundMid.length : 0)) >>> 0);
    cf.fillStyle = '#0a0808'; cf.fillRect(0, 0, W, H);
    const tons = (this._tema || temaDoBioma('raizes')).tons;   // manchas na paleta do bioma
    const manchas = Math.round((W * H) / 900);
    for (let i = 0; i < manchas; i++) {                       // manchas grandes: aglomerados de pixels, nunca formas geométricas
      const cx = r() * W; const cy = r() * H; const raio = 8 + r() * 26; cf.fillStyle = tons[(r() * tons.length) | 0];
      for (let k = 0; k < raio * 1.4; k++) { const a = r() * 6.283; const d = Math.sqrt(r()) * raio; cf.fillRect(Math.round(cx + Math.cos(a) * d), Math.round(cy + Math.sin(a) * d * 0.7), 1 + ((r() * 4) | 0), 1 + ((r() * 3) | 0)); }
    }
    cf.fillStyle = '#1d0e15';                                  // fibras finas e quebradas
    for (let i = 0; i < Math.round((W * H) / 2500); i++) {
      let x = r() * W; let y = r() * H; const dx = r() < 0.5 ? -1 : 1;
      for (let k = 0; k < 18 + r() * 40; k++) { if (r() > 0.15) cf.fillRect(Math.round(x), Math.round(y), 1, 1); y += 1; x += dx * (r() < 0.35 ? 1 : 0); }
    }
    for (let i = 0; i < Math.round((W * H) / 3000); i++) { cf.fillStyle = r() < 0.5 ? '#1f3a2c' : '#3a1a2a'; cf.globalAlpha = 0.5; cf.fillRect((r() * W) | 0, (r() * H) | 0, 1, 1); }   // pontos fracos de luz
    cf.globalAlpha = 1;
    const vein = mapa.layers.backgroundMid;                    // veias contínuas: seguem as colunas marcadas na camada backgroundMid
    if (vein) for (let tx = 0; tx < mapa.width; tx++) {
      let ty = 0;
      while (ty < mapa.height) {
        if (!vein[ty * mapa.width + tx]) { ty++; continue; }
        let ty1 = ty; while (ty1 < mapa.height && vein[ty1 * mapa.width + tx]) ty1++;
        let x = tx * ts + ts / 2; const x0 = x;
        for (let y = ty * ts; y < ty1 * ts; y++) {
          if (r() < 0.3) x = Math.max(x0 - 4, Math.min(x0 + 4, x + (r() < 0.5 ? -1 : 1)));
          cm.fillStyle = '#3d1424'; cm.fillRect(Math.round(x) - 1, y, 2, 1);
          if (r() < 0.45) { cm.fillStyle = '#5a2236'; cm.fillRect(Math.round(x) - 1, y, 1, 1); }
          if (r() < 0.02) { const s = r() < 0.5 ? -1 : 1; for (let b = 1; b < 4; b++) { cm.fillStyle = '#34111f'; cm.fillRect(Math.round(x) + s * b, y + b, 1, 1); } }
        }
        ty = ty1;
      }
    }
    f = { far, mid }; this._fundos.set(mapa, f); return f;
  }

  _drawLayer(mapa, nome, camX, camY, viewW, viewH, ctx = this.ctx, marcas = null, pular = null) {
    const dados = mapa.layers[nome];
    if (!dados) return;
    const organico = (nome === 'backgroundFar' || nome === 'backgroundMid') && this.config.render.organicBackground !== false && (!this._dbg || this._dbg.organicBackground !== false);
    const fundo = organico ? this._fundoOrganico(mapa) : null;
    const ts = mapa.tileSize; const variantes = mapa.autotile[nome];
    const tx0 = Math.max(0, Math.floor(camX / ts)); const tx1 = Math.min(mapa.width - 1, Math.floor((camX + viewW - 1) / ts));
    const ty0 = Math.max(0, Math.floor(camY / ts)); const ty1 = Math.min(mapa.height - 1, Math.floor((camY + viewH - 1) / ts));
    const g = this.graphics;
    const tinta = nome === 'solid' ? (this._tema || temaDoBioma('raizes')).parede : null;
    for (let ty = ty0; ty <= ty1; ty++) {
      for (let tx = tx0; tx <= tx1; tx++) {
        this.visibleCells++;
        const i = ty * mapa.width + tx;
        const id = dados[i];
        if (id === 0 || (pular && pular[i])) continue;   // `pular`: células da decoração reativa (desenhadas por tile-reacao.js)
        if (fundo) {   // tiles de fundo/veia viram recortes do fundo contínuo (sem quadrados nem emendas)
          const st = this._estilo(id);
          if (st === 'bg' || st === 'vein') { ctx.drawImage(st === 'bg' ? fundo.far : fundo.mid, tx * ts, ty * ts, ts, ts, tx * ts - camX, ty * ts - camY, ts, ts); this.visibleTiles++; if (marcas) marcas[i] = 1; continue; }
        }
        // variação por posição: 4 texturas por tile quebram a repetição de 16 px (é o que dava cara de grade)
        const vari = ((tx * 73856093) ^ (ty * 19349663)) & 3;
        if (g.draw(ctx, id, variantes ? variantes[i] : 0, tx * ts - camX, ty * ts - camY, ts, vari)) {
          this.visibleTiles++; if (marcas) marcas[i] = 1;
          if (tinta) { ctx.fillStyle = tinta; ctx.fillRect(tx * ts - camX, ty * ts - camY, ts, ts); }   // cor do bioma sobre paredes e chão
          // Passe de transição orgânica: só visual, aplicado após a tinta e sem tocar na colisão.
          if (nome === 'solid') drawOrganicTransitions(ctx, mapa, tx, ty, id, tx * ts - camX, ty * ts - camY, ts);
        }
      }
    }
  }
}
