// =====================================================================
// DESENHO DO MUNDO VIVO (v1.38.0) — só leitura do estado de entities/mundo-vivo.js. Canvas 2D, retângulos, pixel art.
// Custo por quadro (nível 2, tudo ligado): ~12 retângulos de névoa + até 40 partículas + 8 esporelitos (3 retângulos cada)
// + murais visíveis (1 drawImage cada, o painel é pré-desenhado uma vez). Nada aqui cria gradientes nem objetos por quadro.
// =====================================================================
import { cenaRects, paletaDoMural, PAINEL } from '../world/vestigios.js';

const _cacheMural = new Map();

/** Pré-desenha o painel (48x32) numa tela offscreen; sem `criar` (testes/Node) devolve null e o chamador desenha os retângulos. */
function painel(cena, biome, criar) {
  const chave = `${cena}|${biome}`; if (_cacheMural.has(chave)) return _cacheMural.get(chave);
  if (!criar) return null;
  const c = criar(PAINEL.w, PAINEL.h); const g = c.getContext('2d'); const pal = paletaDoMural(biome);
  g.fillStyle = 'rgba(10,6,10,0.80)'; g.fillRect(0, 0, PAINEL.w, PAINEL.h);
  for (const [x, y, w, h, k] of cenaRects(cena)) { if (k === 0) continue; const [r, gg, b] = pal[k]; g.fillStyle = `rgb(${r},${gg},${b})`; g.fillRect(x, y, w, h); }
  _cacheMural.set(chave, c); return c;
}

/** Murais: quase invisíveis no escuro; a luz do Limo os revela. Os já descobertos ficam um pouco mais legíveis. */
export function desenharMurais(ctx, vivo, camX, camY, W, H, t, criar = null) {
  const lista = vivo?.murais?.lista; if (!lista?.length) return 0; let n = 0;
  const pal = paletaDoMural(vivo.bioma);
  for (const m of lista) {
    const x = Math.round(m.rect.x - camX); const y = Math.round(m.rect.y - camY);
    if (x > W || y > H || x + m.rect.w < 0 || y + m.rect.h < 0) continue;
    if (vivo.segredos.oculta(m.def.x, m.def.y)) continue;
    const base = m.achado ? 0.30 : 0.12; const a = base + (1 - base) * m.vis;
    ctx.save(); ctx.globalAlpha = a;
    const tela = painel(m.def.cena, vivo.bioma, criar);
    if (tela) ctx.drawImage(tela, x, y);
    else { ctx.fillStyle = 'rgba(10,6,10,0.8)'; ctx.fillRect(x, y, PAINEL.w, PAINEL.h); for (const [rx, ry, rw, rh, k] of cenaRects(m.def.cena)) { if (!k) continue; const c = pal[k]; ctx.fillStyle = `rgb(${c[0]},${c[1]},${c[2]})`; ctx.fillRect(x + rx, y + ry, rw, rh); } }
    if (m.vis > 0.5 && !m.achado) { ctx.globalAlpha = 0.35 * m.vis * (0.6 + 0.4 * Math.sin(t * 5)); ctx.strokeStyle = `rgb(${pal[2][0]},${pal[2][1]},${pal[2][2]})`; ctx.strokeRect(x + 0.5, y + 0.5, PAINEL.w - 1, PAINEL.h - 1); }
    ctx.restore(); n++;
  }
  return n;
}

/** Dicas de segredo: fresta de luz que respira na rocha falsa + fiapos de esporo que vazam da boca. */
export function desenharDicas(ctx, vivo, camX, camY, t, resp, tema) {
  const s = vivo?.segredos; if (!s || !s.fechados.length) return;
  const ts = vivo.ts || 16; const [r, g, b] = (tema?.passagem || [236, 196, 110]);
  ctx.save();
  for (const f of s.frestas(ts)) { ctx.fillStyle = `rgba(${r},${g},${b},${(0.05 + 0.13 * resp + (s.rastro ? 0.18 : 0)).toFixed(3)})`; ctx.fillRect(Math.round(f.x - camX), Math.round(f.y - camY), 2, f.h); }
  for (const p of s.fiapos) { ctx.fillStyle = `rgba(${r},${g},${b},${(0.55 * (p.vida / p.max)).toFixed(3)})`; ctx.fillRect(Math.round(p.x - camX), Math.round(p.y - camY), 1, 1); }
  ctx.restore();
}

/** A rocha falsa some devagar quando o segredo é descoberto: desenha o tile antigo com alpha decrescente. */
export function desenharDissolucao(ctx, graphics, vivo, ts, camX, camY) {
  const lista = vivo?.segredos?.dissolvendo; if (!lista?.length) return 0;
  ctx.save();
  for (const d of lista) { ctx.globalAlpha = Math.max(0, 1 - d.t / 0.6); const vari = ((d.x * 73856093) ^ (d.y * 19349663)) & 3; graphics.draw(ctx, d.id, d.v, d.x * ts - camX, d.y * ts - camY, ts, vari); }
  ctx.restore(); return lista.length;
}

/** Névoa baixa em faixas (estilo vinheta em degraus do projeto): 4 retângulos por banco, sem gradiente. */
export function desenharNevoa(ctx, atm, t, camX, W, H) {
  if (!atm) return 0; const bancos = atm.bancos(t, camX, W, H); const [r, g, b] = atm.clima.nevoa.cor;
  ctx.save();
  for (const k of bancos) for (let i = 0; i < 4; i++) {
    ctx.fillStyle = `rgba(${r},${g},${b},${(k.a * (0.3 + 0.22 * i)).toFixed(3)})`;
    ctx.fillRect(Math.round(k.x + i * 8), Math.round(k.y + i * 5), Math.max(1, k.w - i * 16), Math.max(1, k.h - i * 10));
  }
  ctx.restore(); return bancos.length;
}

/** Partículas dos eventos de clima (poeira, rajada de esporos) e anéis do núcleo. */
export function desenharAtmosfera(ctx, atm, camX, camY) {
  if (!atm || (!atm.p.length && !atm.aneis.length)) return;
  ctx.save();
  for (const q of atm.p) {
    const u = q.vida / q.max; const a = Math.min(1, u * 3, (1 - u) * 6 + 0.25) * 0.6; const [r, g, b] = q.cor;
    ctx.fillStyle = `rgba(${r},${g},${b},${a.toFixed(3)})`; ctx.fillRect(Math.round(q.x - camX), Math.round(q.y - camY), q.tam, q.tam);
  }
  for (const a of atm.aneis) {
    const u = 1 - a.vida / a.max; ctx.strokeStyle = `rgba(200,150,255,${(0.5 * (1 - u)).toFixed(3)})`; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(Math.round(a.x - camX), Math.round(a.y - camY), a.r * u, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.restore();
}

/** Esporelitos: pontinhos de luz vivos. Desenhados DEPOIS da iluminação para brilharem no escuro. */
export function desenharEsporelitos(ctx, vivo, camX, camY, t, tema, W, H) {
  const lista = vivo?.esporelitos?.lista; if (!lista?.length) return;
  const cor = tema?.bolha || '120,255,220'; ctx.save();
  for (const e of lista) {
    const x = Math.round(e.x - camX); const y = Math.round(e.y - camY); if (x < -4 || y < -4 || x > W + 4 || y > H + 4) continue;
    const pisca = 0.6 + 0.4 * Math.sin(t * 2.2 + e.fase); const a = (e.medo > 0 ? 0.95 : 0.55) * pisca;
    ctx.fillStyle = `rgba(${cor},${(0.16 * pisca).toFixed(3)})`; ctx.fillRect(x - 1, y - 1, 3, 3);
    ctx.fillStyle = `rgba(${cor},${a.toFixed(3)})`; ctx.fillRect(x, y, 1, 1);
  }
  ctx.restore();
}
