// =====================================================================
// POLIMENTO AUDIOVISUAL v1.36 — lógica pura (sem DOM), testável em Node.
//   LuzesFx          luzes efêmeras (impacto, morte, aviso de ataque) que entram em coletarLuzes
//   CamadaFrontal    partículas em PRIMEIRO plano com parallax > 1 (passam mais rápido que o cenário = profundidade)
//   SUPERFICIE       como cada bioma "soa" ao pisar/golpear (multiplicadores de tom e cauda)
//   TRANSICAO_BIOMA  cor/tempo da íris entre salas, mais lenta e colorida quando o bioma muda
// =====================================================================

/** Luzes efêmeras: {x,y,raio,cor,dur,intens}. O raio cresce rápido e a luz some em ease-out. */
export class LuzesFx {
  constructor(max = 8) { this.max = max; this.itens = []; }
  add({ x, y, raio = 30, cor = [255, 240, 200], dur = 0.18, intens = 0.9 }) {
    if (this.itens.length >= this.max) this.itens.shift();
    this.itens.push({ x, y, raio, cor, dur, intens, t: 0 });
  }
  update(dt) { for (const l of this.itens) l.t += dt; this.itens = this.itens.filter((l) => l.t < l.dur); }
  /** Fontes no formato de coletarLuzes. */
  lista() {
    return this.itens.map((l) => { const u = l.t / l.dur; const k = 1 - u * u;
      return { id: 'fx', x: l.x, y: l.y, raio: l.raio * (0.6 + 0.4 * Math.min(1, u * 4)), intensidade: l.intens * k, cor: l.cor, tinta: 0.3 * k }; });
  }
}

/** Luzes de aviso: quem está anunciando um ataque brilha em vermelho-quente (visível mesmo no escuro). */
export function luzesDeAviso(inimigos) {
  const out = [];
  for (const e of inimigos || []) {
    if (!e.alive || !e.telegrafando) continue; const f = e.telegrafoFracao || 0;
    const boss = e.cfg?.kind === 'boss';
    out.push({ id: 'aviso', x: e.centerX, y: e.centerY, raio: (boss ? 46 : 26) * (0.7 + 0.5 * f), intensidade: 0.35 + 0.55 * f, cor: [255, 80, 60], tinta: 0.12 + 0.2 * f });
    for (const z of boss ? e.attackZones || [] : []) {
      if (!z.active || z.tipo === 'ring') continue;
      out.push({ id: 'zona', x: z.x + z.w / 2, y: z.y + z.h / 2, raio: Math.max(24, Math.min(60, z.w)), intensidade: 0.7, cor: [255, 190, 110], tinta: 0.2 });
    }
  }
  return out;
}

/** Camada frontal por bioma: n partículas, direção (vx,vy px/s), parallax (>1 = mais perto), cor RGB e alpha. */
export const CAMADA_FRONTAL = {
  raizes: { n: 12, vx: 3, vy: 7, parallax: 1.45, cor: [214, 184, 140], alpha: 0.30, tam: [1, 2], nome: 'cinza' },
  jardim: { n: 14, vx: 2, vy: -6, parallax: 1.5, cor: [140, 255, 220], alpha: 0.34, tam: [1, 3], nome: 'esporo' },
  nucleo: { n: 12, vx: -3, vy: -10, parallax: 1.4, cor: [214, 160, 255], alpha: 0.32, tam: [1, 2], nome: 'fagulha' },
};
const PRNG = (s) => () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };

export class CamadaFrontal {
  constructor(bioma = 'raizes', semente = 7) {
    this.cfg = CAMADA_FRONTAL[bioma] || CAMADA_FRONTAL.raizes; const r = PRNG(semente);
    this.p = Array.from({ length: this.cfg.n }, () => ({ x: r(), y: r(), fase: r() * 6.28, tam: this.cfg.tam[0] + Math.round(r() * (this.cfg.tam[1] - this.cfg.tam[0])), prof: 0.8 + r() * 0.4 }));
  }
  /** Posição de tela de cada partícula (envolve a tela: nunca some, nunca se acumula). */
  posicoes(t, camX, camY, W, H) {
    const c = this.cfg;
    return this.p.map((q) => {
      const par = c.parallax * q.prof;
      const x = (((q.x * W + (c.vx * t) - camX * par + Math.sin(t * 0.7 + q.fase) * 6) % W) + W) % W;
      const y = (((q.y * H + (c.vy * t) - camY * par * 0.6) % H) + H) % H;
      return { x, y, tam: q.tam, a: c.alpha * (0.6 + 0.4 * Math.sin(t * 1.3 + q.fase)) };
    });
  }
  draw(ctx, t, camX, camY, W, H) {
    const [r, g, b] = this.cfg.cor; ctx.save();
    for (const q of this.posicoes(t, camX, camY, W, H)) { ctx.fillStyle = `rgba(${r},${g},${b},${q.a.toFixed(3)})`; ctx.fillRect(Math.round(q.x), Math.round(q.y), q.tam, q.tam); }
    ctx.restore();
  }
}

/** Timbre por bioma: multiplicador de tom, de volume e uma cauda opcional ['onda', f0, f1, dur, vol]. */
export const SUPERFICIE = {
  raizes: { tom: 0.86, vol: 1.05, cauda: ['triangle', 210, 90, 0.07, 0.012] },   // osso/carne seca: grave e com "estalo"
  jardim: { tom: 1.14, vol: 0.9, cauda: null },                                  // musgo/folha: leve e macio
  nucleo: { tom: 1.0, vol: 1.0, cauda: ['sine', 520, 380, 0.22, 0.010] },         // santuário: ressoa
};
export const SFX_DE_SUPERFICIE = new Set(['passo', 'pouso', 'pouso_forte', 'acerto', 'acerto_pesado', 'parede', 'derrapar']);

/** Íris entre salas: cor da borda e duração; mudar de bioma é mais lento e marca a viagem. */
export const COR_DA_BORDA = { raizes: '#c98a52', jardim: '#4fe0b0', nucleo: '#b27cff' };
export function planoDeTransicao(biomaAtual, biomaDestino, base = { out: 0.28, in: 0.4 }) {
  const muda = !!biomaDestino && biomaDestino !== biomaAtual;
  return { muda, out: base.out * (muda ? 1.9 : 1), in: base.in * (muda ? 1.8 : 1), cor: COR_DA_BORDA[biomaDestino || biomaAtual] || '#7a1f3d', som: muda ? `bioma_${biomaDestino}` : 'transicao_sala' };
}
