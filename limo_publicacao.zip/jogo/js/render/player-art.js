// =====================================================================
// ARTE PROVISÓRIA DO LIMO (gelatina verde com detalhes amarelos)
// =====================================================================

import { pernaGrossa, PALETA_PATA_LIMO } from './legs.js';
import { poseBasica } from '../entities/limo-anim.js';

const COR = { contorno: '#0b2514', corpo: '#55ce67', membrana: '#84ed77', luz: '#caff91', detalhe: '#ffe135', nucleo: '#f1c94f', branco: '#f4fff0', pupila: '#10240f', sombra: '#278843', profundo: '#176332' };

export function drawPlayer(ctx, player, camX, camY, config) {
  const sp = config.player.sprite;
  const b = player.body;
  
  // --- 1. DESENHAR RASTO DE DASH NO CHÃO E PARTÍCULAS ---
  if (player.trail && player.trail.length > 0) {
    player.trail.forEach((p) => {
      ctx.save();
      ctx.globalAlpha = Math.max(0, p.vida * 0.9);
      const px = Math.round(p.x - camX);
      const py = Math.round(p.y - camY);
      ctx.fillStyle = p.cor || COR.luz;
      if (p.tipo === 'tinta') ctx.globalAlpha = Math.min(0.85, p.vida * 1.4);
      
      const largura = p.w || 4;
      const altura = p.h || 3;
      ctx.fillRect(px, py, largura, altura);
      ctx.restore();
    });
  }

  // --- 2. GOTAS ORGÂNICAS: silhueta, volume e brilho como a Tendril ---
  if (player.gooParticles && player.gooParticles.length > 0) {
    player.gooParticles.forEach((g) => {
      const alpha = Math.max(0, g.vida / g.maxVida);
      const gx = Math.round(g.x - camX); const gy = Math.round(g.y - camY);
      const r = g.raio || 1;
      ctx.save(); ctx.globalAlpha = alpha;
      if (r >= 2) {
        ctx.fillStyle = COR.contorno; ctx.fillRect(gx - 2, gy - 2, 5, 5);
        ctx.fillStyle = g.cor || COR.corpo; ctx.fillRect(gx - 1, gy - 1, 3, 3);
        ctx.fillStyle = COR.luz; ctx.fillRect(gx - 1, gy - 1, 1, 1);
        ctx.fillStyle = COR.sombra; ctx.fillRect(gx + 1, gy + 1, 1, 1);
      } else {
        ctx.fillStyle = COR.contorno; ctx.fillRect(gx - 1, gy - 1, 3, 3);
        ctx.fillStyle = g.cor || COR.corpo; ctx.fillRect(gx, gy, 2, 2);
        ctx.fillStyle = COR.luz; ctx.fillRect(gx, gy, 1, 1);
      }
      ctx.restore();
    });
  }

  // --- 3. DESENHAR PARTÍCULAS DE ATERRAGEM ---
  if (player.landingParticles && player.landingParticles.length > 0) {
    player.landingParticles.forEach((lp) => {
      ctx.save();
      ctx.globalAlpha = Math.max(0, lp.vida / 0.5);
      const lpx = Math.round(lp.x - camX);
      const lpy = Math.round(lp.y - camY);
      ctx.fillStyle = COR.corpo;
      ctx.fillRect(lpx, lpy, lp.tamanho, lp.tamanho);
      ctx.restore();
    });
  }

  // --- 3. DESENHAR PARTÍCULAS DE ATRITO NA PAREDE (Wall Slide) ---
  if (player.wallParticles && player.wallParticles.length > 0) {
    player.wallParticles.forEach((wp) => {
      ctx.save();
      ctx.globalAlpha = Math.max(0, wp.vida / 0.4);
      const wpx = Math.round(wp.x - camX);
      const wpy = Math.round(wp.y - camY);
      ctx.fillStyle = COR.detalhe;
      ctx.fillRect(wpx, wpy, wp.tamanho, wp.tamanho);
      ctx.restore();
    });
  }

  const pose = player.anim?.pose || poseBasica(player);   // deformação/inclinação/olhar/expressão por situação (limo-anim.js)
  let ancoraX = Math.round(b.x + b.w / 2 + sp.offsetX - camX);
  const base = Math.round(b.y + b.h + sp.offsetY - camY) - 1 + Math.round(pose.oy || 0);

  let w = sp.w - 6; let h = sp.h - 5;
  const mola = player.squash.value;

  h = Math.round(h * (1 + mola) * pose.sy);
  w = Math.round(w * (1 - mola * 0.6) * pose.sx);

  if (Math.abs(mola) > 0.05) {
    ancoraX += Math.round(player.facing * mola * 3);
  }
  ancoraX += Math.round(pose.ox);
  ancoraX -= (player.wallSide || 1) * recuoPatas(player);   // agarrado: as patas afastam o corpo da parede (só visual; a hitbox não muda)
  if (pose.tremor) ancoraX += (Math.floor((player.anim?.t || 0) * 50) % 2 ? 1 : -1);   // tremor de dor
  w = Math.max(6, w); h = Math.max(3, h);

  // --- 4. DESENHAR SOMBRA (Apenas quando estiver no chão) ---
  if (player.onGround) {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    const larguraSombra = Math.max(6, w - 2);
    ctx.fillRect(ancoraX - Math.floor(larguraSombra / 2), base + 1, larguraSombra, 2);
  }

  const metade = (i) => {
    const t = ((i + 0.5) / h) * 2 - 1;
    const e = Math.pow(Math.abs(t), t > 0 ? 3.4 : 2.2);
    return Math.max(1, Math.round((w / 2) * Math.sqrt(Math.max(0, 1 - e))));
  };
  const topo = base - h;
  // inclinação elástica (limo-anim.js): o topo desloca até `lean` px e a base fica plantada — cada linha do corpo recebe seu deslocamento
  const lean = Math.max(-3, Math.min(3, pose.inclina || 0));
  const d = (i) => (lean ? Math.round(lean * (1 - i / Math.max(1, h - 1)) ** 1.5) : 0);

  if (player.membranaFlash > 0) {
    ctx.save(); ctx.globalAlpha = Math.min(1, player.membranaFlash / 0.32);
    ctx.strokeStyle = '#c58cff'; ctx.lineWidth = 1;
    ctx.strokeRect(Math.round(b.x - camX) - 2, Math.round(b.y - camY) - 2, b.w + 4, b.h + 4);
    ctx.restore();
  }

  ctx.fillStyle = COR.contorno;
  for (let i = 0; i < h; i++) { const m = metade(i); ctx.fillRect(ancoraX + d(i) - m - 1, topo + i, 2 * m + 2, 1); }
  ctx.fillRect(ancoraX + d(0) - metade(0), topo - 1, 2 * metade(0), 1);
  ctx.fillRect(ancoraX + d(h - 1) - metade(h - 1), base, 2 * metade(h - 1), 1);

  const corpo = player.state === 'hurt' ? '#ffffff' : COR.corpo;
  for (let i = 0; i < h; i++) {
    const m = metade(i);
    // Membrana clara no topo, volume verde no meio e barriga densa embaixo.
    ctx.fillStyle = player.state === 'hurt' ? corpo : (i < h * 0.25 ? COR.membrana : i > h * 0.72 ? COR.sombra : corpo);
    ctx.fillRect(ancoraX + d(i) - m, topo + i, 2 * m, 1);
  }
  if (h >= 7) {
    // Reflexo irregular, núcleo dourado e bolhinhas deixam o Limo menos "bolinha lisa".
    const aT = ancoraX + d(2); const aB = ancoraX + d(h - 2);   // âncoras dos detalhes de cima e de baixo acompanham a inclinação
    ctx.fillStyle = COR.luz; ctx.fillRect(aT - Math.floor(w / 3), topo + 1, 2, 1); ctx.fillRect(aT - Math.floor(w / 2) + 1, topo + 3, 1, 1);
    ctx.fillStyle = COR.profundo; ctx.fillRect(aB + Math.floor(w / 3), topo + h - 3, 1, 1); ctx.fillRect(aB - 1, topo + h - 2, 1, 1);
    const brilho = Math.floor((player.anim?.t || 0) * 5) % 2;
    ctx.fillStyle = COR.nucleo; ctx.fillRect(aT + Math.floor(w / 4), topo + 2, 2, 2);
    ctx.fillStyle = brilho ? '#fff3a5' : COR.detalhe; ctx.fillRect(aT + Math.floor(w / 4), topo + 2, 1, 1);
  }
  drawPatas(ctx, player, b, camX, ancoraX, base, topo, w, h);
  drawBracosLula(ctx, player, ancoraX, base, w);
  const linhaOlhos = Math.max(2, Math.round(h * 0.35));
  if (h >= 6 || pose.expressao === 'morto') drawOlhos(ctx, pose, player.facing > 0 ? 1 : -1, ancoraX + d(linhaOlhos), topo + linhaOlhos, corpo);
  drawParticulasFrente(ctx, player, camX, camY);
}

/** v1.27.0 — partículas que ficam NA FRENTE do corpo: anéis de onda, bolhas de gás e faíscas (golpe, dano, membrana, largada). */
function drawParticulasFrente(ctx, player, camX, camY) {
  const aneis = player.anelParticles; const bolhas = player.bolhaParticles; const faiscas = player.faiscaParticles;
  if (aneis && aneis.length) {
    for (const a of aneis) {   // círculo pontilhado de pixels que cresce e some
      const k = 1 - a.vida / a.maxVida; const r = a.raioIni + (a.raioFim - a.raioIni) * (1 - (1 - k) * (1 - k)); const n = Math.max(8, Math.round(r * 2.4));
      ctx.save(); ctx.globalAlpha = Math.max(0, 1 - k) * 0.9; ctx.fillStyle = a.cor;
      for (let i = 0; i < n; i++) { const ang = (i / n) * Math.PI * 2; ctx.fillRect(Math.round(a.x + Math.cos(ang) * r - camX), Math.round(a.y + Math.sin(ang) * r * 0.8 - camY), 1, 1); }
      ctx.restore();
    }
  }
  if (bolhas && bolhas.length) {
    for (const bo of bolhas) {   // bolha oca: aro claro de 1 px, reflexo e leve sumiço no fim
      const x = Math.round(bo.x - camX); const y = Math.round(bo.y - camY); const a = Math.min(1, bo.vida / 0.35);
      ctx.save(); ctx.globalAlpha = a * 0.85;
      if (bo.raio >= 2) { ctx.fillStyle = COR.membrana; ctx.fillRect(x - 1, y - 2, 3, 1); ctx.fillRect(x - 1, y + 2, 3, 1); ctx.fillRect(x - 2, y - 1, 1, 3); ctx.fillRect(x + 2, y - 1, 1, 3); ctx.fillStyle = COR.branco; ctx.fillRect(x - 1, y - 1, 1, 1); }
      else { ctx.fillStyle = COR.membrana; ctx.fillRect(x, y - 1, 1, 1); ctx.fillRect(x - 1, y, 1, 1); ctx.fillRect(x + 1, y, 1, 1); ctx.fillRect(x, y + 1, 1, 1); ctx.fillStyle = COR.branco; ctx.fillRect(x - 1, y - 1, 1, 1); }
      ctx.restore();
    }
  }
  if (faiscas && faiscas.length) {
    for (const f of faiscas) {
      ctx.save(); ctx.globalAlpha = Math.max(0, Math.min(1, (f.vida / f.maxVida) * 1.4)); ctx.fillStyle = f.cor;
      const fx = Math.round(f.x - camX); const fy = Math.round(f.y - camY); const t = f.tam || 1; ctx.fillRect(fx, fy, t, t);
      if (f.vida / f.maxVida > 0.6 && Math.abs(f.vx) + Math.abs(f.vy) > 60) { ctx.globalAlpha *= 0.5; ctx.fillRect(Math.round(fx - f.vx * 0.02), Math.round(fy - f.vy * 0.02), 1, 1); }   // cauda curta nas rápidas
      ctx.restore();
    }
  }
}

/** Olhos por expressão: normal · piscando (traço) · dor (> <) · foco (estreitos) · susto (pupila minúscula) · cansado (pálpebra caída) · morto (X). */
export function drawOlhos(ctx, pose, facing, ancoraX, y, corCorpo) {
  const ex = pose.expressao;
  const lx = Math.abs(pose.olhar.x) > 0.3 ? Math.sign(pose.olhar.x) : facing * 0.7;
  const ly = pose.olhar.y < -0.3 ? -1 : pose.olhar.y > 0.3 ? 1 : 0;
  for (const dx of [-3, 1]) {
    const bx = ancoraX + dx + (facing > 0 ? 1 : 0);
    if (ex === 'morto') { ctx.fillStyle = COR.pupila; ctx.fillRect(bx, y, 1, 1); ctx.fillRect(bx + 2, y, 1, 1); ctx.fillRect(bx + 1, y + 1, 1, 1); ctx.fillRect(bx, y + 2, 1, 1); ctx.fillRect(bx + 2, y + 2, 1, 1); continue; }
    if (pose.piscar) { ctx.fillStyle = COR.pupila; ctx.fillRect(bx, y + 1, 3, 1); continue; }
    if (ex === 'dor') { ctx.fillStyle = COR.pupila; ctx.fillRect(bx, y, 1, 1); ctx.fillRect(bx + 1, y + 1, 1, 1); ctx.fillRect(bx, y + 2, 1, 1); ctx.fillRect(bx + 2, y, 1, 1); ctx.fillRect(bx + 2, y + 2, 1, 1); continue; }
    const alt = ex === 'foco' ? 2 : 3; const topoOlho = ex === 'foco' ? y + 1 : y;
    ctx.fillStyle = COR.branco; ctx.fillRect(bx, topoOlho, 3, alt);
    const px = bx + (lx > 0.3 ? 2 : lx < -0.3 ? 0 : 1); const py = topoOlho + (alt === 3 ? (ly < 0 ? 0 : 1) : 0);
    ctx.fillStyle = COR.pupila; ctx.fillRect(px, py, 1, ex === 'susto' ? 1 : alt === 3 ? 2 : 2);
    if (ex === 'cansado') { ctx.fillStyle = corCorpo; ctx.fillRect(bx, y, 3, 1); ctx.fillStyle = COR.contorno; ctx.fillRect(bx, y + 1, 3, 1); }   // pálpebra caída
  }
}

/** Salto Elástico (lula): no pulo duplo, braços de lula brotam embaixo do Limo — juntos e esticados no jato, depois abrem e ondulam, e recolhem. */
function drawBracosLula(ctx, player, ancoraX, base, w) {
  const dur = 0.5; const resta = player.squidFx || 0; if (resta <= 0 || player.state === 'dead') return;
  const p = 1 - resta / dur;                                                   // 0..1
  const suave = (x) => x * x * (3 - 2 * x);
  const abre = suave(Math.max(0, Math.min(1, (p - 0.25) / 0.6)));               // 0 = braços colados (jato) ... 1 = abertos
  const comp = Math.round(3 + 6 * Math.min(1, p / 0.3)) * (p > 0.8 ? (1 - p) / 0.2 * 0.6 + 0.4 : 1);   // estica rápido, encolhe no fim
  const esc = Math.min(1, w / 10);
  [-3.5, -1.2, 1.2, 3.5].forEach((off, i) => {
    for (let k = 1; k <= comp; k++) {
      const f = k / comp; const onda = Math.sin(resta * 38 - k * 0.9 + i * 1.7) * (0.5 + 1.4 * abre) * f;
      const x = Math.round(ancoraX + off * esc * (1 + abre * 1.3 * f) + onda); const y = Math.round(base - 1 + k);
      ctx.fillStyle = k >= comp - 1 ? '#c8ff9a' : (k % 3 === 0 ? '#3aa550' : '#2a8040'); ctx.fillRect(x, y, 1, 1);
      if (k < comp * 0.5) { ctx.fillStyle = '#2a8040'; ctx.fillRect(x + (off > 0 ? 1 : -1), y, 1, 1); }   // braço mais grosso na raiz
    }
  });
}

/** Patas visíveis? (mutação + na parede + vivo + fora do chão). */
function patasAtivas(player) { return !!player.hasAbility?.('wallJump') && player.state !== 'dead' && !player.onGround && (player.legGrow || 0) > 0; }
/** Quanto (px) o corpo se afasta da parede enquanto as patas seguram: 0 → 4 junto com o brotar. */
function recuoPatas(player) { if (!patasAtivas(player)) return 0; const g = player.legGrow; return Math.round(4 * (1 - (1 - g) * (1 - g))); }

/**
 * Mutação Salto na Parede: só na parede brotam três patas grossas de aranha (estilo da Tecelã, em verde de Limo).
 * Animação com sentido: (1) BROTAR — as patas saem uma de cada vez (de cima p/ baixo) enquanto o corpo se afasta da parede;
 * o joelho sobe em arco e o pé crava na parede; (2) AGARRADO — pé plantado, joelho respira de leve; (3) DESLIZANDO — cada pé
 * raspa para baixo e se re-agarra mais acima, em fases alternadas (a pata "escala" a parede); (4) SOLTAR — recolhem rápido
 * (legGrow cai em 0,1 s ao pular da parede).
 */
function drawPatas(ctx, player, b, camX, ancoraX, base, topo, w, h) {
  if (!patasAtivas(player)) return;                                     // no chão: fofinho, sem patas
  const g = player.legGrow;
  const s = player.wallSide || 1;
  const t = player.anim?.t || 0;
  const deslizando = (player.vy || 0) > 20 && g >= 1;
  const paredeX = Math.round((s > 0 ? b.x + b.w : b.x) - camX) + (s > 0 ? 0 : -1);
  const dy = [-4, 2, 10];                                                // onde cada pé gruda na parede (abre em leque)
  const joelhoAlto = [-8, -5, -1];                                     // joelho sempre bem acima do pé: arco de aranha
  const kFrac = [0.5, 0.55, 0.5];                                       // quão para fora cada joelho fica
  const patas = [];
  for (let i = 0; i < 3; i++) {
    const gi = Math.max(0, Math.min(1, (g - i * 0.12) / 0.76));         // cada pata começa um pouco depois da anterior
    if (gi <= 0) continue;
    const e = 1 - (1 - gi) * (1 - gi);                                  // sai rápido e desacelera ao tocar
    const ry = topo + Math.round(h * (0.2 + i * 0.3)); const rx = ancoraX + s * Math.round(w / 2 - 1);
    let passo = 0; let respira = 0;
    if (deslizando) { const ciclo = (t * 5 + i / 3) % 1; passo = ciclo < 0.8 ? Math.round(ciclo / 0.8 * 3) : Math.round((1 - (ciclo - 0.8) / 0.2) * 3); }   // raspa p/ baixo (lento) e re-agarra p/ cima (rápido)
    else if (gi >= 1) respira = Math.round(Math.sin(t * 3 + i * 1.9) * 0.6);              // agarrada: joelho oscila de leve
    const fx = rx + (paredeX - rx) * e; const fy = ry + (dy[i] + passo) * e;              // pé: sai do corpo e sobe/desce até a parede
    const kx = rx + (paredeX - rx) * e * kFrac[i]; const ky = ry + joelhoAlto[i] * e - 2 * Math.sin(gi * Math.PI) + respira - (deslizando ? Math.round(passo * 0.4) : 0);
    patas.push([rx, ry, kx, ky, fx, fy]);
  }
  for (const p of patas) pernaGrossa(ctx, ...p, { grossura: 2, paleta: PALETA_PATA_LIMO, fase: 'contorno' });   // silhueta única
  for (const p of patas) pernaGrossa(ctx, ...p, { grossura: 2, paleta: PALETA_PATA_LIMO, fase: 'cor' });
}

export function spriteRect(player, camX, camY, config) {
  const sp = config.player.sprite; const b = player.body;
  return { x: b.x + b.w / 2 - sp.w / 2 + sp.offsetX - camX, y: b.y + b.h - sp.h + sp.offsetY - camY, w: sp.w, h: sp.h };
}
