// =====================================================================
// ARTE DOS GENES: ícone de dupla hélice (usado no gene a coletar, na tela de genes e nos avisos).
// Procedural, sem imagens: ctx.fillRect em pixels lógicos (mesma resolução 320×240 do jogo).
// =====================================================================
const hex = (cor) => { const h = cor.replace('#', ''); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)); };
export const rgba = (cor, a) => { const [r, g, b] = hex(cor); return `rgba(${r},${g},${b},${a})`; };
export const escurecer = (cor, f) => { const [r, g, b] = hex(cor).map((v) => Math.max(0, Math.min(255, Math.round(v * f)))); return `rgb(${r},${g},${b})`; };

/**
 * Desenha uma dupla hélice centrada em (cx, cy). `tamanho` = altura em px; `t` anima o giro (use 0 para ícone parado).
 * opcoes: { apagado } cinza (gene que ainda não está equipado/encontrado), { brilho } 0..1 do halo.
 */
export function drawGeneIcon(ctx, cor, cx, cy, tamanho = 14, t = 0, opcoes = {}) {
  const { apagado = false, brilho = 1 } = opcoes;
  const base = apagado ? '#7a7a88' : cor; const fundo = apagado ? '#3c3c48' : escurecer(cor, 0.45);
  const larg = Math.max(3, Math.round(tamanho * 0.27)); const topo = Math.round(cy - tamanho / 2);
  ctx.save();
  if (!apagado && brilho > 0) {   // halo: dois quadrados translúcidos (sem gradiente: fica nítido em pixel art)
    ctx.fillStyle = rgba(cor, 0.12 * brilho); ctx.fillRect(cx - larg - 3, topo - 1, larg * 2 + 6, tamanho + 2);
    ctx.fillStyle = rgba(cor, 0.16 * brilho); ctx.fillRect(cx - larg - 1, topo + 1, larg * 2 + 2, tamanho - 2);
  }
  for (let i = 0; i < tamanho; i++) {
    const fase = t * 3 + i * 0.46; const s = Math.sin(fase); const d = Math.round(s * larg);
    const y = topo + i;
    if (i % 4 === 2) { ctx.fillStyle = apagado ? '#55556a' : rgba('#ffffff', 0.38); ctx.fillRect(cx - Math.abs(d), y, Math.abs(d) * 2 + 1, 1); }   // degraus de bases
    const frente = Math.cos(fase) >= 0;   // qual fita está na frente
    ctx.fillStyle = frente ? fundo : base; ctx.fillRect(cx - d, y, 2, 1);
    ctx.fillStyle = frente ? base : fundo; ctx.fillRect(cx + d - 1, y, 2, 1);
  }
  ctx.restore();
}
