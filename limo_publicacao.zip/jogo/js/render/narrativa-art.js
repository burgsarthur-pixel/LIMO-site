// Desenho da narrativa de Raízes (v1.50.0): rastros de fios costurados, balões de fala e o clarão de memória. Só lê o que o Game guarda; não decide nada.
const LARG_MAX = 112;

/** Linhas de pontos costurados (traços curtos) que seguem o chão. `game.rastros` = [{spec, pts}] montado em Game._instalarSala. */
export function drawRastros(ctx, game, camX, camY, t) {
  const lista = game.rastros; if (!lista?.length) return;
  const desc = game.progress?.descobertas;
  ctx.save(); ctx.lineWidth = 1; ctx.lineCap = 'butt';
  for (const r of lista) {
    if (r.spec.revela && !desc?.has?.(`hist:${r.spec.revela}`)) continue;
    const { pts, spec } = r; if (pts.length < 2) continue;
    for (let k = 0; k < spec.fios; k++) {
      const off = -k * 2 - (k ? 1 : 0); const pulso = 0.34 + 0.2 * Math.sin(t * (1.6 + spec.tensao * 2.4) + k * 1.7);
      ctx.strokeStyle = `rgba(232,216,255,${pulso.toFixed(3)})`; ctx.setLineDash([3, 3]); ctx.lineDashOffset = -((t * 3) | 0) + k * 2;
      ctx.beginPath();
      for (let i = 0; i < pts.length; i++) {
        const sag = spec.tensao >= 1 ? 0 : Math.sin(i * 1.3 + k) * (1 - spec.tensao) * 0.6;   // frouxo balança; esticado fica reto
        const x = Math.round(pts[i][0] - camX); const y = Math.round(pts[i][1] + off + sag - camY);
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }
  ctx.setLineDash([]); ctx.restore();
}

function quebrar(ctx, texto) {
  const mede = (s) => (ctx.measureText ? ctx.measureText(s).width : s.length * 4.8); const linhas = []; let atual = '';
  for (const p of String(texto).split(/\s+/)) { const teste = atual ? `${atual} ${p}` : p; if (mede(teste) > LARG_MAX && atual) { linhas.push(atual); atual = p; } else atual = teste; }
  if (atual) linhas.push(atual); return { linhas: linhas.slice(0, 4), w: Math.min(LARG_MAX + 10, Math.max(...linhas.map(mede)) + 10) };
}

/** Balões sobre quem fala (Limo, NPC vivo ou presença). Dentro da tela e com fade. `game.baloes` = [{quem, texto, espera, t, dur}]. */
export function drawBaloes(ctx, game, camX, camY, W, H) {
  const lista = game.baloes; if (!lista?.length) return;
  ctx.save(); ctx.font = '8px monospace'; ctx.textAlign = 'center';
  for (const b of lista) {
    if (b.espera > 0) continue;
    const alvo = game.posicaoDeFala?.(b.quem); if (!alvo) continue;
    const a = Math.max(0, Math.min(1, b.t / 0.25, (b.dur - b.t) / 0.4)); if (a <= 0) continue;
    if (b._texto !== b.texto) { const q = quebrar(ctx, b.texto); b._texto = b.texto; b._ls = q.linhas; b._w = q.w; }
    const h = b._ls.length * 9 + 6; const w = b._w;
    let x = Math.round(alvo.x - camX - w / 2); let y = Math.round(alvo.y - camY - h - 8);
    x = Math.max(4, Math.min(W - w - 4, x)); y = Math.max(4, Math.min(H - h - 4, y));
    ctx.globalAlpha = a; ctx.fillStyle = 'rgba(8,4,16,0.9)'; ctx.fillRect(x, y, w, h);
    ctx.fillStyle = b.quem?.presenca ? '#9a6fd0' : b.quem === 'limo' ? '#7ad0a0' : '#c8b0ff'; ctx.fillRect(x, y, w, 1); ctx.fillRect(x, y + h - 1, w, 1); ctx.fillRect(x, y, 1, h); ctx.fillRect(x + w - 1, y, 1, h);
    const cx = Math.max(x + 4, Math.min(x + w - 5, Math.round(alvo.x - camX))); ctx.fillRect(cx - 1, y + h, 3, 1); ctx.fillRect(cx, y + h + 1, 1, 2);   // cauda
    ctx.fillStyle = '#f2ecff'; b._ls.forEach((l, i) => ctx.fillText(l, x + w / 2, y + 9 + i * 9));
  }
  ctx.restore();
}

/**
 * Despertar (v1.51.0): a escuridão se abre em volta do Limo, como olhos que acordam, e dois anéis de pulso saem dele.
 * Sem texto e sem travar o controle (é só desenho). `game.despertar` = {t, dur}; ao fim some.
 */
export function drawDespertar(ctx, game, camX, camY, W, H) {
  const d = game.despertar; if (!d) return;
  const px = game.player ? game.player.centerX - camX : W / 2; const py = game.player ? game.player.centerY - camY : H / 2;
  const k = Math.max(0, Math.min(1, (d.t - 0.6) / 2.2)); const e = k * k * (3 - 2 * k);   // abertura suave (smoothstep)
  const sai = Math.max(0, Math.min(1, (d.dur - d.t) / 0.8));
  const escuro = (1 - e) * sai;
  ctx.save();
  if (escuro > 0.01) {
    const r0 = e * H * 0.9; const r1 = r0 + H * 0.2;   // no início só um halo pequeno em volta do Limo; depois a visão se abre
    const g = ctx.createRadialGradient(px, py, 0, px, py, r1);
    g.addColorStop(Math.min(0.999, r0 / r1), 'rgba(4,2,8,0)'); g.addColorStop(1, `rgba(4,2,8,${(escuro * 0.97).toFixed(3)})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }
  for (const [inicio, cor] of [[0.9, '122,208,160'], [1.7, '232,216,255']]) {   // dois anéis: o primeiro ao abrir os olhos
    const u = d.t - inicio; if (u <= 0 || u > 1.8) continue;
    ctx.strokeStyle = `rgba(${cor},${(0.5 * (1 - u / 1.8)).toFixed(3)})`; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(Math.round(px), Math.round(py), 6 + u * 70, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.restore();
}

/**
 * Lembrança no meio da luta (v1.50.0; v1.51.0 mais evidente): véu violeta leve sobre a arena, uma faixa de memória no alto,
 * uma costura que se fecha da esquerda para a direita e o texto aparecendo letra a letra. Não pausa o combate.
 * `game.lembranca` = {linhas, t, dur}.
 */
export function drawLembranca(ctx, game, W, H) {
  const l = game.lembranca; if (!l) return;
  const T = l.t; const entra = Math.min(1, T / 0.5); const sai = Math.min(1, (l.dur - T) / 0.8); const a = Math.max(0, Math.min(entra, sai)); if (a <= 0) return;
  const F = Math.round(H * 0.17);   // altura da faixa (≈ 41 px em 240 px de altura)
  ctx.save(); ctx.globalAlpha = a;
  ctx.fillStyle = 'rgba(70,40,110,0.12)'; ctx.fillRect(0, 0, W, H);   // véu violeta leve: a arena continua visível
  ctx.fillStyle = 'rgba(12,6,22,0.82)'; ctx.fillRect(0, 0, W, F);     // faixa de memória
  ctx.fillStyle = 'rgba(154,111,208,0.9)'; ctx.fillRect(0, F - 1, W, 1);
  const ate = Math.round(W * Math.min(1, Math.max(0, T - 0.2) / 1.4));   // costura que se fecha da esquerda para a direita
  ctx.fillStyle = 'rgba(200,176,255,0.55)'; ctx.fillRect(0, F - 5, ate, 1);
  for (let x = 4, i = 0; x < ate; x += 8, i++) { ctx.fillStyle = i % 2 ? 'rgba(232,216,255,0.9)' : 'rgba(200,176,255,0.7)'; ctx.fillRect(x, F - 7 + (i % 2) * 2, 2, 2); }
  let falta = Math.max(0, (T - 0.5) * 30);   // letras por segundo, linha após linha
  ctx.textAlign = 'center';
  l.linhas.forEach((s, i) => {
    const mostra = s.slice(0, Math.max(0, Math.min(s.length, Math.floor(falta)))); falta -= s.length + 4;
    const largura = ctx.measureText ? ctx.measureText(s).width : s.length * 4.8;
    ctx.font = largura > W - 16 ? '7px monospace' : '8px monospace';
    const y = Math.round(F / 2 - (l.linhas.length - 1) * 5.5 + i * 11 + 3);
    ctx.fillStyle = '#000'; ctx.fillText(mostra, W / 2 + 1, y + 1);   // sombra para ler sobre a arena
    ctx.fillStyle = '#e4d6ff'; ctx.fillText(mostra, W / 2, y);
  });
  ctx.restore();
}
