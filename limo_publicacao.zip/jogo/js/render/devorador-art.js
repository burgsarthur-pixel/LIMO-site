// =====================================================================
// DEVORADOR DE FLORES — representação visual (reconstrução, Etapa 2.4.2). Só desenho: sem IA, ataques, dano, colisão, arena ou eventos.
// Quadrúpede de raízes e fibras entrelaçadas, voltado para a esquerda. Cabeça híbrida: crânio de casca fundido a raízes na nuca,
// mandíbula com dentes e cavidades sensoriais vegetais (sem olhos). Patas dianteiras de placas de casca; traseiras de raízes.
//
// Método: cada parte é um volume (cápsulas afuniladas e elipses) com campo de distância, sombreado por uma luz vinda de cima à esquerda
// em três tons. O tronco é um tecido de fios que se cruzam (cada fio passa na frente ou atrás dos vizinhos). Cada camada recebe contorno
// de um pixel, calculado sobre a máscara original (sem propagação). Nada é imagem estática: tudo é gerado em código.
//
// Animação: seis quadros pré-renderizados em canvas (uma vez). A respiração muda o tronco (peito, ventre, corcova), a cabeça e a
// mandíbula, a flor e as pétalas; o balanço move tendrilhas sensoriais, folhas, trepadeiras do ventre e a ponta da cauda.
// Por quadro: um drawImage, sem fillRect. Paleta amostrada da imagem conceitual (faixa de cores e quantização da figura).
// =====================================================================
export const PALETA_DEVORADOR = Object.freeze({
  contorno: '#14101c',
  raiz_funda: '#301b2f', raiz_escura: '#4b2d59', raiz_roxa: '#782c6b', raiz: '#73384d',
  casca_sombra: '#4a2e3b', casca: '#8b5550', casca_media: '#a0665c', casca_clara: '#b57d72', casca_brilho: '#d1957f',
  musgo: '#5c5334', musgo_claro: '#817345',
  flor_escura: '#9c3c86', flor: '#cf5e9e', flor_clara: '#e98bc0',
  dente: '#ece2cc',
});
export const DEVORADOR_DIM = Object.freeze({ w: 64, h: 40 });
const { w: W, h: H } = DEVORADOR_DIM;
const LUZ = [-0.55, -0.83];                      // direção para a luz (cima, esquerda)

// ---------- formas (campos de distância) ----------
/** Cadeia de cápsulas afuniladas. Retorna d (negativo dentro), s (posição ao longo), u (lado: + é para cima/direita) e r (raio local). */
function cadeia(pts, rs) {
  const seg = []; let acc = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    const dx = pts[i + 1][0] - pts[i][0]; const dy = pts[i + 1][1] - pts[i][1]; const len = Math.hypot(dx, dy) || 1e-6;
    seg.push({ ax: pts[i][0], ay: pts[i][1], dx: dx / len, dy: dy / len, len, ra: rs[i], rb: rs[i + 1], s0: acc }); acc += len;
  }
  const f = (px, py) => {
    let melhor = null;
    for (let n = 0; n < seg.length; n++) {
      const g = seg[n];
      const bruto = (px - g.ax) * g.dx + (py - g.ay) * g.dy; const t = Math.max(0, Math.min(g.len, bruto));
      const ex = px - (g.ax + g.dx * t); const ey = py - (g.ay + g.dy * t);
      const r = g.ra + (g.rb - g.ra) * (t / g.len); const d = Math.hypot(ex, ey) - r;
      if (!melhor || d < melhor.d) {
        // nas pontas da cadeia, `s` continua além do fim (sem travar em 0), para que texturas ao longo do corpo não fiquem chapadas
        const sPos = (n === 0 && bruto < 0) ? bruto : (n === seg.length - 1 && bruto > g.len) ? g.s0 + bruto : g.s0 + t;
        melhor = { d, s: sPos, u: (px - g.ax) * g.dy - (py - g.ay) * g.dx, r };
      }
    }
    return melhor;
  };
  f.comprimento = acc;
  const mr = Math.max(...rs) + 2;
  f.limites = [Math.min(...pts.map((p) => p[0])) - mr, Math.min(...pts.map((p) => p[1])) - mr, Math.max(...pts.map((p) => p[0])) + mr, Math.max(...pts.map((p) => p[1])) + mr];
  return f;
}
const elipse = (cx, cy, rx, ry) => {
  const f = (px, py) => {
    const nx = (px - cx) / rx; const ny = (py - cy) / ry; const k = Math.hypot(nx, ny);
    return { d: (k - 1) * Math.min(rx, ry), s: px - cx, u: cy - py, r: Math.min(rx, ry) };
  };
  f.limites = [cx - rx - 2, cy - ry - 2, cx + rx + 2, cy + ry + 2];
  return f;
};
const uniao = (...fs) => {
  const u = (px, py) => { let m = null; for (const f of fs) { const v = f(px, py); if (!m || v.d < m.d) m = v; } return m; };
  if (fs.every((f) => f.limites)) u.limites = [Math.min(...fs.map((f) => f.limites[0])), Math.min(...fs.map((f) => f.limites[1])), Math.max(...fs.map((f) => f.limites[2])), Math.max(...fs.map((f) => f.limites[3]))];
  return u;
};
const caixa = (cx, cy, hx, hy) => {
  const f = (px, py) => ({ d: Math.max(Math.abs(px - cx) - hx, Math.abs(py - cy) - hy), s: 0, u: 0, r: 1 });
  f.limites = [cx - hx - 2, cy - hy - 2, cx + hx + 2, cy + hy + 2];
  return f;
};

// ---------- sombreado ----------
/** Tom 0 (sombra), 1 (meio) ou 2 (luz), a partir da normal do campo de distância. Devolve também a profundidade (distância à borda). */
function tomLuz(f, px, py, info) {
  const nx = f(px + 1, py).d - f(px - 1, py).d; const ny = f(px, py + 1).d - f(px, py - 1).d;
  const k = Math.hypot(nx, ny);
  const luz = k < 1e-6 ? 0 : (nx * LUZ[0] + ny * LUZ[1]) / k;
  const prof = -info.d;
  return { tom: luz > 0.25 ? 2 : (luz < -0.5 && prof < 3.4) ? 0 : 1, luz, prof };
}
const RAMPA = {
  casca: ['casca_sombra', 'casca', 'casca_clara'],
  raizA: ['casca_sombra', 'casca', 'casca_media'],
  raizB: ['raiz_funda', 'raiz_escura', 'raiz_roxa'],
  raizC: ['raiz_funda', 'musgo', 'musgo_claro'],
  flor: ['flor_escura', 'flor', 'flor_clara'],
};
const limita = (v) => (v < 0 ? 0 : v > 2 ? 2 : v);
const hash = (x, y) => (((x * 374761393) ^ (y * 668265263)) >>> 0) % 1000;

// ---------- pintura em camadas ----------
function novaGrade() { return Array.from({ length: H }, () => Array(W).fill(null)); }
/** Pinta uma forma: primeiro o contorno de 1 px sobre o que já existe, depois o interior com o material. */
function pintar(g, f, material, opcoes = {}) {
  const mascara = Array.from({ length: H }, () => Array(W).fill(false));
  const infos = Array.from({ length: H }, () => Array(W).fill(null));
  const L = f.limites || [0, 0, W, H];
  const x0 = Math.max(0, Math.floor(L[0])); const y0 = Math.max(0, Math.floor(L[1])); const x1 = Math.min(W, Math.ceil(L[2])); const y1 = Math.min(H, Math.ceil(L[3]));
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) { const i = f(x + 0.5, y + 0.5); infos[y][x] = i; mascara[y][x] = i.d <= 0; }
  const m = (x, y) => x >= 0 && y >= 0 && x < W && y < H && mascara[y][x];
  if (opcoes.contorno !== false) {
    for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
      if (!mascara[y][x] && (m(x - 1, y) || m(x + 1, y) || m(x, y - 1) || m(x, y + 1))) g[y][x] = 'contorno';
    }
  }
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
    if (!mascara[y][x]) continue;
    const info = infos[y][x]; const sh = tomLuz(f, x + 0.5, y + 0.5, info);
    const k = material(x, y, info, sh, opcoes);
    if (k) g[y][x] = k;
  }
}

// ---------- materiais ----------
/** Placas de casca rígida: juntas finas entre placas e tons de luz. */
const matPlacas = (passo, diag = false) => (x, y, i, sh, o) => {
  const coord = diag ? (x * 0.8 + y * 0.7) : i.s;
  const q = coord / passo; const frac = q - Math.floor(q);
  const escuro = o.escuro || 0;
  if (frac < 0.16) return 'casca_sombra';
  const pid = Math.floor(q);
  let tom = limita(sh.tom - escuro);
  if (tom === 2 && sh.prof < 1.6 && sh.luz > 0.8) return 'casca_brilho';
  if (tom === 1 && pid % 2) return 'casca_media';
  return RAMPA.casca[tom];
};
/** Fibras de raiz que correm ao longo do membro e se torcem (patas traseiras). */
const matFibras = (x, y, i, sh, o) => {
  const lado = i.u / (i.r || 1);
  const k = Math.floor((lado + 1) * 2.6 + 1.4 * Math.sin(i.s * 0.75)) % 3;
  const tom = limita(sh.tom - (o.escuro || 0));
  if (hash(x, y) % 29 === 0) return RAMPA.raizC[tom];
  return (k === 0 ? RAMPA.raizB : RAMPA.raizA)[tom];
};
/** Tecido do tronco: fios que acompanham a curvatura e se cruzam, cada um passando por cima ou por baixo. */
const FIOS = [
  { rampa: 0, fase: 0.00 }, { rampa: 1, fase: 0.14 }, { rampa: 0, fase: 0.29 }, { rampa: 2, fase: 0.43 },
  { rampa: 0, fase: 0.57 }, { rampa: 1, fase: 0.71 }, { rampa: 0, fase: 0.86 },
];
const RAMPA4 = [   // quatro tons por tipo de fio: raiz marrom, raiz roxa, trepadeira
  ['casca_sombra', 'casca', 'casca_media', 'casca_clara'],
  ['raiz_funda', 'raiz_escura', 'raiz_roxa', 'raiz'],
  ['raiz_funda', 'musgo', 'musgo_claro', 'musgo_claro'],
];
function tecido(i, sh, o) {
  const un = Math.max(-0.95, Math.min(0.95, i.u >= 0 ? i.u / (i.r || 1) : i.u / ((i.r || 1) * 1.7)));
  let melhor = null; let zMax = -9; let cobertos = 0;
  for (let k = 0; k < FIOS.length; k++) {
    const fase = FIOS[k].fase;
    const c = 0.62 * Math.sin(6.2832 * (i.s / 20 + fase)) + 0.12 * Math.sin(6.2832 * (i.s / 9 + fase * 2.3));
    const z = Math.cos(6.2832 * (i.s / 20 + fase));
    const cruz = (un - c) / 0.27;
    if (Math.abs(cruz) < 1) { cobertos++; if (z > zMax) { zMax = z; melhor = { k, cruz }; } }
  }
  const tomGlobal = sh.tom - (o.escuro || 0);
  if (!melhor) return 'raiz_funda';                                          // fundo escuro entre os fios
  if (cobertos > 1 && Math.abs(melhor.cruz) > 0.72) return 'raiz_funda';      // borda do fio que passa por cima de outro
  const tomFio = melhor.cruz > 0.3 ? 2 : melhor.cruz < -0.45 ? 0 : 1;        // lado de cima do fio recebe luz
  const t4 = Math.max(0, Math.min(3, tomFio + (tomGlobal - 1)));
  return RAMPA4[FIOS[melhor.k].rampa][t4];
}

// ---------- partes do corpo ----------
function pata(g, pts, rs, material, opcoes, garras) {
  const f = cadeia(pts, rs);
  pintar(g, f, material, opcoes);
  const [fx, fy] = pts[pts.length - 1];
  for (const [dx, dy, r] of garras) {
    pintar(g, cadeia([[fx, fy - 1.2], [fx + dx, fy + dy]], [1.5, r]), (x, y, i, sh) => (sh.tom === 2 || i.s > 2.6 ? 'casca_clara' : 'casca'), { contorno: false });
  }
}
function folha(g, x, y, ang, len, tom = 2) {
  const f = cadeia([[x, y], [x + Math.cos(ang) * len, y + Math.sin(ang) * len]], [1.3, 0.3]);
  pintar(g, f, (px, py, i, sh) => RAMPA.raizC[limita(Math.max(tom - 1, sh.tom))], { contorno: false });
}
function flor(g, cx, cy, R) {
  const petalas = [];
  for (let k = 0; k < 5; k++) {
    const a = -1.5708 + k * 1.2566 + 0.18 * Math.sin(k * 2.3);
    petalas.push({ a, px: cx + Math.cos(a) * R * 0.55, py: cy + Math.sin(a) * R * 0.55 });
  }
  const fx0 = Math.max(0, Math.floor(cx - R - 2)); const fx1 = Math.min(W, Math.ceil(cx + R + 2)); const fy0 = Math.max(0, Math.floor(cy - R - 2)); const fy1 = Math.min(H, Math.ceil(cy + R + 2));
  for (let y = fy0; y < fy1; y++) for (let x = fx0; x < fx1; x++) {
    const X = x + 0.5; const Y = y + 0.5; let dentro = false; let dm = 9;
    for (const p of petalas) {
      const ca = Math.cos(p.a); const sa = Math.sin(p.a);
      const dx = X - p.px; const dy = Y - p.py;
      const rad = (dx * ca + dy * sa) / (R * 0.58); const tan = (-dx * sa + dy * ca) / (R * 0.34);
      const k = Math.hypot(rad, tan);
      if (k <= 1) { dentro = true; dm = Math.min(dm, 1 - k); }
    }
    if (!dentro) continue;
    const d = Math.hypot(X - cx, Y - cy);
    const luz = ((X - cx) * LUZ[0] + (Y - cy) * LUZ[1]) / (d || 1);
    let k = 'flor';
    if (d < R * 0.3) k = 'raiz_roxa';
    else if (dm < 0.2) k = 'flor_escura';
    else if (luz > 0.35 && d > R * 0.5) k = 'flor_clara';
    else if (luz < -0.4) k = 'flor_escura';
    g[y][x] = k;
  }
  g[Math.round(cy - 0.5)][Math.round(cx - 0.5)] = 'musgo_claro'; g[Math.round(cy - 0.5)][Math.round(cx + 0.5)] = 'musgo_claro';
}

/** Altura da borda superior do tronco em x, para encaixar as cristas. */
function topoDo(f, x) { for (let y = 0; y < H; y++) if (f(x + 0.5, y + 0.5).d <= 0) return y; return 0; }

/**
 * Gera um quadro. `b` (0..1) é a respiração; `s` (-1..1) é o balanço das partes soltas.
 * Ordem de pintura, do fundo para a frente: patas do fundo, cauda, tronco, corcova e cristas, pata traseira, cabeça, pata dianteira, vegetação.
 */

// ---------- passos: as quatro patas se alternam em diagonal; apoio (o pé fica parado no chão) e balanço (o pé avança) ----------
export const PASSO_DEVORADOR = 2.6;   // quanto o pé anda, para cada lado, em pixels do sprite
const PASSO = PASSO_DEVORADOR;
/** Posição do pé dentro do ciclo `q` (0..1): apoio em 60% (o pé recua com o corpo), balanço em 40% (o pé volta à frente). */
export function passoDaPata(q) {
  if (q < 0.6) { const u = q / 0.6; return { dx: PASSO * (-1 + 2 * u), lift: 0 }; }
  const u = (q - 0.6) / 0.4; return { dx: PASSO * (1 - 2 * u), lift: Math.round(1.6 * Math.sin(Math.PI * u)) };
}
/** Pontos de uma pata no passo global `passo` (0..1), com defasagem `off`. `passo` null = pose de repouso (pontos originais). */
function pernaNoPasso(pts, off, passo) {
  if (passo === null || passo === undefined) return pts;
  const { dx, lift } = passoDaPata(((passo + off) % 1 + 1) % 1);
  const out = pts.map((p) => [p[0], p[1]]);
  const n = out.length;
  out[n - 1] = [out[n - 1][0] + dx, out[n - 1][1] - lift];
  out[n - 2] = [out[n - 2][0] + dx * 0.45, out[n - 2][1] - lift * 0.4];
  return out;
}

/** Camada 1 · patas do fundo (um tom mais escuras). */
function camadaFundo(passo = null) {
  const g = novaGrade();
  // 1. patas do fundo (um tom mais escuras)
  pata(g, pernaNoPasso([[26, 21.5], [24.5, 28.5], [25.8, 34], [23.5, 38]], 0.5, passo), [4, 3.4, 2.6, 2.1], matPlacas(5.5), { escuro: 1 }, [[-2.6, 1.3, 0.8], [2.4, 1.2, 0.7]]);
  pata(g, pernaNoPasso([[41.5, 21], [37.8, 28], [44, 34], [42, 38]], 0, passo), [4.4, 3.4, 2.4, 2], matFibras, { escuro: 1 }, [[-2.4, 1.3, 0.8], [2.6, 1.2, 0.7]]);

  return g;
}
/** Camada 2 · cauda de raízes, balançando (s em -1..1). */
function camadaCauda(s = 0) {
  const g = novaGrade();
  // 2. cauda de raízes, com duas radículas soltas
  pintar(g, cadeia([[52.5, 17], [58, 18.5], [62 + s * 0.4, 24], [61 + s * 1.0, 31], [57.5 + s * 1.6, 36.5]], [2.6, 2.1, 1.6, 1.2, 0.7]), (x, y, i, sh) => tecido(i, sh, {}));
  pintar(g, cadeia([[54, 20.5], [57.5, 24 + s * 0.4], [58.5, 29]], [1, 0.8, 0.4]), (x, y, i, sh) => RAMPA.raizA[sh.tom], { contorno: false });

  return g;
}
/** Camada 3 · corpo: tronco, corcova, cabeça e mandíbula, flor e uma folha. Respira (b em 0..1). */
function camadaCorpo(b = 0) {
  const g = novaGrade(); const s = 0;
  const hb = 0.7 * b; const jb = 0.8 * b;
  // 3. tronco: peito fundo, corcova nos ombros, cintura estreita, quadris; ventre que respira
  const cadTronco = cadeia([[18, 18 + hb], [25, 12.5 + hb * 0.5], [34, 14.5], [43, 17], [50, 20]], [7 + 0.8 * b, 10 + 0.9 * b, 7.2 + 0.4 * b, 6.6, 5.2]);
  const efV = elipse(31.5, 19.5, 10, 3.6 + 1.0 * b); const efP = elipse(22, 21, 7, 5.3 + 0.6 * b);
  const ventre = (px, py) => { const v = efV(px, py); const p = efP(px, py); const c = cadTronco(px, py); return { d: Math.min(v.d, p.d), s: c.s, u: c.u, r: c.r }; };
  ventre.limites = [10, 10, 44, 30];
  const tronco = uniao(cadTronco, ventre);
  const formaTronco = (px, py) => { const t = tronco(px, py); const c = cadTronco(px, py); return { d: t.d, s: c.s, u: c.u, r: c.r }; };
  formaTronco.limites = tronco.limites;
  pintar(g, formaTronco, (x, y, i, sh) => tecido(i, sh, {}));

  // 4. corcova de placas nos ombros e cristas de casca ao longo do dorso
  const corcova = cadeia([[19.5, 12.4 + hb - 0.8 * b], [26, 7.6 - 0.8 * b], [33, 9.2 - 0.5 * b]], [4.6, 5.4, 4.1]);
  pintar(g, corcova, matPlacas(3.8, true), { contorno: true });
  for (const [x, h] of [[27.5, 5.5], [31.5, 5], [35.5, 4.6], [39.5, 4], [43.5, 3.4]]) {
    const yb = topoDo(tronco, x) + 2;
    pintar(g, cadeia([[x, yb], [x + 0.7, yb - h]], [2.1, 0.35]), (px, py, i, sh) => RAMPA.casca[sh.tom], { contorno: true });
  }

  // 6. cabeça: cavidade da boca, chifres, crânio e focinho, mandíbula, nuca de raízes, cavidades sensoriais
  pintar(g, caixa(6.6, 19.6 + jb * 0.5, 5, 1.7 + jb * 0.5), () => 'raiz_funda', { contorno: false });
  pintar(g, cadeia([[13, 9 + hb], [15.6, 2.4 + hb]], [2.7, 0.4]), (x, y, i, sh) => RAMPA.casca[sh.tom]);
  pintar(g, cadeia([[17, 9.4 + hb], [21.8, 4 + hb]], [2.3, 0.4]), (x, y, i, sh) => RAMPA.casca[sh.tom]);
  pintar(g, cadeia([[7.2, 10 + hb], [2.6, 6.6 + hb]], [2, 0.4]), (x, y, i, sh) => RAMPA.casca[sh.tom]);
  const cranio = elipse(12.8, 13.2 + hb, 8.2, 6.6); const focinho = cadeia([[9.5, 14.2 + hb], [2.6, 16.3 + hb]], [4.3, 2.8]);
  pintar(g, uniao(cranio, focinho), (x, y, i, sh, o) => {
    if (x >= 16) { const t = cadTronco(x + 0.5, y + 0.5); return tecido({ s: t.s, u: t.u, r: t.r }, sh, {}); }   // nuca: raízes nascem do crânio
    return matPlacas(4.2, true)(x, y, i, sh, o);
  });
  pintar(g, cadeia([[13, 22.4 + jb], [6.5, 23 + jb], [2.4, 22.2 + jb]], [2.9, 2.3, 1.5]), matPlacas(4, true));
  const abre = Math.round(jb);                                                                              // mandíbula aberta: 0 ou 1 px
  for (const x of [3, 5, 7, 9]) { g[18][x] = 'dente'; g[19][x] = 'dente'; }                                 // dentes de cima (longos)
  for (const x of [4, 6, 8]) { g[19][x] = 'contorno'; if (abre) g[20][x] = 'contorno'; g[20 + abre][x] = 'dente'; }   // vãos escuros e dentes de baixo, intercalados
  for (const [cx, cy, rx, ry] of [[9.2, 11.6 + hb, 2.3, 1.7], [14.6, 9.6 + hb, 1.6, 1.2]]) {                // cavidades sensoriais (sem olhos)
    pintar(g, elipse(cx, cy, rx + 0.8, ry + 0.8), () => 'casca_sombra', { contorno: false });
    pintar(g, elipse(cx, cy, rx, ry), () => 'contorno', { contorno: false });
    g[Math.round(cy - 0.5)][Math.round(cx - 0.5)] = 'flor';                                                   // botão sensorial dentro da cavidade
  }

  pintar(g, cadeia([[31, 12.5], [29.4, 9.6 - 0.8 * b], [28.6, 7]], [1.1, 0.9, 0.7]), (x, y, i, sh) => RAMPA.raizC[sh.tom], { contorno: false });   // haste da flor
  flor(g, 28.5, 5.8 - 0.8 * b, 3.9 + 0.6 * b);
  folha(g, 19.5, 9.2 + hb, -1.05 + s * 0.08, 4.2);
  return g;
}
/** Camada 4 · patas da frente (próxima) e de trás (próxima), com as trepadeiras do ventre. */
function camadaFrente(passo = null) {
  const g = novaGrade(); const s = 0;
  // 5. pata traseira próxima: raízes e fibras
  pata(g, pernaNoPasso([[47.5, 20], [43.5, 27], [50.5, 33], [48.5, 38]], 0.5, passo), [5.6, 4.2, 2.9, 2.3], matFibras, {}, [[-3, 1.2, 0.8], [0.8, 1.4, 0.7], [3.4, 1, 0.7]]);

  // 7. pata dianteira próxima: placas de casca protetoras
  pata(g, pernaNoPasso([[21, 22], [16.2, 28.6], [17.6, 34.4], [14, 38]], 0, passo), [5.3, 4.5, 3.3, 2.8], matPlacas(5.2), {}, [[-3.6, 1.2, 0.8], [0.6, 1.5, 0.7], [3.4, 1.1, 0.7]]);
  pintar(g, elipse(15.2 + (passo === null ? 0 : passoDaPata((passo % 1 + 1) % 1).dx * 0.45), 28.4, 3.3, 3), matPlacas(3, true), { contorno: true });   // cotovelo de casca

  pintar(g, cadeia([[33, 22], [32.4 + s * 0.8, 26.5]], [0.9, 0.45]), () => 'musgo', { contorno: false });
  pintar(g, cadeia([[39, 22.5], [40 + s * 0.9, 27]], [0.9, 0.45]), () => 'musgo_claro', { contorno: false });
  return g;
}
/** Camada 5 · folhas e tendrilhas soltas, que balançam (s em -1..1). */
function camadaFolhas(s = 0) {
  const g = novaGrade(); const hb = 0;
  pintar(g, cadeia([[10.2, 10.6 + hb], [11.6 + s * 0.7, 8.6 + hb], [12.4 + s * 1.3, 6.8 + hb]], [0.9, 0.7, 0.5]), (x, y, i, sh) => RAMPA.raizC[2], { contorno: false });   // tendrilha sensorial
  folha(g, 33.5, 7.2, -1.7 + s * 0.1, 3.8);
  folha(g, 41, 12.6, -0.5 + s * 0.1, 4);
  folha(g, 52.5, 14.5, -0.9, 3.4);
  return g;
}

/** Composição estática (repouso) das camadas, na mesma ordem de pintura. Usada para comparar com o desenho aprovado. */
export function gerarQuadroDevorador(b = 0, s = 0) {
  const g = novaGrade();
  const sobrepor = (c) => { for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (c[y][x]) g[y][x] = c[y][x]; };
  sobrepor(camadaFundo(null)); sobrepor(camadaCauda(s)); sobrepor(camadaCorpo(b)); sobrepor(camadaFrente(null)); sobrepor(camadaFolhas(s));
  return g;
}

// ---------- pré-renderização em canvas (uma vez por variante de camada) ----------
// 22 telas no total: corpo (6 respirações), cauda (3 balanços), patas do fundo (5 passos), patas da frente (5 passos), folhas (3 balanços).
export const CICLO_DEVORADOR = 4.2;     // segundos por ciclo completo de respiração
const RESPIRACAO_DEVORADOR = Object.freeze([0, 0.5, 1, 1, 0.5, 0]);
const PASSOS_DEVORADOR = Object.freeze([null, 0, 0.25, 0.5, 0.75]);   // null = pose de repouso
const BALANCO_DEVORADOR = Object.freeze([-1, 0, 1]);
export const TOTAL_TELAS_DEVORADOR = RESPIRACAO_DEVORADOR.length + BALANCO_DEVORADOR.length * 2 + PASSOS_DEVORADOR.length * 2;

let fabricaDeTelas = (w, h) => {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas'); c.width = w; c.height = h; return c;
};
/** Troca a fábrica de canvas (testes e ambientes sem DOM) e limpa o cache. */
export function definirFabricaDeTelasDevorador(fn) { fabricaDeTelas = fn; telas = null; }
let telas = null;

function fabricar(grade) {
  const tela = fabricaDeTelas(W, H);
  if (tela) {
    const ctx = tela.getContext('2d'); ctx.imageSmoothingEnabled = false;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const k = grade[y][x]; if (k) { ctx.fillStyle = PALETA_DEVORADOR[k]; ctx.fillRect(x, y, 1, 1); } }
  }
  return tela;
}
function prepararTelas() {
  telas = {
    corpo: RESPIRACAO_DEVORADOR.map((b) => fabricar(camadaCorpo(b))),
    cauda: BALANCO_DEVORADOR.map((v) => fabricar(camadaCauda(v))),
    fundo: PASSOS_DEVORADOR.map((p) => fabricar(camadaFundo(p))),
    frente: PASSOS_DEVORADOR.map((p) => fabricar(camadaFrente(p))),
    folhas: BALANCO_DEVORADOR.map((v) => fabricar(camadaFolhas(v))),
  };
}

/**
 * Desenha o Devorador com o canto superior esquerdo do sprite em (x, y).
 * est: passo (null = parado; 0..1 = fase do ciclo de passos), resp (0..1 respiração), s (-1..1 balanço das partes soltas),
 * dir (-1 olha para a esquerda, que é o desenho aprovado; 1 espelha para a direita).
 * Cinco drawImage por quadro, sem fillRect. A ordem de pintura é a mesma do desenho aprovado.
 */
export function desenharEstado(ctx, x, y, est = {}) {
  if (!telas) prepararTelas();
  const passo = est.passo === undefined ? null : est.passo;
  const resp = (((est.resp || 0) % 1) + 1) % 1;
  const iB = Math.floor(resp * RESPIRACAO_DEVORADOR.length) % RESPIRACAO_DEVORADOR.length;
  const iS = Math.max(0, Math.min(2, Math.round(est.s || 0) + 1));
  const fase = passo === null ? 0 : (((passo % 1) + 1) % 1);
  const iG = passo === null ? 0 : 1 + (Math.floor(fase * 4) % 4);
  const bob = passo !== null && ((fase * 2) % 1) < 0.5 ? -1 : 0;   // o corpo sobe 1 px a cada meio passo
  const espelho = (est.dir || -1) > 0;
  if (espelho) { ctx.save(); ctx.translate(x + W, y); ctx.scale(-1, 1); x = 0; y = 0; }
  const d = (tela, dx, dy) => { if (tela) ctx.drawImage(tela, x + dx, y + dy); };
  d(telas.fundo[iG], 0, 0);
  d(telas.cauda[iS], 0, 0);
  d(telas.corpo[iB], 0, bob);
  d(telas.frente[iG], 0, 0);
  d(telas.folhas[iS], 0, 0);
  if (espelho) ctx.restore();
}

/** Compatível com a chamada anterior: só respiração e balanço, em repouso, olhando para a esquerda. */
export function desenharDevorador(ctx, x, y, t = 0) {
  desenharEstado(ctx, x, y, { passo: null, resp: t / CICLO_DEVORADOR, s: Math.sin(t * 1.2) * 0.8, dir: -1 });
}

/** Desenha o chefe a partir do estado de movimento (`enemy.devorador`). Sem estado, usa só o repouso. */
export function drawDevorador(ctx, enemy, rx, ry, t = 0) {
  const e = enemy.devorador;
  if (!e) { desenharDevorador(ctx, rx + Math.round((enemy.body.w - W) / 2), ry + enemy.body.h - H, t); return; }
  const x = Math.round(e.corpo.x + (e.corpo.w - W) / 2);
  const y = Math.round(e.corpo.y + e.corpo.h - H);
  desenharEstado(ctx, x, y, { passo: e.passo, resp: e.resp, s: e.balanco, dir: e.facing });
}
