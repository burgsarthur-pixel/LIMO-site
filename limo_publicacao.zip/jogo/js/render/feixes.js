// =====================================================================
// FEIXES DE LUZ (v1.42.0) — lógica pura, sem DOM: testável em Node.
//
// Um feixe nasce numa FRESTA (abertura HORIZONTAL de `largura` px, na face de baixo do teto) e desce numa direção fixa (luz de fonte
// distante: todos os feixes de uma sala são paralelos). O que é calculado de verdade, por pixel do campo de luz:
//   · GEOMETRIA   (a largura perpendicular do feixe é largura·cosθ)   N+1 raios saem da fresta (leve divergência) e marcham pela grade de tiles até o primeiro tile sólido ou o
//                 topo de uma plataforma. O volume iluminado é o que os raios alcançam: paredes e plataformas projetam sombra.
//   · ATENUAÇÃO   Beer–Lambert no ar:  I(s) = I0 · exp(−σ·s)  (σ = densidade do meio, 1/px).
//   · PENUMBRA    a fonte tem tamanho angular: a borda do feixe se alarga com a distância (pen(s) = p0 + s·fonteAngular).
//   · CORPOS      o Limo é um gel translúcido: o raio que o atravessa perde luz por canal, T_c = exp(−σ_c · espessura), com
//                 σ_c maior onde a cor do corpo absorve mais (a luz que passa sai esverdeada). Inimigos são quase opacos.
//   · SUPERFÍCIE  onde o raio bate há uma POÇA de luz: irradiância E = I0·exp(−σ·d)·T·cosθ (lei de Lambert, θ = ângulo entre o
//                 raio e a normal do tile); a mancha se alarga 1/cosθ (energia conservada). Uma fração `quique` (albedo) volta
//                 como brilho largo e fraco em volta (luz indireta).
//   · VOLUME      o ar do feixe tem turbulência (ruído de valor que deriva com o vento) e a poeira só brilha onde o feixe passa
//                 (espalhamento Tyndall): o brilho de cada grão é a própria intensidade do feixe no ponto.
// Coordenadas em px do MUNDO. Ângulo em graus a partir da vertical (positivo = desce para a direita).
// =====================================================================

export const FEIXE_PADRAO = { largura: 14, angulo: 12, alcance: 240, cor: [255, 230, 170], intensidade: 0.85, densidade: 0.004, divergencia: 3, fonteAngular: 0.035 };
export const LIMITES_FEIXE = { largura: [2, 64], angulo: [-60, 60], alcance: [16, 600], intensidade: [0, 2], densidade: [0, 0.05], divergencia: [0, 20] };

const PASSO = 1.5;            // px por passo da marcha do raio
const TAM_PLATAFORMA = 4;     // px de espessura da plataforma fina (só o topo do tile bloqueia)
const smooth = (x) => { const k = x < 0 ? 0 : x > 1 ? 1 : x; return k * k * (3 - 2 * k); };
const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);

// ---------- ruído de valor determinístico (sem Math.random) ----------
function hash2(ix, iy) { let h = Math.imul(ix, 374761393) ^ Math.imul(iy, 668265263); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967295; }
export function ruido(x, y) {
  const ix = Math.floor(x); const iy = Math.floor(y); const fx = x - ix; const fy = y - iy; const u = fx * fx * (3 - 2 * fx); const v = fy * fy * (3 - 2 * fy);
  const a = hash2(ix, iy); const b = hash2(ix + 1, iy); const c = hash2(ix, iy + 1); const d = hash2(ix + 1, iy + 1);
  return (a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v) * 2 - 1;
}
function mulberry32(a) { return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function semente(txt) { let h = 2166136261; for (const ch of String(txt)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }

// ---------- dados ----------
/** Definição do JSON (tiles/px/graus) -> feixe pronto para calcular (px do mundo, vetores unitários). */
export function normalizarFeixe(def, ts, idSala = '') {
  const n = (v, d) => (Number.isFinite(v) ? v : d); const ang = n(def.angulo, FEIXE_PADRAO.angulo) * Math.PI / 180;
  return {
    id: def.id || 'feixe', ax: n(def.x, 0) * ts, ay: n(def.y, 0) * ts, meia: Math.max(1, n(def.largura, FEIXE_PADRAO.largura)) / 2,
    ang, dx: Math.sin(ang), dy: Math.cos(ang), px: Math.cos(ang), py: -Math.sin(ang),
    meiaP: Math.max(1, n(def.largura, FEIXE_PADRAO.largura)) / 2 * Math.cos(ang), sobre: Math.max(1, n(def.largura, FEIXE_PADRAO.largura)) / 2 * Math.sin(ang),   // meia-largura perpendicular; deslocamento de s entre as pontas da fresta
    alcance: n(def.alcance, FEIXE_PADRAO.alcance), cor: Array.isArray(def.cor) && def.cor.length === 3 ? def.cor : FEIXE_PADRAO.cor,
    I0: n(def.intensidade, FEIXE_PADRAO.intensidade), sigma: n(def.densidade, FEIXE_PADRAO.densidade),
    tanDiv: Math.tan(n(def.divergencia, FEIXE_PADRAO.divergencia) * Math.PI / 360), fonte: n(def.fonteAngular, FEIXE_PADRAO.fonteAngular),
    semente: semente(`${idSala}:${def.id || 'feixe'}`),
  };
}

/** Valida o bloco `feixes` de uma sala (dados puros). */
export function validarFeixes(lista, dados) {
  const errors = []; const warnings = [];
  if (lista === undefined || lista === null) return { errors, warnings };
  if (!Array.isArray(lista)) return { errors: ['"feixes" precisa ser uma lista.'], warnings };
  if (lista.length > 8) errors.push(`feixes: no máximo 8 por sala (tem ${lista.length}).`);
  const ids = new Set();
  lista.forEach((f, i) => {
    const nome = `feixes[${i}]`;
    if (!f || typeof f !== 'object') { errors.push(`${nome}: precisa ser um objeto.`); return; }
    if (typeof f.id !== 'string' || !/^[a-z0-9_]+$/.test(f.id)) errors.push(`${nome}: id inválido (letras minúsculas, números e "_").`); else if (ids.has(f.id)) errors.push(`${nome}: id repetido "${f.id}".`); else ids.add(f.id);
    if (!Number.isFinite(f.x) || f.x < 0 || (dados && f.x > dados.width)) errors.push(`${nome}: x fora da sala (em tiles).`);
    if (!Number.isFinite(f.y) || f.y < 0 || (dados && f.y > dados.height)) errors.push(`${nome}: y fora da sala (em tiles).`);
    for (const [k, [a, b]] of Object.entries(LIMITES_FEIXE)) if (f[k] !== undefined && (!Number.isFinite(f[k]) || f[k] < a || f[k] > b)) errors.push(`${nome}: ${k} deve estar entre ${a} e ${b}.`);
    if (f.cor !== undefined && !(Array.isArray(f.cor) && f.cor.length === 3 && f.cor.every((v) => Number.isInteger(v) && v >= 0 && v <= 255))) errors.push(`${nome}: cor deve ser [r,g,b] com inteiros de 0 a 255.`);
  });
  return { errors, warnings };
}

// ---------- grade de ocupação (cache por mapa+revisão) ----------
const _occ = new WeakMap();
/** 0 = livre · 1 = tile sólido (bloqueia inteiro) · 2 = plataforma fina (bloqueia só o topo). */
function ocupacao(mapa) {
  const o = _occ.get(mapa); if (o && o.rev === (mapa.revision ?? 0)) return o.arr;
  const W = mapa.width; const H = mapa.height; const arr = new Uint8Array(W * H); const sol = mapa.layers?.solid; const pla = mapa.layers?.platform;
  for (let i = 0; i < arr.length; i++) {
    const a = sol?.[i]; if (a) { const t = mapa.catalog?.get?.(a); if (!t || t.collision === 'solid') { arr[i] = 1; continue; } }
    const b = pla?.[i]; if (b) { const t = mapa.catalog?.get?.(b); arr[i] = !t ? 2 : t.collision === 'solid' ? 1 : t.collision === 'oneway' ? 2 : 0; }
  }
  _occ.set(mapa, { rev: mapa.revision ?? 0, arr }); return arr;
}
function bloqueio(arr, mapa, px, py) {
  const ts = mapa.tileSize; const tx = Math.floor(px / ts); const ty = Math.floor(py / ts);
  if (tx < 0 || ty < 0 || tx >= mapa.width || ty >= mapa.height) return 1;
  const c = arr[ty * mapa.width + tx]; if (c === 2) return (py - ty * ts) < TAM_PLATAFORMA ? 2 : 0; return c;
}

/**
 * Lança os N+1 raios do feixe contra o mapa. Cada raio: {ox,oy,dx,dy, dist, bate, nx,ny, hx,hy, cosT}.
 * `dist` é refinada por bisseção (precisão < 0,1 px); a normal vem da face do tile atravessada (ou "para cima" na plataforma).
 */
export function lancarRaios(mapa, f, N = 32) {
  const arr = ocupacao(mapa); const ts = mapa.tileSize; const raios = []; const phi = Math.atan(f.tanDiv);
  for (let i = 0; i <= N; i++) {
    const u = -1 + (2 * i) / N; const a = f.ang + phi * u; const dx = Math.sin(a); const dy = Math.cos(a);
    const ox = f.ax + f.meia * u; const oy = f.ay;   // fresta horizontal no teto
    let prev = 0; let achou = 0; let s = 0.5;
    for (; s <= f.alcance; s += PASSO) { achou = bloqueio(arr, mapa, ox + dx * s, oy + dy * s); if (achou) break; prev = s; }
    const r = { u, ox, oy, dx, dy, dist: f.alcance, bate: false, nx: 0, ny: 0, hx: 0, hy: 0, cosT: 0, cp: [] };
    if (achou) {
      let lo = prev; let hi = Math.min(s, f.alcance);
      for (let k = 0; k < 6; k++) { const m = (lo + hi) / 2; if (bloqueio(arr, mapa, ox + dx * m, oy + dy * m)) hi = m; else lo = m; }
      r.dist = hi; r.bate = true; r.hx = ox + dx * hi; r.hy = oy + dy * hi;
      if (achou === 2) { r.nx = 0; r.ny = -1; } else {
        const tx0 = Math.floor((ox + dx * lo) / ts); const ty0 = Math.floor((oy + dy * lo) / ts); const tx1 = Math.floor((ox + dx * (hi + 0.01)) / ts); const ty1 = Math.floor((oy + dy * (hi + 0.01)) / ts);
        const ddx = tx0 - tx1; const ddy = ty0 - ty1;
        if (ddx !== 0 && ddy === 0) { r.nx = Math.sign(ddx); r.ny = 0; } else if (ddy !== 0 && ddx === 0) { r.nx = 0; r.ny = Math.sign(ddy); }
        else if (Math.abs(dx) > Math.abs(dy)) { r.nx = Math.sign(ddx || -dx); r.ny = 0; } else { r.nx = 0; r.ny = Math.sign(ddy || -dy); }
      }
      r.cosT = Math.max(0, -(dx * r.nx + dy * r.ny));   // lei de Lambert
    }
    raios.push(r);
  }
  return raios;
}

// ---------- corpos (oclusores dinâmicos, translúcidos) ----------
/** Intervalo [sIn,sOut] em que o raio (O,d) está dentro do retângulo; null se não cruza. */
function cruza(r, c) {
  let t0 = -Infinity; let t1 = Infinity;
  for (const [o, d, a, b] of [[r.ox, r.dx, c.x, c.x + c.w], [r.oy, r.dy, c.y, c.y + c.h]]) {
    if (Math.abs(d) < 1e-9) { if (o < a || o > b) return null; } else { let p = (a - o) / d; let q = (b - o) / d; if (p > q) { const z = p; p = q; q = z; } t0 = Math.max(t0, p); t1 = Math.min(t1, q); if (t0 > t1) return null; }
  }
  return t1 < 0 ? null : [Math.max(0, t0), t1];
}
/** Absorção por canal: o corpo absorve mais onde sua cor é mais escura (gel verde: passa verde, perde vermelho e azul). */
function sigmaCanais(c) { const k = c.sigma ?? 0.06; const cor = c.cor || [128, 128, 128]; return [k * (1.08 - cor[0] / 255), k * (1.08 - cor[1] / 255), k * (1.08 - cor[2] / 255)]; }
/** Anexa a cada raio os trechos em que ele atravessa corpos (recalculado por quadro). */
export function aplicarCorpos(raios, corpos) {
  for (const r of raios) {
    r.cp.length = 0;
    for (const c of corpos || []) { const iv = cruza(r, c); if (iv && iv[0] < r.dist) r.cp.push({ sIn: iv[0], sOut: Math.min(iv[1], r.dist), sig: c.__sig ||= sigmaCanais(c) }); }
  }
}
/** Transmitância por canal do raio até a distância s. */
export function transmitancia(r, s, out) {
  out[0] = out[1] = out[2] = 1;
  for (const c of r.cp) { const L = clamp(s - c.sIn, 0, c.sOut - c.sIn); if (L > 0) { out[0] *= Math.exp(-c.sig[0] * L); out[1] *= Math.exp(-c.sig[1] * L); out[2] *= Math.exp(-c.sig[2] * L); } }
}

// ---------- amostragem do volume ----------
const _tr = [1, 1, 1];
/**
 * Luz espalhada do feixe no ponto (px,py): escreve {r,g,b} em `out` (cor × intensidade, 0..~1) e devolve a intensidade escalar.
 * `turb` liga a turbulência do ar (desligada nos testes de física pura e na poeira).
 */
export function amostrar(f, raios, t, px, py, out, turb = true) {
  out.r = out.g = out.b = 0;
  if (py < f.ay - 0.5) return 0;   // acima da fresta (dentro do teto) não há luz
  const rx = px - f.ax; const ry = py - f.ay; const s = rx * f.dx + ry * f.dy; const lat = rx * f.px + ry * f.py;
  const sp = s > 0 ? s : 0; const w = f.meiaP + sp * f.tanDiv; const pen = 1.2 + sp * f.fonte;
  const cobre = smooth((w - Math.abs(lat)) / pen * 0.5 + 0.5); if (cobre <= 0) return 0;
  const uu = clamp(lat / w, -1, 1); const sr = s - uu * f.sobre; const srp = sr > 0 ? sr : 0;   // distância desde a origem do PRÓPRIO raio
  const N = raios.length - 1; const fi = (uu + 1) / 2 * N; const i0 = Math.min(N - 1, Math.floor(fi)); const fr = fi - i0;
  // oclusão com PENUMBRA: a fonte tem tamanho, então a borda de uma sombra se suaviza (5 pontos laterais, largura ∝ pen(s));
  // um ponto no escuro de um oclusor próximo vê parte da fonte pela borda dele.
  let livre = 0; const span = pen * 1.4;
  for (let k = -2; k <= 2; k++) {
    const uk = clamp((lat + k * span / 2) / w, -1, 1); const fk = (uk + 1) / 2 * N; const j = Math.min(N - 1, Math.floor(fk)); const dk = raios[j].dist + (raios[j + 1].dist - raios[j].dist) * (fk - j);
    livre += smooth((dk - srp) / 2 + 0.5) * (k === 0 ? 0.3 : 0.175);
  }
  if (livre <= 0.001) return 0;
  let I = f.I0 * cobre * livre * Math.exp(-f.sigma * srp) * smooth((py - f.ay) / 4 + 0.5);
  const rr = raios[fr < 0.5 ? i0 : i0 + 1]; transmitancia(rr, srp, _tr);
  if (turb) { const n = 1 + 0.30 * ruido(px * 0.045 + t * 0.55, py * 0.045 - t * 0.22) + 0.14 * ruido(px * 0.12 - t * 0.9, py * 0.12 + t * 0.4) + 0.12 * ruido(lat * 0.3, s * 0.012 + t * 0.12); I *= clamp(n, 0.35, 1.7); }
  out.r = f.cor[0] / 255 * I * _tr[0]; out.g = f.cor[1] / 255 * I * _tr[1]; out.b = f.cor[2] / 255 * I * _tr[2];
  return I * (_tr[0] + _tr[1] + _tr[2]) / 3;
}

/** Irradiância (0..1) e cor transmitida na poça do raio i: E = I0·exp(−σ d)·T·cosθ. */
export function irradianciaDaPoca(f, r, out) {
  transmitancia(r, r.dist, _tr); const e = f.I0 * Math.exp(-f.sigma * r.dist) * r.cosT;
  out.r = f.cor[0] / 255 * e * _tr[0]; out.g = f.cor[1] / 255 * e * _tr[1]; out.b = f.cor[2] / 255 * e * _tr[2]; return e;
}

// ---------- sistema (uma sala por vez) ----------
export class SistemaFeixes {
  constructor() { this.salaId = null; this.mapa = null; this.rev = -1; this.feixes = []; this.R = null; this.G = null; this.B = null; this.GW = 0; this.GH = 0; this._tp = null; }

  /** Recalcula a geometria quando a sala ou o mapa mudam. Devolve se há feixes. */
  preparar(dados, mapa, N = 32) {
    const lista = dados?.feixes; if (!lista?.length || !mapa) { this.feixes = []; this.salaId = null; return false; }
    if (this.salaId === dados.id && this.mapa === mapa && this.rev === (mapa.revision ?? 0) && this.N === N) return true;
    this.salaId = dados.id; this.mapa = mapa; this.rev = mapa.revision ?? 0; this.N = N;
    this.feixes = lista.map((def) => { const f = normalizarFeixe(def, mapa.tileSize, dados.id); f.raios = lancarRaios(mapa, f, N); f.poeira = []; f.rnd = mulberry32(f.semente); return f; });
    return true;
  }

  /** Poeira: grãos que derivam (assentam devagar, mexem com a turbulência) e renascem dentro do feixe. */
  atualizarPoeira(dt, t, quantidade = 14) {
    for (const f of this.feixes) {
      const alvo = Math.round(quantidade); const lim = Math.max(...f.raios.map((r) => r.dist));
      while (f.poeira.length < alvo) f.poeira.push(this._nascer(f, lim, true));
      f.poeira.length = alvo;
      for (let i = 0; i < f.poeira.length; i++) {
        const p = f.poeira[i]; p.fase += dt;
        p.x += (p.vx + 3 * ruido(p.x * 0.05 + t * 0.4, p.y * 0.05)) * dt; p.y += (p.vy + 2 * ruido(p.y * 0.05, p.x * 0.05 - t * 0.3)) * dt;
        if (!this._dentro(f, p.x, p.y)) f.poeira[i] = this._nascer(f, lim, false);
      }
    }
  }
  /** O ponto está dentro do volume iluminado (entre a fresta e o ponto onde o raio bate)? */
  _dentro(f, x, y) {
    if (y < f.ay) return false;
    const rx = x - f.ax; const ry = y - f.ay; const s = rx * f.dx + ry * f.dy; const lat = rx * f.px + ry * f.py; const w = f.meiaP + Math.max(0, s) * f.tanDiv; if (Math.abs(lat) > w) return false;
    const uu = clamp(lat / w, -1, 1); const sr = s - uu * f.sobre; const fi = (uu + 1) / 2 * (f.raios.length - 1); return sr <= f.raios[Math.round(fi)].dist - 1;
  }
  _nascer(f, lim, espalhar) {
    const r = f.rnd; const u = (r() * 2 - 1) * 0.92; const phi = Math.atan(f.tanDiv); const a = f.ang + phi * u; const ra = f.raios[Math.round((u + 1) / 2 * (f.raios.length - 1))];
    const sMax = Math.min(ra.dist, f.alcance) - 2; const s = Math.max(2, (espalhar ? r() : 0.02 + r() * 0.3) * sMax);
    return { x: f.ax + f.meia * u + Math.sin(a) * s, y: f.ay + Math.cos(a) * s, vx: (r() - 0.5) * 5, vy: 2 + r() * 4, fase: r() * 6.28, tam: r() < 0.25 ? 2 : 1 };
  }
  /** Grãos visíveis neste instante: [{x,y,a,tam,r,g,b}] (a = brilho 0..1 = intensidade do feixe no grão × cintilação). */
  graos(t, corpos) {
    const out = []; const c = { r: 0, g: 0, b: 0 };
    for (const f of this.feixes) {
      aplicarCorpos(f.raios, corpos);
      for (const p of f.poeira) { const I = amostrar(f, f.raios, t, p.x, p.y, c, false); if (I < 0.03) continue; const tw = 0.65 + 0.35 * Math.sin(p.fase * 2.7 + p.x); out.push({ x: p.x, y: p.y, a: clamp(I * 1.25 * tw, 0, 0.85), tam: p.tam, r: c.r / (I || 1), g: c.g / (I || 1), b: c.b / (I || 1) }); }
    }
    return out;
  }

  /**
   * Campo de luz em baixa resolução (células de `celula` px), em espaço de tela: R,G,B em ~0..1 (cor×intensidade).
   * g = { volume, superficie, quique }: ganhos do ar, da poça e da luz indireta.
   */
  campo({ camX, camY, W, H, celula = 4, t = 0, corpos = [], volume = 0.22, superficie = 0.75, quique = 0.35 }) {
    const GW = Math.ceil(W / celula); const GH = Math.ceil(H / celula);
    if (!this.R || this.GW !== GW || this.GH !== GH) { this.GW = GW; this.GH = GH; this.R = new Float32Array(GW * GH); this.G = new Float32Array(GW * GH); this.B = new Float32Array(GW * GH); }
    this.R.fill(0); this.G.fill(0); this.B.fill(0);
    const o = { r: 0, g: 0, b: 0 }; const idx = (cx, cy) => cy * GW + cx;
    for (const f of this.feixes) {
      aplicarCorpos(f.raios, corpos);
      const dmax = Math.max(...f.raios.map((r) => r.dist)); const wmax = f.meia + dmax * f.tanDiv + 10;   // folga larga: cobre a fresta horizontal e o cone
      const xs = [f.ax - f.px * wmax, f.ax + f.px * wmax, f.ax + f.dx * dmax - f.px * wmax, f.ax + f.dx * dmax + f.px * wmax]; const ys = [f.ay - f.py * wmax, f.ay + f.py * wmax, f.ay + f.dy * dmax - f.py * wmax, f.ay + f.dy * dmax + f.py * wmax];
      const pad = 22;   // espaço para a luz indireta
      const cx0 = Math.max(0, Math.floor((Math.min(...xs) - pad - camX) / celula)); const cx1 = Math.min(GW - 1, Math.ceil((Math.max(...xs) + pad - camX) / celula));
      const cy0 = Math.max(0, Math.floor((Math.min(...ys) - pad - camY) / celula)); const cy1 = Math.min(GH - 1, Math.ceil((Math.max(...ys) + pad - camY) / celula));
      if (cx1 < 0 || cy1 < 0 || cx0 > GW - 1 || cy0 > GH - 1) continue;
      // 1) volume (ar com luz espalhada)
      for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) {
        amostrar(f, f.raios, t, camX + (cx + 0.5) * celula, camY + (cy + 0.5) * celula, o, true);
        if (o.r + o.g + o.b > 0) { const i = idx(cx, cy); this.R[i] += o.r * volume; this.G[i] += o.g * volume; this.B[i] += o.b * volume; }
      }
      // 2) poças de luz (superfície, Lambert) + 3) luz indireta (fração `quique` do que a superfície recebeu)
      const N = f.raios.length - 1; const larg = (dist) => 2 * (f.meiaP + dist * f.tanDiv) / N; const e = { r: 0, g: 0, b: 0 };
      for (let i = 0; i <= N; i++) {
        const r = f.raios[i]; if (!r.bate || r.cosT < 0.02) continue; irradianciaDaPoca(f, r, e);
        const espPerp = larg(r.dist); const espSup = espPerp / Math.max(0.12, r.cosT); const sT = clamp(espSup * 0.8, 1.2, 24); const sN = 2.6;   // σ ao longo da superfície / da normal
        const tx = -r.ny; const ty = r.nx;
        const hx = r.hx + r.nx * 0.5; const hy = r.hy + r.ny * 0.5; const raio = Math.max(sT, sN) * 3;
        const a0 = Math.max(0, Math.floor((hx - raio - camX) / celula)); const a1 = Math.min(GW - 1, Math.ceil((hx + raio - camX) / celula));
        const b0 = Math.max(0, Math.floor((hy - raio - camY) / celula)); const b1 = Math.min(GH - 1, Math.ceil((hy + raio - camY) / celula));
        for (let cy = b0; cy <= b1; cy++) for (let cx = a0; cx <= a1; cx++) {
          const dx = camX + (cx + 0.5) * celula - hx; const dy = camY + (cy + 0.5) * celula - hy; const ta = dx * tx + dy * ty; const nb = dx * r.nx + dy * r.ny;
          const g = Math.exp(-(ta * ta) / (2 * sT * sT) - (nb * nb) / (2 * sN * sN)); if (g < 0.01) continue;
          const k = g * superficie * (espSup / (sT * 2.5066)); const j = idx(cx, cy); this.R[j] += e.r * k; this.G[j] += e.g * k; this.B[j] += e.b * k;
        }
        if (quique > 0 && i % 4 === 0) {   // luz indireta: 1 de cada 4 raios, peso ×4
          const sB = 15; const bx = r.hx + r.nx * 7; const by = r.hy + r.ny * 7; const rb = sB * 2.6;
          const a0b = Math.max(0, Math.floor((bx - rb - camX) / celula)); const a1b = Math.min(GW - 1, Math.ceil((bx + rb - camX) / celula));
          const b0b = Math.max(0, Math.floor((by - rb - camY) / celula)); const b1b = Math.min(GH - 1, Math.ceil((by + rb - camY) / celula));
          const kb = quique * 2 / (N + 1);   // a luz indireta soma ≈ quique × 0,5 × E no pico (perceptual: a normalização 2D exata ficaria invisível)
          for (let cy = b0b; cy <= b1b; cy++) for (let cx = a0b; cx <= a1b; cx++) {
            const dx = camX + (cx + 0.5) * celula - bx; const dy = camY + (cy + 0.5) * celula - by; const g = Math.exp(-(dx * dx + dy * dy) / (2 * sB * sB)); const j = idx(cx, cy);
            this.R[j] += e.r * g * kb; this.G[j] += e.g * g * kb; this.B[j] += e.b * g * kb;
          }
        }
      }
    }
    return { GW, GH, R: this.R, G: this.G, B: this.B, usado: this.feixes.length > 0 };
  }

  /** Converte o campo em dois RGBA (GW×GH): `tinta` (soma de cor, tone-mapped) e `furo` (alfa que clareia a escuridão). */
  static pixels(campo, tinta, furo, ganhoFuro = 1.6) {
    const n = campo.GW * campo.GH;
    for (let i = 0; i < n; i++) {
      const r = campo.R[i]; const g = campo.G[i]; const b = campo.B[i]; const o = i * 4;
      tinta[o] = 255 * (1 - Math.exp(-1.3 * r)); tinta[o + 1] = 255 * (1 - Math.exp(-1.3 * g)); tinta[o + 2] = 255 * (1 - Math.exp(-1.3 * b)); tinta[o + 3] = 255;
      furo[o] = furo[o + 1] = furo[o + 2] = 0; furo[o + 3] = 255 * Math.min(0.92, (0.3 * r + 0.59 * g + 0.11 * b) * ganhoFuro);
    }
  }
}
