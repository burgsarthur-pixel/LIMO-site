// =====================================================================
// ORGANIC DEPTH SYSTEM (2.5D) — CONFIGURAÇÃO (dados puros, sem DOM).
// Bloco OPCIONAL `depth` no JSON da sala. Sala sem `depth` = visual idêntico ao de antes (compatibilidade total).
//   depth: { versao:1, preset?, volume:{ativo,forca,espessura,sombra,ambiente},
//            parallax:{ativo,substituiFundo,camadas:[{id,plano,motivo,vx,vy,alfa,nevoa,densidade,semente}]} }
// Só visual: nada aqui toca colisão, hitbox, física, câmera ou transições.
// =====================================================================

export const DEPTH_VERSAO = 1;
export const PLANOS = ['fundo', 'meio', 'frente'];
export const MOTIVOS = ['troncos', 'costelas', 'veias', 'raizes', 'nodulos', 'raizesFrente'];
export const MAX_CAMADAS = 6;   // teto para Android: cada camada custa 2 drawImage por quadro

const clamp = (v, a, b, pad) => { const n = Number(v); return Number.isFinite(n) ? Math.min(b, Math.max(a, n)) : pad; };

/** Camadas padrão do bioma Raízes (fundo distante, meio e primeiro plano). */
export const PRESETS = {
  raizes: () => ({
    versao: DEPTH_VERSAO, preset: 'raizes',
    volume: { ativo: true, forca: 1, espessura: 2, sombra: true, ambiente: true },
    parallax: {
      ativo: true, substituiFundo: true,
      camadas: [
        { id: 'troncos', plano: 'fundo', motivo: 'troncos', vx: 0.12, vy: 0.08, alfa: 1, nevoa: 0.6, densidade: 1, semente: 11 },
        { id: 'costelas', plano: 'fundo', motivo: 'costelas', vx: 0.26, vy: 0.16, alfa: 0.85, nevoa: 0.42, densidade: 1, semente: 23 },
        { id: 'veias', plano: 'meio', motivo: 'raizes', vx: 0.5, vy: 0.32, alfa: 0.8, nevoa: 0.22, densidade: 1, semente: 37 },
        { id: 'nodulos', plano: 'meio', motivo: 'nodulos', vx: 0.68, vy: 0.45, alfa: 0.75, nevoa: 0.12, densidade: 1, semente: 41 },
        { id: 'frente', plano: 'frente', motivo: 'raizesFrente', vx: 1.35, vy: 1.2, alfa: 0.7, nevoa: 0, densidade: 1, semente: 53 },
      ],
    },
  }),
};

/** Só volume (sem parallax): bom ponto de partida para salas antigas no editor. */
export const presetSoVolume = () => ({ versao: DEPTH_VERSAO, volume: { ativo: true, forca: 1, espessura: 2, sombra: true, ambiente: true }, parallax: { ativo: false, substituiFundo: false, camadas: [] } });

/**
 * Valida o bloco bruto. Erros = estrutura inutilizável; avisos = valor corrigido/ignorado.
 * `undefined` é válido (sala sem profundidade).
 */
export function validarDepth(raw) {
  const errors = []; const warnings = [];
  if (raw === undefined) return { errors, warnings };
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) { errors.push('"depth" deve ser um objeto.'); return { errors, warnings }; }
  if (raw.versao !== undefined && raw.versao !== DEPTH_VERSAO) warnings.push(`depth.versao ${raw.versao} desconhecida (esperado ${DEPTH_VERSAO}); lendo com as regras atuais.`);
  if (raw.volume !== undefined && (!raw.volume || typeof raw.volume !== 'object')) errors.push('"depth.volume" deve ser um objeto.');
  const p = raw.parallax;
  if (p !== undefined) {
    if (!p || typeof p !== 'object') errors.push('"depth.parallax" deve ser um objeto.');
    else if (p.camadas !== undefined && !Array.isArray(p.camadas)) errors.push('"depth.parallax.camadas" deve ser uma lista.');
    else {
      const cs = p.camadas || [];
      if (cs.length > MAX_CAMADAS) warnings.push(`depth: só as primeiras ${MAX_CAMADAS} camadas de parallax são usadas (desempenho no celular).`);
      cs.forEach((c, i) => {
        if (!c || typeof c !== 'object') { errors.push(`depth.parallax.camadas[${i}] deve ser um objeto.`); return; }
        if (!PLANOS.includes(c.plano)) warnings.push(`depth.parallax.camadas[${i}]: plano "${c.plano}" inválido (use ${PLANOS.join(', ')}); usando "fundo".`);
        if (!MOTIVOS.includes(c.motivo)) warnings.push(`depth.parallax.camadas[${i}]: motivo "${c.motivo}" desconhecido (use ${MOTIVOS.join(', ')}).`);
      });
    }
  }
  return { errors, warnings };
}

/**
 * Bloco bruto -> configuração normalizada (valores limitados, padrões preenchidos) ou null se a sala não usa o sistema.
 * `chave` identifica o conteúdo: muda quando qualquer parâmetro visual muda (invalida os caches).
 */
export function normalizarDepth(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const v = raw.volume && typeof raw.volume === 'object' ? raw.volume : {};
  const volume = {
    ativo: v.ativo !== false && raw.volume !== undefined, forca: clamp(v.forca, 0, 1.5, 1), espessura: Math.round(clamp(v.espessura, 0, 3, 2)),
    sombra: v.sombra !== false, ambiente: v.ambiente !== false,
  };
  const p = raw.parallax && typeof raw.parallax === 'object' ? raw.parallax : {};
  const camadas = (Array.isArray(p.camadas) ? p.camadas : []).slice(0, MAX_CAMADAS).filter((c) => c && typeof c === 'object').map((c, i) => ({
    id: typeof c.id === 'string' && c.id ? c.id : `camada${i + 1}`,
    plano: PLANOS.includes(c.plano) ? c.plano : 'fundo',
    motivo: MOTIVOS.includes(c.motivo) ? c.motivo : 'troncos',
    vx: clamp(c.vx, 0, 2, 0.3), vy: clamp(c.vy, 0, 2, 0.2), alfa: clamp(c.alfa, 0, 1, 1), nevoa: clamp(c.nevoa, 0, 1, 0),
    densidade: clamp(c.densidade, 0, 2, 1), semente: Math.round(clamp(c.semente, 0, 99999, 1 + i)),
  }));
  const ordem = (a) => PLANOS.indexOf(a.plano);
  camadas.sort((a, b) => ordem(a) - ordem(b) || a.vx - b.vx);   // mais longe primeiro: ordem de pintura estável
  const parallax = { ativo: p.ativo !== false && camadas.length > 0 && raw.parallax !== undefined, substituiFundo: p.substituiFundo !== false, camadas };
  const cfg = { versao: DEPTH_VERSAO, preset: typeof raw.preset === 'string' ? raw.preset : undefined, volume, parallax };
  cfg.chave = JSON.stringify([volume, parallax.ativo, parallax.substituiFundo, camadas]);
  return cfg;
}

// ---------------------------------------------------------------------
// PERFIL DE MATERIAL: como cada família de tile reage à luz (relevo, brilho, elevação).
// As cores vêm da própria arte do tile (art.color/color2/color3): o relevo sempre combina com o material.
// `elev` decide quem "sobra" sobre quem num contato entre materiais sólidos diferentes (osso > raiz > cartilagem > carne).
// ---------------------------------------------------------------------
const MATERIAIS = {
  carne: { relevo: 0.8, brilho: 0.5, elev: 1, umido: true },
  osso: { relevo: 1, brilho: 0.9, elev: 3, lascas: true },
  cartilagem: { relevo: 0.7, brilho: 0.55, elev: 2, translucido: true },
  raiz: { relevo: 1, brilho: 0.25, elev: 2.5, sulcos: true },
  musculo: { relevo: 0.85, brilho: 0.45, elev: 1.5, estrias: true },
  fungo: { relevo: 0.7, brilho: 0.3, elev: 1, fofo: true },
  planta: { relevo: 0.6, brilho: 0.35, elev: 1, fofo: true },
  escorregadio: { relevo: 0.5, brilho: 0.95, elev: 0.5, umido: true },
};
const PADRAO = MATERIAIS.carne;

const hexRgb = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(c || ''); if (!m) return [128, 100, 96]; const n = parseInt(m[1], 16); return [n >> 16, (n >> 8) & 255, n & 255]; };
const misturar = (a, b, k) => a.map((v, i) => Math.round(v + (b[i] - v) * k));
const rgb = (c) => `${c[0]},${c[1]},${c[2]}`;

const _perfis = new WeakMap();
/** Perfil (com cache por objeto de tile). Cores como "r,g,b" para montar rgba() sem custo. */
export function perfilDoMaterial(tile) {
  if (!tile) return null;
  let p = _perfis.get(tile); if (p) return p;
  const base = MATERIAIS[tile.category] || PADRAO; const a = tile.art || {};
  const c1 = hexRgb(a.color); const c2 = hexRgb(a.color2 || a.color); const c3 = hexRgb(a.color3 || a.color);
  p = {
    id: tile.id, categoria: tile.category, ...base,
    hi: rgb(misturar(c2, [255, 244, 220], 0.28 + 0.25 * base.brilho)),     // luz na quina voltada à luz
    topo: rgb(misturar(c2, c1, 0.35)),                                      // "face de cima" (espessura visível)
    lo: rgb(misturar(c3, [0, 0, 0], 0.45)),                                 // sombra da quina oposta
    ao: rgb(misturar(c3, [8, 2, 10], 0.65)),                                // oclusão ambiente (cantos internos, contatos)
    grupo: tile.autotile?.group || `id:${tile.id}`,
  };
  _perfis.set(tile, p); return p;
}

/** Os dois tiles se conectam visualmente (mesmo grupo de autotile)? Regra idêntica à do autotile: sem borda artificial entre vizinhos. */
export const mesmoGrupo = (a, b) => !!a && !!b && a.grupo === b.grupo;
