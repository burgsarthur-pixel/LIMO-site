// =====================================================================
// CENÁRIO COLOSSAL (só desenho, sem DOM; testável com um contexto falso).
// Dá a medida do corpo em que Limo está: silhuetas gigantes em parallax (costelas, coluna vertebral, pálpebra, órgão, membrana,
// raízes, tendões, vasos) que RESPIRAM (ciclo lento de Ambience.respira) e acompanham o batimento (pulso). Mais as partículas de ar de cada sala.
// Quais silhuetas e partículas cada sala usa vem de world/personalidade.js. Tudo é fillRect de pixels: nenhuma imagem, nenhuma alocação por quadro.
// =====================================================================

const R = Math.round;
const rect = (ctx, x, y, w, h) => ctx.fillRect(R(x), R(y), Math.max(1, R(w)), Math.max(1, R(h)));
const mod = (a, n) => ((a % n) + n) % n;
const rgba = (c, a) => `rgba(${c[0]},${c[1]},${c[2]},${Math.max(0, Math.min(1, a)).toFixed(3)})`;
const corOsso = (T) => T.bolha.split(',').map(Number);   // tom claro do bioma ("120,255,220"): os ossos/membranas assumem a luz do lugar

/** Costelas: arcos que saem da borda de cima ('topo') ou de baixo ('base') e se curvam para dentro; abrem e fecham com a respiração. */
function costelas(ctx, e, c) {
  const { W, H, camX, t, resp, pulso, T } = c; const f = e.prof ?? 0.08; const n = e.n ?? 5; const k = (e.intensidade ?? 1);
  const topo = e.de === 'topo'; const dir = topo ? 1 : -1; const passo = 64; const total = passo * Math.max(3, n);
  const o = corOsso(T); const x0 = -mod(camX * f, total) - passo;
  for (let i = 0; i * passo + x0 < W + passo; i++) {
    const baseX = x0 + i * passo; const lado = (Math.floor((baseX + camX * f) / passo) % 2) ? 1 : -1;   // costelas alternam o lado da curva
    const alcance = (44 + (i % 3) * 8) * (1 + 0.05 * resp); const altura = (H * 0.5 + (i % 2) * 18) * (1 + 0.035 * resp);
    const yBase = topo ? -6 + resp * 3 : H + 6 - resp * 3;
    for (let s = 0; s <= 36; s++) {
      const u = s / 36; const x = baseX + lado * alcance * (1 - Math.cos(u * Math.PI / 2)); const y = yBase + dir * altura * Math.sin(u * Math.PI / 2);
      const esp = 8 * (1 - u) + 2;
      ctx.fillStyle = rgba(o, (0.13 + pulso * 0.03) * k); rect(ctx, x - esp / 2, y, esp, 3);
      ctx.fillStyle = rgba(o, 0.12 * k); rect(ctx, x - esp / 2, y, 1, 3);   // fio de luz na borda
    }
  }
}

/** Coluna vertebral: pilha de vértebras com processos laterais, ondulando levemente com a respiração. */
function coluna(ctx, e, c) {
  const { W, H, camX, camY, resp, T } = c; const f = e.prof ?? 0.06; const o = corOsso(T); const k = e.intensidade ?? 1;
  const cx = (e.x ?? 0.5) * W - camX * f; if (cx < -60 || cx > W + 60) return;
  const seg = 26; const desl = mod(-camY * f * 0.5, seg);
  for (let i = -1; i * seg < H + seg; i++) {
    const y = i * seg + desl + Math.sin(i * 0.8) * 2 * resp; const x = cx + Math.sin(i * 0.5) * 3;
    ctx.fillStyle = rgba(o, 0.09 * k); rect(ctx, x - 14, y, 28, 14);
    ctx.fillStyle = rgba(o, 0.05 * k); rect(ctx, x - 5, y + 4, 10, 6);                    // canal da medula
    ctx.fillStyle = rgba(o, 0.08 * k); rect(ctx, x - 26, y + 4, 12, 5); rect(ctx, x + 14, y + 4, 12, 5);   // processos laterais
  }
}

/** Pálpebra gigante: um arco enorme no alto com a fenda fechada, cílios e um tremor a cada batida (o Deus quase acorda). */
function palpebra(ctx, e, c) {
  const { W, H, camX, t, pulso, resp, T } = c; const f = e.prof ?? 0.04; const o = corOsso(T); const k = e.intensidade ?? 1;
  const cx = W / 2 - camX * f; const cy = H * 0.1; const rx = W * 0.85; const ry = H * 0.62 * (1 + 0.02 * resp);
  ctx.fillStyle = rgba(T.veia, 0.09 * k);
  for (let y = 0; y < cy + ry; y += 3) { const q = 1 - Math.pow((y - cy) / ry, 2); if (q <= 0) continue; const hw = rx * Math.sqrt(q); rect(ctx, cx - hw, y, hw * 2, 3); }
  const yF = cy + ry * 0.62; ctx.fillStyle = rgba(T.veiaPulso, (0.10 + 0.14 * pulso) * k);
  for (let x = -rx * 0.9; x <= rx * 0.9; x += 3) { const q = 1 - Math.pow(x / (rx * 0.9), 2); rect(ctx, cx + x, yF + (1 - q) * 14, 3, 1 + pulso * 2.5 * q); }   // fenda treme no batimento
  ctx.fillStyle = rgba(o, 0.07 * k);
  for (let x = -rx * 0.8; x <= rx * 0.8; x += 14) { const q = 1 - Math.pow(x / (rx * 0.9), 2); rect(ctx, cx + x, yF + (1 - q) * 14 + 2, 1, 6 + (Math.sin(x * 0.3 + t * 0.4) + 1) * 4); }   // cílios
}

/** Órgão: massa lobulada de fundo que incha com o batimento (e um pouco com a respiração). */
function orgao(ctx, e, c) {
  const { W, H, camX, camY, pulso, resp, T } = c; const f = e.prof ?? 0.07; const k = e.intensidade ?? 1;
  const esc = 1 + 0.035 * pulso + 0.02 * resp; const cx = W * 0.55 - camX * f; const cy = H * 0.72 - camY * f * 0.4;
  const lobos = [[0, 0, 120, 70], [-90, 24, 70, 50], [84, 30, 66, 46]];
  for (const [dx, dy, rx0, ry0] of lobos) {
    const rx = rx0 * esc; const ry = ry0 * esc;
    for (let y = -ry; y <= ry; y += 3) {
      const q = 1 - (y / ry) * (y / ry); const hw = rx * Math.sqrt(q);
      ctx.fillStyle = rgba(T.veia, (0.12 + pulso * 0.05) * k * (0.8 + 0.2 * (1 - Math.abs(y) / ry))); rect(ctx, cx + dx - hw, cy + dy + y, hw * 2, 3);
    }
  }
  ctx.fillStyle = rgba(T.veiaPulso, (0.06 + 0.10 * pulso) * k);   // vasos sobre a massa
  for (let i = 0; i < 4; i++) for (let s = 0; s < 22; s++) rect(ctx, cx - 70 + i * 46 + Math.sin(s * 0.5 + i) * 8, cy - 50 + s * 5, 2, 5);
}

/** Membrana celular: malha ondulada de células com núcleos; "respira" mudando de tamanho. */
function membrana(ctx, e, c) {
  const { W, H, camX, camY, t, resp, pulso, T } = c; const f = e.prof ?? 0.1; const k = e.intensidade ?? 1; const o = corOsso(T);
  const s = 40 * (1 + 0.025 * resp); const ox = mod(-camX * f, s); const oy = mod(-camY * f * 0.5, s);
  ctx.fillStyle = rgba(o, 0.055 * k);
  for (let gx = -1; gx * s < W + s; gx++) for (let y = 0; y < H; y += 8) rect(ctx, ox + gx * s + Math.sin(y * 0.06 + gx * 1.7 + t * 0.3) * 4, y, 1, 8);
  for (let gy = -1; gy * s < H + s; gy++) for (let x = 0; x < W; x += 8) rect(ctx, x, oy + gy * s + Math.sin(x * 0.06 + gy * 2.1 + t * 0.3) * 4, 8, 1);
  for (let gx = 0; gx * s < W + s; gx++) for (let gy = 0; gy * s < H + s; gy++) {
    const n = Math.sin(gx * 12.9 + gy * 78.2) * 0.5 + 0.5; if (n < 0.45) continue;
    ctx.fillStyle = rgba(o, (0.05 + 0.05 * pulso * n) * k); rect(ctx, ox + (gx - 0.5) * s - 2, oy + (gy - 0.5) * s - 2, 4, 4);   // núcleos
  }
}

/** Raízes gigantes descendo do teto, afinando e balançando devagar. */
function raizesGigantes(ctx, e, c) {
  const { W, H, camX, t, resp, T } = c; const f = e.prof ?? 0.1; const n = e.n ?? 3; const k = e.intensidade ?? 1; const v = T.veia;
  for (let i = 0; i < n; i++) {
    const x0 = mod(i * (W / n) + 40 - camX * f, W + 80) - 40; ctx.fillStyle = rgba(v, 0.15 * k);
    for (let y = -4; y < H * 0.92; y += 4) {
      const u = y / (H * 0.92); const x = x0 + Math.sin(y * 0.022 + i * 2 + t * 0.25) * (10 + 8 * resp); const w = 18 * (1 - u) + 2;
      rect(ctx, x - w / 2, y, w, 4);
      if (y % 44 === 0 && u > 0.1 && u < 0.7) rect(ctx, x + (i % 2 ? w / 2 : -w / 2 - 14), y + 2, 14, 2);   // ramo lateral
    }
  }
}

/** Tendões: fibras esticadas atravessando o ar; vibram mais a cada batida. */
function tendoes(ctx, e, c) {
  const { W, H, camX, camY, t, pulso, T } = c; const f = e.prof ?? 0.14; const n = e.n ?? 6; const k = e.intensidade ?? 1; const o = corOsso(T);
  for (let i = 0; i < n; i++) {
    const xa = mod(i * 71 - camX * f, W + 120) - 60; const ya = (i * 37) % (H - 30) + 10 - camY * f * 0.4; const dx = 90 + (i % 3) * 40; const dy = ((i % 2) ? -1 : 1) * (20 + (i % 4) * 22);
    ctx.fillStyle = rgba(o, (0.26 + 0.12 * pulso) * k);
    for (let s = 0; s <= 40; s++) { const u = s / 40; rect(ctx, xa + dx * u, ya + dy * u + Math.sin(u * Math.PI * 3 + t * 6 + i) * (0.5 + pulso * 1.8) * Math.sin(u * Math.PI), 2, 1); }
  }
}

/** Vaso gigante atravessando a sala, com uma onda de pulso que corre por dentro dele. */
function veiaGigante(ctx, e, c) {
  const { W, H, camX, camY, t, pulso, T } = c; const f = e.prof ?? 0.1; const n = e.n ?? 1; const k = e.intensidade ?? 1;
  for (let i = 0; i < n; i++) {
    const yc = H * (0.3 + 0.35 * i) - camY * f * 0.5; const onda = mod(t * 55 + i * 130, W + 160) - 80;
    for (let x = -4; x < W + 4; x += 4) {
      const y = yc + Math.sin((x + camX * f) * 0.011 + i * 2.3) * 16; const bulbo = 7 * Math.exp(-Math.pow((x - onda) / 34, 2)); const th = 18 + bulbo;
      ctx.fillStyle = rgba(T.veia, (0.13 + 0.07 * pulso) * k); rect(ctx, x, y - th / 2, 4, th);
      ctx.fillStyle = rgba(T.veiaPulso, (0.05 + 0.18 * (bulbo / 7)) * k); rect(ctx, x, y - th / 2 + 2, 4, 2);
    }
  }
}

export const SILHUETAS = { costelas, coluna, palpebra, orgao, membrana, raizesGigantes, tendoes, veiaGigante };

/**
 * Desenha as silhuetas da sala. `c` = { W, H, camX, camY, t, pulso, resp, tema }. A respiração da sala (`pers.respira`) escala `resp`.
 * Sem personalidade ou sem silhuetas não desenha nada.
 */
export function desenharColosso(ctx, pers, c) {
  if (!pers || !pers.escala || !pers.escala.length || !c.tema) return;
  const cc = { ...c, T: c.tema, resp: (c.resp || 0) * (pers.respira ?? 0.5) * 2 };   // 0..~2: salas muito vivas respiram mais fundo
  ctx.save();
  for (const e of pers.escala) { const f = SILHUETAS[e.tipo]; if (f) f(ctx, e, cc); }
  ctx.restore();
}

/** Partículas de ar da sala (posições deterministas por índice: sem alocação). `m` = { tipo, n }. */
export function desenharMotes(ctx, m, c) {
  if (!m || !m.n || !c.tema) return;
  const { W, H, camX, camY, t, tema: T } = c; const o = corOsso(T);
  ctx.save();
  for (let i = 0; i < m.n; i++) {
    const s1 = (i * 73) % 311; const s2 = (i * 41) % 197; const v = 4 + (i % 4) * 2.5;
    let x; let y; let tam = 1;
    if (m.tipo === 'cinza') {          // flocos de cinza/osso caindo, balançando
      x = mod(s1 + Math.sin(t * 0.5 + i) * 8 - camX * 0.4, W); y = mod(s2 + t * v - camY * 0.2, H); ctx.fillStyle = `rgba(222,200,160,${(0.22 + (i % 3) * 0.08).toFixed(2)})`; tam = i % 5 ? 1 : 2;
    } else if (m.tipo === 'brasa') {   // brasas subindo, tremeluzindo
      x = mod(s1 + Math.sin(t * 0.9 + i * 2) * 6 - camX * 0.35, W); y = mod(s2 - t * (7 + (i % 4) * 3) - camY * 0.2, H); const a = 0.25 + 0.35 * (0.5 + 0.5 * Math.sin(t * 5 + i * 3));
      ctx.fillStyle = i % 2 ? `rgba(255,176,80,${a.toFixed(2)})` : `rgba(${T.veiaPulso[0] + 90},${T.veiaPulso[1] + 60},${T.veiaPulso[2] + 40},${a.toFixed(2)})`;
    } else if (m.tipo === 'fio') {     // fiapos finos e longos à deriva
      x = mod(s1 + t * 3 * (i % 2 ? 1 : -1) - camX * 0.45, W); y = mod(s2 - t * (3 + (i % 3)) - camY * 0.2, H); ctx.fillStyle = rgba(o, 0.28); rect(ctx, x, y, 1, 4 + (i % 3)); continue;
    } else if (m.tipo === 'bolha') {   // bolhas ocas subindo
      x = mod(s1 + Math.sin(t * 0.7 + i) * 5 - camX * 0.3, W); y = mod(s2 - t * (5 + (i % 3) * 2) - camY * 0.2, H); ctx.fillStyle = rgba(o, 0.30);
      rect(ctx, x, y - 1, 2, 1); rect(ctx, x, y + 2, 2, 1); rect(ctx, x - 1, y, 1, 2); rect(ctx, x + 2, y, 1, 2); continue;
    } else {                            // esporo (padrão): luzes que sobem devagar
      x = mod(s1 + Math.sin(t * 0.6 + i) * 7 - camX * 0.38, W); y = mod(s2 - t * (4 + (i % 4)) - camY * 0.2, H); ctx.fillStyle = i % 3 ? T.esporoA : T.esporoB;
    }
    rect(ctx, x, y, tam, tam);
  }
  ctx.restore();
}
