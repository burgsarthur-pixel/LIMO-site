// =====================================================================
// SPRITES DAS MUTAÇÕES · Pseudópode, Tendril e Membrana (pixel art 17×17, 8 quadros de animação)
// Antes: as três apareciam como um disco genérico com um brilho branco. Agora cada uma tem silhueta própria:
//   pseudópode  braço de músculo de memória terminando num punho com nós; no ápice do ciclo solta uma faísca dourada
//   tendril     bulbo com um fio que ondula, gota-lágrima com núcleo dourado na ponta, filamentos finos e uma gota que escorre
//   membrana    célula-escudo de epiderme: anel roxo que respira, miolo escuro, núcleo verde de Limo protegido e um brilho que circula
// Cores: as mesmas do HUD (css/ui.css, [data-ability]) + o verde/dourado do Limo no núcleo da Membrana.
// Cada quadro é montado em camadas (máscara → sombreamento luz/sombra → contorno de 1 px), então a silhueta fica consistente.
// O mesmo código gera os PNGs de assets/sprites (tools/gerar_sprites_mutacoes.mjs). Só visual: nenhuma regra de jogo muda.
// =====================================================================

export const SPRITE_N = 17;
export const QUADROS = 8;
const QUADROS_POR_SEGUNDO = 7;
export const MUTACOES_COM_SPRITE = Object.freeze(['pseudopode', 'tendril', 'membrana']);

/** Todas as cores permitidas (o teste confere que nenhum pixel sai desta lista). */
export const PALETA_MUTACAO = Object.freeze({
  // pseudópode (carne de memória)
  pContorno: '#31101f', pSombra: '#7d2637', pBase: '#b4515f', pLuz: '#e88f7f', pBrilho: '#ffd0a4',
  // tendril (nervo-gosma)
  tContorno: '#09251f', tSombra: '#1f6b5a', tBase: '#2b8f77', tLuz: '#59dcb4', tBrilho: '#a6ffdb',
  // membrana (epiderme)
  mContorno: '#161333', mSombra: '#4a3b8a', mBase: '#7660b5', mLuz: '#a98ce0', mBrilho: '#e2ccff', mMiolo: '#30275c', mCelula: '#5b49a0',
  // Limo (núcleo da membrana) e faíscas
  lContorno: '#0b2514', lSombra: '#278843', lBase: '#55ce67', lLuz: '#caff91', nucleo: '#f1c94f', ouro: '#ffe135', ouroClaro: '#fff3a5',
});
const C = PALETA_MUTACAO;
const RAMPA = {
  pseudopode: { contorno: C.pContorno, sombra: C.pSombra, base: C.pBase, luz: C.pLuz },
  tendril: { contorno: C.tContorno, sombra: C.tSombra, base: C.tBase, luz: C.tLuz },
  anel: { contorno: C.mContorno, sombra: C.mSombra, base: C.mBase, luz: C.mLuz },
  limo: { contorno: C.lContorno, sombra: C.lSombra, base: C.lBase, luz: C.lLuz },
};

// ---------- mini-rasterizador ----------
const N = SPRITE_N;
const mascara = () => Array.from({ length: N }, () => new Uint8Array(N));
const dentro = (x, y) => x >= 0 && y >= 0 && x < N && y < N;
const cheio = (m, x, y) => dentro(x, y) && m[y][x] === 1;

function disco(m, cx, cy, r) {
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r + 0.25) m[y][x] = 1;
}
function elipse(m, cx, cy, rx, ry) {
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const dx = (x - cx) / rx; const dy = (y - cy) / ry; if (dx * dx + dy * dy <= 1.05) m[y][x] = 1; }
}
/** Traço grosso: carimba discos de raio r0→r1 ao longo de (x0,y0)→(x1,y1). */
function traco(m, x0, y0, x1, y1, r0, r1) {
  const n = Math.max(2, Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 2));
  for (let i = 0; i <= n; i++) { const k = i / n; disco(m, x0 + (x1 - x0) * k, y0 + (y1 - y0) * k, r0 + (r1 - r0) * k); }
}
function ponto(m, x, y) { x = Math.round(x); y = Math.round(y); if (dentro(x, y)) m[y][x] = 1; }

/** Pinta uma máscara na grade: luz na borda de cima/esquerda, sombra embaixo/direita, base no miolo; contorno opcional por fora. */
function pintar(px, m, R, { contorno = true } = {}) {
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    if (m[y][x] !== 1) continue;
    const topo = !cheio(m, x, y - 1) || !cheio(m, x - 1, y); const baixo = !cheio(m, x, y + 1) || !cheio(m, x + 1, y);
    px[y][x] = baixo ? R.sombra : topo ? R.luz : R.base;
  }
  if (!contorno) return;
  for (let y = -1; y <= N; y++) for (let x = -1; x <= N; x++) {
    if (cheio(m, x, y) || !dentro(x, y)) continue;
    if (cheio(m, x - 1, y) || cheio(m, x + 1, y) || cheio(m, x, y - 1) || cheio(m, x, y + 1)) px[y][x] = R.contorno;
  }
}
const pixel = (px, x, y, cor) => { x = Math.round(x); y = Math.round(y); if (dentro(x, y)) px[y][x] = cor; };

// ---------- quadros ----------
function pseudopode(q) {
  const px = Array.from({ length: N }, () => Array(N).fill(null));
  const ciclo = (q / QUADROS) * Math.PI * 2; const esticar = 0.5 + 0.5 * Math.sin(ciclo - 1.2);      // 0 = recuado · 1 = punho esticado
  const fx = 10.6 + esticar * 1.2; const fy = 7.4 - esticar * 0.5;                                         // centro do punho (sobe um pouco ao esticar)
  const m = mascara();
  disco(m, 2.6, 11.4, 1.9);                                                    // raiz do braço, brotando do corpo
  elipse(m, 5.4, 10.1 - esticar * 0.4, 2.7, 2.1);                              // bíceps: o músculo incha ao golpear
  traco(m, 7, 9.4, fx - 2.2, fy + 0.4, 1.3, 1.5);                              // antebraço fino
  disco(m, fx, fy, 3.5);                                                       // punho
  disco(m, fx + 2.8, fy - 2.2, 1.15); disco(m, fx + 3.4, fy - 0.1, 1.15); disco(m, fx + 3.2, fy + 2.1, 1.1);   // nós dos dedos
  pintar(px, m, RAMPA.pseudopode);
  // vincos entre os dedos (escuros) e o polegar dobrado sobre o punho
  const fxr = Math.round(fx); const fyr = Math.round(fy);
  for (let i = 0; i < 3; i++) { pixel(px, fxr + 1 + i, fyr - 1, C.pSombra); pixel(px, fxr + 1 + i, fyr + 1, C.pSombra); }
  pixel(px, fxr - 1, fyr + 2, C.pSombra); pixel(px, fxr, fyr + 2, C.pSombra); pixel(px, fxr - 2, fyr + 1, C.pSombra);
  // músculo: estrias no bíceps, tendão do antebraço e reflexos
  pixel(px, 4, 11, C.pSombra); pixel(px, 5, 11, C.pSombra); pixel(px, 6, 10, C.pSombra);
  pixel(px, 4, 9, C.pBrilho); pixel(px, 5, 8.6, C.pLuz); pixel(px, 7, 9, C.pLuz);
  pixel(px, fx - 1.6, fy - 1.8, C.pBrilho); pixel(px, fx - 0.6, fy - 2.4, C.pBrilho); pixel(px, fx - 2.2, fy - 0.8, C.pLuz);
  if (esticar > 0.72) {   // faísca dourada do golpe no ápice
    const sx = Math.min(14, Math.round(fx + 3.4)); const sy = Math.round(fy - 5);
    pixel(px, sx, sy, C.ouro); pixel(px, sx - 1, sy, C.ouroClaro); pixel(px, sx + 1, sy, C.ouro); pixel(px, sx, sy - 1, C.ouro); pixel(px, sx, sy + 1, C.ouroClaro);
  } else if (esticar > 0.5) pixel(px, Math.min(14, Math.round(fx + 3.4)), Math.round(fy - 5), C.ouro);
  return px;
}

function tendril(q) {
  const px = Array.from({ length: N }, () => Array(N).fill(null));
  const fase = (q / QUADROS) * Math.PI * 2;
  const filamentos = mascara();   // finos (1 px, sem contorno): dois fios laterais que ondulam em fases opostas
  for (let i = 0; i <= 14; i++) {
    const k = i / 14;
    ponto(filamentos, 6.4 - k * 3.2 + Math.sin(fase + k * 4) * 0.9 * k, 11.2 - k * 7.6);
    ponto(filamentos, 9.6 + k * 2.6 + Math.sin(fase * -1 + k * 3.6) * 0.8 * k, 11.6 - k * 5.4);
  }
  pintar(px, filamentos, { contorno: false, sombra: C.tBase, base: C.tLuz, luz: C.tBrilho });
  pixel(px, 3.2 + Math.sin(fase + 4) * 0.9, 3.6, C.tBrilho); pixel(px, 12.2 + Math.sin(-fase + 3.6) * 0.8, 6.2, C.tBrilho);   // contas na ponta dos fios

  const m = mascara();
  elipse(m, 8, 13.6, 4.4, 2.5);                                               // bulbo-raiz
  let xt = 8; const yt = 4.6;
  for (let i = 0; i <= 18; i++) {                                              // caule ondulante, afinando
    const k = i / 18; xt = 8 + Math.sin(fase + k * 3.4) * 2.3 * k; disco(m, xt, 12 - k * 7.4, 1.5 - 0.65 * k);
  }
  disco(m, xt, yt - 0.4, 2.0);                                                 // gota-lágrima na ponta
  ponto(m, xt, yt - 3.1);
  pintar(px, m, RAMPA.tendril);
  pixel(px, xt, yt - 0.4, C.nucleo); pixel(px, xt - 1, yt - 1.4, C.tBrilho); pixel(px, xt, yt - 0.4, q % 4 < 2 ? C.ouroClaro : C.ouro);   // núcleo dourado pulsa
  pixel(px, 6, 13, C.tBrilho); pixel(px, 7, 12.4, C.tLuz); pixel(px, 10, 14.4, C.tSombra);
  if (q < 6) {   // gota que escorre pelo caule e some no bulbo
    const gy = 5.2 + q * 1.3; const gx = 8 + Math.sin(fase + ((gy - 4.6) / 8) * 3.4) * 2.3 * ((12 - gy) / 7.4 > 0 ? (12 - gy) / 7.4 : 0) + 3.2;
    pixel(px, gx, gy, C.tContorno); pixel(px, gx, gy + 1, C.tContorno); pixel(px, gx + 1, gy, C.tContorno); pixel(px, gx + 1, gy + 1, C.tLuz);
  }
  return px;
}

function membrana(q) {
  const px = Array.from({ length: N }, () => Array(N).fill(null));
  const fase = (q / QUADROS) * Math.PI * 2; const R = 6.9 + 0.3 * Math.sin(fase);   // respira
  const miolo = mascara(); disco(miolo, 8, 8, R - 1.2);
  pintar(px, miolo, { contorno: false, sombra: C.mMiolo, base: C.mMiolo, luz: C.mMiolo });
  for (const [x, y] of [[5, 6], [11, 5], [11, 11], [5, 11], [8, 4]]) pixel(px, x, y, C.mCelula);   // padrão celular da epiderme
  const anel = mascara();
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const d = Math.hypot(x - 8, y - 8); if (d >= R - 1.35 && d <= R + 0.15) anel[y][x] = 1; }
  pintar(px, anel, RAMPA.anel);
  for (let i = 0; i < 2; i++) {   // dois brilhos orbitando (o segundo, mais fraco)
    const a = fase + i * Math.PI; const bx = 8 + Math.cos(a) * (R - 0.6); const by = 8 + Math.sin(a) * (R - 0.6);
    pixel(px, bx, by, i ? C.mLuz : C.mBrilho); if (!i) { pixel(px, bx + Math.cos(a + 1.57), by + Math.sin(a + 1.57), C.mLuz); }
  }
  const nucleo = mascara(); disco(nucleo, 8, 8, 2.3);                         // Limo protegido no centro
  pintar(px, nucleo, RAMPA.limo);
  pixel(px, 7, 7, C.lLuz); pixel(px, 8, 8, q % 4 < 2 ? C.ouro : C.nucleo); pixel(px, 9, 9, C.lSombra);
  return px;
}

const FABRICAS = { pseudopode, tendril, membrana };
const cache = new Map();

/** Grade 17×17 (linhas de cores '#rrggbb' ou null) do quadro `q` (0..7) da mutação. */
export function gradeMutacao(id, q = 0) {
  const fab = FABRICAS[id]; if (!fab) return null;
  const quadro = ((q % QUADROS) + QUADROS) % QUADROS; const chave = `${id}:${quadro}`;
  let g = cache.get(chave); if (!g) { g = fab(quadro); cache.set(chave, g); }
  return g;
}

/** Quadro de animação para o tempo `t` (s). */
export const quadroDe = (t) => Math.floor((t || 0) * QUADROS_POR_SEGUNDO) % QUADROS;

/** Desenha o sprite centrado em (cx, cy). Linhas contínuas da mesma cor viram um só fillRect. */
export function drawSpriteMutacao(ctx, id, cx, cy, t = 0) {
  const g = gradeMutacao(id, quadroDe(t)); if (!g) return false;
  const x0 = Math.round(cx) - 8; const y0 = Math.round(cy) - 8;
  for (let y = 0; y < N; y++) {
    let x = 0;
    while (x < N) {
      const cor = g[y][x]; if (!cor) { x++; continue; }
      let fim = x + 1; while (fim < N && g[y][fim] === cor) fim++;
      ctx.fillStyle = cor; ctx.fillRect(x0 + x, y0 + y, fim - x, 1); x = fim;
    }
  }
  return true;
}

/** Ícone para o HUD (DOM): <canvas> com o quadro `q`, ampliado por CSS sem suavização. */
export function criarIconeMutacao(doc, id, q = 0) {
  const g = gradeMutacao(id, q); if (!g || !doc?.createElement) return null;
  const cv = doc.createElement('canvas'); cv.width = N; cv.height = N; cv.className = 'ab-sprite'; cv.setAttribute('aria-hidden', 'true');
  const c = cv.getContext?.('2d'); if (!c) return null;
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) if (g[y][x]) { c.fillStyle = g[y][x]; c.fillRect(x, y, 1, 1); }
  return cv;
}
