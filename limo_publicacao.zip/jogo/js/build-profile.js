// Perfil de distribuição. Dois perfis:
//   'release' → versão final: o modo dev (painel, editor, botão do menu) fica DESLIGADO, qualquer que seja a URL.
//   'interno' → edição de desenvolvimento: modo dev disponível (?dev=1, botão "Modo desenvolvedor" no menu de pausa).
// Para publicar, volte para 'release' ANTES de gerar a versão final.
export const BUILD_PROFILE = 'release';

/** O que cada perfil força na configuração. Só o release desliga o modo dev. */
export function overridesPara(perfil) {
  return perfil === 'release'
    ? Object.freeze({ debug: Object.freeze({ allowDevToggle: false, devMode: false, mirrorToConsole: false }) })
    : Object.freeze({});
}
export const BUILD_OVERRIDES = overridesPara(BUILD_PROFILE);
export const isReleaseBuild = BUILD_PROFILE === 'release';
