// =====================================================================
// MENSAGENS CURTAS NA TELA ("Checkpoint salvo", "Mutação adquirida: ...", "Passagem selada...").
// Uma de cada vez; some sozinha. Fica em HTML por cima do canvas (aria-live para leitores de tela).
// =====================================================================
export function createToast(doc, win = (typeof window !== 'undefined' ? window : null)) {
  const el = doc.getElementById('toast'); let timer = null;
  return {
    show(texto, ms = 2600) {
      el.textContent = texto; el.classList.remove('hidden');
      if (win) { win.clearTimeout(timer); timer = win.setTimeout(() => el.classList.add('hidden'), ms); }
    },
    hide() { el.classList.add('hidden'); },
  };
}
