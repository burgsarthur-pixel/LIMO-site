// =====================================================================
// HUD (vida, sala e mutações). Fica em HTML por cima do canvas.
// Só mexe no DOM quando algo muda (nada de recriar elementos a cada quadro).
//  - Vida: "VIDA" + corações + número (3/5); pisca em vermelho quando resta 1.
//  - Sala: nome da sala atual (dá um destaque rápido ao trocar de sala).
//  - Mutações: só aparecem as que o jogador já tem, cada uma com ícone e nome.
//  - Botão de investida: apagado enquanto a mutação não existe; escurece durante a recarga.
// =====================================================================
import { ABILITIES } from '../entities/abilities.js';
import { criarIconeMutacao, MUTACOES_COM_SPRITE } from '../render/mutacao-sprites.js';

// Mutações sem sprite próprio usam um ícone de traço fino (o mesmo sprite SVG do index.html), não emoji.
const ICONE_SVG = Object.freeze({ investida: 'i-dash', saltoElastico: 'i-jump', wallJump: 'i-wall', instanteVital: 'i-hourglass' });

export function createHud(doc) {
  const coracoes = doc.getElementById('hud-hearts');
  const textoVida = doc.getElementById('hud-life-text');
  const habilidades = doc.getElementById('hud-abilities');
  const sala = doc.getElementById('hud-room');
  const essencia = doc.getElementById('hud-essence');
  let chaveEss = -1;
  const material = doc.getElementById('hud-material'); const celulas = doc.getElementById('hud-mat-cells'); const btnFoco = doc.getElementById('btn-foco'); let chaveMat = '';
  const btnDash = doc.getElementById('btn-dash');
  const btnTendril = doc.getElementById('btn-tendril'); const btnAtaque = doc.getElementById('btn-attack'); let atacando = false;
  let chaveVida = ''; let chaveHab = ''; let chaveSala = ''; let chaveDash = ''; let chaveTendril = '';

  const possui = (jogador, id) => (typeof jogador.hasAbility === 'function'
    ? jogador.hasAbility(id)
    : Array.isArray(jogador.abilities) ? jogador.abilities.includes(id) : !!(jogador.abilities && jogador.abilities[id]));

  return {
    update(jogador, extra = {}) {
      // --- vida ---
      const kv = `${jogador.life}/${jogador.maxLife}`;
      if (kv !== chaveVida) {
        chaveVida = kv;
        coracoes.replaceChildren();
        for (let i = 0; i < jogador.maxLife; i++) {
          const el = doc.createElement('span');
          el.className = `heart${i < jogador.life ? '' : ' empty'}`;
          coracoes.appendChild(el);
        }
        if (textoVida) textoVida.textContent = kv;
        coracoes.classList.toggle('low', jogador.life === 1 && jogador.maxLife > 1);
        coracoes.setAttribute('aria-label', `Vida ${kv}`);
      }

      // --- essência (orbes guardados para curar feridas) ---
      if (essencia && extra.essencia !== undefined && extra.essencia !== chaveEss) {
        chaveEss = extra.essencia; essencia.hidden = chaveEss <= 0; essencia.textContent = `◆ ${chaveEss}`; essencia.title = 'Essência: cura as Feridas do Deus';
      }

      // --- material biológico (medidor do foco) ---
      if (material && celulas && extra.material !== undefined) {
        const max = extra.materialMax ?? 9; const progresso = Math.round((extra.focoProgresso ?? 0) * 100); const km = `${extra.material}/${max}/${extra.focoPronto ? 1 : 0}${extra.focando ? 1 : 0}/${progresso}/${jogador.life < jogador.maxLife ? 1 : 0}`;
        if (km !== chaveMat) {
          chaveMat = km;
          if (celulas.children.length !== max) { celulas.replaceChildren(); for (let i = 0; i < max; i++) celulas.appendChild(doc.createElement('i')); }
          [...celulas.children].forEach((c, i) => c.classList.toggle('on', i < extra.material));
          const util = !!extra.focoPronto && jogador.life < jogador.maxLife;
          material.classList.toggle('pronto', util); material.classList.toggle('focando', !!extra.focando);
          material.style.setProperty('--foco-progresso', `${progresso}%`);
          if (btnFoco) { btnFoco.classList.toggle('pronto', util); btnFoco.classList.toggle('sem-material', !extra.focoPronto); }
          celulas.setAttribute('aria-label', extra.focando ? `Foco ${progresso}%: material biológico ${extra.material} de ${max}` : `Material biológico ${extra.material} de ${max}`);
        }
      }

      // --- nome da sala ---
      if (sala && extra.sala !== undefined && extra.sala !== chaveSala) {
        chaveSala = extra.sala; sala.textContent = extra.sala;
        sala.classList.remove('flash'); void sala.offsetWidth; sala.classList.add('flash');
      }

      // --- mutações (só as que já foram adquiridas) ---
      const lista = Object.entries(ABILITIES).filter(([, a]) => a.implementada);
      const kh = lista.map(([id]) => (possui(jogador, id) ? 1 : 0)).join('') + (extra.novaHabilidade || '');
      if (kh !== chaveHab) {
        chaveHab = kh;
        habilidades.replaceChildren();
        for (const [id, a] of lista) {
          if (!possui(jogador, id)) continue;
          const el = doc.createElement('span');
          el.className = `ability-icon active${extra.novaHabilidade === id ? ' novo' : ''}`;   // recém-desbloqueada: pulsa até trocar de sala
          // A identidade de cada mutação também vive no HUD: a cor e a matéria
          // contam qual órgão o Limo acabou de recuperar, sem alterar a mecânica.
          el.dataset.ability = id;
          el.title = `${a.nome} — ${a.descricao}${a.uso ? ` Uso: ${a.uso}.` : ''}`;
          const ic = doc.createElement('span'); ic.className = 'ab-ico';
          const sprite = MUTACOES_COM_SPRITE.includes(id) ? criarIconeMutacao(doc, id, 0) : null;   // pseudópode · tendril · membrana têm sprite próprio
          if (sprite) ic.appendChild(sprite);
          else if (ICONE_SVG[id]) { ic.innerHTML = `<svg class="ico"><use href="#${ICONE_SVG[id]}"/></svg>`; ic.classList.add('ab-svg'); }
          else ic.textContent = a.icone || '✦';
          const nm = doc.createElement('span'); nm.className = 'ab-name'; nm.textContent = a.curto || a.nome;
          el.appendChild(ic); el.appendChild(nm);
          habilidades.appendChild(el);
        }
      }

      // --- botão de investida (toque) ---
      if (btnDash) {
        const temDash = possui(jogador, 'investida');
        const recarga = temDash && jogador.dashCooldown > 0;
        const kd = `${temDash ? 1 : 0}${recarga ? 1 : 0}`;
        if (kd !== chaveDash) {
          chaveDash = kd;
          btnDash.classList.toggle('locked', !temDash);
          btnDash.classList.toggle('cooling', recarga);
        }
      }

      if (btnAtaque) { const tem = possui(jogador, 'pseudopode'); if (tem === btnAtaque.classList.contains('locked')) { btnAtaque.classList.toggle('locked', !tem); btnAtaque.setAttribute('aria-hidden', tem ? 'false' : 'true'); } }   // some até adquirir a mutação
      if (btnAtaque && !!extra.atacando !== atacando) { atacando = !!extra.atacando; btnAtaque.classList.toggle('cooling', atacando); }   // ataque básico em andamento

      // --- botão da Tendril: aceso só com a mutação; segurar estende, soltar recolhe ---
      if (btnTendril) {
        const temTendril = possui(jogador, 'tendril');
        const kt = temTendril ? '1' : '0';
        if (kt !== chaveTendril) {
          chaveTendril = kt;
          btnTendril.classList.toggle('locked', !temTendril);
          btnTendril.setAttribute('aria-disabled', temTendril ? 'false' : 'true');
        }
      }
    },
  };
}
