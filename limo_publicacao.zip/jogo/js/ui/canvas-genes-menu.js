// =====================================================================
// TELA DE GENES NO CANVAS (abre ao descansar num Casulo de Repouso)
// Mesma resolução lógica 320×240 da cena. 15 espaços em grade 5×3: gene encontrado = ícone de hélice;
// ainda não encontrado ou espaço reservado = "?". Equipar gasta ENCAIXES (limitados): é preciso escolher.
// Teclado: setas/WASD movem · Enter/Espaço/Z equipam · Esc/E/X fecham. Toque: tocar seleciona, tocar de novo equipa.
// Gamepad: direcional move · A equipa · B fecha.
// =====================================================================
import { GENES } from '../entities/genes.js';
import { drawGeneIcon, rgba } from '../render/gene-art.js';

export const COLUNAS = 5;
export const LINHAS = 3;

/** Estado e regras da tela (sem desenho nem DOM): cursor na grade 5×3 e equipar/remover pelo progresso. */
export class GenesMenuModel {
  constructor(progress) { this.progress = progress; this.cursor = 0; this.mensagem = ''; }
  mover(dx, dy) {
    const col = (this.cursor % COLUNAS + dx + COLUNAS) % COLUNAS; const lin = (Math.floor(this.cursor / COLUNAS) + dy + LINHAS) % LINHAS;
    this.cursor = lin * COLUNAS + col; this.mensagem = '';
  }
  selecionar(indice) { if (indice >= 0 && indice < GENES.length) { this.cursor = indice; this.mensagem = ''; } }
  get gene() { return GENES[this.cursor]; }
  get obtido() { return this.progress.genes.has(this.gene.id); }
  get equipado() { return this.progress.genesEquipados.includes(this.gene.id); }
  /** Equipa/remove o gene sob o cursor. Devolve {ok, equipado, motivo}. */
  alternar() {
    const g = this.gene;
    if (!g.implementado) { this.mensagem = 'Este espaço do genoma ainda está vazio.'; return { ok: false, equipado: false, motivo: this.mensagem }; }
    if (!this.obtido) { this.mensagem = 'Você ainda não encontrou este gene.'; return { ok: false, equipado: false, motivo: this.mensagem }; }
    const r = this.progress.alternarGene(g.id);
    this.mensagem = r.ok ? (r.equipado ? `${g.nome} equipado.` : `${g.nome} removido.`) : r.motivo;
    return r;
  }
  get encontrados() { return GENES.filter((g) => this.progress.genes.has(g.id)).length; }
}

export class CanvasGenesMenu {
  constructor({ canvas, renderer, config }) {
    this.canvas = canvas; this.renderer = renderer; this.config = config;
    this.open = false; this.modelo = null; this.aoMudar = null; this.aoFechar = null;
    this._rects = []; this._fechar = null;
    this._onPointerDown = (e) => this._pointerDown(e); this._onKeyDown = (e) => this._keyDown(e);
    canvas.addEventListener?.('pointerdown', this._onPointerDown);
    (typeof window !== 'undefined' ? window : null)?.addEventListener?.('keydown', this._onKeyDown);
  }

  abrir({ progress, aoMudar = null, aoFechar = null }) {
    this.modelo = new GenesMenuModel(progress); this.aoMudar = aoMudar; this.aoFechar = aoFechar; this.open = true;
    this.canvas.setAttribute?.('aria-label', 'Tela de genes aberta. Setas movem, Enter equipa, Esc fecha.');
  }

  fechar() {
    if (!this.open) return;
    const fim = this.aoFechar; this.open = false; this.modelo = null; this.aoMudar = null; this.aoFechar = null;
    this.canvas.setAttribute?.('aria-label', 'Área do jogo LIMO');
    fim?.();
  }

  _acionar() { const r = this.modelo.alternar(); if (r.ok) this.aoMudar?.(r); return r; }

  _keyDown(event) {
    if (!this.open) return;
    const c = event.code;
    if (['ArrowLeft', 'KeyA'].includes(c)) this.modelo.mover(-1, 0);
    else if (['ArrowRight', 'KeyD'].includes(c)) this.modelo.mover(1, 0);
    else if (['ArrowUp', 'KeyW'].includes(c)) this.modelo.mover(0, -1);
    else if (['ArrowDown', 'KeyS'].includes(c)) this.modelo.mover(0, 1);
    else if (event.repeat) { event.preventDefault?.(); return; }
    else if (['Enter', 'Space', 'KeyZ'].includes(c)) this._acionar();
    else if (['Escape', 'KeyE', 'KeyX', 'Backspace'].includes(c)) this.fechar();
    else return;
    event.preventDefault?.();
  }

  _pointerDown(event) {
    if (!this.open) return;
    event.preventDefault?.();
    const r = this.canvas.getBoundingClientRect();
    const x = (event.clientX - r.left) * this.config.render.internalWidth / r.width; const y = (event.clientY - r.top) * this.config.render.internalHeight / r.height;
    const f = this._fechar; if (f && x >= f.x && x <= f.x + f.w && y >= f.y && y <= f.y + f.h) { this.fechar(); return; }
    const i = this._rects.findIndex((q) => x >= q.x && x <= q.x + q.w && y >= q.y && y <= q.y + q.h);
    if (i < 0) return;
    if (this.modelo.cursor === i) this._acionar(); else this.modelo.selecionar(i);   // 1º toque seleciona (mostra a descrição); 2º equipa
  }

  /** Chamado a cada quadro pelo GamepadPoller (botões "standard": 12-15 direcional, 0 = A, 1 = B). */
  aoGamepad(info) {
    if (!this.open || !info?.pressed) return;
    const p = info.pressed;
    if (p.has(14)) this.modelo.mover(-1, 0); if (p.has(15)) this.modelo.mover(1, 0);
    if (p.has(12)) this.modelo.mover(0, -1); if (p.has(13)) this.modelo.mover(0, 1);
    if (p.has(0)) this._acionar();
    if (p.has(1)) this.fechar();
  }

  _quebrar(ctx, texto, largura) {
    const palavras = String(texto || '').split(/\s+/).filter(Boolean); const linhas = []; let atual = '';
    for (const w of palavras) { const t = atual ? `${atual} ${w}` : w; if (atual && ctx.measureText(t).width > largura) { linhas.push(atual); atual = w; } else atual = t; }
    if (atual) linhas.push(atual); return linhas;
  }

  draw(ctx) {
    if (!this.open || !this.modelo) return;
    const { internalWidth: W, internalHeight: H } = this.config.render; const m = this.modelo; const pr = m.progress;
    const agora = (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000;
    ctx.save();
    ctx.fillStyle = 'rgba(2, 2, 3, 0.84)'; ctx.fillRect(0, 0, W, H);
    const P = { x: 10, y: 8, w: W - 20, h: H - 16 };
    ctx.fillStyle = '#050506'; ctx.fillRect(P.x - 3, P.y - 3, P.w + 6, P.h + 6);
    ctx.fillStyle = '#8a8577'; ctx.fillRect(P.x - 1, P.y - 1, P.w + 2, P.h + 2);
    ctx.fillStyle = '#151514'; ctx.fillRect(P.x, P.y, P.w, P.h);
    ctx.fillStyle = '#0d0d0e'; ctx.fillRect(P.x + 3, P.y + 3, P.w - 6, P.h - 6);

    ctx.textAlign = 'center'; ctx.font = 'bold 11px monospace';
    ctx.fillStyle = '#401722'; ctx.fillText('CASULO DE REPOUSO', W / 2 + 1, P.y + 19); ctx.fillStyle = '#ece6d6'; ctx.fillText('CASULO DE REPOUSO', W / 2, P.y + 18);
    ctx.font = '7px monospace'; ctx.fillStyle = '#b9b3a2'; ctx.fillText(`Vida restaurada · progresso salvo · genes ${m.encontrados}/${GENES.length}`, W / 2, P.y + 28);
    ctx.fillStyle = '#6e3a40'; ctx.fillRect(P.x + 14, P.y + 32, P.w - 28, 1);
    // fechar (toque)
    this._fechar = { x: P.x + P.w - 26, y: P.y + 6, w: 18, h: 14 };
    ctx.fillStyle = '#2a1a1d'; ctx.fillRect(this._fechar.x, this._fechar.y, 18, 14); ctx.fillStyle = '#8e5a58'; ctx.fillRect(this._fechar.x, this._fechar.y, 18, 2);
    ctx.font = 'bold 9px monospace'; ctx.fillStyle = '#ece6d6'; ctx.fillText('X', this._fechar.x + 9, this._fechar.y + 11);

    // encaixes: um quadradinho por encaixe, preenchido com a cor do gene que o ocupa
    ctx.textAlign = 'left'; ctx.font = 'bold 7px monospace'; ctx.fillStyle = '#cfc9b8'; ctx.fillText('ENCAIXES', P.x + 12, P.y + 46);
    const ocupados = []; for (const id of pr.genesEquipados) { const g = GENES.find((x) => x.id === id); for (let k = 0; k < (g?.custo || 0); k++) ocupados.push(g.cor); }
    for (let i = 0; i < pr.encaixes; i++) {
      const x = P.x + 62 + i * 13; const y = P.y + 39;
      ctx.fillStyle = '#050505'; ctx.fillRect(x - 1, y - 1, 12, 10); ctx.fillStyle = ocupados[i] || '#121211'; ctx.fillRect(x, y, 10, 8);
      if (ocupados[i]) { ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.fillRect(x + 1, y + 1, 8, 1); }
    }
    ctx.textAlign = 'right'; ctx.fillStyle = '#b9b3a2'; ctx.font = '7px monospace'; ctx.fillText(`${pr.encaixesEmUso}/${pr.encaixes} em uso`, P.x + P.w - 12, P.y + 46);

    // grade 5×3 com os 15 espaços
    const CW = 44; const CH = 32; const G = 4; const gx = Math.round((W - (COLUNAS * CW + (COLUNAS - 1) * G)) / 2); const gy = P.y + 54;
    this._rects = [];
    GENES.forEach((g, i) => {
      const x = gx + (i % COLUNAS) * (CW + G); const y = gy + Math.floor(i / COLUNAS) * (CH + G);
      const obtido = pr.genes.has(g.id); const equipado = pr.genesEquipados.includes(g.id); const sel = i === m.cursor;
      ctx.fillStyle = equipado ? '#ffe69a' : obtido ? '#8a8577' : '#2a2926'; ctx.fillRect(x - 1, y - 1, CW + 2, CH + 2);
      ctx.fillStyle = obtido ? '#1a1917' : '#090909'; ctx.fillRect(x, y, CW, CH);
      if (obtido) { ctx.fillStyle = rgba(g.cor, equipado ? 0.22 : 0.1); ctx.fillRect(x + 2, y + 2, CW - 4, CH - 4); }
      if (obtido) drawGeneIcon(ctx, g.cor, x + CW / 2, y + CH / 2 - 2, 18, agora, { brilho: equipado ? 1 : 0, apagado: false });
      else { ctx.textAlign = 'center'; ctx.font = 'bold 14px monospace'; ctx.fillStyle = '#4a463e'; ctx.fillText('?', x + CW / 2, y + CH / 2 + 5); }
      if (obtido) { for (let k = 0; k < g.custo; k++) { ctx.fillStyle = equipado ? '#ffe69a' : '#b9b3a2'; ctx.fillRect(x + 4 + k * 5, y + CH - 6, 3, 3); } }   // custo em encaixes
      if (equipado) { ctx.fillStyle = '#ffe69a'; ctx.fillRect(x + CW - 8, y + 3, 5, 5); ctx.fillStyle = '#5a4a14'; ctx.fillRect(x + CW - 7, y + 4, 3, 3); }
      if (sel) { const pulso = 0.5 + 0.5 * Math.sin(agora * 7); ctx.strokeStyle = pulso > 0.45 ? '#ffffff' : '#ece6d6'; ctx.lineWidth = 2; ctx.strokeRect(x - 2, y - 2, CW + 4, CH + 4); }
      this._rects.push({ x, y, w: CW, h: CH });
    });

    // descrição do gene sob o cursor
    const iy = gy + LINHAS * (CH + G) + 2; const g = m.gene; const ih = P.y + P.h - 20 - iy;
    ctx.fillStyle = '#050505'; ctx.fillRect(P.x + 10, iy, P.w - 20, ih); ctx.fillStyle = '#242321'; ctx.fillRect(P.x + 11, iy + 1, P.w - 22, ih - 2); ctx.fillStyle = '#0d0d0e'; ctx.fillRect(P.x + 12, iy + 2, P.w - 24, ih - 4);
    ctx.textAlign = 'left'; ctx.font = 'bold 9px monospace'; ctx.fillStyle = m.obtido ? '#ece6d6' : '#8f8a7c'; ctx.fillText(m.obtido ? g.nome : (g.implementado ? '???' : `Espaço ${g.slot}`), P.x + 18, iy + 13);
    if (m.obtido) { ctx.textAlign = 'right'; ctx.font = '7px monospace'; ctx.fillStyle = '#b9b3a2'; ctx.fillText(`custo ${g.custo} ${g.custo > 1 ? 'encaixes' : 'encaixe'}${m.equipado ? ' · EQUIPADO' : ''}`, P.x + P.w - 18, iy + 12); }
    ctx.textAlign = 'left'; ctx.font = '7px monospace'; ctx.fillStyle = '#cfc9b8';
    const texto = m.obtido ? g.desc : (g.implementado ? 'Um gene deste tipo ainda está escondido em algum lugar do corpo do deus.' : 'Este espaço do genoma ainda está vazio.');
    this._quebrar(ctx, texto, P.w - 44).slice(0, 3).forEach((l, k) => ctx.fillText(l, P.x + 18, iy + 24 + k * 9));
    if (m.mensagem) { ctx.fillStyle = /equipado|removido/.test(m.mensagem) ? '#ece6d6' : '#ffb59b'; ctx.fillText(m.mensagem, P.x + 18, iy + ih - 5); }

    ctx.textAlign = 'center'; ctx.font = '7px monospace'; ctx.fillStyle = '#b9b3a2';
    ctx.fillText('SETAS MOVEM · ENTER EQUIPA · ESC FECHA · TOQUE 2× EQUIPA', W / 2, P.y + P.h - 8);
    ctx.restore();
  }
}
