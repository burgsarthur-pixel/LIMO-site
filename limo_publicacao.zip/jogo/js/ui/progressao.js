// =====================================================================
// PROGRESSÃO E QUALIDADE DE VIDA v1.37 — lógica pura (sem DOM), testável em Node.
//   itensDaSala / resumoDoMundo   o que já foi pego e o que resta (só conta salas JÁ VISITADAS: sem spoiler)
//   passagensDaHabilidade         quais passagens já vistas a nova habilidade abre
//   formatarTempo                 "1h 05min" / "12 min"
// =====================================================================
import { chaveItem } from '../core/progress.js';
import { checkRequirement, normalizeRequires } from '../entities/abilities.js';

/** Itens PERMANENTES: mutação, fragmento de carne (vida), bulbo de encaixe e gene. */
export const TIPOS_PERMANENTES = ['mutation', 'vida', 'encaixe', 'gene'];

export function itemColetado(progress, salaId, e) {
  return e.type === 'gene' ? !!progress.genes?.has(e.gene) : !!progress.collected?.has(chaveItem(salaId, e.id));
}

/** {total, coletados, restantes[]} de uma sala (sem olhar se foi visitada). */
export function itensDaSala(d, progress) {
  const itens = (d.entities || []).filter((e) => TIPOS_PERMANENTES.includes(e.type));
  const restantes = itens.filter((e) => !itemColetado(progress, d.id, e));
  return { total: itens.length, coletados: itens.length - restantes.length, restantes };
}

/** Panorama do mundo. Os totais só incluem salas visitadas; `salasNaoVisitadas` avisa que ainda há mais por descobrir. */
export function resumoDoMundo(world, progress) {
  const ids = world.ids(); const visitadas = ids.filter((id) => progress.visited?.has(id));
  const porSala = {}; const por = { vida: [0, 0], encaixe: [0, 0], mutation: [0, 0], gene: [0, 0] }; const porBioma = {};
  for (const id of ids) {
    const d = world.get(id); const vis = visitadas.includes(id); const it = itensDaSala(d, progress);
    const b = (porBioma[d.biome] ||= { salas: 0, visitadas: 0, itens: 0, coletados: 0 });
    b.salas++; if (vis) { b.visitadas++; b.itens += it.total; b.coletados += it.coletados; }
    porSala[id] = { visitada: vis, ...it, completa: vis && it.restantes.length === 0 };
    if (!vis) continue;
    for (const e of d.entities || []) if (por[e.type]) { por[e.type][1]++; if (itemColetado(progress, id, e)) por[e.type][0]++; }
  }
  const soma = Object.values(porSala).filter((s) => s.visitada);
  return {
    salas: { visitadas: visitadas.length, total: ids.length }, salasNaoVisitadas: ids.length - visitadas.length,
    itens: { coletados: soma.reduce((s, x) => s + x.coletados, 0), total: soma.reduce((s, x) => s + x.total, 0) },
    por, porSala, porBioma,
  };
}

/** Passagens já VISTAS (seladas) cujo requisito passa a ser cumprido por `habilidade` — o que a nova mutação abre agora. */
export function passagensDaHabilidade(world, progress, habilidade) {
  const antes = { ...progress.abilities, [habilidade]: false }; const out = [];
  for (const chave of progress.blockedFound || []) {
    const [salaId, conId] = chave.split(':'); const d = world.get(salaId); const c = d?.connections?.find((x) => x.id === conId); if (!c) continue;
    const req = normalizeRequires(c.requires); if (!req.length) continue;
    if (!checkRequirement(antes, c.requires).ok && checkRequirement(progress.abilities, c.requires).ok) out.push({ sala: d.name || salaId, id: conId });
  }
  return out;
}

export function formatarTempo(segundos = 0) {
  const m = Math.floor(Math.max(0, segundos) / 60); const h = Math.floor(m / 60);
  return h > 0 ? `${h}h ${String(m % 60).padStart(2, '0')}min` : `${m} min`;
}
