// =====================================================================
// CARTÃO DE HISTÓRIA NO CANVAS
// Revelações de chefe e capítulos ficam no quadro do jogo, não na viewport.
// =====================================================================
import { COR, FONTE, texto, divisor, painel, seta } from './hk-canvas.js';

export class CanvasStoryCard {
  constructor({ canvas, renderer, config }) {
    this.canvas = canvas;
    this.renderer = renderer;
    this.config = config;
    this.open = false;
    this.card = null;
    this.onClose = null;
    this._onPointerDown = (event) => this._pointerDown(event);
    this._onKeyDown = (event) => this._keyDown(event);
    canvas.addEventListener('pointerdown', this._onPointerDown);
    window.addEventListener('keydown', this._onKeyDown);
  }

  show(card, onClose) {
    this.card = card || {};
    this.onClose = onClose;
    this.open = true;
    this.canvas.setAttribute('aria-label', `História: ${this.card.titulo || ''}. Toque ou pressione Enter para continuar.`);
  }

  close() {
    if (!this.open) return;
    const done = this.onClose;
    this.open = false;
    this.card = null;
    this.onClose = null;
    this.canvas.setAttribute('aria-label', 'Área do jogo LIMO');
    done?.();
  }

  _keyDown(event) {
    if (!this.open || event.repeat) return;
    if (!['Enter', 'Space', 'Escape'].includes(event.code)) return;
    event.preventDefault();
    this.close();
  }

  _pointerDown(event) {
    if (!this.open) return;
    event.preventDefault();
    this.close();
  }

  _wrap(ctx, text, maxWidth) {
    const words = String(text || '').split(/\s+/).filter(Boolean);
    const lines = []; let line = '';
    for (const word of words) {
      const next = line ? `${line} ${word}` : word;
      if (line && ctx.measureText(next).width > maxWidth) { lines.push(line); line = word; }
      else line = next;
    }
    if (line) lines.push(line);
    return lines;
  }

  draw(ctx) {
    if (!this.open || !this.card) return;
    const { internalWidth: W, internalHeight: H } = this.config.render;
    const card = this.card;
    const panel = { x: 22, y: 31, w: W - 44, h: H - 62 };
    const maxTextWidth = panel.w - 34;

    ctx.save();
    ctx.fillStyle = 'rgba(2, 2, 3, 0.62)'; ctx.fillRect(0, 0, W, H);
    painel(ctx, panel.x, panel.y, panel.w, panel.h);

    texto(ctx, String(card.tema || 'MEMÓRIA').toUpperCase(), W / 2, panel.y + 21, { tam: 7, cor: COR.carne, espaco: 3, sombra: false });
    texto(ctx, card.titulo || '', W / 2, panel.y + 42, { tam: 13, cor: COR.osso, espaco: 2, brilho: 4 });
    divisor(ctx, W / 2, panel.y + 50, panel.w - 56);

    let y = panel.y + 67;
    ctx.font = `8px ${FONTE}`;
    for (const paragraph of card.linhas || []) {
      for (const line of this._wrap(ctx, paragraph, maxTextWidth)) { texto(ctx, line, W / 2, y, { tam: 8, cor: COR.osso2, espaco: 0.3 }); y += 12; }
      y += 2;
    }
    if (card.frase) {
      ctx.font = `italic 8px ${FONTE}`;
      for (const line of this._wrap(ctx, `“${card.frase}”`, maxTextWidth)) { texto(ctx, line, W / 2, y, { tam: 8, cor: '#d9a7a1', estilo: 'italic', espaco: 0.3 }); y += 11; }
    }
    // chamada discreta: seta + texto que pulsam devagar (leitura ocupa o centro)
    const pulso = 0.6 + 0.4 * Math.sin(performance.now() / 420);
    const cy = panel.y + panel.h - 13;
    ctx.globalAlpha = pulso;
    const larg = texto(ctx, 'CONTINUAR', W / 2, cy, { tam: 8, cor: COR.osso, espaco: 3, sombra: false });
    seta(ctx, W / 2 - larg / 2 - 22, cy - 3, 1, COR.osso); seta(ctx, W / 2 + larg / 2 + 22, cy - 3, -1, COR.osso);
    ctx.globalAlpha = 1;
    ctx.restore();
  }
}
