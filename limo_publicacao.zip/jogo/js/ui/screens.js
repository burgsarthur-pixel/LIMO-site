// =====================================================================
// TELAS: pausa, derrota, erro, carregando e tela cheia.
// =====================================================================

import { criarArteDoTitulo } from './title-art.js';

export function createScreens(doc, win = (typeof window !== 'undefined' ? window : null)) {
  const $ = (id) => doc.getElementById(id);
  const mostrar = (el, sim) => el.classList.toggle('hidden', !sim);
  let pauseCanvas = null;
  let storyCanvas = null;
  let arteTitulo = null;   // fundo da tela inicial (carne, ossos e vegetação); criado na primeira vez que a tela aparece

  return {
    setCanvasPauseMenu(menu) { pauseCanvas = menu; mostrar($('overlay-pause'), false); },
    setCanvasStoryCard(story) { storyCanvas = story; mostrar($('overlay-story'), false); },
    setPause(ligado) {
      if (pauseCanvas) { pauseCanvas.setOpen(ligado); mostrar($('overlay-pause'), false); }
      else mostrar($('overlay-pause'), ligado);
    },
    showDefeat(ligado) { mostrar($('overlay-defeat'), ligado); },
    /** Finais: escolhe entre Vigília, Despertar e Fusão; mostra o texto e chama aoFechar. */
    /** A DECISÃO: escolha entre os finais (cartões com lema) → epílogo com o balanço da jornada. */
    showEnding(intro, finais, aoFechar, resumo = '', aoTitulo = null) {
      let el = $('overlay-ending');
      if (!el) { el = doc.createElement('div'); el.id = 'overlay-ending'; el.className = 'overlay defeat ending'; doc.body.appendChild(el); }
      const criar = (tag, txt, cls, pai = el) => { const n = doc.createElement(tag); n.textContent = txt; if (cls) n.className = cls; pai.appendChild(n); return n; };
      const botao = (txt, fn, pai = el) => { const b = criar('button', txt, 'menu-btn', pai); b.type = 'button'; b.onclick = fn; return b; };
      mostrar($('overlay-pause'), false); el.style.background = 'rgba(14,5,8,0.97)'; el.style.zIndex = 50; el.innerHTML = '';
      criar('p', 'CAPÍTULO 4', 'story-tema'); criar('h2', 'A DECISÃO'); criar('p', intro, 'ending-intro');
      for (const f of finais) {
        const c = criar('div', '', 'ending-card'); criar('b', f.nome, '', c); criar('small', f.lema || '', '', c);
        c.onclick = () => {
          el.innerHTML = ''; criar('p', 'FIM', 'story-tema'); criar('h2', f.nome); criar('p', f.texto, 'ending-texto');
          if (resumo) criar('p', resumo, 'ending-resumo');
          botao('Continuar explorando', () => { mostrar(el, false); aoFechar?.(f); });
          if (aoTitulo) botao('Voltar ao título', () => { mostrar(el, false); aoFechar?.(f); aoTitulo(); });
        };
      }
      mostrar(el, true);
    },
    showTitle(ligado) {
      mostrar($('overlay-title'), ligado);
      if (!arteTitulo && ligado) { try { arteTitulo = criarArteDoTitulo(doc, win); } catch (e) { arteTitulo = null; } }   // a arte é enfeite: se falhar, o menu continua funcionando
      arteTitulo?.setAtivo(ligado);
    },
    /** Cartão de história {tema, titulo, linhas[], frase?}; chama aoFechar ao tocar em Continuar (ou Enter/Espaço/Esc). */
    showStory(card, aoFechar) {
      if (storyCanvas) { storyCanvas.show(card, aoFechar); return; }
      const ov = $('overlay-story'); if (!ov) { aoFechar?.(); return; }
      $('story-tema').textContent = card.tema || ''; $('story-titulo').textContent = card.titulo || '';
      const L = $('story-linhas'); L.replaceChildren(...(card.linhas || []).map((t) => { const p = doc.createElement('p'); p.textContent = t; return p; }));
      $('story-frase').textContent = card.frase ? `“${card.frase}”` : '';
      mostrar(ov, true); let fechado = false;
      const fechar = () => { if (fechado) return; fechado = true; mostrar(ov, false); $('btn-story').removeEventListener('click', fechar); win?.removeEventListener('keydown', tecla); aoFechar?.(); };
      const tecla = (e) => { if (['Enter', 'Space', 'Escape'].includes(e.code)) { e.preventDefault(); fechar(); } };
      $('btn-story').addEventListener('click', fechar); win?.addEventListener('keydown', tecla); $('btn-story').focus?.();
    },

    
    /** Estado da tela inicial: se dá para Continuar e a mensagem sobre o salvamento (ou erro). */
    configurarTitulo({ podeContinuar, mensagem = '', resumo = '' }) {
      const btnContinuar = $('btn-continuar');
      if (btnContinuar) {
        btnContinuar.disabled = !podeContinuar; 
        btnContinuar.classList.toggle('desabilitado', !podeContinuar);
      }
      const titleStatus = $('title-status');
      if (titleStatus) {
        titleStatus.textContent = mensagem || resumo; 
        titleStatus.classList.toggle('aviso', !!mensagem);
      }
    },

    /** Pergunta Sim/Cancelar sem usar window.confirm (que é feio e ruim no celular). Devolve Promise<boolean>. */
    confirmar(texto, textoSim = 'Sim') {
      return new Promise((resolve) => {
        $('confirm-text').textContent = texto; 
        $('btn-confirm-sim').textContent = textoSim; 
        mostrar($('overlay-confirm'), true);
        
        const fim = (v) => { 
          mostrar($('overlay-confirm'), false); 
          $('btn-confirm-sim').onclick = null; 
          $('btn-confirm-nao').onclick = null; 
          resolve(v); 
        };
        
        $('btn-confirm-sim').onclick = () => fim(true); 
        $('btn-confirm-nao').onclick = () => fim(false);
      });
    },

    setLoading(ligado, texto) { 
      mostrar($('overlay-loading'), ligado); 
      if (texto && $('loading-text')) $('loading-text').textContent = texto; 
    },

    showError(mensagem, detalhes = []) {
      $('error-message').textContent = mensagem;
      $('error-details').textContent = detalhes.slice(0, 8).join('\n');
      $('error-details').classList.toggle('hidden', detalhes.length === 0);
      mostrar($('overlay-error'), true);
      mostrar($('overlay-loading'), false);
    },

    /** Tela cheia + tenta travar em paisagem (Android/Chrome). Falhas são ignoradas com segurança. */
    async toggleFullscreen() {
      try {
        const raiz = doc.documentElement;
        if (!doc.fullscreenElement) {
          await raiz.requestFullscreen?.();
          try { await win?.screen?.orientation?.lock?.('landscape'); } catch (e) { /* nem todo navegador permite */ }
        } else await doc.exitFullscreen?.();
      } catch (e) { /* ignorado: tela cheia é opcional */ }
    },
  };
}
