// =====================================================================
// LINGUAGEM VISUAL DOS MENUS EM CANVAS (pausa, história, diálogo…)
// Mesma identidade do CSS (css/tema-hk.css): osso sobre breu, filete fino,
// ornamento discreto, nada de moldura grossa ou botão em relevo.
// O canvas do jogo tem 320×240 lógicos; por isso os traços são de 1 px.
// =====================================================================

export const COR = Object.freeze({
  osso: '#ece6d6',
  osso2: '#b9b3a2',
  osso3: '#7b766a',
  breu: '#060607',
  carne: '#c8636c',
  ambar: '#e0c88a',
});

export const FONTE = '"Cinzel", "Trajan Pro 3", "Trajan Pro", "Cormorant Garamond", "Palatino Linotype", "Book Antiqua", Georgia, "Times New Roman", serif';

/** Texto com espaçamento entre letras (a propriedade nativa letterSpacing não existe em todo WebView). */
export function texto(ctx, str, x, y, { tam = 9, cor = COR.osso, alinhar = 'center', espaco = 1, peso = '400', estilo = '', sombra = true, brilho = 0 } = {}) {
  const s = String(str);
  ctx.save();
  ctx.font = `${estilo ? `${estilo} ` : ''}${peso} ${tam}px ${FONTE}`;
  ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
  const larguras = [...s].map((c) => ctx.measureText(c).width);
  const total = larguras.reduce((a, b) => a + b, 0) + espaco * Math.max(0, s.length - 1);
  let cx = alinhar === 'center' ? x - total / 2 : alinhar === 'right' ? x - total : x;
  if (brilho > 0) { ctx.shadowColor = 'rgba(255,255,255,.65)'; ctx.shadowBlur = brilho; }
  [...s].forEach((c, i) => {
    if (sombra && !brilho) { ctx.fillStyle = 'rgba(0,0,0,.85)'; ctx.fillText(c, cx + 1, y + 1); }
    ctx.fillStyle = cor; ctx.fillText(c, cx, y); cx += larguras[i] + espaco;
  });
  ctx.restore();
  return total;
}

/** Mede o texto com o mesmo espaçamento de `texto`. */
export function medir(ctx, str, { tam = 9, espaco = 1, peso = '400', estilo = '' } = {}) {
  ctx.save(); ctx.font = `${estilo ? `${estilo} ` : ''}${peso} ${tam}px ${FONTE}`;
  const w = [...String(str)].reduce((a, c) => a + ctx.measureText(c).width, 0) + espaco * Math.max(0, String(str).length - 1);
  ctx.restore(); return w;
}

/** Filete horizontal que some nas pontas, com um losango no meio. */
export function divisor(ctx, cx, y, largura, { cor = COR.osso2, losango = true } = {}) {
  ctx.save();
  const g = ctx.createLinearGradient?.(cx - largura / 2, 0, cx + largura / 2, 0);
  if (g) { g.addColorStop(0, 'rgba(185,179,162,0)'); g.addColorStop(0.25, 'rgba(185,179,162,.7)'); g.addColorStop(0.5, 'rgba(236,230,214,.9)'); g.addColorStop(0.75, 'rgba(185,179,162,.7)'); g.addColorStop(1, 'rgba(185,179,162,0)'); }
  ctx.fillStyle = g || 'rgba(185,179,162,.6)'; ctx.fillRect(Math.round(cx - largura / 2), Math.round(y), Math.round(largura), 1);
  if (losango) {
    ctx.fillStyle = COR.breu; ctx.fillRect(Math.round(cx) - 4, Math.round(y) - 3, 8, 7);
    ctx.fillStyle = cor; ctx.beginPath(); ctx.moveTo(cx, y - 3); ctx.lineTo(cx + 3.5, y + 0.5); ctx.lineTo(cx, y + 4); ctx.lineTo(cx - 3.5, y + 0.5); ctx.closePath(); ctx.fill();
    ctx.fillStyle = COR.breu; ctx.fillRect(Math.round(cx) - 1, Math.round(y) - 0, 2, 1);
  }
  ctx.restore();
}

/** Painel escuro com filete fino, cantos chanfrados e um pequeno losango no centro das bordas. */
export function painel(ctx, x, y, w, h, { opacidade = 0.94, chanfro = 5 } = {}) {
  ctx.save();
  const caminho = (i) => {
    const a = x + i; const b = y + i; const c = x + w - i; const d = y + h - i; const k = Math.max(1, chanfro - i);
    ctx.beginPath(); ctx.moveTo(a + k, b); ctx.lineTo(c - k, b); ctx.lineTo(c, b + k); ctx.lineTo(c, d - k); ctx.lineTo(c - k, d); ctx.lineTo(a + k, d); ctx.lineTo(a, d - k); ctx.lineTo(a, b + k); ctx.closePath();
  };
  const g = ctx.createLinearGradient?.(0, y, 0, y + h);   // (contextos simplificados de teste não têm degradê)
  if (g) { g.addColorStop(0, `rgba(16,15,15,${opacidade})`); g.addColorStop(1, `rgba(5,5,6,${opacidade})`); }
  caminho(0.5); ctx.fillStyle = g || `rgba(8,8,9,${opacidade})`; ctx.fill();
  ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(185,179,162,.62)'; caminho(0.5); ctx.stroke();
  ctx.strokeStyle = 'rgba(185,179,162,.16)'; caminho(3.5); ctx.stroke();
  ctx.fillStyle = COR.osso2;
  for (const [px, py] of [[x + w / 2, y + 0.5], [x + w / 2, y + h - 0.5]]) { ctx.beginPath(); ctx.moveTo(px, py - 2.5); ctx.lineTo(px + 2.5, py); ctx.lineTo(px, py + 2.5); ctx.lineTo(px - 2.5, py); ctx.closePath(); ctx.fill(); }
  ctx.restore();
}

/** Seta ornamental em forma de folha, apontando para o texto (lado = +1 à esquerda do texto, −1 à direita). */
export function seta(ctx, x, y, lado = 1, cor = COR.osso) {
  ctx.save(); ctx.translate(x, y); ctx.scale(lado, 1);
  ctx.strokeStyle = cor; ctx.fillStyle = cor; ctx.lineWidth = 1; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(2, 0); ctx.quadraticCurveTo(6, -3.2, 12, 0); ctx.quadraticCurveTo(6, 3.2, 2, 0); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(12, 0); ctx.lineTo(17, 0); ctx.moveTo(15, -2); ctx.lineTo(17.5, 0); ctx.lineTo(15, 2); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, 0.9, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

/** Item de menu em texto: apagado quando solto; claro, com brilho e duas setas quando selecionado. */
export function itemDeMenu(ctx, rotulo, cx, y, { selecionado = false, perigo = false, tam = 10, largura = 150 } = {}) {
  const cor = selecionado ? (perigo ? '#f0b4ae' : '#f7f2e4') : (perigo ? '#a8736f' : COR.osso3);
  const w = texto(ctx, rotulo, cx, y, { tam, cor, espaco: 1.6, brilho: selecionado ? 6 : 0 });
  if (selecionado) { const meio = Math.max(w / 2 + 8, 24); seta(ctx, cx - meio - 18, y - tam * 0.32, 1, cor); seta(ctx, cx + meio + 18, y - tam * 0.32, -1, cor); }
  void largura;
  return w;
}

/** Quebra o texto em linhas que cabem em `max` pixels (usa a fonte atual do contexto). */
export function quebrar(ctx, str, max) {
  const palavras = String(str || '').split(/\s+/).filter(Boolean); const linhas = []; let linha = '';
  for (const p of palavras) { const t = linha ? `${linha} ${p}` : p; if (linha && ctx.measureText(t).width > max) { linhas.push(linha); linha = p; } else linha = t; }
  if (linha) linhas.push(linha); return linhas;
}
