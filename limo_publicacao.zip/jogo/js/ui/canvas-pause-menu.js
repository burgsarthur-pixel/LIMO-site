// =====================================================================
// MENU DE PAUSA NO CANVAS
// A interface usa a mesma resolução lógica 320×240 da cena: nunca vaza
// para a área dos controles nem depende da altura da janela do celular.
// =====================================================================
import { COR, texto, divisor, painel, itemDeMenu } from './hk-canvas.js';

export class CanvasPauseMenu {
  constructor({ canvas, renderer, config, actions = {} }) {
    this.canvas = canvas;
    this.renderer = renderer;
    this.config = config;
    this.actions = actions;
    this.open = false;
    this.page = 0;
    this.selected = 0;
    this._rects = [];
    this._onPointerDown = (event) => this._pointerDown(event);
    this._onKeyDown = (event) => this._keyDown(event);
    canvas.addEventListener('pointerdown', this._onPointerDown);
    window.addEventListener('keydown', this._onKeyDown);
  }

  setOpen(open) {
    this.open = !!open;
    this.page = 0;
    this.selected = 0;
    this.canvas.setAttribute('aria-label', this.open ? 'Menu de pausa aberto. Use setas e Enter.' : 'Área do jogo LIMO');
  }

  _buttons() {
    const first = [
      { label: 'CONTINUAR', action: 'resume' },
      { label: 'SALVAR PROGRESSO', action: 'save' },
      { label: 'REINICIAR SALA', action: 'restart' },
      { label: 'MAPA', action: 'map' },
      { label: 'CATÁLOGO', action: 'catalog' },
      { label: 'MAIS OPÇÕES', action: 'more' },
    ];
    const more = [
      { label: 'EXPORTAR PROGRESSO', action: 'export' },
      { label: 'IMPORTAR PROGRESSO', action: 'import' },
      { label: 'MODO EDITOR', action: 'editor' },
      { label: 'REINICIAR PROGRESSO', action: 'reset', danger: true },
    ];
    if (this.actions.dev) more.push({ label: 'MODO DESENVOLVEDOR', action: 'dev' });
    more.push({ label: 'VOLTAR', action: 'back' });
    return this.page ? more : first;
  }

  _activate(button) {
    if (!button) return;
    if (button.action === 'more') { this.page = 1; this.selected = 0; return; }
    if (button.action === 'back') { this.page = 0; this.selected = 0; return; }
    this.actions[button.action]?.();
  }

  _keyDown(event) {
    if (!this.open || event.repeat) return;
    const buttons = this._buttons();
    if (['ArrowUp', 'KeyW'].includes(event.code)) {
      this.selected = (this.selected + buttons.length - 1) % buttons.length;
    } else if (['ArrowDown', 'KeyS'].includes(event.code)) {
      this.selected = (this.selected + 1) % buttons.length;
    } else if (['Enter', 'Space'].includes(event.code)) {
      this._activate(buttons[this.selected]);
    } else if (event.code === 'Escape') {
      this.actions.resume?.();
    } else return;
    event.preventDefault();
  }

  _pointerDown(event) {
    if (!this.open) return;
    const rect = this.canvas.getBoundingClientRect();
    const W = this.config.render.internalWidth;
    const H = this.config.render.internalHeight;
    const x = (event.clientX - rect.left) * W / rect.width;
    const y = (event.clientY - rect.top) * H / rect.height;
    const index = this._rects.findIndex((r) => x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h);
    if (index < 0) return;
    event.preventDefault();
    this.selected = index;
    this._activate(this._buttons()[index]);
  }

  draw(ctx) {
    if (!this.open) return;
    const { internalWidth: W, internalHeight: H } = this.config.render;
    const buttons = this._buttons();
    this.selected = Math.min(this.selected, Math.max(0, buttons.length - 1));
    const painelBox = { x: 62, y: 14, w: W - 124, h: H - 28 };
    const topo = painelBox.y + 44; const livre = painelBox.h - 44 - 30;   // entre o título e o rodapé
    const passo = Math.max(17, Math.min(26, Math.floor(livre / buttons.length)));   // item alto = fácil de tocar no celular
    const startY = Math.round(topo + Math.max(0, (livre - passo * buttons.length) / 2));

    ctx.save();
    ctx.fillStyle = 'rgba(2, 2, 3, 0.72)'; ctx.fillRect(0, 0, W, H);
    painel(ctx, painelBox.x, painelBox.y, painelBox.w, painelBox.h);
    texto(ctx, this.page ? 'OPÇÕES' : 'PAUSADO', W / 2, painelBox.y + 27, { tam: 14, cor: COR.osso, espaco: 4, brilho: 5 });
    divisor(ctx, W / 2, painelBox.y + 36, painelBox.w - 44);

    this._rects = [];
    buttons.forEach((button, index) => {
      const y = startY + index * passo;
      itemDeMenu(ctx, button.label, W / 2, y + Math.round(passo / 2) + 3, { selecionado: index === this.selected, perigo: !!button.danger, tam: buttons.length > 5 ? 9 : 10 });
      this._rects.push({ x: painelBox.x + 10, y: y, w: painelBox.w - 20, h: passo });   // a área de toque ocupa a linha inteira
    });
    const info = this.actions.info?.();
    if (info) texto(ctx, info.length > 52 ? `${info.slice(0, 51)}…` : info, W / 2, painelBox.y + painelBox.h - 20, { tam: 7, cor: COR.osso3, espaco: 0.6 });
    texto(ctx, 'TOQUE · SETAS + ENTER · ESC VOLTA', W / 2, painelBox.y + painelBox.h - 10, { tam: 6, cor: COR.osso3, espaco: 1.2, sombra: false });
    ctx.restore();
  }
}
