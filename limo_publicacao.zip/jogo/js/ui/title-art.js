// =====================================================================
// TELA INICIAL — fundo procedural em camadas (carne, ossos e vegetação)
// Inspirada na composição das telas de título de metroidvanias sombrios:
// um feixe de luz pálido ao centro, massas escuras nas bordas e poeira no ar.
//
// · Nada de arquivos de imagem: tudo é desenhado uma vez (por tamanho de tela)
//   em 3 canvases e depois só se move por CSS (barato em celular).
// · Só a poeira (partículas) é animada por requestAnimationFrame, e apenas
//   enquanto a tela inicial está visível.
// · Também cuida da navegação do menu por teclado/gamepad (setas + Enter).
// =====================================================================

/** Gerador pseudoaleatório determinístico (a arte é sempre a mesma). */
function criarRng(semente) {
  let a = semente >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PI = Math.PI;
const bez = (p0, p1, p2, t) => {   // ponto de uma curva quadrática
  const u = 1 - t;
  return { x: u * u * p0.x + 2 * u * t * p1.x + t * t * p2.x, y: u * u * p0.y + 2 * u * t * p1.y + t * t * p2.y };
};
const amostrar = (p0, p1, p2, n = 24) => Array.from({ length: n + 1 }, (_, i) => bez(p0, p1, p2, i / n));

// ---------------------------------------------------------------------
// Peças básicas de desenho
// ---------------------------------------------------------------------

/** Faixa afunilada ao longo de uma polilinha (osso, raiz, tendão). */
function faixa(ctx, pts, w0, w1, preenchimento) {
  const esq = []; const dir = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[Math.max(0, i - 1)]; const b = pts[Math.min(pts.length - 1, i + 1)];
    const ang = Math.atan2(b.y - a.y, b.x - a.x) + PI / 2;
    const k = i / (pts.length - 1); const w = (w0 + (w1 - w0) * k) / 2;
    esq.push({ x: pts[i].x + Math.cos(ang) * w, y: pts[i].y + Math.sin(ang) * w });
    dir.push({ x: pts[i].x - Math.cos(ang) * w, y: pts[i].y - Math.sin(ang) * w });
  }
  ctx.beginPath();
  ctx.moveTo(esq[0].x, esq[0].y);
  for (const p of esq) ctx.lineTo(p.x, p.y);
  for (let i = dir.length - 1; i >= 0; i--) ctx.lineTo(dir[i].x, dir[i].y);
  ctx.closePath();
  ctx.fillStyle = preenchimento; ctx.fill();
  return { esq, dir };
}

/** Costela / osso longo: corpo afunilado, sombra num lado, brilho fosco no outro, junta nodosa na base. */
function osso(ctx, pts, largura, cores) {
  const { esq, dir } = faixa(ctx, pts, largura, largura * 0.28, cores.base);
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.strokeStyle = cores.sombra; ctx.lineWidth = Math.max(1, largura * 0.18);
  ctx.beginPath(); dir.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.stroke();
  ctx.strokeStyle = cores.luz; ctx.lineWidth = Math.max(1, largura * 0.1);
  ctx.beginPath(); esq.forEach((p, i) => { if (i > 1 && i < esq.length - 2) (i === 2 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)); }); ctx.stroke();
  const p0 = pts[0];
  ctx.fillStyle = cores.base; ctx.beginPath(); ctx.arc(p0.x, p0.y, largura * 0.62, 0, PI * 2); ctx.fill();
  ctx.fillStyle = cores.luz; ctx.globalAlpha = 0.5; ctx.beginPath(); ctx.arc(p0.x - largura * 0.14, p0.y - largura * 0.16, largura * 0.26, 0, PI * 2); ctx.fill(); ctx.globalAlpha = 1;
}

/** Vértebra: corpo arredondado + processo espinhoso + dois "ombros". */
function vertebra(ctx, x, y, r, cores) {
  ctx.fillStyle = cores.base;
  ctx.beginPath(); ctx.ellipse(x, y, r * 1.15, r * 0.78, 0, 0, PI * 2); ctx.fill();
  ctx.fillStyle = cores.sombra; ctx.beginPath(); ctx.ellipse(x + r * 0.15, y + r * 0.22, r * 1.0, r * 0.5, 0, 0, PI); ctx.fill();
  ctx.fillStyle = cores.base;
  ctx.beginPath(); ctx.moveTo(x - r * 0.35, y - r * 0.5); ctx.quadraticCurveTo(x - r * 0.1, y - r * 1.9, x + r * 0.5, y - r * 1.55); ctx.quadraticCurveTo(x + r * 0.15, y - r * 1.2, x + r * 0.3, y - r * 0.5); ctx.closePath(); ctx.fill();
  ctx.fillStyle = cores.luz; ctx.globalAlpha = 0.5; ctx.beginPath(); ctx.ellipse(x - r * 0.35, y - r * 0.25, r * 0.4, r * 0.18, -0.4, 0, PI * 2); ctx.fill(); ctx.globalAlpha = 1;
}

/** Folha com nervura central. */
function folha(ctx, x, y, comp, ang, larg, cor, nervura) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
  ctx.fillStyle = cor;
  ctx.beginPath(); ctx.moveTo(0, 0);
  ctx.bezierCurveTo(comp * 0.25, -larg, comp * 0.7, -larg * 0.85, comp, 0);
  ctx.bezierCurveTo(comp * 0.7, larg * 0.85, comp * 0.25, larg, 0, 0);
  ctx.fill();
  if (nervura) { ctx.strokeStyle = nervura; ctx.lineWidth = Math.max(0.6, larg * 0.07); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(comp * 0.95, 0); ctx.stroke(); }
  ctx.restore();
}

/** Samambaia: haste curva com folíolos que diminuem até a ponta. */
function samambaia(ctx, x, y, comp, ang, curva, cor, nervura, rng) {
  const p0 = { x, y };
  const p2 = { x: x + Math.cos(ang) * comp, y: y + Math.sin(ang) * comp };
  const p1 = { x: (p0.x + p2.x) / 2 + Math.cos(ang + PI / 2) * curva, y: (p0.y + p2.y) / 2 + Math.sin(ang + PI / 2) * curva };
  const pts = amostrar(p0, p1, p2, 26);
  ctx.strokeStyle = cor; ctx.lineWidth = Math.max(1.2, comp * 0.012); ctx.lineCap = 'round';
  ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.stroke();
  for (let i = 3; i < pts.length - 1; i++) {
    const k = i / pts.length; const a = pts[i - 1]; const b = pts[i + 1];
    const dir = Math.atan2(b.y - a.y, b.x - a.x);
    const tam = comp * 0.2 * Math.sin(Math.min(1, k * 1.25) * PI * 0.9 + 0.2) * (0.8 + rng() * 0.3);
    folha(ctx, pts[i].x, pts[i].y, tam, dir - 1.05, tam * 0.2, cor, nervura);
    folha(ctx, pts[i].x, pts[i].y, tam, dir + 1.05, tam * 0.2, cor, nervura);
  }
}

/** Trepadeira: caule que ondula e ramifica, com folhas e espinhos. */
function trepadeira(ctx, x, y, ang, comp, larg, prof, cores, rng) {
  const n = 18; const pts = [{ x, y }]; let a = ang;
  for (let i = 1; i <= n; i++) {
    a += (rng() - 0.5) * 0.55 + Math.sin(i * 0.7) * 0.06;
    pts.push({ x: pts[i - 1].x + Math.cos(a) * comp / n, y: pts[i - 1].y + Math.sin(a) * comp / n });
  }
  faixa(ctx, pts, larg, Math.max(0.8, larg * 0.25), cores.caule);
  for (let i = 3; i < n; i += 2) {
    const lado = i % 4 === 1 ? 1 : -1;
    const dir = Math.atan2(pts[i + 1].y - pts[i - 1].y, pts[i + 1].x - pts[i - 1].x);
    const tam = comp * (0.07 + rng() * 0.05);
    folha(ctx, pts[i].x, pts[i].y, tam, dir + lado * (0.9 + rng() * 0.5), tam * 0.38, cores.folha, cores.nervura);
    if (prof > 0 && i % 6 === 3) trepadeira(ctx, pts[i].x, pts[i].y, dir + lado * 0.9, comp * 0.5, larg * 0.5, prof - 1, cores, rng);
  }
  folha(ctx, pts[n].x, pts[n].y, comp * 0.09, a, comp * 0.035, cores.folha, cores.nervura);
}

/** Veias: caminhada aleatória que se bifurca. */
function veias(ctx, x, y, ang, comp, larg, prof, cor, rng) {
  ctx.strokeStyle = cor; ctx.lineWidth = larg; ctx.lineCap = 'round';
  let px = x; let py = y; let a = ang;
  ctx.beginPath(); ctx.moveTo(px, py);
  const passos = Math.max(4, Math.round(comp / 7));
  for (let i = 0; i < passos; i++) {
    a += (rng() - 0.5) * 0.7; px += Math.cos(a) * 7; py += Math.sin(a) * 7; ctx.lineTo(px, py);
    if (prof > 0 && rng() < 0.12) { ctx.stroke(); veias(ctx, px, py, a + (rng() < 0.5 ? -0.8 : 0.8), comp * 0.55, larg * 0.7, prof - 1, cor, rng); ctx.strokeStyle = cor; ctx.lineWidth = larg; ctx.beginPath(); ctx.moveTo(px, py); }
  }
  ctx.stroke();
}

/** Cortina de carne: pendurada do alto, borda inferior ondulada, veias e brilho úmido. */
function cortinaDeCarne(ctx, x, w, h, rng, cores) {
  const pts = []; const passos = 14;
  for (let i = 0; i <= passos; i++) {
    const k = i / passos; const dobra = Math.sin(k * PI * 3 + rng()) * 0.07 + (rng() - 0.5) * 0.06;
    pts.push({ x: x + w * k, y: h * (0.05 + 0.95 * Math.pow(Math.sin(k * PI), 0.72) * (0.55 + rng() * 0.45) + dobra) });
  }
  ctx.beginPath(); ctx.moveTo(x, -10);
  pts.forEach((p, i) => { if (i === 0) ctx.lineTo(p.x, p.y); else { const q = pts[i - 1]; ctx.quadraticCurveTo(q.x + (p.x - q.x) * 0.5, Math.max(q.y, p.y) + 14, p.x, p.y); } });
  ctx.lineTo(x + w, -10); ctx.closePath();
  const g = ctx.createLinearGradient(0, 0, 0, h * 1.05);
  g.addColorStop(0, cores.carneEscura); g.addColorStop(0.55, cores.carne); g.addColorStop(1, cores.carneClara);
  ctx.fillStyle = g; ctx.fill();
  ctx.save(); ctx.clip();
  for (let i = 0; i < 9; i++) veias(ctx, x + w * (0.08 + rng() * 0.84), -5, PI / 2 + (rng() - 0.5) * 0.7, h * (0.5 + rng() * 0.5), 1 + rng() * 1.8, 3, cores.veia, rng);
  ctx.strokeStyle = cores.brilho; ctx.lineWidth = 2; ctx.lineCap = 'round';
  for (let i = 0; i < 5; i++) { const bx = x + w * (0.1 + rng() * 0.8); const by = h * (0.15 + rng() * 0.45); ctx.globalAlpha = 0.25 + rng() * 0.2; ctx.beginPath(); ctx.moveTo(bx, by); ctx.quadraticCurveTo(bx + 8, by + h * 0.1, bx + 3, by + h * 0.2); ctx.stroke(); }
  ctx.globalAlpha = 1; ctx.restore();
  // gotas pendentes
  ctx.fillStyle = cores.carneClara;
  for (let i = 0; i < 4; i++) { const p = pts[2 + Math.floor(rng() * (pts.length - 4))]; ctx.beginPath(); ctx.ellipse(p.x, p.y + 10 + rng() * 12, 2.2, 5 + rng() * 4, 0, 0, PI * 2); ctx.fill(); }
}

/** Raiz que desce do teto (fibra grossa que se divide). */
function raizPendente(ctx, x, comp, larg, cor, rng) {
  const p0 = { x, y: -6 }; const p2 = { x: x + (rng() - 0.5) * comp * 0.5, y: comp };
  const p1 = { x: x + (rng() - 0.5) * comp * 0.7, y: comp * 0.5 };
  const pts = amostrar(p0, p1, p2, 24);
  faixa(ctx, pts, larg, larg * 0.2, cor);
  for (let i = 8; i < 20; i += 4) { const a = pts[i]; const b = pts[i + 1]; const ang = Math.atan2(b.y - a.y, b.x - a.x) + (i % 8 === 0 ? 0.7 : -0.7);
    faixa(ctx, amostrar(a, { x: a.x + Math.cos(ang) * comp * 0.12, y: a.y + Math.sin(ang) * comp * 0.12 + 8 }, { x: a.x + Math.cos(ang) * comp * 0.2, y: a.y + comp * 0.2 }, 10), larg * 0.4, 1, cor); }
}

// ---------------------------------------------------------------------
// As três camadas
// ---------------------------------------------------------------------
const PAL = {
  osso: { base: '#3b3832', sombra: '#16140f', luz: '#625d50' },
  ossoLonge: { base: '#47443c', sombra: '#1a1815', luz: '#6d685b' },
  flesh: { carneEscura: '#150709', carne: '#34121a', carneClara: '#4a1a23', veia: 'rgba(120,40,52,.5)', brilho: 'rgba(214,150,140,.42)' },
  mato: { caule: '#1b2a21', folha: '#1f3326', nervura: 'rgba(122,164,128,.30)' },
  matoPerto: { caule: '#06100b', folha: '#07130d', nervura: 'rgba(78,120,88,.16)' },
};

export function desenharCamadaLonge(ctx, W, H) {
  const rng = criarRng(7311);
  // costelas: duas "gaiolas" que entram pelas laterais e se curvam para dentro
  const gaiola = (lado) => {
    const sx = lado < 0 ? -W * 0.04 : W * 1.04;
    for (let i = 0; i < 6; i++) {
      const y0 = H * (0.08 + i * 0.17);
      const p0 = { x: sx, y: y0 };
      // as costelas se curvam para baixo e para dentro
      const alvo = { x: lado < 0 ? W * (0.22 + (i % 2) * 0.03) : W * (0.78 - (i % 2) * 0.03), y: y0 + H * (0.50 + rng() * 0.04) };
      const ctrl = { x: lado < 0 ? W * 0.18 : W * 0.82, y: y0 - H * 0.04 };
      osso(ctx, amostrar(p0, ctrl, alvo, 26), H * (0.07 - i * 0.004), PAL.ossoLonge);
    }
  };
  gaiola(-1); gaiola(1);
  // coluna vertebral ao fundo, à direita
  for (let i = 0; i < 9; i++) vertebra(ctx, W * 0.93 + Math.sin(i * 0.8) * 5, H * (0.02 + i * 0.12), H * 0.055, PAL.ossoLonge);
  // massa de carne no piso (volumes escuros)
  const g = ctx.createLinearGradient(0, H * 0.7, 0, H);
  g.addColorStop(0, 'rgba(32,10,14,0)'); g.addColorStop(1, 'rgba(46,14,20,.85)');
  ctx.fillStyle = g; ctx.fillRect(0, H * 0.7, W, H * 0.3);
  // mato distante (muito escuro, sem detalhes)
  for (let i = 0; i < 10; i++) samambaia(ctx, W * (i / 9) + (rng() - 0.5) * 40, H * 1.02, H * (0.34 + rng() * 0.2), -PI / 2 + (rng() - 0.5) * 1.1, (rng() - 0.5) * H * 0.2, '#16201a', null, rng);
}

export function desenharCamadaMeio(ctx, W, H) {
  const rng = criarRng(4099);
  // cortinas de carne nos cantos superiores
  cortinaDeCarne(ctx, -W * 0.03, W * 0.30, H * 0.52, rng, PAL.flesh);
  cortinaDeCarne(ctx, W * 0.74, W * 0.30, H * 0.46, rng, PAL.flesh);
  cortinaDeCarne(ctx, W * 0.26, W * 0.10, H * 0.20, rng, PAL.flesh);
  // raízes e tendões pendurados
  for (let i = 0; i < 6; i++) raizPendente(ctx, W * (0.05 + i * 0.037) + rng() * 10, H * (0.32 + rng() * 0.28), H * 0.035, '#1d1410', rng);
  for (let i = 0; i < 6; i++) raizPendente(ctx, W * (0.78 + i * 0.036) + rng() * 10, H * (0.3 + rng() * 0.3), H * 0.035, '#1d1410', rng);
  // costelas do meio, em primeiro plano nos cantos de baixo
  osso(ctx, amostrar({ x: -W * 0.02, y: H * 0.95 }, { x: W * 0.12, y: H * 0.58 }, { x: W * 0.34, y: H * 0.5 }, 26), H * 0.075, PAL.osso);
  osso(ctx, amostrar({ x: W * 1.02, y: H * 0.98 }, { x: W * 0.9, y: H * 0.6 }, { x: W * 0.68, y: H * 0.54 }, 26), H * 0.07, PAL.osso);
  // trepadeiras descendo das bordas e subindo do chão
  const t1 = { ...PAL.mato }; t1.folha = '#233a2b';
  trepadeira(ctx, W * 0.02, -4, PI / 2, H * 0.78, H * 0.022, 2, t1, rng);
  trepadeira(ctx, W * 0.97, -4, PI / 2, H * 0.7, H * 0.02, 2, t1, rng);
  trepadeira(ctx, W * 0.14, H + 4, -PI / 2, H * 0.55, H * 0.02, 2, t1, rng);
  trepadeira(ctx, W * 0.88, H + 4, -PI / 2, H * 0.6, H * 0.02, 2, t1, rng);
  for (let i = 0; i < 5; i++) samambaia(ctx, W * (0.02 + i * 0.05), H * 1.02, H * (0.4 + rng() * 0.2), -PI / 2 - 0.35 + rng() * 0.3, -H * 0.12, '#20382b', 'rgba(130,175,135,.28)', rng);
  for (let i = 0; i < 5; i++) samambaia(ctx, W * (0.80 + i * 0.05), H * 1.02, H * (0.4 + rng() * 0.2), -PI / 2 + 0.35 - rng() * 0.3, H * 0.12, '#20382b', 'rgba(130,175,135,.28)', rng);
  // brotos luminosos (esporos bioluminescentes presos às folhas)
  for (let i = 0; i < 16; i++) {
    const x = (i % 2 ? W * (0.04 + rng() * 0.22) : W * (0.74 + rng() * 0.22)); const y = H * (0.55 + rng() * 0.4);
    const gr = ctx.createRadialGradient(x, y, 0, x, y, 9); gr.addColorStop(0, 'rgba(190,255,205,.75)'); gr.addColorStop(0.3, 'rgba(110,200,140,.25)'); gr.addColorStop(1, 'rgba(60,140,90,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(x, y, 9, 0, PI * 2); ctx.fill();
  }
}

export function desenharCamadaPerto(ctx, W, H) {
  const rng = criarRng(1213);
  // silhuetas quase pretas que emolduram a cena (desfocadas por CSS)
  for (let i = 0; i < 4; i++) samambaia(ctx, -W * 0.02 + i * W * 0.035, H * 1.06, H * (0.5 + rng() * 0.2), -PI / 2 - 0.5 + rng() * 0.4, -H * 0.14, '#050b08', 'rgba(70,110,80,.14)', rng);
  for (let i = 0; i < 4; i++) samambaia(ctx, W * 1.02 - i * W * 0.035, H * 1.06, H * (0.5 + rng() * 0.2), -PI / 2 + 0.5 - rng() * 0.4, H * 0.14, '#050b08', 'rgba(70,110,80,.14)', rng);
  trepadeira(ctx, -W * 0.01, H * 0.1, 0.35, H * 0.55, H * 0.045, 1, PAL.matoPerto, rng);
  trepadeira(ctx, W * 1.01, H * 0.14, PI - 0.35, H * 0.5, H * 0.04, 1, PAL.matoPerto, rng);
  // vigas de osso nas bordas superiores
  osso(ctx, amostrar({ x: -W * 0.03, y: -H * 0.02 }, { x: W * 0.12, y: H * 0.05 }, { x: W * 0.2, y: H * 0.2 }, 22), H * 0.1, { base: '#0b0a09', sombra: '#050505', luz: '#1d1b18' });
  osso(ctx, amostrar({ x: W * 1.03, y: -H * 0.02 }, { x: W * 0.88, y: H * 0.05 }, { x: W * 0.8, y: H * 0.22 }, 22), H * 0.1, { base: '#0b0a09', sombra: '#050505', luz: '#1d1b18' });
}

// ---------------------------------------------------------------------
// Montagem e animação
// ---------------------------------------------------------------------
export function criarArteDoTitulo(doc, win) {
  const raiz = doc.getElementById('title-bg');
  const overlay = doc.getElementById('overlay-title');
  if (!raiz || !overlay) return { setAtivo() {}, redesenhar() {} };

  const camadas = [
    { id: 'longe', desenhar: desenharCamadaLonge },
    { id: 'meio', desenhar: desenharCamadaMeio },
    { id: 'perto', desenhar: desenharCamadaPerto },
  ].map((c) => ({ ...c, el: doc.createElement('canvas') }));
  const luz = doc.createElement('div'); luz.className = 'title-shaft';
  const poeira = doc.createElement('canvas'); poeira.className = 'title-dust';
  const vinheta = doc.createElement('div'); vinheta.className = 'title-vignette';
  // ordem de empilhamento: o feixe de luz fica ATRÁS das massas do meio e da frente
  for (const el of [camadas[0].el, luz, camadas[1].el, camadas[2].el, poeira, vinheta]) raiz.appendChild(el);
  for (const c of camadas) c.el.className = `title-layer title-layer-${c.id}`;

  let ativo = false; let quadro = 0; let desenhadoPara = ''; let particulas = [];
  const reduzido = !!win?.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;

  const redesenhar = () => {
    const W = Math.max(320, Math.round(overlay.clientWidth || win?.innerWidth || 800));
    const H = Math.max(200, Math.round(overlay.clientHeight || win?.innerHeight || 400));
    const chave = `${W}x${H}`; if (chave === desenhadoPara) return; desenhadoPara = chave;
    const dpr = Math.min(win?.devicePixelRatio || 1, 1.5); const margem = 40;
    for (const c of camadas) {
      const cw = W + margem * 2; const ch = H + margem * 2;
      c.el.width = Math.round(cw * dpr); c.el.height = Math.round(ch * dpr);
      const ctx = c.el.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, margem * dpr, margem * dpr);
      ctx.clearRect(-margem, -margem, cw, ch);
      c.desenhar(ctx, W, H);
    }
    poeira.width = W; poeira.height = H;
    const rng = criarRng(99);
    particulas = Array.from({ length: Math.round(Math.min(70, W * H / 6500)) }, () => ({
      x: rng() * W, y: rng() * H, r: 0.6 + rng() * 1.7, v: 3 + rng() * 9, fase: rng() * PI * 2, onda: 6 + rng() * 14, escura: rng() < 0.28,
    }));
    if (reduzido) pintarPoeira(0);
  };

  const pintarPoeira = (t) => {
    const ctx = poeira.getContext('2d'); const W = poeira.width; const H = poeira.height;
    ctx.clearRect(0, 0, W, H);
    for (const p of particulas) {
      const y = ((p.y - t * p.v) % H + H) % H; const x = p.x + Math.sin(t * 0.4 + p.fase) * p.onda;
      const pisca = 0.55 + 0.45 * Math.sin(t * 0.9 + p.fase * 2);
      ctx.fillStyle = p.escura ? `rgba(0,0,0,${0.55 * pisca})` : `rgba(235,240,230,${0.55 * pisca})`;
      ctx.beginPath(); ctx.arc(x, y, p.r, 0, PI * 2); ctx.fill();
    }
  };

  let ultimo = 0;
  const laco = (agora) => {
    if (!ativo) return;
    quadro = win.requestAnimationFrame(laco);
    if (agora - ultimo < 33) return;   // ~30 quadros/s bastam para poeira lenta
    ultimo = agora; pintarPoeira(agora / 1000);
  };

  // ---- navegação do menu por teclado (setas + Enter); toque e mouse seguem funcionando como botões comuns ----
  const botoes = () => [...overlay.querySelectorAll('.title-menu .menu-btn')].filter((b) => !b.disabled && !b.classList.contains('hidden'));
  const marcar = (alvo) => { overlay.querySelectorAll('.title-menu .menu-btn').forEach((b) => b.classList.toggle('sel', b === alvo)); alvo?.focus?.({ preventScroll: true }); };
  const aoTeclar = (e) => {
    if (!ativo) return;
    const lista = botoes(); if (!lista.length) return;
    const atual = Math.max(0, lista.findIndex((b) => b.classList.contains('sel')));
    if (['ArrowDown', 'KeyS'].includes(e.code)) { e.preventDefault(); marcar(lista[(atual + 1) % lista.length]); }
    else if (['ArrowUp', 'KeyW'].includes(e.code)) { e.preventDefault(); marcar(lista[(atual + lista.length - 1) % lista.length]); }
    else if (['Enter', 'Space', 'NumpadEnter'].includes(e.code)) { const b = lista[atual]; if (b) { e.preventDefault(); b.click(); } }
  };
  overlay.addEventListener('pointerover', (e) => { const b = e.target?.closest?.('.menu-btn'); if (b && !b.disabled && e.pointerType === 'mouse') marcar(b); });
  win?.addEventListener('keydown', aoTeclar);
  let timer = 0;
  win?.addEventListener('resize', () => { if (!ativo) { desenhadoPara = ''; return; } win.clearTimeout(timer); timer = win.setTimeout(redesenhar, 150); });
  doc.addEventListener?.('visibilitychange', () => { if (doc.hidden) { ativo && win.cancelAnimationFrame(quadro); } else if (ativo && !reduzido) quadro = win.requestAnimationFrame(laco); });

  return {
    setAtivo(sim) {
      if (sim === ativo) return; ativo = !!sim;
      if (ativo) {
        redesenhar();
        const lista = botoes(); marcar(lista[0] || null);
        if (!reduzido) quadro = win.requestAnimationFrame(laco);
      } else if (quadro) win.cancelAnimationFrame(quadro);
    },
    redesenhar,
  };
}
