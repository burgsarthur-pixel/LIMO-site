// =====================================================================
// CAIXA DE DIÁLOGO NO CANVAS (v1.43.0)
// Mesma linguagem visual do cartão de história e da pausa (verde-escuro + moldura rosada), contida no quadro do jogo.
// Entradas, todas compatíveis com o resto da interface:
//   · teclado ........ Enter / Espaço / E (ação "interact") avança · Esc fecha
//   · toque .......... tocar no quadro do jogo OU no botão de interação (☾/💬) avança
//   · gamepad ........ A avança · B fecha
// Enquanto aberta, o jogo fica `suspended = 'dialogo'` (como genes/catálogo): ao fechar, tudo volta; nunca prende o jogador.
// O texto aparece letra a letra; avançar no meio da fala a completa; avançar com ela completa passa para a próxima.
// =====================================================================
import { ARTE_NPC, ARTE_RETRATO } from '../render/npc-art.js';
import { COR, FONTE, painel as painelHK } from './hk-canvas.js';

const CPS = 46;            // letras por segundo
const MAX_LINHAS = 4;

export class CanvasDialogo {
  constructor({ canvas, renderer, config }) {
    this.canvas = canvas; this.renderer = renderer; this.config = config;
    this.open = false; this.d = null; this.i = 0; this.t = 0; this.rev = 0; this.tAnim = 0;
    this._linhas = null; this._cacheTexto = null;
    this._onPointerDown = (e) => this._pointerDown(e); this._onKeyDown = (e) => this._keyDown(e);
    canvas.addEventListener('pointerdown', this._onPointerDown);
    window.addEventListener('keydown', this._onKeyDown);
  }

  /** Abre o diálogo. `falas` = lista de textos; `topo` põe a caixa no alto da tela (para não cobrir quem fala); `aoFechar` roda UMA vez, ao fechar. */
  abrir({ nome, falas, npc = null, topo = false, aoFechar = null }) {
    const lista = (falas || []).map((f) => String(f)).filter((f) => f.trim());
    if (!lista.length) return false;
    this.d = { nome: nome || '…', falas: lista, npc, topo: !!topo, aoFechar }; this.i = 0; this.rev = 0; this.t = 0; this._cacheTexto = null; this.open = true;
    this._rotular(); return true;
  }

  fechar() {
    if (!this.open) return;
    const fim = this.d?.aoFechar; this.open = false; this.d = null; this._linhas = null; this._cacheTexto = null;
    this.canvas.setAttribute('aria-label', 'Área do jogo LIMO');
    fim?.();
  }

  /** Avança: completa a fala em andamento; com ela completa, vai para a próxima; na última, fecha. */
  avancar() {
    if (!this.open || !this.d) return;
    const total = this.d.falas[this.i].length;
    if (this.rev < total) { this.rev = total; return; }
    if (this.i + 1 < this.d.falas.length) { this.i++; this.rev = 0; this._cacheTexto = null; this._rotular(); } else this.fechar();
  }

  get completa() { return !!this.d && this.rev >= this.d.falas[this.i].length; }
  get ultima() { return !!this.d && this.i === this.d.falas.length - 1; }

  /** Chamado a cada quadro de tela (o jogo está suspenso): anima o texto e lê o botão de interação (toque/E). */
  update(dt, input = null) {
    if (!this.open || !this.d) return;
    this.tAnim += dt; this.t += dt;
    const total = this.d.falas[this.i].length; if (this.rev < total) this.rev = Math.min(total, this.rev + CPS * dt);
    if (input?.wasPressed?.('interact')) { this.avancar(); input.endStep?.(); }
  }

  _rotular() { this.canvas.setAttribute('aria-label', `${this.d.nome}: ${this.d.falas[this.i]} Toque ou pressione Enter para continuar.`); }
  _keyDown(e) {
    if (!this.open || e.repeat) return;
    if (e.code === 'Escape') { e.preventDefault(); this.fechar(); return; }
    if (e.code === 'Enter' || e.code === 'Space' || e.code === 'NumpadEnter') { e.preventDefault(); this.avancar(); }
  }
  _pointerDown(e) { if (!this.open) return; e.preventDefault(); this.avancar(); }
  aoGamepad(info) { if (!this.open || !info?.pressed) return; if (info.pressed.has(0)) this.avancar(); else if (info.pressed.has(1)) this.fechar(); }

  _quebrar(ctx, texto, largura) {
    const palavras = String(texto || '').split(/\s+/).filter(Boolean); const linhas = []; let atual = '';
    for (const w of palavras) { const n = atual ? `${atual} ${w}` : w; if (atual && ctx.measureText(n).width > largura) { linhas.push(atual); atual = w; } else atual = n; }
    if (atual) linhas.push(atual); return linhas;
  }

  draw(ctx) {
    if (!this.open || !this.d) return;
    const { internalWidth: W, internalHeight: H } = this.config.render;
    const painel = { x: 8, y: this.d.topo ? 20 : H - 82, w: W - 16, h: 74 }; const larguraTexto = painel.w - 70;   // topo: y=20 deixa espaço para a etiqueta do nome
    const fala = this.d.falas[this.i]; const n = Math.floor(this.rev);
    ctx.save();
    // moldura: mesmo painel fino do cartão de história e da pausa
    painelHK(ctx, painel.x, painel.y, painel.w, painel.h, { opacidade: 0.93, chanfro: 4 });
    // etiqueta com o nome: texto solto sobre o filete, sem caixa
    ctx.textAlign = 'left'; ctx.font = `bold 8px ${FONTE}`; ctx.fillStyle = 'rgba(0,0,0,.85)'; ctx.fillText(this.d.nome, painel.x + 15, painel.y - 4); ctx.fillStyle = COR.osso; ctx.fillText(this.d.nome, painel.x + 14, painel.y - 5);
    // retrato (a mesma arte do mundo, ampliada 2× com pixels nítidos)
    const fx = painel.x + 7; const fy = painel.y + 8;
    ctx.fillStyle = 'rgba(185,179,162,.45)'; ctx.fillRect(fx - 1, fy - 1, 46, 46); ctx.fillStyle = '#121413'; ctx.fillRect(fx, fy, 44, 44);
    const arte = ARTE_RETRATO[this.d.npc] || ARTE_NPC[this.d.npc];   // v1.51.0: retrato próprio quando existe
    if (arte) { ctx.save(); ctx.beginPath(); ctx.rect(fx, fy, 44, 44); ctx.clip(); ctx.translate(fx + 6, fy + 4); ctx.scale(2, 2); arte(ctx, 0, 0, this.tAnim, !this.completa); ctx.restore(); }
    // texto (letra a letra)
    const tx = painel.x + 60; let ty = painel.y + 17;
    ctx.textAlign = 'left'; ctx.font = `8px ${FONTE}`; ctx.fillStyle = COR.osso;
    if (!this._cacheTexto || this._cacheTexto.i !== this.i) this._cacheTexto = { i: this.i, linhas: this._quebrar(ctx, fala, larguraTexto) };
    let restante = n;
    for (const linha of this._cacheTexto.linhas.slice(0, MAX_LINHAS)) {
      const mostra = linha.slice(0, Math.max(0, restante)); ctx.fillText(mostra, tx, ty); restante -= linha.length + 1; ty += 11; if (restante <= 0) break;
    }
    // progresso e indicador de continuar
    ctx.textAlign = 'left'; ctx.fillStyle = COR.osso3; ctx.font = `7px ${FONTE}`;
    if (this.d.falas.length > 1) ctx.fillText(`${this.i + 1}/${this.d.falas.length}`, painel.x + 60, painel.y + painel.h - 8);   // contador no canto livre (embaixo à esquerda do texto)
    ctx.textAlign = 'right';
    if (this.completa) {
      const pisca = Math.floor(this.tAnim * 2.5) % 2 === 0; ctx.fillStyle = pisca ? COR.osso : COR.osso3;
      ctx.fillText(this.ultima ? 'FECHAR' : 'CONTINUAR', painel.x + painel.w - 17, painel.y + painel.h - 8);
      const bx = painel.x + painel.w - 14; const by = painel.y + painel.h - 14;   // seta ▼ desenhada (não depende da fonte)
      ctx.fillRect(bx, by, 7, 1); ctx.fillRect(bx + 1, by + 1, 5, 1); ctx.fillRect(bx + 2, by + 2, 3, 1); ctx.fillRect(bx + 3, by + 3, 1, 1);
    }
    ctx.restore();
  }
}
