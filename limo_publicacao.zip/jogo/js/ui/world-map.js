// =====================================================================
// MAPA DE EXPLORAÇÃO — desenhado a partir dos DADOS REAIS das salas (nada de imagem fixa).
//   - salas visitadas: silhueta real (tiles sólidos e plataformas, 1 pixel por tile)
//   - salas apenas conhecidas (ligadas a uma sala visitada): contorno tracejado com "?"
//   - passagens: verde = aberta, vermelha = selada e já descoberta, cinza = ainda não testada
//   - localização atual: ponto piscando
// A cartografia é independente das coordenadas físicas das salas. Assim, a construção
// artesanal de cada fase continua livre, enquanto o atlas mantém uma leitura coerente.
// =====================================================================
import { resumoDoMundo, formatarTempo } from './progressao.js';
import { checkRequirement, ABILITIES, ABILITY_IDS } from '../entities/abilities.js';
import { checkGenes } from '../entities/genes.js';
import { chaveItem } from '../core/progress.js';
import { calcularLayoutAtlas } from '../world/atlas-layout.js';

/**
 * Posições do atlas principal, em tiles de mapa. Não são coordenadas jogáveis.
 * O percurso desce pelas Raízes, sobe para o Jardim e volta a descer rumo ao Núcleo;
 * desvios e segredos saem da rota central. Manter novas salas explícitas aqui evita
 * que alterações no tamanho físico de uma fase embaralhem o mapa inteiro.
 */
export const LAYOUT_CARTOGRAFICO = Object.freeze({
  // Rota principal: leitura contínua da esquerda para a direita (vão de 2 tiles, portas alinhadas).
  // pós-v1.46.0: Raízes inteira recalculada por `node tools/mapas/mappos.mjs` (todas as 13 salas fixas, sem sala "solta");
  // Jardim e Núcleo só foram deslocados juntos (+87 em x) para continuar encostados na Coroa.
  raizes_camara: { x: 34, y: 143 }, raizes_veia: { x: 70, y: 142 }, raizes_bercario: { x: 110, y: 131 },
  raizes_bosque: { x: 140, y: 126 }, raizes_antecamara: { x: 182, y: 123 }, raizes_guardiao: { x: 210, y: 129 },
  raizes_02: { x: 242, y: 115 }, raizes_ascensao: { x: 262, y: 100 },
  raizes_coroa: { x: 290, y: 90 }, jardim_entrada: { x: 324, y: 92 },
  jardim_copa: { x: 363, y: 92 }, nucleo_fissura: { x: 404, y: 92 },
  nucleo_salao: { x: 445, y: 92 }, nucleo_condutos: { x: 491, y: 92 },
  nucleo_coracao: { x: 534, y: 92 },
  // Ramificações ficam junto da sala da qual saem, com o sentido real da abertura.
  // Óssario a oeste da Câmara; Santuário a leste da Antessala (sobre o Guardião); Costelas sobre o Bosque; Nicho sob o Bosque.
  raizes_nicho: { x: 162, y: 142 }, jardim_galerias: { x: 324, y: 120 },
  jardim_lago: { x: 363, y: 120 }, jardim_nicho: { x: 404, y: 120 },
  jardim_secreto: { x: 369, y: 72 },
  // v1.34.0 — rotas e segredos (atalhos entre regiões)
  raizes_costelas: { x: 157, y: 92 }, raizes_ossario: { x: 0, y: 140 }, raizes_santuario: { x: 210, y: 115 },
  jardim_pomar: { x: 363, y: 142 }, nucleo_aqueduto: { x: 449, y: 54 },
});

/**
 * Ordem lógica do mundo. O número descreve a progressão, não a distância física.
 * A sala 20 volta para perto da 3 de propósito: ela é um retorno tardio ao Bosque.
 */
export const ROTA_DAS_SALAS = Object.freeze({
  raizes_camara:    { numero: 1,  papel: 'Despertar e controles básicos', tipo: 'principal' },
  raizes_veia:      { numero: 2,  papel: 'Corredor de orientação', tipo: 'principal' },
  raizes_bosque:    { numero: 3,  papel: 'Encruzilhada e retorno futuro', tipo: 'principal' },
  raizes_guardiao:  { numero: 4,  papel: 'Arena da Tecelã das Raízes', tipo: 'principal' },
  raizes_02:        { numero: 5,  papel: 'Chaminé da Muda e progresso', tipo: 'principal' },
  raizes_ascensao:  { numero: 6,  papel: 'Travessia para a Coroa', tipo: 'principal' },
  raizes_coroa:     { numero: 7,  papel: 'Saída das Raízes', tipo: 'principal' },
  jardim_entrada:   { numero: 8,  papel: 'Portal e bifurcação do Jardim', tipo: 'principal' },
  jardim_copa:      { numero: 9,  papel: 'Copa vertical e rota ao Núcleo', tipo: 'principal' },
  nucleo_fissura:   { numero: 10, papel: 'Entrada selada do Núcleo', tipo: 'principal' },
  nucleo_salao:     { numero: 11, papel: 'Salão de confronto do Núcleo', tipo: 'principal' },
  nucleo_condutos:  { numero: 12, papel: 'Condutos de aproximação final', tipo: 'principal' },
  nucleo_coracao:   { numero: 13, papel: 'Coração Residual e conclusão', tipo: 'principal' },
  jardim_galerias:  { numero: 14, papel: 'Descida opcional do Jardim', tipo: 'ramo' },
  jardim_lago:      { numero: 15, papel: 'Lago e encontro do Pastor', tipo: 'ramo' },
  jardim_nicho:     { numero: 16, papel: 'Recompensa lateral do Lago', tipo: 'ramo' },
  jardim_secreto:   { numero: 18, papel: 'Segredo acima da Copa', tipo: 'segredo' },
  raizes_nicho:     { numero: 20, papel: 'Retorno tardio ao Bosque', tipo: 'segredo' },
  raizes_costelas:  { numero: 17, papel: 'Atalho elevado Raízes ⇄ Jardim', tipo: 'ramo' },
  jardim_pomar:     { numero: 19, papel: 'Atalho vertical Copa ⇄ Galerias', tipo: 'ramo' },
  raizes_ossario:   { numero: 21, papel: 'Segredo da primeira sala', tipo: 'segredo' },
  nucleo_aqueduto:  { numero: 22, papel: 'Atalho Fissura ⇄ Condutos', tipo: 'ramo' },
  raizes_santuario: { numero: 23, papel: 'Câmara do Instante (Instante Vital)', tipo: 'segredo' },
});

export function ordemDaSala(id) { return ROTA_DAS_SALAS[id]?.numero ?? Number.MAX_SAFE_INTEGER; }

function posicoesDoAtlas(world) {
  // Grade de tiles: posições deliberadas (LAYOUT_CARTOGRAFICO ou mapPos) têm prioridade; qualquer sala
  // sem posição, ou cuja posição colida com outra, é encaixada ao lado da vizinha pela porta pareada.
  const fixas = {}; const ocupado = new Set();
  const cabe = (d, p) => { for (let j = p.y; j < p.y + d.height; j++) for (let i = p.x; i < p.x + d.width; i++) if (ocupado.has(i + ',' + j)) return false; return true; };
  for (const [id, d] of world.rooms) {
    const p = LAYOUT_CARTOGRAFICO[id] || (world.rooms.size && !Object.keys(LAYOUT_CARTOGRAFICO).some((k) => world.rooms.has(k)) ? d.mapPos : null);
    if (!p || !cabe(d, p)) continue;
    fixas[id] = { x: p.x, y: p.y };
    for (let j = p.y; j < p.y + d.height; j++) for (let i = p.x; i < p.x + d.width; i++) ocupado.add(i + ',' + j);
  }
  return calcularLayoutAtlas(world.rooms, fixas);
}

function centroDoGatilho(posicao, conexao) {
  return {
    x: posicao.x + conexao.trigger.x + conexao.trigger.w / 2,
    y: posicao.y + conexao.trigger.y + conexao.trigger.h / 2,
  };
}

/** Calcula o que aparece no mapa (puro: sem canvas). */
export function computeMapLayout(world, progress, roomIdAtual) {
  const salas = []; const conexoes = []; const trilhas = [];
  const posicoes = posicoesDoAtlas(world);
  const conhecidas = new Set();
  for (const id of progress.visited) { const d = world.get(id); if (!d) continue; for (const c of d.connections) if (world.has(c.to) && !progress.visited.has(c.to)) conhecidas.add(c.to); }
  const mostrar = new Set([...progress.visited].filter((id) => world.has(id)));
  for (const id of conhecidas) mostrar.add(id);
  const paresTraçados = new Set();
  for (const id of mostrar) {
    const d = world.get(id); const p = posicoes.get(id); const visitada = progress.visited.has(id);
    const rota = ROTA_DAS_SALAS[id];
    salas.push({ id, name: visitada ? d.name : '?', numero: rota?.numero || null, papel: rota?.papel || '', x: p.x, y: p.y, w: d.width, h: d.height, estado: visitada ? 'visitada' : 'conhecida', atual: id === roomIdAtual, biome: d.biome });
    if (!visitada) continue;
    for (const c of d.connections) {
      const ok = checkRequirement(progress.abilities, c.requires).ok && checkGenes(progress.genesEquipados || [], c.requerGene).ok; const chave = chaveItem(id, c.id);
      const estado = ok ? 'aberta' : (progress.blockedFound.has(chave) ? 'bloqueada' : 'desconhecida');
      conexoes.push({ sala: id, para: c.to, id: c.id, x: p.x + c.trigger.x, y: p.y + c.trigger.y, w: c.trigger.w, h: c.trigger.h, estado, requires: c.requires || null });
      // Uma trilha é somente uma pista cartográfica. Ela usa os mesmos gatilhos,
      // mas não altera destino, requisito, porta nem qualquer lógica de jogo.
      const destino = world.get(c.to); const chavePar = [id, c.to].sort().join('::');
      if (!destino || !mostrar.has(c.to) || paresTraçados.has(chavePar)) continue;
      paresTraçados.add(chavePar);
      const volta = destino.connections.find((x) => x.to === id);
      const ate = volta ? centroDoGatilho(posicoes.get(c.to), volta) : { x: posicoes.get(c.to).x + destino.width / 2, y: posicoes.get(c.to).y + destino.height / 2 };
      trilhas.push({ de: centroDoGatilho(p, c), ate, estado });
    }
  }
  let minX = Infinity; let minY = Infinity; let maxX = -Infinity; let maxY = -Infinity;
  for (const s of salas) { minX = Math.min(minX, s.x); minY = Math.min(minY, s.y); maxX = Math.max(maxX, s.x + s.w); maxY = Math.max(maxY, s.y + s.h); }
  if (!salas.length) { minX = minY = 0; maxX = maxY = 1; }
  const regioesMapa = regioes(world, posicoes);
  for (const r of regioesMapa) { minX = Math.min(minX, r.minX); minY = Math.min(minY, r.minY); maxX = Math.max(maxX, r.maxX); maxY = Math.max(maxY, r.maxY); }
  return { salas, conexoes, trilhas, regioes: regioesMapa, bounds: { minX, minY, maxX, maxY } };
}

/** Posição do jogador no mapa (em tiles do mundo), ou null. */
export function playerMapPos(layout, roomId, tx, ty) {
  const s = layout.salas.find((r) => r.id === roomId);
  return s ? { x: s.x + tx, y: s.y + ty } : null;
}

const COR_BIOMA = { raizes: '#8b5a5a', jardim: '#4a6b4a', nucleo: '#7a2a3a' };
// Cores ÚNICAS do mapa: o desenho do canvas e as amostras da legenda leem daqui (não podem divergir).
export const COR = {
  aberta: '#7cfc00', bloqueada: '#ff4d4d', desconhecida: '#9aa59a', conhecida: '#6a8a6a', atual: '#ffe135',
  checkpoint: '#62dcff', item: '#ffd23f', porta: '#00d0b0', transicao: '#b77cff', chefe: '#ff4d6a',
};
const COR_CONEXAO = { aberta: COR.aberta, bloqueada: COR.bloqueada, desconhecida: COR.desconhecida };
const NOME_BIOMA = { raizes: 'Ossuário das Raízes', jardim: 'Jardim Sepulcral', nucleo: 'Núcleo do Deus' };
/** Cor própria de cada mutação (legenda + cor do chip). */
export const COR_MUTACAO = { investida: '#ffb347', saltoElastico: '#5ff0c8', wallJump: '#8be36b', membrana: '#c58cff', tendril: '#73e6bc', instanteVital: '#9dffd2' };
/** Itens da LEGENDA GERAL: [cor, forma da amostra, texto]. */
export const LEGENDA_GERAL = [
  [COR.aberta, 'bar', 'Passagem aberta'], [COR.bloqueada, 'bar', 'Passagem selada'], [COR.desconhecida, 'bar', 'Passagem ainda não testada'],
  [COR.conhecida, 'room', 'Sala conhecida'], [COR.conhecida, 'dashed', 'Sala ainda não testada'], [COR.atual, 'roomon', 'Sala atualmente visitada'],
  [COR.checkpoint, 'diamond', 'Checkpoint'], [COR.item, 'square', 'Baú ou item'], [COR.porta, 'door', 'Porta bloqueada'],
  [COR.transicao, 'ring', 'Transição de bioma'], [COR.chefe, 'skull', 'Chefe'],
];
const BIOMAS = {
  raizes: { nome: 'RAÍZES DA CARNE', sub: 'o início de tudo', cor: '#ff5279', fundo: 'rgba(148, 30, 63, 0.18)' },
  jardim: { nome: 'JARDIM DAS VÍSCERAS', sub: 'vida em constante mutação', cor: '#71e88a', fundo: 'rgba(41, 139, 76, 0.16)' },
  nucleo: { nome: 'NÚCLEO DO DEUS', sub: 'o fim — e o recomeço', cor: '#b77cff', fundo: 'rgba(100, 42, 161, 0.18)' },
};

/** Chefes do mundo (id = `${sala}:${entidade}`, o mesmo gravado em progress.bossesDefeated). `principal` = os 3 da progressão. */
export const CHEFES = [
  { id: 'raizes_guardiao:guardiao_raizes', sala: 'raizes_guardiao', nome: 'Guardião das Raízes', bioma: 'raizes', dica: 'Defesa da região inicial.', principal: true },
  { id: 'nucleo_salao:mastigador_pulso', sala: 'nucleo_salao', nome: 'Mastigador do Pulso', bioma: 'nucleo', dica: 'Guarda os condutos do Núcleo.', principal: false },
  { id: 'nucleo_coracao:coracao_residual', sala: 'nucleo_coracao', nome: 'Coração Residual', bioma: 'nucleo', dica: 'O núcleo do Deus.', principal: true },
];

/** Destinos da viagem rápida: checkpoints já descobertos, na ordem do mundo; marca o checkpoint atual. */
export function destinosDeViagem(progress, world) {
  const lista = []; const atual = progress?.checkpoint;
  for (const k of progress?.bancos || []) {
    const [sala, id] = k.split(':'); const d = world?.get?.(sala); if (!d || !d.entities.some((e) => e.type === 'checkpoint' && e.id === id)) continue;
    lista.push({ sala, id, nome: d.name || sala, bioma: d.biome, atual: !!atual && atual.sala === sala && atual.id === id });
  }
  return lista.sort((a, b) => ordemDaSala(a.sala) - ordemDaSala(b.sala) || a.id.localeCompare(b.id));
}

/** Qual sala está sob o ponto (px do desenho do mapa)? Usa o layout e a transformação (ox, oy, escala) do último desenho. */
export function salaNoPonto(lay, ox, oy, escala, px, py) {
  for (const s of lay?.salas || []) {
    const x = ox + s.x * escala; const y = oy + s.y * escala;
    if (px >= x && px <= x + s.w * escala && py >= y && py <= y + s.h * escala) return s.id;
  }
  return null;
}

/** Checkpoint de destino ao tocar numa sala do mapa: o atual dela, senão o primeiro descoberto; null se a sala não tem banco descoberto. */
export function bancoDaSala(progress, sala) {
  const ids = [...(progress?.bancos || [])].filter((k) => k.startsWith(`${sala}:`)).map((k) => k.slice(sala.length + 1)); if (!ids.length) return null;
  const atual = progress.checkpoint; return atual && atual.sala === sala && ids.includes(atual.id) ? atual.id : ids.sort()[0];
}

/** Estado de cada chefe no mapa: derrotado · encontrado (a sala já foi visitada) · desconhecido (não revela nada). */
export function estadoDosChefes(progress, world) {
  const feitos = progress?.bossesDefeated || []; const visitadas = progress?.visited;
  return CHEFES.filter((c) => !world || world.has?.(c.sala) !== false).map((c) => ({
    ...c, estado: feitos.includes(c.id) ? 'derrotado' : (visitadas?.has?.(c.sala) ? 'encontrado' : 'desconhecido'),
  }));
}

/** Progressão principal: Raízes ▸ Jardim ▸ Núcleo ▸ Conclusão. feito = chefe do bioma derrotado; atual = bioma onde Limo está. */
export function progressaoPrincipal(progress, world, roomId) {
  const feitos = progress?.bossesDefeated || []; const biomaAtual = world?.get?.(roomId)?.biome;
  const etapas = ['raizes', 'jardim', 'nucleo'].map((bioma) => {
    const chefe = CHEFES.find((c) => c.principal && c.bioma === bioma);
    const feito = feitos.includes(chefe.id);
    return { id: bioma, nome: NOME_BIOMA[bioma], chefe: chefe.nome, estado: feito ? 'feito' : (bioma === biomaAtual ? 'atual' : 'pendente') };
  });
  const tudo = etapas.every((e) => e.estado === 'feito');
  return [...etapas, { id: 'conclusao', nome: 'Conclusão', chefe: '', estado: tudo ? 'feito' : 'pendente' }];
}

function regioes(world, posicoes) {
  const grupos = new Map();
  for (const [id, d] of world.rooms) {
    const p = posicoes.get(id); if (!p || !BIOMAS[d.biome]) continue;
    const caixa = { minX: p.x, minY: p.y, maxX: p.x + d.width, maxY: p.y + d.height };
    const r = grupos.get(d.biome);
    if (!r) grupos.set(d.biome, caixa);
    else { r.minX = Math.min(r.minX, caixa.minX); r.minY = Math.min(r.minY, caixa.minY); r.maxX = Math.max(r.maxX, caixa.maxX); r.maxY = Math.max(r.maxY, caixa.maxY); }
  }
  return [...grupos.entries()].map(([biome, r]) => ({ biome, ...BIOMAS[biome], minX: r.minX - 5, minY: r.minY - 7, maxX: r.maxX + 5, maxY: r.maxY + 5 }));
}

/** Silhueta 1px/tile de uma sala visitada, desenhada uma vez (cache por sala). */
function silhueta(fabrica, d, catalogo) {
  const c = fabrica(d.width, d.height); const ctx = c.getContext('2d');
  const cor = COR_BIOMA[d.biome] || '#888';
  ctx.fillStyle = 'rgba(255,255,255,0.05)'; ctx.fillRect(0, 0, d.width, d.height);
  for (const nome of ['solid', 'platform']) {
    const camada = d.layers[nome]; if (!camada) continue;
    for (let y = 0; y < d.height; y++) for (let x = 0; x < d.width; x++) {
      const t = catalogo.get(camada[y][x]); if (!t || t.collision === 'none' || t.collision === 'damage') continue;
      ctx.fillStyle = t.collision === 'oneway' ? '#d9cbb0' : cor; ctx.fillRect(x, y, 1, 1);
    }
  }
  return c;
}

/** Veia pontilhada em L: liga portas distantes sem suavizar o desenho pixelado. */
function trilhaPontilhada(ctx, x1, y1, x2, y2, cor, passo, espessura) {
  const dx = Math.sign(x2 - x1); const dy = Math.sign(y2 - y1);
  const total = Math.abs(x2 - x1) + Math.abs(y2 - y1); if (!total) return;
  ctx.fillStyle = cor;
  for (let p = 0; p <= total; p += passo) {
    const x = Math.round(x1 + dx * Math.min(p, Math.abs(x2 - x1)));
    const y = Math.round(y1 + dy * Math.max(0, p - Math.abs(x2 - x1)));
    ctx.fillRect(x - Math.floor(espessura / 2), y - Math.floor(espessura / 2), espessura, espessura);
  }
}

function desenharTrilha(ctx, trilha, ox, oy, escala) {
  const x1 = ox + trilha.de.x * escala; const y1 = oy + trilha.de.y * escala;
  const x2 = ox + trilha.ate.x * escala; const y2 = oy + trilha.ate.y * escala;
  const passo = Math.max(3, Math.round(escala * 5)); const espessura = Math.max(1, Math.round(escala));
  ctx.save?.(); ctx.globalAlpha = 0.58;
  // O cotovelo ortogonal deixa a leitura de mapa mais clara que uma diagonal lisa.
  trilhaPontilhada(ctx, x1, y1, x2, y1, COR_CONEXAO[trilha.estado], passo, espessura);
  trilhaPontilhada(ctx, x2, y1, x2, y2, COR_CONEXAO[trilha.estado], passo, espessura);
  ctx.restore?.();
}

/** Marcadores dentro de uma sala visitada: checkpoint, item não coletado, porta trancada e chefe (em coordenadas de mundo, tiles). */
export function marcadoresDaSala(d, progress) {
  const m = [];
  for (const e of d.entities || []) {
    if (e.type === 'checkpoint') m.push({ tipo: 'checkpoint', x: e.x + 0.5, y: e.y + 0.5 });
    else if (e.type === 'gene' && !progress.genes?.has(e.gene)) m.push({ tipo: 'item', x: e.x + 0.5, y: e.y + 0.5 });
    else if ((e.type === 'mutation' || e.type === 'vida' || e.type === 'encaixe') && !progress.collected.has(chaveItem(d.id, e.id))) m.push({ tipo: 'item', x: e.x + 0.5, y: e.y + 0.5 });
    else if (e.type === 'door' && e.requires && !checkRequirement(progress.abilities, e.requires).ok) m.push({ tipo: 'porta', x: e.x + 0.5, y: e.y + 0.5 });
    else if (e.type === 'enemy' && e.kind === 'boss') m.push({ tipo: 'chefe', x: e.x + 0.5, y: e.y + 0.5 });
  }
  return m;
}

export function createWorldMap({ doc, win = (typeof window !== 'undefined' ? window : null), game, catalog }) {
  const overlay = doc.getElementById('overlay-map'); const canvas = doc.getElementById('map-canvas');
  const legenda = doc.getElementById('map-legend'); const biomasEl = doc.getElementById('map-biomes'); const habEl = doc.getElementById('map-abilities');
  const viagemEl = doc.getElementById('map-travel'); const salasEl = doc.getElementById('map-rooms'); const progEl = doc.getElementById('map-progress'); const chefesEl = doc.getElementById('map-bosses'); const foco = doc.getElementById('map-focus'); const cache = new Map(); let aberto = false; let timer = null;
  const fabrica = (w, h) => { const c = doc.createElement('canvas'); c.width = w; c.height = h; return c; };
  const el = (tag, cls, texto) => { const e = doc.createElement(tag); if (cls) e.className = cls; if (texto !== undefined) e.textContent = texto; return e; };
  const sw = (forma, cor) => { const e = el('i', `sw sw-${forma}`); e.style.setProperty('--c', cor); e.setAttribute('aria-hidden', 'true'); return e; };

  /** Painel lateral: legenda geral, biomas e mutações (estado vem do progresso real). Tudo texto real no DOM. */
  function montarLegenda() {
    legenda.replaceChildren(...LEGENDA_GERAL.map(([cor, forma, texto]) => { const it = el('div', 'map-item'); it.append(sw(forma, cor), el('span', '', texto)); return it; }));
    biomasEl.replaceChildren(...Object.entries(BIOMAS).map(([id, b]) => {
      const it = el('div', `map-biome ${id}`); it.style.setProperty('--c', b.cor); it.style.setProperty('--f', b.fundo); const t = el('span'); const nome = el('b', '', NOME_BIOMA[id]); t.append(nome, el('small', '', b.sub));
      it.append(sw('biome', b.cor), t); return it;
    }));
    habEl.replaceChildren(...ABILITY_IDS.map((id) => {
      const a = ABILITIES[id]; const livre = !!game.progress?.abilities?.[id]; const cor = COR_MUTACAO[id] || '#cfe8c8';
      const it = el('div', `map-ability${livre ? '' : ' locked'}`); it.style.setProperty('--c', cor);
      const chip = el('i', 'chip', a.icone); chip.setAttribute('aria-hidden', 'true'); const t = el('span');
      t.append(el('b', '', a.nome.replace(/ \(.*\)$/, '')), el('small', '', a.descricao), el('span', 'estado', livre ? 'DESBLOQUEADA' : 'BLOQUEADA'));
      it.append(chip, t); return it;
    }));
    if (viagemEl) {
      const dest = destinosDeViagem(game.progress, game.world);
      viagemEl.replaceChildren(...(dest.length ? dest.map((d) => {
        const b = el('button', `map-travel-btn${d.atual ? ' atual' : ''}`, `${d.atual ? '● ' : '◆ '}${d.nome}`); b.type = 'button'; b.style.setProperty('--c', (BIOMAS[d.bioma] || {}).cor || COR.chefe);
        if (d.atual) b.disabled = true;
        else b.addEventListener('click', () => { api.close(); game.viajarPara(d.sala, d.id); });
        return b;
      }) : [el('small', 'map-travel-vazio', 'Descanse em um checkpoint para liberar a viagem.')]));
    }
    const upEl = doc.getElementById('map-upgrades');
    if (upEl && game.progress && game.world) {   // v1.37: o que já foi feito e o que ainda falta (só nas salas visitadas)
      const r = resumoDoMundo(game.world, game.progress); const p = game.progress; const linha = (rot, val, cor) => { const it = el('div', 'map-item'); it.style.setProperty('--c', cor); it.append(el('b', '', rot), el('span', '', ` ${val}`)); return it; };
      const fr = (a) => `${a[0]}/${a[1]}${r.salasNaoVisitadas ? '+' : ''}`;
      upEl.replaceChildren(
        linha('Salas', `${r.salas.visitadas}/${r.salas.total} exploradas`, COR.atual),
        linha('Itens permanentes', `${r.itens.coletados}/${r.itens.total}${r.salasNaoVisitadas ? '+ (há salas por descobrir)' : ''}`, COR.item),
        linha('Fragmentos de Carne', `${fr(r.por.vida)} · vida máx. ${game.player?.maxLife ?? '?'}`, '#ff7fa8'),
        linha('Bulbos de Encaixe', `${fr(r.por.encaixe)} · ${p.encaixes} encaixes de gene`, '#7fe8ff'),
        linha('Genes', fr(r.por.gene), '#c58cff'),
        linha('Tempo · quedas', `${formatarTempo(p.tempoJogo)} · ${p.mortes | 0}`, COR.conhecida),
        ...Object.entries(r.porBioma).map(([id, b]) => linha(NOME_BIOMA[id] || id, `${b.visitadas}/${b.salas} salas · ${b.coletados}/${b.itens} itens`, (BIOMAS[id] || {}).cor || COR.conhecida)),
      );
    }
    if (salasEl) salasEl.replaceChildren(...Object.entries(ROTA_DAS_SALAS).sort(([, a], [, b]) => a.numero - b.numero).map(([id, rota]) => {
      const sala = game.world?.get(id); const bioma = sala && BIOMAS[sala.biome]; const atual = id === game.roomId;
      const it = el('div', `map-room${atual ? ' atual' : ''}`); it.style.setProperty('--c', bioma?.cor || COR.conhecida);
      const st = game.progress && game.world ? resumoDoMundo(game.world, game.progress).porSala[id] : null; const oculta = rota.tipo === 'segredo' && !st?.visitada;
      const status = !st ? '' : !st.visitada ? ' · não visitada' : st.total === 0 ? ' · visitada' : st.completa ? ' · ✓ completa' : ` · itens ${st.coletados}/${st.total}`;
      const t = el('span'); t.append(el('b', '', oculta ? '???' : (sala ? sala.name : id)), el('small', '', oculta ? 'Segredo ainda não encontrado' : `${rota.papel}${status}`));
      if (st?.completa) it.classList.add('completa');
      it.append(el('span', 'numero', String(rota.numero).padStart(2, '0')), t); return it;
    }));
    if (progEl) progEl.replaceChildren(...progressaoPrincipal(game.progress, game.world, game.roomId).map((e, i) => {
      const it = el('div', `map-step ${e.estado}`); const cor = (BIOMAS[e.id] || {}).cor || COR.chefe; it.style.setProperty('--c', cor);
      const marca = e.estado === 'feito' ? '✔' : e.estado === 'atual' ? '●' : '○'; const t = el('span');
      t.append(el('b', '', `${i + 1}. ${e.nome}`), el('small', '', e.chefe ? `Chefe: ${e.chefe}` : 'Complete os 3 chefes'));
      it.append(el('i', 'marca', marca), t); return it;
    }));
    if (chefesEl) chefesEl.replaceChildren(...estadoDosChefes(game.progress, game.world).map((c) => {
      const it = el('div', `map-boss ${c.estado}`); it.style.setProperty('--c', BIOMAS[c.bioma].cor); const t = el('span');
      const rotulo = { derrotado: 'DERROTADO', encontrado: 'ENCONTRADO', desconhecido: 'DESCONHECIDO' }[c.estado];
      t.append(el('b', '', c.estado === 'desconhecido' ? '???' : c.nome), el('small', '', c.estado === 'desconhecido' ? NOME_BIOMA[c.bioma] : c.dica), el('span', 'estado', rotulo));
      it.append(sw('skull', COR.chefe), t); return it;
    }));
    const atual = game.world?.get(game.roomId); const b = atual && BIOMAS[atual.biome];
    if (foco) foco.textContent = `FOCO ATUAL · ${b ? b.nome : '—'}`;
  }

  /** Resolução do canvas = tamanho real da coluna do mapa (em pixels físicos, até 2x): sem esticar, sem borrar. */
  function ajustarCanvas() {
    const host = canvas.parentElement; const cw = host && host.clientWidth; const ch = host && host.clientHeight;
    if (!cw || !ch) return { W: canvas.width, H: canvas.height, k: 1 };
    const k = Math.max(1, Math.min(2, (win && win.devicePixelRatio) || 1));
    const pw = Math.round(cw * k); const ph = Math.round(ch * k);
    if (canvas.width !== pw || canvas.height !== ph) { canvas.width = pw; canvas.height = ph; }
    return { W: cw, H: ch, k };
  }

  // A vista é independente do desenho: redimensionar ou atualizar o mapa não apaga o zoom do jogador.
  let ultimo = null; let vista = { zoom: 1, panX: 0, panY: 0 };
  function transformacaoBase(lay, W, H, zoom = vista.zoom) {
    const b = lay.bounds; const margem = W < 260 ? 8 : 24;
    const escalaBase = Math.max(0.35, Math.min((W - 2 * margem) / (b.maxX - b.minX), (H - 2 * margem) / (b.maxY - b.minY), 6));
    const escala = escalaBase * zoom;
    return { escala, ox: (W - (b.maxX - b.minX) * escala) / 2 - b.minX * escala, oy: (H - (b.maxY - b.minY) * escala) / 2 - b.minY * escala };
  }
  function limitarVista(lay, W, H) {
    const t = transformacaoBase(lay, W, H); const b = lay.bounds;
    const sobraX = Math.max(0, ((b.maxX - b.minX) * t.escala - W) / 2) + 24;
    const sobraY = Math.max(0, ((b.maxY - b.minY) * t.escala - H) / 2) + 24;
    vista.panX = Math.max(-sobraX, Math.min(sobraX, vista.panX)); vista.panY = Math.max(-sobraY, Math.min(sobraY, vista.panY));
  }
  function zoomNoPonto(novoZoom, px, py) {
    if (!ultimo) return; const mundoX = (px - ultimo.ox) / ultimo.escala; const mundoY = (py - ultimo.oy) / ultimo.escala;
    vista.zoom = Math.max(1, Math.min(4, novoZoom));
    const t = transformacaoBase(ultimo.lay, ultimo.W, ultimo.H);
    vista.panX = px - mundoX * t.escala - t.ox; vista.panY = py - mundoY * t.escala - t.oy;
    limitarVista(ultimo.lay, ultimo.W, ultimo.H);
  }
  function pontoDoCanvas(e) { const r = canvas.getBoundingClientRect?.(); return !r || !r.width ? null : { x: (e.clientX - r.left) * (ultimo.W / r.width), y: (e.clientY - r.top) * (ultimo.H / r.height) }; }
  function desenhar() {
    const { W, H, k } = ajustarCanvas(); const ctx = canvas.getContext('2d');
    ctx.setTransform?.(k, 0, 0, k, 0, 0);
    ctx.imageSmoothingEnabled = false; ctx.fillStyle = '#050a07'; ctx.fillRect(0, 0, W, H);
    const lay = computeMapLayout(game.world, game.progress, game.roomId); limitarVista(lay, W, H);
    const t = transformacaoBase(lay, W, H); const escala = t.escala; const ox = t.ox + vista.panX; const oy = t.oy + vista.panY;
    ultimo = { W, H, ox, oy, escala, lay };
    const tempo = game.metrics.totalSteps / 60 + (win ? win.performance.now() / 1000 : 0);
    const fs = (px) => `${Math.max(7, Math.round(px * Math.min(1, W / 520)))}px sans-serif`;
    for (const r of lay.regioes) {
      const x = ox + r.minX * escala; const y = oy + r.minY * escala; const w = (r.maxX - r.minX) * escala; const h = (r.maxY - r.minY) * escala;
      // Cada bioma vira uma região bem legível, mesmo antes de o jogador explorar as salas.
      ctx.fillStyle = r.fundo; ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = r.cor; ctx.globalAlpha = 0.68; ctx.lineWidth = 2;
      ctx.setLineDash?.([8, 4]); ctx.strokeRect(x, y, w, h); ctx.setLineDash?.([]); ctx.globalAlpha = 1;
      const titulo = r.nome; ctx.font = `bold ${fs(12)}`; const tw = Math.min(w - 12, ctx.measureText(titulo).width + 16);
      ctx.fillStyle = 'rgba(5, 12, 9, .76)'; ctx.fillRect(x + 5, Math.max(4, y + 4), Math.max(56, tw), 18);
      ctx.strokeStyle = r.cor; ctx.globalAlpha = .8; ctx.strokeRect(x + 5, Math.max(4, y + 4), Math.max(56, tw), 18); ctx.globalAlpha = 1;
      ctx.fillStyle = '#e4f1df'; ctx.fillText(titulo, x + 12, Math.max(17, y + 17));
      if (W >= 300) { ctx.fillStyle = 'rgba(220,245,240,.82)'; ctx.font = fs(10); ctx.fillText(r.sub, x + 10, Math.max(30, y + 31)); }
    }
    // Trilhas ficam sob as salas: só os trechos entre portas aparecem como veias do atlas.
    for (const trilha of lay.trilhas) desenharTrilha(ctx, trilha, ox, oy, escala);
    for (const s of lay.salas) {
      const x = ox + s.x * escala; const y = oy + s.y * escala; const w = s.w * escala; const h = s.h * escala;
      if (s.estado === 'visitada') {
        if (!cache.has(s.id)) cache.set(s.id, silhueta(fabrica, game.world.get(s.id), catalog));
        ctx.drawImage(cache.get(s.id), x, y, w, h);
        ctx.strokeStyle = s.atual ? COR.atual : COR.conhecida; ctx.lineWidth = s.atual ? 2 : 1; ctx.strokeRect(x, y, w, h);
        if (s.numero && w >= 16 && h >= 14) { const texto = String(s.numero); ctx.font = `bold ${fs(10)}`; const tw = ctx.measureText(texto).width + 7; ctx.fillStyle = 'rgba(4, 10, 7, .88)'; ctx.fillRect(x + 2, y + 2, tw, 13); ctx.fillStyle = s.atual ? COR.atual : '#d7efe0'; ctx.fillText(texto, x + 5, y + 12); }
        if (w >= 70) { ctx.fillStyle = '#cfe8c8'; ctx.font = fs(11); ctx.fillText(s.name, x + 4, y + 28); }
        if (!s.atual && bancoDaSala(game.progress, s.id) && w >= 22) { ctx.fillStyle = '#7cfc00'; ctx.font = fs(11); ctx.fillText('◆', x + w - 13, y + h - 4); }   // toque para viajar
        for (const m of marcadoresDaSala(game.world.get(s.id), game.progress)) marcador(ctx, ox + (s.x + m.x) * escala, oy + (s.y + m.y) * escala, m.tipo, Math.max(3, escala * 1.1));
      } else {
        ctx.strokeStyle = COR.conhecida; ctx.lineWidth = 1; ctx.setLineDash?.([5, 4]); ctx.strokeRect(x, y, w, h); ctx.setLineDash?.([]);
        ctx.fillStyle = COR.conhecida; ctx.font = '22px sans-serif'; ctx.fillText('?', x + w / 2 - 6, y + h / 2 + 8);
      }
    }
    for (const c of lay.conexoes) {
      const cx = ox + c.x * escala; const cy = oy + c.y * escala; const cw = Math.max(3, c.w * escala); const chh = Math.max(3, c.h * escala);
      ctx.fillStyle = COR_CONEXAO[c.estado]; ctx.fillRect(cx, cy, cw, chh);
      const dest = game.world.get(c.para); const orig = game.world.get(c.sala);
      if (dest && orig && dest.biome !== orig.biome) { ctx.strokeStyle = COR.transicao; ctx.lineWidth = 2; ctx.beginPath?.(); ctx.arc?.(cx + cw / 2, cy + chh / 2, Math.max(5, Math.max(cw, chh) * 0.8), 0, Math.PI * 2); ctx.stroke?.(); }
    }
    const j = playerMapPos(lay, game.roomId, game.player.centerX / game.map.tileSize, game.player.centerY / game.map.tileSize);
    if (j && Math.floor(tempo * 3) % 2 === 0) { ctx.fillStyle = COR.atual; ctx.beginPath?.(); ctx.arc?.(ox + j.x * escala, oy + j.y * escala, 4, 0, Math.PI * 2); ctx.fill?.(); }
    return lay;
  }

  // Arrastar move o atlas, pinçar aproxima e um toque curto numa sala com ◆ faz viagem rápida.
  function ativarSalaNoPonto(p) {
    if (!ultimo || !p) return; const sala = salaNoPonto(ultimo.lay, ultimo.ox, ultimo.oy, ultimo.escala, p.x, p.y); if (!sala || sala === game.roomId) return;
    const id = bancoDaSala(game.progress, sala); if (!id) return; api.close(); game.viajarPara(sala, id);
  }
  const ponteiros = new Map(); let arraste = null; let pinca = null;
  const distancia = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const centro = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
  canvas.addEventListener?.('pointerdown', (e) => {
    if (!aberto || !ultimo) return; const p = pontoDoCanvas(e); if (!p) return; e.preventDefault?.(); canvas.setPointerCapture?.(e.pointerId); ponteiros.set(e.pointerId, p);
    if (ponteiros.size === 1) arraste = { id: e.pointerId, inicio: p, panX: vista.panX, panY: vista.panY, moveu: false };
    else if (ponteiros.size === 2) { const [a, b] = [...ponteiros.values()]; arraste = null; pinca = { distancia: distancia(a, b), zoom: vista.zoom, centro: centro(a, b) }; }
  });
  canvas.addEventListener?.('pointermove', (e) => {
    if (!aberto || !ponteiros.has(e.pointerId)) return; const p = pontoDoCanvas(e); if (!p) return; e.preventDefault?.(); ponteiros.set(e.pointerId, p);
    if (pinca && ponteiros.size === 2) { const [a, b] = [...ponteiros.values()]; const c = centro(a, b); const d = Math.max(1, distancia(a, b)); zoomNoPonto(pinca.zoom * d / Math.max(1, pinca.distancia), c.x, c.y); pinca = { distancia: d, zoom: vista.zoom, centro: c }; desenhar(); return; }
    if (!arraste || arraste.id !== e.pointerId) return;
    const dx = p.x - arraste.inicio.x; const dy = p.y - arraste.inicio.y; if (Math.abs(dx) > 4 || Math.abs(dy) > 4) arraste.moveu = true;
    vista.panX = arraste.panX + dx; vista.panY = arraste.panY + dy; limitarVista(ultimo.lay, ultimo.W, ultimo.H); desenhar();
  });
  const soltarPonteiro = (e) => {
    const p = ponteiros.get(e.pointerId); const toque = arraste && arraste.id === e.pointerId ? arraste : null; ponteiros.delete(e.pointerId);
    if (!ponteiros.size) { arraste = null; pinca = null; if (toque && !toque.moveu) ativarSalaNoPonto(p); return; }
    if (ponteiros.size < 2) { pinca = null; const [id, restante] = [...ponteiros.entries()][0]; arraste = { id, inicio: restante, panX: vista.panX, panY: vista.panY, moveu: true }; }
  };
  for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) canvas.addEventListener?.(ev, soltarPonteiro);
  canvas.addEventListener?.('wheel', (e) => { if (!aberto || !ultimo) return; const p = pontoDoCanvas(e); if (!p) return; e.preventDefault?.(); zoomNoPonto(vista.zoom * (e.deltaY < 0 ? 1.16 : 1 / 1.16), p.x, p.y); desenhar(); }, { passive: false });
  const aoRedimensionar = () => { if (aberto) desenhar(); };
  const api = {
    isOpen: () => aberto, desenhar, layout: () => computeMapLayout(game.world, game.progress, game.roomId),
    open() {
      if (aberto || !game.world || !game.progress) return;
      aberto = true; game.suspended = game.suspended || 'mapa'; game.input.releaseAll(); overlay.classList.remove('hidden');
      montarLegenda();
      if (win) { win.addEventListener('resize', aoRedimensionar); win.addEventListener('orientationchange', aoRedimensionar); }
      desenhar(); if (win) { timer = win.setInterval(desenhar, 200); win.requestAnimationFrame?.(() => desenhar()); }
    },
    close() {
      if (!aberto) return; aberto = false; overlay.classList.add('hidden'); if (win && timer) win.clearInterval(timer); timer = null;
      if (win) { win.removeEventListener('resize', aoRedimensionar); win.removeEventListener('orientationchange', aoRedimensionar); }
      if (game.suspended === 'mapa') game.suspended = null;
    },
    toggle() { if (aberto) api.close(); else api.open(); },
  };
  return api;
}

/** Desenha um marcador pequeno (mesma forma/cor da amostra da legenda). */
function marcador(ctx, x, y, tipo, r) {
  ctx.save?.(); ctx.fillStyle = COR[tipo]; ctx.strokeStyle = '#05090a'; ctx.lineWidth = 1;
  if (tipo === 'item') { ctx.fillRect(x - r / 2, y - r / 2, r, r); ctx.strokeRect(x - r / 2, y - r / 2, r, r); }
  else if (tipo === 'porta') { ctx.strokeStyle = COR.porta; ctx.lineWidth = 2; ctx.strokeRect(x - r / 2, y - r, r, r * 1.6); }
  else {
    ctx.beginPath?.(); ctx.moveTo?.(x, y - r); ctx.lineTo?.(x + r, y); ctx.lineTo?.(x, y + r); ctx.lineTo?.(x - r, y); ctx.closePath?.(); ctx.fill?.(); ctx.stroke?.();
    if (tipo === 'chefe') { ctx.fillStyle = '#ffd0d6'; ctx.fillRect(x - 1, y - 1, 2, 2); }
  }
  ctx.restore?.();
}
