// =====================================================================
// CATÁLOGO NO CANVAS (v1.39.0) — mesma resolução lógica 320×240 do jogo, pensado para toque.
// Cinco abas (Criaturas, Regiões, Mutações, Chefes, Notas), lista à esquerda e detalhe à direita.
// Toque: tocar na aba/linha seleciona · arrastar a lista ou o detalhe rola · setas ▲▼ grandes · X fecha.
// Teclado: ←→ abas · ↑↓ itens · PgUp/PgDn rola o detalhe · Esc/C fecham. Gamepad: direcional · B fecha.
// Entradas ainda não descobertas aparecem como "???" com uma DICA de onde procurar (incentivo a explorar).
// =====================================================================
import { CATEGORIAS, construirCatalogo, resumoDoCatalogo, quebrarTexto } from '../core/diario.js';

const LISTA = { x: 8, y: 48, w: 142, h: 164 }; const LINHA = 22; const VISIVEIS = Math.floor(LISTA.h / LINHA);
const DETALHE = { x: 154, y: 48, w: 158, h: 164 }; const COLS = 31; const ALTURA_LINHA = 9; const LINHAS_DETALHE = Math.floor((DETALHE.h - 22) / ALTURA_LINHA);

/** Estado e regras (sem desenho nem DOM). */
export class CatalogoModel {
  constructor(progress, world) { this.progress = progress; this.world = world; this.aba = 0; this.cursor = 0; this.topo = 0; this.rolagem = 0; this.atualizar(); }
  atualizar() { this.abas = construirCatalogo(this.progress, this.world); this.resumo = resumoDoCatalogo(this.progress, this.world); this._ajustar(); }
  get categoria() { return CATEGORIAS[this.aba]; }
  get itens() { return this.abas[this.categoria.id] || []; }
  get item() { return this.itens[this.cursor] || null; }
  get linhas() { const it = this.item; if (!it) return []; const out = quebrarTexto(it.linhas.join('\n'), COLS); if (it.estado === 'oculto' && it.dica) out.push('', ...quebrarTexto(`Dica: ${it.dica}`, COLS)); return out; }
  get maxRolagem() { return Math.max(0, this.linhas.length - LINHAS_DETALHE); }
  mudarAba(d) { this.aba = (this.aba + d + CATEGORIAS.length) % CATEGORIAS.length; this.cursor = 0; this.topo = 0; this.rolagem = 0; }
  irParaAba(i) { if (i >= 0 && i < CATEGORIAS.length) { this.aba = i; this.cursor = 0; this.topo = 0; this.rolagem = 0; } }
  mover(d) { const n = this.itens.length; if (!n) return; this.cursor = Math.max(0, Math.min(n - 1, this.cursor + d)); this.rolagem = 0; this._ajustar(); }
  selecionar(i) { if (i >= 0 && i < this.itens.length) { this.cursor = i; this.rolagem = 0; this._ajustar(); } }
  rolarLista(linhas) { this.topo = Math.max(0, Math.min(Math.max(0, this.itens.length - VISIVEIS), this.topo + linhas)); }
  rolarDetalhe(linhas) { this.rolagem = Math.max(0, Math.min(this.maxRolagem, this.rolagem + linhas)); }
  _ajustar() { const n = this.itens.length; this.cursor = Math.max(0, Math.min(Math.max(0, n - 1), this.cursor)); if (this.cursor < this.topo) this.topo = this.cursor; if (this.cursor >= this.topo + VISIVEIS) this.topo = this.cursor - VISIVEIS + 1; this.topo = Math.max(0, Math.min(Math.max(0, n - VISIVEIS), this.topo)); }
}

export class CanvasCatalogo {
  constructor({ canvas, renderer, config }) {
    this.canvas = canvas; this.renderer = renderer; this.config = config; this.open = false; this.modelo = null; this.aoFechar = null;
    this._abasRects = []; this._linhasRects = []; this._fechar = null; this._setas = []; this._arrasto = null;
    this._onDown = (e) => this._down(e); this._onMove = (e) => this._move(e); this._onUp = () => this._soltou(); this._onKey = (e) => this._key(e);
    canvas.addEventListener?.('pointerdown', this._onDown); canvas.addEventListener?.('pointermove', this._onMove);
    canvas.addEventListener?.('pointerup', this._onUp); canvas.addEventListener?.('pointercancel', this._onUp);
    (typeof window !== 'undefined' ? window : null)?.addEventListener?.('keydown', this._onKey);
  }

  abrir({ progress, world, aoFechar = null }) {
    this.modelo = new CatalogoModel(progress, world); this.aoFechar = aoFechar; this.open = true;
    this.canvas.setAttribute?.('aria-label', 'Catálogo aberto. Setas navegam, Esc fecha.');
  }
  fechar() {
    if (!this.open) return; const fim = this.aoFechar; this.open = false; this.modelo = null; this.aoFechar = null; this._arrasto = null;
    this.canvas.setAttribute?.('aria-label', 'Área do jogo LIMO'); fim?.();
  }

  _key(e) {
    if (!this.open) return; const c = e.code; const m = this.modelo;
    if (['ArrowLeft', 'KeyA'].includes(c)) m.mudarAba(-1); else if (['ArrowRight', 'KeyD'].includes(c)) m.mudarAba(1);
    else if (['ArrowUp', 'KeyW'].includes(c)) m.mover(-1); else if (['ArrowDown', 'KeyS'].includes(c)) m.mover(1);
    else if (c === 'PageUp') m.rolarDetalhe(-4); else if (c === 'PageDown') m.rolarDetalhe(4);
    else if (['Escape', 'KeyC', 'KeyX', 'Backspace'].includes(c)) { if (e.repeat) { e.preventDefault?.(); return; } this.fechar(); } else return;
    e.preventDefault?.();
  }

  _pos(e) { const r = this.canvas.getBoundingClientRect(); return { x: (e.clientX - r.left) * this.config.render.internalWidth / r.width, y: (e.clientY - r.top) * this.config.render.internalHeight / r.height }; }
  static _dentro(p, r) { return r && p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h; }

  _down(e) {
    if (!this.open) return; e.preventDefault?.(); const p = this._pos(e); const m = this.modelo; const D = CanvasCatalogo._dentro;
    if (D(p, this._fechar)) { this.fechar(); return; }
    const a = this._abasRects.findIndex((r) => D(p, r)); if (a >= 0) { m.irParaAba(a); return; }
    const s = this._setas.find((r) => D(p, r)); if (s) { m.mover(s.d); return; }
    if (D(p, LISTA)) { this._arrasto = { alvo: 'lista', y0: p.y, topo0: m.topo, mexeu: false, linha: this._linhasRects.findIndex((r) => D(p, r)) }; return; }
    if (D(p, DETALHE)) this._arrasto = { alvo: 'detalhe', y0: p.y, rol0: m.rolagem, mexeu: false };
  }
  _move(e) {
    if (!this.open || !this._arrasto) return; const p = this._pos(e); const a = this._arrasto; const m = this.modelo; const dy = p.y - a.y0;
    if (Math.abs(dy) > 4) a.mexeu = true; if (!a.mexeu) return;
    if (a.alvo === 'lista') { m.topo = a.topo0; m.rolarLista(-Math.round(dy / LINHA)); } else { m.rolagem = a.rol0; m.rolarDetalhe(-Math.round(dy / ALTURA_LINHA)); }
  }
  /** Soltar sem arrastar = toque: seleciona a linha. (Feito no pointerup para o arrasto não selecionar sem querer.) */
  _soltou() { const a = this._arrasto; this._arrasto = null; if (a?.alvo === 'lista' && !a.mexeu && a.linha >= 0) this.modelo.selecionar(this.modelo.topo + a.linha); }

  aoGamepad(info) {
    if (!this.open || !info?.pressed) return; const p = info.pressed; const m = this.modelo;
    if (p.has(14)) m.mudarAba(-1); if (p.has(15)) m.mudarAba(1); if (p.has(12)) m.mover(-1); if (p.has(13)) m.mover(1); if (p.has(1)) this.fechar();
  }

  draw(ctx) {
    if (!this.open || !this.modelo) return; const m = this.modelo; const { internalWidth: W, internalHeight: H } = this.config.render;
    ctx.save(); ctx.fillStyle = 'rgba(2, 2, 3, 0.92)'; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#8a8577'; ctx.fillRect(3, 3, W - 6, H - 6); ctx.fillStyle = '#0d0d0e'; ctx.fillRect(4, 4, W - 8, H - 8);
    // cabeçalho
    ctx.textAlign = 'left'; ctx.font = 'bold 11px monospace'; ctx.fillStyle = '#ece6d6'; ctx.fillText('CATÁLOGO DO ORGANISMO', 10, 20);
    ctx.font = '7px monospace'; ctx.fillStyle = '#b9b3a2'; ctx.fillText(`${m.resumo.achados}/${m.resumo.total} descobertas · ${m.resumo.percent}%`, 10, 31);
    ctx.fillStyle = '#050505'; ctx.fillRect(10, 34, 150, 4); ctx.fillStyle = '#8a8577'; ctx.fillRect(10, 34, Math.round(150 * m.resumo.percent / 100), 4);
    this._fechar = { x: W - 34, y: 8, w: 26, h: 22 };
    ctx.fillStyle = '#2a1a1d'; ctx.fillRect(this._fechar.x, this._fechar.y, 26, 22); ctx.fillStyle = '#8e5a58'; ctx.fillRect(this._fechar.x, this._fechar.y, 26, 2);
    ctx.textAlign = 'center'; ctx.font = 'bold 11px monospace'; ctx.fillStyle = '#ece6d6'; ctx.fillText('X', this._fechar.x + 13, this._fechar.y + 15);
    // abas (cada uma ≥ 60×18 px lógicos)
    this._abasRects = []; const aw = Math.floor((W - 16) / CATEGORIAS.length);
    CATEGORIAS.forEach((c, i) => {
      const r = { x: 8 + i * aw, y: 40, w: aw - 2, h: 18 }; this._abasRects.push(r); const sel = i === m.aba; const rs = m.resumo.porAba[c.id];
      ctx.fillStyle = sel ? '#8a8577' : '#1c1b19'; ctx.fillRect(r.x, r.y, r.w, r.h); ctx.fillStyle = sel ? '#0d0d0e' : '#b9b3a2'; ctx.font = 'bold 7px monospace';
      ctx.fillText(c.nome, r.x + r.w / 2, r.y + 8); ctx.font = '6px monospace'; ctx.fillText(`${rs.achados}/${rs.total}`, r.x + r.w / 2, r.y + 15);
    });
    // lista
    const L = { x: LISTA.x, y: LISTA.y + 12, w: LISTA.w, h: LISTA.h - 24 }; this._linhasRects = []; this._setas = [];
    ctx.fillStyle = '#090909'; ctx.fillRect(LISTA.x, LISTA.y, LISTA.w, LISTA.h);
    const vis = Math.floor(L.h / LINHA);
    this._setas.push({ x: LISTA.x, y: LISTA.y, w: LISTA.w, h: 12, d: -1 }, { x: LISTA.x, y: LISTA.y + LISTA.h - 12, w: LISTA.w, h: 12, d: 1 });
    ctx.fillStyle = '#8a8577'; ctx.font = '8px monospace'; ctx.textAlign = 'center'; ctx.fillText(m.topo > 0 ? '▲' : '·', LISTA.x + LISTA.w / 2, LISTA.y + 9); ctx.fillText(m.topo + vis < m.itens.length ? '▼' : '·', LISTA.x + LISTA.w / 2, LISTA.y + LISTA.h - 3);
    ctx.save(); ctx.beginPath(); ctx.rect(L.x, L.y, L.w, L.h); ctx.clip();
    m.itens.slice(m.topo, m.topo + vis).forEach((it, k) => {
      const y = L.y + k * LINHA; const sel = m.topo + k === m.cursor; this._linhasRects.push({ x: L.x, y, w: L.w, h: LINHA });
      ctx.fillStyle = sel ? '#2a2926' : (k % 2 ? '#0c0c0c' : '#121211'); ctx.fillRect(L.x, y, L.w, LINHA - 1); if (sel) { ctx.fillStyle = '#ffe69a'; ctx.fillRect(L.x, y, 2, LINHA - 1); }
      const cor = it.estado === 'completo' ? '#ffe69a' : it.estado === 'visto' ? '#cfc9b8' : '#5e5a50';
      ctx.fillStyle = cor; ctx.textAlign = 'left'; ctx.font = 'bold 8px monospace'; ctx.fillText(it.estado === 'completo' ? '●' : it.estado === 'visto' ? '◐' : '○', L.x + 5, y + 10);
      ctx.fillStyle = it.estado === 'oculto' ? '#7b766a' : '#ece6d6'; ctx.fillText(this._cortar(it.titulo, 18), L.x + 15, y + 10);
      ctx.font = '6px monospace'; ctx.fillStyle = '#8f8a7c'; ctx.fillText(this._cortar(it.sub || (it.estado === 'oculto' ? 'não descoberto' : ''), 26), L.x + 15, y + 18);
    });
    ctx.restore();
    // detalhe
    ctx.fillStyle = '#090909'; ctx.fillRect(DETALHE.x, DETALHE.y, DETALHE.w, DETALHE.h); const it = m.item;
    ctx.textAlign = 'left';
    if (it) {
      ctx.font = 'bold 9px monospace'; ctx.fillStyle = it.estado === 'oculto' ? '#7b766a' : '#ece6d6'; ctx.fillText(this._cortar(it.titulo, 25), DETALHE.x + 5, DETALHE.y + 12);
      ctx.fillStyle = '#8a8577'; ctx.fillRect(DETALHE.x + 5, DETALHE.y + 16, DETALHE.w - 10, 1);
      ctx.font = '7px monospace'; const ls = m.linhas; const ini = m.rolagem;
      for (let i = 0; i < LINHAS_DETALHE; i++) { const t = ls[ini + i]; if (t === undefined) break; ctx.fillStyle = t.startsWith('—') ? '#ffd27a' : t.startsWith('Dica:') ? '#f0b07a' : '#cfc9b8'; ctx.fillText(t, DETALHE.x + 5, DETALHE.y + 28 + i * ALTURA_LINHA); }
      if (ini > 0) { ctx.fillStyle = '#8a8577'; ctx.textAlign = 'right'; ctx.fillText('▲', DETALHE.x + DETALHE.w - 4, DETALHE.y + 26); }
      if (ini < m.maxRolagem) { ctx.fillStyle = '#8a8577'; ctx.textAlign = 'right'; ctx.fillText('▼', DETALHE.x + DETALHE.w - 4, DETALHE.y + DETALHE.h - 3); }
    } else { ctx.font = '7px monospace'; ctx.fillStyle = '#7b766a'; ctx.fillText('Nada aqui ainda.', DETALHE.x + 5, DETALHE.y + 14); }
    ctx.textAlign = 'center'; ctx.font = '6px monospace'; ctx.fillStyle = '#8f8a7c'; ctx.fillText('toque nas abas e itens · arraste para rolar · X fecha', W / 2, H - 10);
    ctx.restore();
  }
  _cortar(t, n) { t = String(t || ''); return t.length > n ? t.slice(0, n - 1) + '…' : t; }
}
