// =====================================================================
// MUNDO VIVO (v1.38.0) — fachada: um objeto por sala que reúne os quatro sistemas.
//   ecossistema + esporelitos (vida-eco.js) · segredos + murais (segredos.js) · atmosfera (atmosfera.js)
// O Game cria um por sala (`game.vivo`), chama `atualizar` uma vez por quadro e o Renderer só LÊ o estado.
// Nada aqui mexe em física, colisão (exceto os tiles falsos que o próprio segredo abre) ou dano.
// =====================================================================
import { Ecossistema, Esporelitos, criarRng, hashTexto, nivelDeVida } from './vida-eco.js';
import { Segredos, Murais } from './segredos.js';
import { Atmosfera, pulsarLuzes } from './atmosfera.js';

export { nivelDeVida, pulsarLuzes };

export class MundoVivo {
  /**
   * @param o {mapa, roomData, progress|null, reacao|null, nivel, solido(x,y), onSegredo(def), onMural(def,n,total), lightRadius}
   */
  constructor({ mapa, roomData, progress = null, reacao = null, nivel = 2, solido = () => false, onSegredo = null, onMural = null, onRastro = null, lightRadius = 70 }) {
    const id = roomData?.id || 'sala'; const semente = hashTexto(id);
    this.nivel = nivel; this.ts = mapa.tileSize; this.salaId = id; this.bioma = roomData?.biome || 'raizes'; this.lightRadius = lightRadius;
    this.segredos = new Segredos({ mapa, salaId: id, progress, onDescobrir: onSegredo, onRastro, rng: criarRng(semente ^ 0x51) });   // segredos funcionam em qualquer nível
    this.murais = new Murais({ salaId: id, progress, ts: mapa.tileSize, oculta: (tx, ty) => this.segredos.oculta(tx, ty), onDescobrir: onMural });
    this.ecossistema = reacao ? new Ecossistema(reacao, { rng: criarRng(semente), nivel }) : null;
    this.ecossistema?._classificar();
    this._foco = { cx: 0, cy: 0, vx: 0, vy: 0 }; this._focoAtivo = false;   // v2.1
    this.esporelitos = new Esporelitos(mapa, this.ecossistema?.orgs || [], { rng: criarRng(semente ^ 0x9e37), nivel, solido });
    this.atmosfera = new Atmosfera(this.bioma, { rng: criarRng(semente ^ 0x2545), nivel });
  }

  /** v2.1 · ponto de atenção do ecossistema (centro em coordenadas do mundo). Sem alocação: reaproveita o mesmo objeto. */
  definirFoco(cx, cy) { this._foco.cx = cx; this._foco.cy = cy; this._focoAtivo = true; }
  limparFoco() { this._focoAtivo = false; }

  /** @param jogador {x,y,w,h,vx,vy}  @param vista {x,y,w,h}  @param fx LuzesFx  @param respira 0..1 */
  atualizar(dt, jogador, vista, t, fx = null, respira = 0) {
    const cx = jogador.x + jogador.w / 2; const cy = jogador.y + jogador.h / 2; const j = { cx, cy, vx: jogador.vx, vy: jogador.vy };
    this.segredos.atualizar(dt, jogador, vista, this.atmosfera.emCurso ? 1 : 0);   // v1.47.0: o evento raro revela o rastro dos segredos
    this.murais.atualizar(dt, j, this.lightRadius);
    if (!this.nivel) return;
    this.ecossistema?.atualizar(dt, this._focoAtivo ? this._foco : j, vista, fx, respira);   // v2.1: com foco (a Jardineira falando), as plantas se viram para ela
    this.esporelitos.atualizar(dt, t, j, vista);
    this.atmosfera.atualizar(dt, vista, fx);
  }

  /** Esconde o que está dentro de câmara secreta ainda fechada (itens, luz, mural). */
  oculta(tx, ty) { return this.segredos.oculta(tx, ty); }
}
