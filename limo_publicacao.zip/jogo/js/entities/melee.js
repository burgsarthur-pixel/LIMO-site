// =====================================================================
// ATAQUE BÁSICO — golpe corpo a corpo de Limo, em combo de 3 (jab, jab, golpe forte).
// Lógica pura (sem DOM): pressionar ataca; apertar de novo na janela encadeia o próximo golpe.
//  fases de cada golpe: inicio (anúncio) → ativo (hitbox) → fim (recuperação) → idle (janela de combo)
// Cada golpe acerta cada inimigo no máximo UMA vez; paredes bloqueiam o golpe; dano, morte, investida,
// puxão da Tendril, pausa e troca de sala cancelam com segurança.
// =====================================================================
import { linhaBloqueada } from './tendril.js';

export const MELEE_DEFAULTS = {
  buffer: 0.18,          // s: um aperto feito um pouco cedo ainda vale
  janelaCombo: 0.32,     // s após o golpe para encadear o próximo
  recargaFinal: 0.28,    // s de recuperação depois do 3º golpe
  passos: [
    { dano: 1, alcance: 22, altura: 18, inicio: 0.05, ativo: 0.08, fim: 0.10, empurrao: 90, impacto: [0.035, 2] },
    { dano: 1, alcance: 24, altura: 18, inicio: 0.04, ativo: 0.08, fim: 0.12, empurrao: 110, impacto: [0.04, 2.5] },
    { dano: 2, alcance: 32, altura: 24, inicio: 0.08, ativo: 0.12, fim: 0.20, empurrao: 190, impacto: [0.07, 4] },
  ],
  // Golpes direcionais (inspirados no ataque de pulo de Hollow Knight): ↑ + ataque golpeia para cima;
  // ↓ + ataque, NO AR, golpeia para baixo e, ao acertar algo (inimigo, parede rachada ou espinho), faz Limo quicar.
  direcionais: {
    cima:  { dano: 1, alcance: 26, largura: 20, inicio: 0.04, ativo: 0.09, fim: 0.10, empurrao: 80, impacto: [0.035, 2], recarga: 0.06 },
    baixo: { dano: 1, alcance: 26, largura: 20, inicio: 0.03, ativo: 0.10, fim: 0.09, empurrao: 60, impacto: [0.035, 2], recarga: 0.04, pogo: 235 },
  },
};

export class MeleeCombo {
  constructor(config = {}) {
    const c = config.melee || {};
    this.config = { ...MELEE_DEFAULTS, ...c, direcionais: { ...MELEE_DEFAULTS.direcionais, ...(c.direcionais || {}) } };
    this.events = []; this.reset();
  }

  reset() {
    this.passo = -1; this.fase = 'idle'; this.t = 0; this.dir = 1; this.acertados = new Set();
    this.buffer = 0; this.janela = 0; this.bloqueio = 0; this.pedido = false;
    this.direcao = 'frente'; this.pogou = false;   // 'frente' | 'cima' | 'baixo'
  }
  cancelar() { this.reset(); }
  /** Avisa o jogo (uma vez por golpe) que o golpe para baixo acertou algo e Limo deve quicar. */
  _pogo(onPogo, c) { if (this.direcao !== 'baixo' || this.pogou) return; this.pogou = true; onPogo?.(c.pogo ?? 235); }
  drenarEventos() { const e = this.events; this.events = []; return e; }
  /** Para o HUD: true enquanto o golpe está em andamento ou na recuperação final. */
  get ocupado() { return this.fase !== 'idle' || this.bloqueio > 0; }
  get direcional() { return this.direcao !== 'frente'; }
  get cfgPasso() { return this.direcional ? this.config.direcionais[this.direcao] : this.config.passos[Math.max(0, this.passo)]; }

  /** Retângulo do golpe (só existe na fase ativa): cobre o corpo de Limo e `alcance` px à frente. */
  hitbox(player) {
    if (this.fase !== 'ativo') return null;
    const c = this.cfgPasso; const b = player.body;
    if (this.direcao === 'cima') return { x: b.x + b.w / 2 - c.largura / 2, y: b.y - c.alcance, w: c.largura, h: c.alcance + b.h / 2 };
    if (this.direcao === 'baixo') return { x: b.x + b.w / 2 - c.largura / 2, y: b.y + b.h / 2, w: c.largura, h: c.alcance + b.h / 2 };
    return { x: this.dir > 0 ? b.x : b.x - c.alcance, y: b.y + b.h / 2 - c.altura / 2, w: b.w + c.alcance, h: c.altura };
  }

  _iniciar(player, n, input = null) {
    const cima = !!input?.isDown?.('up'); const baixo = !!input?.isDown?.('down') && !player.onGround;   // golpe para baixo só existe no ar
    this.direcao = cima ? 'cima' : baixo ? 'baixo' : 'frente';
    if (this.direcional) n = 0;   // golpes direcionais não entram no combo de 3
    this.passo = n; this.fase = 'inicio'; this.t = 0; this.buffer = 0; this.janela = 0; this.pedido = false; this.acertados.clear(); this.pogou = false;
    this.dir = player.facing === -1 ? -1 : 1; this.events.push(`golpe${this.direcao === 'baixo' ? 1 : n}`);
    player.squash?.kick?.(1.5 + n * 0.5);
  }

  update(dt, ctx = {}) {
    const { player, input, mapa, enemies = [], paredes = [], paused = false, transition = false, onHit = null, onParede = null, onPogo = null } = ctx;
    const vivo = !!player && player.life > 0 && player.state !== 'dead';
    const tem = player?.hasAbility ? !!player.hasAbility('pseudopode') : true;   // Limo começa fraco: o golpe é uma mutação adquirida
    const pode = vivo && tem && !paused && !transition && !player.dashing && !(player.hurtTimer > 0) && !player.tendrilPulling;
    if (!pode) { if (this.fase !== 'idle' || this.passo >= 0 || this.buffer > 0 || this.pedido) this.cancelar(); this.bloqueio = 0; return; }

    this.buffer = Math.max(0, this.buffer - dt);
    if (input?.wasPressed?.('attack')) {   // durante um golpe (que não é o último) o pedido espera o fim dele; fora disso vale por um instante
      if (this.fase !== 'idle' && this.passo < this.config.passos.length - 1) this.pedido = true; else this.buffer = this.config.buffer;
    }
    this.bloqueio = Math.max(0, this.bloqueio - dt);

    if (this.fase === 'idle') {
      this.janela = Math.max(0, this.janela - dt);
      if (this.janela <= 0 && this.passo >= 0 && this.bloqueio <= 0) this.passo = -1;   // janela do combo expirou
      if (this.buffer > 0 && this.bloqueio <= 0) this._iniciar(player, this.passo >= 0 && this.janela > 0 ? this.passo + 1 : 0, input);
      if (this.fase === 'idle') return;
    }

    const c = this.cfgPasso; this.t += dt;
    if (this.fase === 'inicio' && this.t >= c.inicio) this.fase = 'ativo';
    if (this.fase === 'ativo') {
      const h = this.hitbox(player);
      for (const en of enemies) {
        if (!en.alive || this.acertados.has(en) || en.hurtTimer > 0) continue;
        const b = en.body; if (!(h.x < b.x + b.w && h.x + h.w > b.x && h.y < b.y + b.h && h.y + h.h > b.y)) continue;
        if (linhaBloqueada(mapa, { x: player.centerX, y: player.centerY }, { x: b.x + b.w / 2, y: b.y + b.h / 2 })) continue;   // parede no meio
        this.acertados.add(en);
        const r = en.receberGolpe ? en.receberGolpe({ dano: c.dano, origemX: player.centerX, empurrao: c.empurrao, tipo: 'golpe', passo: this.passo })
          : { resultado: 'dano', morreu: !!en.takeHit(c.dano, player.centerX, c.empurrao) };
        const morreu = !!r.morreu;
        onHit?.(en, morreu, this.passo, c, r.resultado);
        this._pogo(onPogo, c);
      }
      for (const w of paredes) {   // paredes rachadas: cada golpe pode rachar cada parede uma vez
        if (this.acertados.has(w)) continue; const r = w.body;
        if (!(h.x < r.x + r.w && h.x + h.w > r.x && h.y < r.y + r.h && h.y + h.h > r.y)) continue;
        this.acertados.add(w); onParede?.(w, this.passo, c);
        this._pogo(onPogo, c);
      }
      if (this.direcao === 'baixo' && !this.pogou && mapa?.forEachCollidable) {   // espinhos também fazem Limo quicar
        let espinho = false;
        mapa.forEachCollidable(h.x, h.y, h.w, h.h, (cel) => { if (cel.kind === 'damage') espinho = true; });
        if (espinho) { onHit?.(null, false, this.passo, c); this._pogo(onPogo, c); }
      }
      if (this.t >= c.inicio + c.ativo) this.fase = 'fim';
    }
    if (this.fase === 'fim' && this.t >= c.inicio + c.ativo + c.fim) {
      this.fase = 'idle'; this.t = 0;
      if (this.direcional) { this.bloqueio = this.cfgPasso.recarga ?? 0.05; this.passo = -1; this.direcao = 'frente'; this.buffer = this.pedido ? this.config.buffer : 0; }
      else if (this.passo >= this.config.passos.length - 1) { this.passo = -1; this.bloqueio = this.config.recargaFinal; this.buffer = 0; }   // fim do combo
      else { this.janela = this.config.janelaCombo; if (this.pedido) this.buffer = this.config.buffer; }   // aperto feito no meio do golpe encadeia já
      this.pedido = false;
    }
  }
}
