// =====================================================================
// GENES — equipamentos passivos (referência de design: os Amuletos de Hollow Knight).
// O Limo encontra genes pelo mundo e só os TROCA descansando num Casulo de Repouso (o checkpoint). Cada gene ocupa
// ENCAIXES; o total de encaixes é limitado, então é preciso escolher o que equipar.
// O catálogo tem 15 ESPAÇOS (a tela de genes mostra os 15); hoje só 3 têm gene de verdade — os outros 12 estão
// reservados. Para criar um gene novo: preencha um espaço reservado (nome, desc, custo, cor, efeito, implementado: true)
// e coloque uma entidade { type: 'gene', gene: '<id>' } numa sala (o editor tem a ferramenta 🧬 Gene).
// Lógica pura (sem DOM).
// =====================================================================

export const ENCAIXES_BASE = 4;          // encaixes disponíveis no começo do jogo
export const TOTAL_ESPACOS = 15;

/** Efeitos suportados (todos opcionais em cada gene). Somam (extras) ou multiplicam (Mul) entre os genes equipados. */
export const MODIFICADORES_PADRAO = Object.freeze({
  invulnExtra: 0,        // s a mais de invulnerabilidade depois de levar dano
  dashCooldownMul: 1,    // × recuperação da investida
  dashSpeedMul: 1,       // × velocidade da investida
  focoTempoMul: 1,       // × tempo para o foco curar (menor = mais rápido)
});

const reservado = (slot) => Object.freeze({
  slot, id: `gene_${String(slot).padStart(2, '0')}`, nome: '???', desc: 'Um espaço ainda vazio no genoma.', custo: 1, cor: '#4a4a56', efeito: {}, implementado: false,
});

export const GENES = Object.freeze([
  Object.freeze({
    slot: 1, id: 'membrana_reativa', nome: 'Membrana Reativa', custo: 1, cor: '#5fe0c4', implementado: true,
    desc: 'A pele endurece depois de um golpe: +0,6 s de invulnerabilidade ao levar dano.',
    efeito: Object.freeze({ invulnExtra: 0.6 }),
  }),
  Object.freeze({
    slot: 2, id: 'sinapse_veloz', nome: 'Sinapse Veloz', custo: 2, cor: '#ffd23f', implementado: true,
    desc: 'Nervos em brasa: a investida é 15% mais rápida e se recupera em menos da metade do tempo.',
    efeito: Object.freeze({ dashCooldownMul: 0.4, dashSpeedMul: 1.15 }),
  }),
  Object.freeze({
    slot: 3, id: 'glandula_de_seiva', nome: 'Glândula de Seiva', custo: 2, cor: '#ff7aa8', implementado: true,
    desc: 'A seiva circula depressa: o foco cura em 30% menos tempo.',
    efeito: Object.freeze({ focoTempoMul: 0.7 }),
  }),
  ...Array.from({ length: TOTAL_ESPACOS - 3 }, (_, i) => reservado(i + 4)),
]);

export const GENE_IDS = GENES.map((g) => g.id);
export const geneDe = (id) => GENES.find((g) => g.id === id) || null;
export const geneImplementado = (id) => !!geneDe(id)?.implementado;

/** Junta os efeitos dos genes equipados num objeto de modificadores (ids desconhecidos/reservados são ignorados). */
export function calcularModificadores(ids = []) {
  const m = { ...MODIFICADORES_PADRAO };
  for (const id of ids) {
    const g = geneDe(id); if (!g || !g.implementado) continue;
    const e = g.efeito || {};
    if (e.invulnExtra) m.invulnExtra += e.invulnExtra;
    if (e.dashCooldownMul) m.dashCooldownMul *= e.dashCooldownMul;
    if (e.dashSpeedMul) m.dashSpeedMul *= e.dashSpeedMul;
    if (e.focoTempoMul) m.focoTempoMul *= e.focoTempoMul;
  }
  return m;
}

export function encaixesUsados(ids = []) { return ids.reduce((n, id) => n + (geneDe(id)?.custo || 0), 0); }

// ---------------------------------------------------------------------
// RESSONÂNCIA: passagens (e, no futuro, outros obstáculos) que só abrem com um gene EQUIPADO naquele momento.
// Diferente de `requires` (mutação permanente): trocar o gene fecha de novo.
// ---------------------------------------------------------------------
/** `requerGene` aceita um id, uma lista de ids ou vazio. */
export function normalizeRequerGene(v) { return v == null || v === '' ? [] : (Array.isArray(v) ? v : [v]).filter((x) => typeof x === 'string' && x); }

/** Confere os genes equipados contra `requerGene`. Devolve { ok, missing: [ids que faltam] }. */
export function checkGenes(equipados = [], requerGene) {
  const missing = normalizeRequerGene(requerGene).filter((id) => !equipados.includes(id));
  return { ok: missing.length === 0, missing };
}

export const nomeDoGene = (id) => geneDe(id)?.nome || id;
