// =====================================================================
// SEGREDOS E MURAIS (v1.38.0) — lógica pura, sem DOM.
//
// SEGREDOS: câmaras escondidas (dados em js/world/vida-dados.js, aplicadas nas salas por tools/segredos_organicos.mjs).
//   "toque"  a câmara é feita de tiles FALSOS (parecem rocha, mas collision "none"). Encostar neles revela: os tiles somem
//            (dissolvem em 0,6 s) e o que estava lá dentro (recompensas, mural) aparece. Nenhuma colisão nova é criada.
//   "parede" a boca é uma parede rachada (paredeFragil, já existente): quando cede, a câmara se revela.
//   Dicas para quem observa: fiapos de esporo vazam da boca (só com o Limo por perto) e uma fresta de luz respira na rocha falsa.
// MURAIS: pinturas de pictogramas. Ficam quase invisíveis no escuro e se revelam na luz do Limo; ficar perto por 0,6 s as
//   "descobre" (uma vez, guardado no save) e mostra uma frase curta + quantos já foram achados. Sem diálogo.
// O estado persiste em progress.collected (chaves "sala:segredo_<id>" e "sala:mural_<id>"): nenhum campo novo no save.
// =====================================================================
import { chaveItem } from '../core/progress.js';
import { segredos as segredosDaSala, murais as muraisDaSala, MURAIS, chaveMural, IDS_FALSOS } from '../world/vida-dados.js';
import { PAINEL } from '../world/vestigios.js';

export const RAIO_RASTRO = 360;
const FALSOS = new Set(IDS_FALSOS);
const dentro = (r, tx, ty) => tx >= r.x && tx < r.x + r.w && ty >= r.y && ty < r.y + r.h;
const sobrepoe = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

export class Segredos {
  /** @param o {mapa, salaId, progress|null, lista?, onDescobrir(def), rng} */
  constructor({ mapa, salaId, progress = null, lista = segredosDaSala(salaId), onDescobrir = null, onRastro = null, rng = Math.random }) {
    this.onRastro = onRastro; this.rastro = 0; this._rastroVisto = false;
    this.mapa = mapa; this.salaId = salaId; this.progress = progress; this.onDescobrir = onDescobrir; this.rng = rng;
    this.mem = new Set();   // sem progresso (editor/expedição): lembra só nesta sessão
    this.itens = lista.map((def) => ({ def, aberto: false, tempo: 0 }));
    this.dissolvendo = []; this.fiapos = [];
    for (const s of this.itens) { if (this._jaDescoberto(s.def)) this._abrir(s, false); }
  }

  _chave(def) { return chaveItem(this.salaId, `segredo_${def.id}`); }
  _jaDescoberto(def) {
    const c = this.progress?.collected ?? this.mem;
    return c.has(this._chave(def)) || (def.modo === 'parede' && c.has(chaveItem(this.salaId, def.parede.id)));
  }

  /** Esta célula está dentro de uma câmara ainda escondida? (esconde itens, murais e luz de dentro) */
  oculta(tx, ty) { return this.itens.some((s) => !s.aberto && dentro(s.def.camara, tx, ty)); }
  get fechados() { return this.itens.filter((s) => !s.aberto); }

  /** Troca os tiles falsos por ar. `efeito` guarda o desenho antigo para dissolver. */
  _abrir(s, efeito = true) {
    s.aberto = true; const m = this.mapa;
    for (const r of s.def.falsos) for (let y = r.y; y < r.y + r.h; y++) for (let x = r.x; x < r.x + r.w; x++) {
      const id = m.getTileId('solid', x, y); if (!FALSOS.has(id)) continue;
      if (efeito) this.dissolvendo.push({ x, y, id, v: m.getVariant('solid', x, y), t: 0 });
      m.setTileId('solid', x, y, 0);
    }
  }

  descobrir(s) {
    if (s.aberto) return false;
    this._abrir(s, true);
    (this.progress?.collected ?? this.mem).add(this._chave(s.def));
    this.onDescobrir?.(s.def);
    return true;
  }

  /** O jogo avisa quando uma paredeFragil cede. */
  paredeQuebrada(id) { for (const s of this.itens) if (!s.aberto && s.def.modo === 'parede' && s.def.parede.id === id) this.descobrir(s); }

  /** @param corpo {x,y,w,h} do Limo  @param vista {x,y,w,h}  @param cx,cy centro do Limo */
  atualizar(dt, corpo, vista, rastro = 0) {
    this.rastro = rastro;   // v1.47.0 (Etapa 5): durante um evento ambiental o corpo do Deus "denuncia" as câmaras fechadas (mais fiapos, de mais longe)
    const ts = this.mapa.tileSize;
    for (const s of this.itens) {
      if (s.aberto) continue; const d = s.def;
      if (d.modo === 'toque') for (const r of d.falsos) if (sobrepoe(corpo, { x: r.x * ts, y: r.y * ts, w: r.w * ts, h: r.h * ts })) { this.descobrir(s); break; }
    }
    for (let i = this.dissolvendo.length - 1; i >= 0; i--) { this.dissolvendo[i].t += dt; if (this.dissolvendo[i].t > 0.6) this.dissolvendo.splice(i, 1); }
    // dicas: fiapos que vazam da boca, só com o Limo por perto
    const cx = corpo.x + corpo.w / 2; const cy = corpo.y + corpo.h / 2;
    for (const s of this.itens) {
      if (s.aberto) continue; const e = this.emissor(s.def, ts);
      const dist = Math.hypot(cx - e.x, cy - e.y); if (dist > (rastro ? RAIO_RASTRO : 150)) continue;
      if (rastro && dist <= 150 && !this._rastroVisto) { this._rastroVisto = true; this.onRastro?.(s.def); }
      if ((s.tempo -= dt) <= 0 && this.fiapos.length < (rastro ? 14 : 8)) { s.tempo = (1.4 + this.rng() * 1.8) * (rastro ? 0.35 : 1); this.fiapos.push({ x: e.x + (this.rng() - 0.5) * e.w, y: e.y + (this.rng() - 0.5) * e.h, vx: e.dir * (4 + this.rng() * 6), vy: -(5 + this.rng() * 7), vida: 2.2, max: 2.2, fase: this.rng() * 6.28 }); }
    }
    for (let i = this.fiapos.length - 1; i >= 0; i--) { const f = this.fiapos[i]; f.vida -= dt; if (f.vida <= 0) { this.fiapos.splice(i, 1); continue; } f.fase += dt * 3; f.x += (f.vx + Math.sin(f.fase) * 4) * dt; f.y += f.vy * dt; }
  }

  /** Ponto de vazamento da dica (px) e a direção do vazamento (rumo ao ar livre). */
  emissor(def, ts) {
    if (def.modo === 'parede') { const p = def.parede; return { x: (p.x + p.w / 2) * ts, y: (p.y + p.h / 2) * ts, w: p.w * ts, h: p.h * ts, dir: def.boca.x < p.x ? -1 : 1 }; }
    const dir = def.camara.x < def.boca.x ? -1 : 1;   // rumo à câmara; o vazamento sai para o lado oposto
    return { x: (def.boca.x + 0.5 + dir * 0.5) * ts, y: (def.boca.y + 0.5) * ts, w: 2, h: ts * 0.8, dir: -dir };
  }

  /** Frestas de luz que "respiram" na rocha falsa (para o desenho): só secretos fechados do modo toque. */
  frestas(ts) {
    return this.fechados.filter((s) => s.def.modo === 'toque').map((s) => { const e = this.emissor(s.def, ts); const x = e.dir > 0 ? e.x - 2 : e.x; return { x, y: e.y - 4, h: 8, dir: e.dir }; });
  }
}

export class Murais {
  /** @param o {salaId, progress|null, oculta(tx,ty), ts, onDescobrir(def, n, total)} */
  constructor({ salaId, progress = null, oculta = () => false, ts = 16, onDescobrir = null, lista = muraisDaSala(salaId) }) {
    this.salaId = salaId; this.progress = progress; this.oculta = oculta; this.ts = ts; this.onDescobrir = onDescobrir; this.mem = new Set();
    this.lista = lista.map((def) => ({ def, vis: 0, dwell: 0, achado: (progress?.collected ?? this.mem).has(chaveItem(salaId, chaveMural(def.id))), rect: { x: def.x * ts, y: def.y * ts, w: PAINEL.w * ts / 16, h: PAINEL.h * ts / 16 } }));
  }

  /** Quantos murais o jogador já achou no jogo todo. */
  static contar(progress) { let n = 0; for (const k of progress?.collected || []) if (k.includes(':mural_')) n++; return n; }

  atualizar(dt, jogador, raioLuz = 72) {
    for (const m of this.lista) {
      const escondido = this.oculta(m.def.x, m.def.y);
      const cx = m.rect.x + m.rect.w / 2; const cy = m.rect.y + m.rect.h / 2; const d = Math.hypot(jogador.cx - cx, jogador.cy - cy);
      const alvo = escondido ? 0 : Math.max(0, Math.min(1, 1 - (d - 24) / Math.max(1, raioLuz - 24)));
      m.vis += (alvo - m.vis) * Math.min(1, dt * 4);
      if (m.achado || escondido) continue;
      m.dwell = m.vis > 0.85 ? m.dwell + dt : Math.max(0, m.dwell - dt);
      if (m.dwell >= 0.6) {
        m.achado = true; (this.progress?.collected ?? this.mem).add(chaveItem(this.salaId, chaveMural(m.def.id)));
        this.onDescobrir?.(m.def, this.progress ? Murais.contar(this.progress) : 1, MURAIS.length);
      }
    }
  }
}
