// =====================================================================
// FOCO — cura por material biológico (referência de design: o "Foco" de Hollow Knight).
// Golpear inimigos enche o medidor de MATERIAL BIOLÓGICO; segurar o botão de foco, parado no chão,
// converte `custo` de material em `cura` de vida ao fim de `tempo` segundos.
// Lógica pura (sem DOM). Qualquer interrupção (dano, andar, pular, atacar, investida, Tendril, pausa,
// troca de sala) cancela o foco SEM gastar material: o risco é ficar parado e vulnerável.
// =====================================================================
export const FOCO_DEFAULTS = {
  materialMax: 9,     // capacidade do medidor (3 curas)
  custo: 3,           // material gasto por cura
  tempo: 0.9,         // s segurando o botão até curar
  cura: 1,            // vida devolvida por foco
  ganhoPorDano: 1,    // material ganho por ponto de dano causado (golpe forte = 2)
  pausaEntre: 0.12,   // s entre um foco e o seguinte (se o botão continuar apertado)
  tique: 0.3,         // s entre os sons de carga
};

export class Foco {
  constructor(config = {}) {
    this.config = { ...FOCO_DEFAULTS, ...(config.foco || {}) };
    this.tempoMul = 1;   // genes: × tempo para curar (ver entities/genes.js)
    this.events = []; this.reset();
  }
  reset() { this.material = 0; this.ativo = false; this.t = 0; this.flash = 0; this.pausa = 0; this._tique = 0; }
  drenarEventos() { const e = this.events; this.events = []; return e; }

  /** Progresso do foco em andamento, de 0 a 1 (para o desenho). */
  get tempo() { return this.config.tempo * this.tempoMul; }
  get progresso() { return this.ativo ? Math.min(1, this.t / this.tempo) : 0; }
  get cheio() { return this.material >= this.config.materialMax; }
  /** Há material suficiente para pelo menos uma cura? */
  get pronto() { return this.material >= this.config.custo; }

  /** Chamado quando um golpe acerta um inimigo. Devolve quanto material realmente entrou. */
  ganhar(dano = 1) {
    const antes = this.material;
    this.material = Math.min(this.config.materialMax, this.material + Math.max(0, dano) * this.config.ganhoPorDano);
    return this.material - antes;
  }

  cancelar(motivo = '') {
    if (!this.ativo) return;
    this.ativo = false; this.t = 0; this._tique = 0; this.events.push('focoCancela');
    void motivo;
  }

  update(dt, ctx = {}) {
    const { player, input, melee = null, paused = false, transition = false, onCura = null } = ctx;
    this.flash = Math.max(0, this.flash - dt); this.pausa = Math.max(0, this.pausa - dt);
    const vivo = !!player && player.life > 0 && player.state !== 'dead';
    const bloqueado = !vivo || paused || transition || player.dashing || player.hurtTimer > 0 || player.tendrilPulling || !!melee?.ocupado;
    const precisa = vivo && player.life < player.maxLife;
    const c = this.config;

    if (!bloqueado && precisa && input?.wasPressed?.('foco') && !this.pronto) this.events.push('focoVazio');   // apertou sem material

    const pode = !bloqueado && precisa && !!player.onGround && this.pronto
      && !!input?.isDown?.('foco') && !input.isDown('jump') && input.axisX() === 0;
    if (!pode) { this.cancelar(); return; }
    if (!this.ativo) {
      if (this.pausa > 0) return;
      this.ativo = true; this.t = 0; this._tique = 0; this.events.push('focoInicio');
    }
    this.t += dt; this._tique += dt;
    if (this._tique >= c.tique) { this._tique -= c.tique; this.events.push('focoCarga'); }
    if (this.t >= this.tempo) {
      this.material -= c.custo;
      player.life = Math.min(player.maxLife, player.life + c.cura);
      this.ativo = false; this.t = 0; this._tique = 0; this.pausa = c.pausaEntre; this.flash = 0.4;
      this.events.push('focoCura'); onCura?.(c.cura);
    }
  }
}
