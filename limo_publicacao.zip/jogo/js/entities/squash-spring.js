// =====================================================================
// MOLA DE DEFORMAÇÃO (gelatina): valor > 0 = esticado na vertical, < 0 = achatado.
// "Chutamos" a mola no pulo/aterrissagem/dano e ela volta sozinha para 0.
// É só visual: não altera a física nem a hitbox.
// =====================================================================
export class SquashSpring {
  constructor(rigidez = 90, amortecimento = 14) {
    this.rigidez = rigidez; 
    this.amortecimento = amortecimento;
    this.value = 0; 
    this.velocity = 0;
  }
  
  kick(forca) { 
    this.velocity += forca; 
  }
  
  update(dt) {
    const aceleracao = -this.rigidez * this.value - this.amortecimento * this.velocity;
    this.velocity += aceleracao * dt;
    this.value += this.velocity * dt;
    
    if (this.value > 0.6) this.value = 0.6;
    if (this.value < -0.6) this.value = -0.6;
  }
}
