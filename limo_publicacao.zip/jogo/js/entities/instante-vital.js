// =====================================================================
// INSTANTE VITAL (v1.40.0) — ao CONCLUIR uma cura por Foco, o mundo desacelera por um instante.
// Lógica pura (sem DOM). O jogo lê `escala` (1 = velocidade normal) e multiplica o dt do MUNDO
// (inimigos, ecologia, ambiente, esfíncteres, fungos, orbes). O dt do JOGADOR nunca é multiplicado:
// controles, golpe, foco e câmera seguem na velocidade normal. Não toca em vida, invulnerabilidade nem dano.
// Curva: desce até `escalaMinima` em `entrada`, segura, e volta a 1 em `saida` (smoothstep nas duas rampas).
// =====================================================================
export const INSTANTE_DEFAULTS = {
  duracao: 0.7,         // s totais (v1.40.2: 220 ms ficava imperceptível)
  escalaMinima: 0.15,   // velocidade do mundo no ponto mais lento (0.15 = 15%)
  entrada: 0.06,        // s de descida até a escala mínima
  saida: 0.25,          // s de volta à velocidade normal
};

const suave = (u) => { const x = Math.max(0, Math.min(1, u)); return x * x * (3 - 2 * x); };

export class InstanteVital {
  constructor(config = {}) {
    this.config = { ...INSTANTE_DEFAULTS, ...(config.instanteVital || config || {}) };
    this.ligado = true; this.reset();
  }
  reset() { this.t = 0; this.ativo = false; }

  /** Começa (ou reinicia) o instante. Devolve false se desligado. */
  iniciar() {
    if (!this.ligado) return false;
    this.t = 0; this.ativo = true; return true;
  }

  /** Avança no tempo REAL (dt do jogo). */
  update(dt) {
    if (!this.ativo) return;
    this.t += Math.max(0, dt);
    if (this.t >= this.config.duracao) this.reset();
  }

  /** Fator de velocidade do mundo agora: 1 fora do instante; entre escalaMinima e 1 durante. */
  get escala() {
    if (!this.ativo) return 1;
    const c = this.config; const min = Math.max(0.05, Math.min(1, c.escalaMinima));
    const entrada = Math.max(1e-4, c.entrada); const saida = Math.max(1e-4, c.saida);
    const fimSegura = Math.max(entrada, c.duracao - saida);
    if (this.t < entrada) return 1 - (1 - min) * suave(this.t / entrada);
    if (this.t < fimSegura) return min;
    return min + (1 - min) * suave((this.t - fimSegura) / saida);
  }

  /** 0..1: quanto o efeito está "forte" (para o desenho de feedback). */
  get intensidade() { return this.ativo ? (1 - this.escala) / Math.max(1e-4, 1 - this.config.escalaMinima) : 0; }
}
