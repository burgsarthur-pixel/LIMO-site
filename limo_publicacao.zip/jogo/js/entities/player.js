// =====================================================================
// JOGADOR (Limo)
// =====================================================================
import { moveBody, probeGround, probeDamage, createContacts } from '../world/collision.js';
import { SquashSpring } from './squash-spring.js';
import { ParticleSystem } from './particles.js';

import { MODIFICADORES_PADRAO } from './genes.js';

function approach(atual, alvo, passo) {
  if (atual < alvo) return Math.min(atual + passo, alvo);
  return Math.max(atual - passo, alvo);
}

export class Player {
  constructor(config, logger = null) {
    this.config = config; this.logger = logger;
    this.body = { x: 0, y: 0, w: config.player.hitbox.w, h: config.player.hitbox.h };
    this.abilities = config.abilities.initial; 
    this.squash = new SquashSpring();
    this.particles = new ParticleSystem();
    this.contacts = createContacts();
    this.genes = { ...MODIFICADORES_PADRAO };   // efeitos dos genes equipados (o Game atualiza)
    this.onDamage = null; this.onDeath = null;
    this.godMode = false; this.noclip = false;
    this.reset(0, 0);
  }

  reset(x, y) {
    this.tendrilPulling = false; this.launchT = 0; this.recuoT = 0; this.resets = (this.resets || 0) + 1;   // a animação de surgimento observa isto
    const hb = this.config.player.hitbox;
    this.body.x = x; this.body.y = y; this.body.w = hb.w; this.body.h = hb.h;
    this.vx = 0; this.vy = 0; this.facing = 1;
    this.state = 'idle';
    this.maxLife = this.config.player.maxLife; this.life = this.maxLife;
    this.invuln = 0; this.hurtTimer = 0;
    this.dashing = false; this.dashTimer = 0; this.dashCooldown = 0; this.airDashesLeft = this.config.dash.airDashes;
    this.coyote = 0; this.jumpBuffer = 0; this.jumpHeldSinceStart = false;
    this.airJumpsLeft = this.config.abilities.saltoElastico?.extraJumps || 1;
    this.onGround = false; this.groundInfo = null; this.dropThroughTimer = 0;
    this.safeTimer = 0; this.lastSafe = { x, y };
    this.squash.value = 0; this.squash.velocity = 0;
    this.membranaCooldown = 0; this.membranaFlash = 0;
    this.particles.reset();
    this.contacts = createContacts();
    this.wallCoyoteLeft = 0;
    this.wallCoyoteRight = 0;
    this.airJumpFx = 0; this.squidFx = 0; this.legGrow = 0; this.wallSide = 0; // patas brotando na parede (0..1) e de que lado
  }

  teleport(x, y) { this.body.x = x; this.body.y = y; this.vx = 0; this.vy = 0; }
  get centerX() { return this.body.x + this.body.w / 2; }
  get centerY() { return this.body.y + this.body.h / 2; }

  get trail() { return this.particles.trail; }
  get landingParticles() { return this.particles.landing; }
  get wallParticles() { return this.particles.wall; }
  get gooParticles() { return this.particles.goo; }
  get bolhaParticles() { return this.particles.bolhas; }
  get faiscaParticles() { return this.particles.faiscas; }
  get anelParticles() { return this.particles.aneis; }

  hasAbility(id) {
    if (!this.abilities) return false;
    if (Array.isArray(this.abilities)) return this.abilities.includes(id);
    if (typeof this.abilities === 'object') return !!this.abilities[id];
    return false;
  }

  update(dt, input, mapa) {
    const cfg = this.config; const ph = cfg.physics;
    this._tickTimers(dt);
    this.squash.update(dt);
    this.membranaFlash = Math.max(0, this.membranaFlash - dt);

    this.squidFx = Math.max(0, (this.squidFx || 0) - dt);
    if (this.airJumpFx > 0) { this.airJumpFx -= dt; this.particles.spawnAirJump(this.body.x, this.body.y, this.body.w, this.body.h); }
    if (this.dashing) {
      this.particles.spawnDash(this.body.x, this.body.y, this.body.w, this.body.h, this.facing, this.onGround);
    }

    const touchingWallActive = (this.contacts.left || this.contacts.right) && !this.onGround;
    const wallSlidingActive = touchingWallActive && this.vy > 0;

    if (touchingWallActive) {
      if (this.contacts.left) this.wallCoyoteLeft = 0.12;
      if (this.contacts.right) this.wallCoyoteRight = 0.12;
    }

    // Patas de aranha: brotam rápido ao encostar na parede e recolhem ao soltar
    if (this.hasAbility('wallJump') && touchingWallActive) { this.legGrow = Math.min(1, this.legGrow + dt / 0.14); this.wallSide = this.contacts.left ? -1 : 1; }
    else this.legGrow = Math.max(0, this.legGrow - dt / 0.1);

    if (wallSlidingActive && Math.random() < 0.4) {
      const wallDir = this.contacts.left ? -1 : 1;
      this.particles.spawnWallSlide(wallDir, this.body.x, this.body.y, this.body.h);
    }

    this.particles.update(dt);

    if (this.life <= 0) { this._updateDead(dt, mapa); return; }
    if (this.noclip) { this._updateNoclip(dt, input); return; }
    // Pendurado na Tendril: sem gravidade nem andar sozinho; o controlador move o corpo pelas colisões. Pulo/investida cancelam e agem.
    if (this.tendrilPulling && !input.wasPressed('jump') && !input.wasPressed('dash')) {
      const ex = input.axisX(); if (ex !== 0) this.facing = ex;   // velocidade é do controlador da Tendril (mola/pêndulo)
      this.dashing = false; this.onGround = !!this.contacts.down; this._updateState(); return;
    }

    const eixo = input.axisX();
    const ferido = this.hurtTimer > 0;
    const recuando = (this.recuoT || 0) > 0; if (recuando) this.recuoT = Math.max(0, this.recuoT - dt);   // impacto da investida: sem controle horizontal por um instante
    const lancado = (this.launchT || 0) > 0; if (lancado) this.launchT = Math.max(0, this.launchT - dt);   // arremesso da Tendril: sem atrito por um instante

    if (input.wasPressed('jump')) this.jumpBuffer = ph.jumpBufferTime;
    if (this.onGround) this.coyote = ph.coyoteTime;

    const temInvestida = this.hasAbility('investida');
    if (!ferido && !recuando && temInvestida && !this.dashing && input.wasPressed('dash')
        && this.dashCooldown <= 0 && (this.onGround || this.airDashesLeft > 0)) {
      this._startDash();
    }

    if (this.dashing) {
      this.vx = this.facing * cfg.dash.speed * this.genes.dashSpeedMul; this.vy = 0;
    } else if (recuando && !ferido) {
      this.vx = approach(this.vx, 0, ph.deceleration * 0.35 * dt);
    } else if (!ferido) {
      const atrito = this.onGround && this.groundInfo ? this.groundInfo.tile.friction : 1;
      const controle = this.onGround ? 1 : ph.airControl;
      if (eixo !== 0) {
        this.facing = eixo;
        const virando = this.vx * eixo < 0;
        if (!(lancado && !virando && Math.abs(this.vx) > ph.maxSpeed)) this.vx = approach(this.vx, eixo * ph.maxSpeed, ph.acceleration * controle * atrito * (virando ? ph.turnMultiplier : 1) * dt);
      } else if (!(lancado && !this.onGround)) {
        this.vx = approach(this.vx, 0, ph.deceleration * controle * atrito * dt);
      }
    } else {
      this.vx = approach(this.vx, 0, ph.deceleration * 0.25 * dt);
    }

    let pulouNoChao = false; let desceu = false;   // desceu = atravessou a plataforma neste quadro (o MESMO aperto de pulo não pode virar pulo duplo)
    if (!this.dashing && !ferido) {
      const querDescer = input.isDown('down') && this.onGround && this.groundInfo && this.groundInfo.kind === 'oneway';
      
      if (this.jumpBuffer > 0 && querDescer) {
        this.dropThroughTimer = ph.dropThroughTime; this.jumpBuffer = 0; this.onGround = false; this.coyote = 0; desceu = true;
      } else if (this.jumpBuffer > 0 && this.coyote > 0) {
        this.vy = -ph.jumpSpeed; this.coyote = 0; this.jumpBuffer = 0;
        this.onGround = false; this.groundInfo = null;
        this.jumpHeldSinceStart = input.isDown('jump');
        this.squash.kick(3); pulouNoChao = true;
      } else if (this.hasAbility('wallJump') && this.jumpBuffer > 0 && (this.wallCoyoteLeft > 0 || this.wallCoyoteRight > 0)) {
        const canLeft = this.wallCoyoteLeft > 0;
        const wallDir = canLeft ? 1 : -1;
        this.vx = wallDir * ph.maxSpeed * 1.2;
        this.vy = -ph.jumpSpeed * 0.95;
        this.facing = wallDir;
        this.jumpBuffer = 0;
        this.wallCoyoteLeft = 0;
        this.wallCoyoteRight = 0;
        this.jumpHeldSinceStart = true;
        this.squash.kick(3.5);
      }
    }

    // --- Salto Elástico (mutação): pulo extra no ar ---
    if (!pulouNoChao && !desceu && !ferido && !this.dashing && this.hasAbility('saltoElastico') && input.wasPressed('jump')
        && !this.onGround && this.coyote <= 0 && this.airJumpsLeft > 0 && !this._pertoDoChao(mapa)) {
      this.vy = -ph.jumpSpeed * cfg.abilities.saltoElastico.speedFactor; this.airJumpsLeft--; this.jumpBuffer = 0; this.airJumpFx = 0.18; this.squidFx = 0.5; this.particles.spawnTinta(this.body.x, this.body.y, this.body.w, this.body.h);
      this.jumpHeldSinceStart = input.isDown('jump'); this.squash.kick(4);
      this.logger?.debug('habilidades', `Salto Elástico usado (restam ${this.airJumpsLeft}).`);
    }

    if (this.jumpHeldSinceStart && this.vy < 0 && !input.isDown('jump')) { this.vy *= ph.jumpCutFactor; this.jumpHeldSinceStart = false; }
    if (this.vy >= 0) this.jumpHeldSinceStart = false;

    if (!this.dashing) {
      const touchingWall = (this.contacts.left || this.contacts.right) && !this.onGround;
      const wallSliding = touchingWall && this.vy > 0;
      const g = ph.gravity * (this.vy > 0 ? ph.fallGravityMultiplier : 1);
      
      if (wallSliding) {
        this.vy = Math.min(this.vy + g * dt, 70); 
      } else {
        this.vy = Math.min(this.vy + g * dt, ph.maxFallSpeed);
      }
    }

    const atravessar = this.dropThroughTimer > 0;
    moveBody(mapa, this.body, this.vx * dt, this.vy * dt, { dropThrough: atravessar }, this.contacts);
    if (this.contacts.left || this.contacts.right) { this.vx = 0; if (this.dashing) this._endDash('parede'); }
    if (this.contacts.up && this.vy < 0) this.vy = 0;
    const vyAoChegar = this.vy;
    if (this.contacts.down && this.vy > 0) this.vy = 0;

    const maxX = mapa.pixelWidth - this.body.w;
    if (this.body.x < 0) { this.body.x = 0; this.vx = 0; }
    if (this.body.x > maxX) { this.body.x = maxX; this.vx = 0; }

    const estavaNoChao = this.onGround;
    this.groundInfo = probeGround(mapa, this.body, atravessar);
    this.onGround = !!this.groundInfo && this.vy >= 0;
    if (!this.onGround) this.groundInfo = null;
    if (this.onGround) {
      this.airDashesLeft = cfg.dash.airDashes;
      this.airJumpsLeft = cfg.abilities.saltoElastico?.extraJumps || 1;
      if (!estavaNoChao) {
        this.squash.kick(-Math.min(4.5, vyAoChegar / 70));
        this.particles.spawnLanding(this.centerX, this.body.y + this.body.h, vyAoChegar);
      }
    }

    const perigo = probeDamage(mapa, this.body);
    if (perigo) {
      if (this.hasAbility('membrana') && this.membranaCooldown <= 0) {
        this.membranaCooldown = 2.4; this.membranaFlash = 0.32;
        this.squash.kick(1.5);
        this.particles.spawnMembrana(this.centerX, this.body.y + this.body.h / 2);   // onda roxa + estilhaços (só visual)
        this.logger?.info('habilidades', 'A Membrana absorveu o contato com espinhos.');
      } else this.takeDamage(perigo.tile.damage, perigo.x + perigo.w / 2);
    }

    if (this.body.y > mapa.pixelHeight + cfg.player.voidMargin) this._fellIntoVoid();

    if (this.onGround && !perigo && this.groundInfo.kind === 'solid' && this._peApoiado(mapa)) {
      this.safeTimer += dt;
      if (this.safeTimer >= cfg.player.safeSpotDelay) this.lastSafe = { x: this.body.x, y: this.body.y };
    } else this.safeTimer = 0;

    this._updateState();
  }

  _pertoDoChao(mapa) {
    if (this.vy <= 0) return false;
    const adiante = Math.min(24, this.vy * this.config.physics.jumpBufferTime);
    return !!probeGround(mapa, { x: this.body.x, y: this.body.y + adiante, w: this.body.w, h: this.body.h }, false);
  }

  _tickTimers(dt) {
    this.invuln = Math.max(0, this.invuln - dt);
    this.hurtTimer = Math.max(0, this.hurtTimer - dt);
    this.membranaCooldown = Math.max(0, this.membranaCooldown - dt);
    this.dashCooldown = Math.max(0, this.dashCooldown - dt);
    this.dropThroughTimer = Math.max(0, this.dropThroughTimer - dt);
    this.jumpBuffer = Math.max(0, this.jumpBuffer - dt);
    if (!this.onGround) this.coyote = Math.max(0, this.coyote - dt);
    
    this.wallCoyoteLeft = Math.max(0, this.wallCoyoteLeft - dt);
    this.wallCoyoteRight = Math.max(0, this.wallCoyoteRight - dt);

    if (this.dashing) { this.dashTimer -= dt; if (this.dashTimer <= 0) this._endDash('fim'); }
  }

  _startDash() {
    const d = this.config.dash;
    this.dashing = true; this.dashTimer = d.duration;
    this.vx = this.facing * d.speed * this.genes.dashSpeedMul; this.vy = 0;
    if (!this.onGround) this.airDashesLeft--;
    this.squash.kick(-2);
    this.logger?.debug('combate', `Investida iniciada (${this.facing > 0 ? 'direita' : 'esquerda'}${this.onGround ? '' : ', no ar'}).`);
  }

  /** Impacto da investida contra um inimigo: a investida acaba NA HORA (não atravessa mais) e o Limo é jogado para trás. */
  recuarDaInvestida(fator = 1) {
    const d = this.config.dash; const dir = -this.facing;   // facing ainda é o sentido da investida
    if (this.dashing) this._endDash('impacto');
    this.vx = dir * d.recoilSpeed * fator; this.vy = -d.recoilLift * fator;
    this.recuoT = d.recoilTime; this.onGround = false; this.groundInfo = null;
    this.squash.kick(-2.5);
    this.logger?.debug('combate', 'Impacto da investida: Limo recua.');
  }

  _endDash(motivo) {
    if (!this.dashing) return;
    this.dashing = false; this.dashTimer = 0;
    this.dashCooldown = this.config.dash.cooldown * this.genes.dashCooldownMul;
    this.vx = motivo === 'fim' ? this.facing * this.config.physics.maxSpeed * this.config.dash.exitSpeedFactor : 0;
    this.invuln = Math.max(this.invuln, 0.25);
    this.logger?.debug('combate', `Investida terminou (${motivo}).`);
  }

  _peApoiado(mapa) {
    const m = this.config.player.safeSpotMargin;
    const y = this.body.y + this.body.h + 1;
    return mapa.isSolidPoint(this.body.x - m, y) && mapa.isSolidPoint(this.body.x + this.body.w + m, y)
      && mapa.isSolidPoint(this.centerX, y);
  }

  takeDamage(quantidade, origemX = null, opcoes = {}) {
    if (this.life <= 0 || this.godMode) return false;
    if (this.invuln > 0 && !opcoes.force) return false;
    const cfg = this.config.player;
    this.life = Math.max(0, this.life - quantidade);
    this.invuln = cfg.invulnerability + this.genes.invulnExtra; this.hurtTimer = cfg.hurtTime;
    if (this.dashing) this._endDash('dano');
    if (!opcoes.noKnockback) {
      const dir = origemX == null ? -this.facing : (this.centerX >= origemX ? 1 : -1);
      this.vx = dir * cfg.knockbackX; this.vy = -cfg.knockbackY; this.onGround = false; this.groundInfo = null;
    }
    this.squash.kick(-2);
    this.logger?.info('combate', `Jogador levou ${quantidade} de dano (vida ${this.life}/${this.maxLife}).`);
    this.onDamage?.(this, quantidade);
    if (this.life <= 0) {
      this.state = 'dead'; this.vx = 0; this.dashing = false;
      this.logger?.info('combate', 'Jogador dissolvido.');
      this.onDeath?.(this);
    }
    return true;
  }

  heal() { this.life = this.maxLife; this.state = this.life > 0 && this.state === 'dead' ? 'idle' : this.state; }

  _fellIntoVoid() {
    this.logger?.warn('fisica', 'Jogador caiu no vazio: voltando à última posição segura.');
    this.takeDamage(1, null, { force: true, noKnockback: true });
    if (this.life > 0) { this.teleport(this.lastSafe.x, this.lastSafe.y); this.invuln = this.config.player.invulnerability; }
  }

  _updateDead(dt, mapa) {
    this.vx = 0;
    this.vy = Math.min(this.vy + this.config.physics.gravity * dt, this.config.physics.maxFallSpeed);
    moveBody(mapa, this.body, 0, this.vy * dt, {}, this.contacts);
    if (this.contacts.down) this.vy = 0;
    this.state = 'dead';
  }

  _updateNoclip(dt, input) {
    const v = this.config.physics.maxSpeed * 1.6;
    this.vx = input.axisX() * v;
    this.vy = ((input.isDown('down') ? 1 : 0) - (input.isDown('jump') || input.isDown('up') ? 1 : 0)) * v;
    if (this.vx !== 0) this.facing = Math.sign(this.vx);
    this.body.x += this.vx * dt; this.body.y += this.vy * dt;
    this.onGround = false; this.groundInfo = null; this.state = 'noclip';
  }

  _updateState() {
    if (this.life <= 0) this.state = 'dead';
    else if (this.hurtTimer > 0) this.state = 'hurt';
    else if (this.dashing) this.state = 'dashing';
    else if (!this.onGround) this.state = this.vy < 0 ? 'jumping' : 'falling';
    else this.state = Math.abs(this.vx) > 8 ? 'running' : 'idle';
  }
}
