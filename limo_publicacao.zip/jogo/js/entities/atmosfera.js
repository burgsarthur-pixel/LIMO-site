// =====================================================================
// ATMOSFERA DINÂMICA (v1.38.0) — lógica pura, sem DOM. Cada bioma tem seu clima:
//   raizes  poeira do teto cai em fiapos de tempos em tempos (o corpo velho se acomoda); a luz bate com o coração (lub-dub)
//   jardim  rajada de esporos atravessa a tela; névoa verde-azulada baixa; a luz respira devagar; gotas acendem ao cair
//   nucleo  descarga: um anel de energia expande e a sala acende por um instante; a luz tem tremor rápido
// Névoa = bancos baixos e largos (o desenho está em render/vida-art.js). Partículas: pool pequeno e fixo (Android).
// =====================================================================
import { criarRng } from './vida-eco.js';

export const CLIMA = Object.freeze({
  raizes: { nevoa: { n: 2, cor: [196, 150, 104], a: 0.055, vel: 3, y: 0.80 }, evento: { tipo: 'poeira', cada: [14, 28] }, pulsoLuz: { batida: 0.35, respira: 0, tremor: 0 } },
  jardim: { nevoa: { n: 3, cor: [90, 230, 200], a: 0.075, vel: 5, y: 0.84 }, evento: { tipo: 'rajada', cada: [16, 30] }, pulsoLuz: { batida: 0, respira: 0.30, tremor: 0 } },
  nucleo: { nevoa: { n: 2, cor: [170, 110, 240], a: 0.060, vel: -4, y: 0.72 }, evento: { tipo: 'descarga', cada: [10, 22] }, pulsoLuz: { batida: 0.25, respira: 0.1, tremor: 0.08 } },
});
/** v1.47.0 (Etapa 4): evento RARO por bioma (além do comum). `dur` = quanto tempo ele fica "em curso" (gancho da Etapa 5: o rastro de segredo só aparece durante um). */
export const EVENTOS_RAROS = Object.freeze({
  raizes: { tipo: 'desabamento', cada: [70, 130], dur: 5, aviso: 'O teto estremece: o corpo do Deus se acomoda.' },
  jardim: { tipo: 'florada', cada: [80, 140], dur: 7, aviso: 'As lanternas florescem todas de uma vez.' },
  nucleo: { tipo: 'apagao', cada: [60, 110], dur: 3, aviso: 'O coração falha um instante. A sala escurece.' },
});
export const climaDoBioma = (b) => CLIMA[b] || CLIMA.raizes;

/** Luzes de decoração que batem com o corpo do Deus: devolve NOVAS luzes (as de entrada não são alteradas). */
export function pulsarLuzes(luzes, { bioma, pulso = 0, respira = 0, t = 0, escuro = 0 }) {
  const c = climaDoBioma(bioma).pulsoLuz;
  return luzes.map((l) => {
    const k = (1 - escuro) * (1 + c.batida * pulso + c.respira * (respira - 0.5) * 2 + c.tremor * Math.sin(t * 7.3 + (l.semente || 0)));
    return { ...l, intensidade: l.intensidade * k, raio: l.raio * (1 + 0.12 * (k - 1)) };
  });
}

export class Atmosfera {
  constructor(bioma, { rng = criarRng(5), nivel = 2 } = {}) {
    this.bioma = bioma; this.clima = climaDoBioma(bioma); this.rng = rng; this.nivel = nivel;
    this.max = nivel >= 2 ? 40 : 18; this.p = []; this.aneis = []; this.carga = 0;
    this.espera = this._sorteio(); this.eventos = 0;
    this.rara = EVENTOS_RAROS[bioma] || EVENTOS_RAROS.raizes; this.esperaRara = this._sorteioRaro(); this.emCurso = null; this.raros = 0; this.aviso = null;   // v1.47.0
  }
  _sorteioRaro() { const [a, b] = this.rara.cada; return a + this.rng() * (b - a); }
  /** 0..1: quanto as luzes de decoração escurecem agora (apagão do Núcleo; entra e sai suave). */
  get escuro() { const e = this.emCurso; if (!e || e.tipo !== 'apagao') return 0; const k = e.t / e.dur; return 0.55 * Math.min(1, k * 6, (1 - k) * 4); }
  _sorteio() { const [a, b] = this.clima.evento.cada; return a + this.rng() * (b - a); }

  /** Bancos de névoa em coordenadas de TELA: [{x,y,w,h,a}]. Deriva devagar e dá a volta; parallax 0,5. */
  bancos(t, camX, W, H) {
    if (!this.nivel) return []; const c = this.clima.nevoa; const n = this.nivel >= 2 ? c.n : Math.max(1, c.n - 1); const span = W + 220; const out = [];
    for (let i = 0; i < n; i++) {
      const x = ((((i * 131 + t * c.vel - camX * 0.5) % span) + span) % span) - 110;
      out.push({ x, y: c.y * H - i * 9 + Math.sin(t * 0.3 + i * 2) * 4, w: 160 + i * 30, h: 34, a: c.a * (0.75 + 0.25 * Math.sin(t * 0.4 + i)) });
    }
    return out;
  }

  /** Uma gota do teto encostou no chão: o jardim e o núcleo acendem o ponto por um instante. */
  respingo(x, y, fx = null) {
    if (!this.nivel || this.bioma === 'raizes') return;
    const cor = this.bioma === 'jardim' ? [120, 255, 220] : [200, 150, 255];
    fx?.add?.({ x, y: y - 2, raio: 14, cor, dur: 0.22, intens: 0.35 });
  }

  _add(q) { if (this.p.length < this.max) this.p.push(q); }

  atualizar(dt, vista, fx = null) {
    if (!this.nivel) return; const rng = this.rng;
    if ((this.espera -= dt) <= 0) { this.espera = this._sorteio(); this._disparar(vista, fx); }
    if (this.emCurso) { this.emCurso.t += dt; if (this.emCurso.t >= this.emCurso.dur) this.emCurso = null; }
    if ((this.esperaRara -= dt) <= 0) { this.esperaRara = this._sorteioRaro(); this._dispararRaro(vista, fx); }
    if (this.carga > 0) {   // rajada de esporos: sai pela borda esquerda aos poucos
      const n = Math.min(this.carga, Math.ceil(10 * dt + rng())); this.carga -= n;
      for (let i = 0; i < n; i++) this._add({ x: vista.x - 6, y: vista.y + vista.h * (0.25 + rng() * 0.7), vx: 40 + rng() * 30, vy: -3 + rng() * 6, vida: 3.4, max: 3.4, tam: 1 + (rng() < 0.3 ? 1 : 0), cor: rng() < 0.7 ? [120, 255, 226] : [255, 230, 110], fase: rng() * 6.28, onda: 5 });
    }
    for (let i = this.p.length - 1; i >= 0; i--) {
      const q = this.p[i]; q.vida -= dt; if (q.vida <= 0) { this.p[i] = this.p[this.p.length - 1]; this.p.pop(); continue; }
      q.fase += dt * 3; q.x += (q.vx + (q.onda ? Math.sin(q.fase) * q.onda : 0)) * dt; q.y += q.vy * dt;
    }
    for (let i = this.aneis.length - 1; i >= 0; i--) { const a = this.aneis[i]; a.vida -= dt; if (a.vida <= 0) this.aneis.splice(i, 1); }
  }

  _dispararRaro(vista, fx) {
    const rng = this.rng; const r = this.rara; this.raros++; this.emCurso = { tipo: r.tipo, t: 0, dur: r.dur }; this.aviso = r.aviso;
    if (r.tipo === 'desabamento') {   // chuva de pedaços do teto, mais densa que a poeira comum
      const n = this.nivel >= 2 ? 30 : 12;
      for (let i = 0; i < n; i++) this._add({ x: vista.x + rng() * vista.w, y: vista.y - 4 + rng() * 30, vx: -3 + rng() * 6, vy: 30 + rng() * 40, vida: 2 + rng(), max: 3, tam: rng() < 0.3 ? 2 : 1, cor: [168, 138, 100], fase: rng() * 6.28, onda: 0 });
      fx?.add?.({ x: vista.x + vista.w / 2, y: vista.y + vista.h * 0.2, raio: 110, cor: [255, 200, 140], dur: 0.4, intens: 0.2 });
    } else if (r.tipo === 'florada') {   // esporos sobem de baixo, brilhando
      const n = this.nivel >= 2 ? 30 : 12;
      for (let i = 0; i < n; i++) this._add({ x: vista.x + rng() * vista.w, y: vista.y + vista.h + 2 - rng() * 20, vx: -4 + rng() * 8, vy: -(14 + rng() * 22), vida: 4, max: 4, tam: 1 + (rng() < 0.3 ? 1 : 0), cor: rng() < 0.5 ? [150, 255, 210] : [255, 240, 140], fase: rng() * 6.28, onda: 4 });
      fx?.add?.({ x: vista.x + vista.w / 2, y: vista.y + vista.h * 0.7, raio: 120, cor: [120, 255, 210], dur: 0.8, intens: 0.25 });
    }
    // 'apagao': só o escurecimento (getter `escuro`) e o clarão de volta no fim; nada de partícula
  }

  _disparar(vista, fx) {
    const rng = this.rng; this.eventos++;
    const tipo = this.clima.evento.tipo;
    if (tipo === 'poeira') {   // fiapos de poeira soltos do teto, ao longo da tela
      const n = this.nivel >= 2 ? 14 : 7;
      for (let i = 0; i < n; i++) this._add({ x: vista.x + rng() * vista.w, y: vista.y - 4 + rng() * 24, vx: -2 + rng() * 4, vy: 18 + rng() * 22, vida: 2.2 + rng(), max: 3, tam: 1, cor: [214, 184, 140], fase: rng() * 6.28, onda: 0 });
    } else if (tipo === 'rajada') this.carga = this.nivel >= 2 ? 16 : 8;
    else {   // descarga do núcleo: anel + clarão
      const x = vista.x + vista.w * (0.2 + rng() * 0.6); const y = vista.y + vista.h * (0.25 + rng() * 0.5);
      this.aneis.push({ x, y, vida: 0.9, max: 0.9, r: 52 });
      fx?.add?.({ x, y, raio: 88, cor: [190, 140, 255], dur: 0.45, intens: 0.34 });
    }
  }
}
