// =====================================================================
// ARTE PROVISÓRIA DOS OBJETOS DA SALA: checkpoints, mutações a coletar e passagens (abertas ou seladas).
// Tudo desenhado por código (pixels nítidos). A animação usa o tempo do jogo (passos de física), então é determinística.
// =====================================================================
import { ABILITIES } from '../entities/abilities.js';
import { chaveItem } from '../core/progress.js';
import { drawMudaAracnidea } from '../render/tecela-art.js';
import { drawSpriteMutacao, MUTACOES_COM_SPRITE } from '../render/mutacao-sprites.js';
import { drawGeneIcon } from '../render/gene-art.js';
import { geneDe } from './genes.js';
import { ARTE_NPC, ALTURA_NPC, desenharConvite, desenharAuraFio, desenharNomeNpc } from '../render/npc-art.js';
import { ehCasulo } from '../world/narrativa-dados.js';
import { chaveNpc } from '../world/npc-dados.js';

const COR_HABILIDADE = { investida: '#ffb347', saltoElastico: '#5ff0c8', wallJump: '#3fae52', membrana: '#c58cff', pseudopode: '#e88f7f', tendril: '#59dcb4', instanteVital: '#9dffd2' };

function disco(ctx, cx, cy, r, cor) {   // círculo feito de retângulos (pixel art)
  ctx.fillStyle = cor;
  for (let y = -r; y <= r; y++) { const w = Math.round(Math.sqrt(r * r - y * y)); ctx.fillRect(cx - w, cy + y, 2 * w + 1, 1); }
}

const CORACAO = ['.XX.XX.', 'XXXXXXX', 'XXXXXXX', '.XXXXX.', '..XXX..', '...X...'];
/** Fragmento de Carne: coração pulsante que flutua. */
export function drawVida(ctx, x, y, ts, camX, camY, t) {
  const cx = Math.round(x * ts - camX + ts / 2); const cy = Math.round(y * ts - camY + ts / 2 + Math.sin(t * 2.5) * 2);
  ctx.globalAlpha = 0.25 + 0.15 * Math.sin(t * 6); disco(ctx, cx, cy, 8, '#ff4f7a'); ctx.globalAlpha = 1;
  CORACAO.forEach((lin, j) => { for (let i = 0; i < 7; i++) if (lin[i] === 'X') { ctx.fillStyle = j < 1 || (j === 1 && i < 2) ? '#ffc0d0' : j > 3 ? '#b02a50' : '#ff4f7a'; ctx.fillRect(cx - 3 + i, cy - 3 + j, 1, 1); } });
}


/** Bulbo de Encaixe: botão de carne ciano que se abre em pétalas — +1 encaixe de gene, permanente. */
export function drawEncaixe(ctx, x, y, ts, camX, camY, t) {
  const cx = Math.round(x * ts - camX + ts / 2); const cy = Math.round(y * ts - camY + ts / 2 + Math.sin(t * 2.2) * 2);
  ctx.globalAlpha = 0.25 + 0.15 * Math.sin(t * 5); disco(ctx, cx, cy, 9, '#4fd8ff'); ctx.globalAlpha = 1;
  const aberto = 0.5 + 0.5 * Math.sin(t * 1.6);   // as pétalas abrem e fecham devagar
  ctx.fillStyle = '#1a6f8f'; ctx.fillRect(cx - 3, cy - 1, 7, 6); ctx.fillStyle = '#7fe8ff';
  for (const [dx, dy] of [[-4, -3], [3, -3], [-5, 0], [4, 0]]) ctx.fillRect(cx + dx - Math.round(aberto * Math.sign(dx)), cy + dy, 2, 3);
  ctx.fillStyle = '#e6fbff'; ctx.fillRect(cx - 1, cy - 4, 3, 3); ctx.fillStyle = '#ffe36b'; ctx.fillRect(cx, cy - 3, 1, 1);
}

/** Vesícula de seiva: cura local, desenhada como gota âmbar viva. */
function drawCura(ctx, x, y, ts, camX, camY, t) {
  const cx = Math.round(x * ts - camX + ts / 2); const cy = Math.round(y * ts - camY + ts / 2 + Math.sin(t * 2.8));
  ctx.globalAlpha = 0.2 + 0.15 * Math.sin(t * 5); disco(ctx, cx, cy, 8, '#d7c45a'); ctx.globalAlpha = 1;
  ctx.fillStyle = '#63501b'; ctx.fillRect(cx - 3, cy - 2, 7, 8); ctx.fillRect(cx - 2, cy - 5, 5, 4);
  ctx.fillStyle = '#fff4a8'; ctx.fillRect(cx - 1, cy - 4, 2, 4); ctx.fillRect(cx - 2, cy, 4, 4);
}

/** Eco de memória: fragmento ciano que registra um vestígio do mundo ao ser tocado. */
export function drawEco(ctx, x, y, ts, camX, camY, t) {
  const cx = Math.round(x * ts - camX + ts / 2); const cy = Math.round(y * ts - camY + ts / 2 + Math.sin(t * 2.2) * 2);
  ctx.globalAlpha = 0.22 + 0.12 * Math.sin(t * 5); disco(ctx, cx, cy, 8, '#63e7e0'); ctx.globalAlpha = 1;
  ctx.fillStyle = '#123c43'; ctx.fillRect(cx - 4, cy - 5, 8, 10);
  ctx.fillStyle = '#78fff0'; ctx.fillRect(cx - 2, cy - 4, 4, 8);
  ctx.fillStyle = '#eaffd8'; ctx.fillRect(cx - 1, cy - 2, 2, 4);
}

/**
 * Casulo vazio do Berçário (v1.51.0): um dos ecos que guardam informação importante. Lê-se de longe: casca de seda pálida com um vão
 * escuro no meio (o vazio), dois fios que tremem e um halo que pulsa e cresce quando o Limo se aproxima (`distTiles`).
 */
export function drawCasulo(ctx, x, y, ts, camX, camY, t, distTiles = 99) {
  const cx = Math.round(x * ts - camX + ts / 2); const cy = Math.round(y * ts - camY + ts / 2 + Math.sin(t * 1.8) * 1);
  const perto = Math.max(0, Math.min(1, (6 - distTiles) / 4)); const pulso = 0.5 + 0.5 * Math.sin(t * 2.4);
  ctx.save();   // halo em discos de pixel com alfa (sem gradiente): cresce e pulsa mais perto
  ctx.globalAlpha = 0.10 + 0.06 * pulso + 0.12 * perto; disco(ctx, cx, cy, 11, '#78ffe1');
  ctx.globalAlpha = 0.06 + 0.04 * pulso + 0.08 * perto; disco(ctx, cx, cy, 16, '#78ffe1');
  ctx.globalAlpha = 1;
  const tr = Math.sin(t * (3 + perto * 4)) * (0.6 + perto);   // fios tremem mais quando perto
  ctx.strokeStyle = `rgba(232,255,246,${(0.35 + 0.3 * perto).toFixed(3)})`; ctx.lineWidth = 1;
  ctx.beginPath(); ctx.moveTo(cx, cy - 7); ctx.lineTo(cx + tr, cy - 14); ctx.moveTo(cx, cy + 7); ctx.lineTo(cx - tr, cy + 13); ctx.stroke();
  ctx.fillStyle = '#123c43'; ctx.beginPath(); ctx.ellipse(cx, cy, 5.5, 7.5, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#d8f7ee'; ctx.beginPath(); ctx.ellipse(cx, cy, 4.5, 6.5, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#9fd9cf'; ctx.fillRect(cx - 4, cy - 2, 9, 1); ctx.fillRect(cx - 4, cy + 3, 9, 1);   // bandas de seda
  ctx.fillStyle = '#0b2226'; ctx.beginPath(); ctx.ellipse(cx, cy - 1, 2, 3, 0, 0, Math.PI * 2); ctx.fill();   // o vão vazio
  ctx.fillStyle = `rgba(234,255,216,${(0.35 + 0.5 * pulso).toFixed(3)})`; ctx.fillRect(cx - 1, cy - 2, 1, 1);   // brilho que pisca por dentro
  ctx.restore();
}

/**
 * CASULO DE REPOUSO (o checkpoint): bulbo de carne ancorado ao chão por raízes. Apagado = casca fechada e opaca;
 * ativo (é o ponto de renascimento) = membrana azul-esverdeada com núcleo que respira e esporos subindo;
 * `perto` = o casulo se abre (fresta luminosa) e aparece o balão "▲" convidando a descansar.
 */
export function drawCheckpoint(ctx, ativo, x, y, ts, camX, camY, t = 0, perto = false) {
  const px = Math.round(x * ts - camX); const py = Math.round(y * ts - camY);
  const respira = 0.5 + 0.5 * Math.sin(t * (ativo ? 2.4 : 1.1) + x * 1.7);
  const borda = '#241420'; const pele = ativo ? '#4c7e8e' : '#6d4a63'; const luz = ativo ? '#92dbe8' : '#93708a'; const veia = ativo ? '#2f5666' : '#4a2c42';
  const R = (rx, ry, w, h, c) => { ctx.fillStyle = c; ctx.fillRect(px + rx, py + ry, w, h); };
  ctx.save();
  // raízes que prendem o casulo ao chão
  R(0, 15, 3, 1, '#2a1a22'); R(13, 15, 3, 1, '#2a1a22'); R(3, 15, 10, 1, '#3a2230'); R(1, 14, 3, 1, '#4a2c38'); R(12, 14, 3, 1, '#4a2c38'); R(2, 13, 2, 1, '#2a1a22'); R(12, 13, 2, 1, '#2a1a22');
  // corpo em bulbo: [linha, x, largura]
  const corpo = [[2, 6, 4], [3, 5, 6], [4, 4, 8], [5, 3, 10], [6, 3, 10], [7, 3, 10], [8, 3, 10], [9, 3, 10], [10, 4, 8], [11, 4, 8], [12, 5, 6], [13, 6, 4]];
  for (const [ly, lx, w] of corpo) R(lx - 1, ly, w + 2, 1, borda);
  R(6, 1, 4, 1, borda); R(5, 14, 6, 1, borda);
  for (const [ly, lx, w] of corpo) R(lx, ly, w, 1, pele);
  R(4, 5, 1, 4, luz); R(5, 4, 2, 1, luz); R(5, 10, 1, 1, escurecerSimples(pele));          // brilho da membrana
  R(10, 6, 1, 3, veia); R(9, 9, 1, 2, veia); R(6, 11, 2, 1, veia); R(4, 9, 1, 2, veia);    // veias
  // fresta (olho do casulo): fechada = fenda escura; ativa/perto = abre e brilha
  const aberta = ativo || perto;
  if (!aberta) R(7, 5, 2, 6, '#2b1a2a');
  else {
    const a = (0.45 + 0.4 * respira).toFixed(2);
    R(6, 4, 4, 8, '#1b2c33'); R(6, 4, 4, 8, ativo ? `rgba(110,235,255,${a})` : `rgba(150,255,190,${(0.25 + 0.2 * respira).toFixed(2)})`);
    R(7, 6 + (respira > 0.6 ? 1 : 0), 2, 3, ativo ? '#eaffff' : '#c9f5da');                // núcleo
  }
  // esporos subindo do casulo ativo
  if (ativo) for (let i = 0; i < 3; i++) {
    const subida = (t * 7 + i * 5) % 14; const sx = 5 + i * 3 + Math.round(Math.sin(t * 2 + i * 2) * 1.5);
    ctx.globalAlpha = Math.max(0, 1 - subida / 14); R(sx, 12 - subida, 1, 1, '#b6fff0'); ctx.globalAlpha = 1;
  }
  // convite para descansar: seta "▲" com contorno, subindo e descendo sobre o casulo
  if (perto) {
    const bob = Math.round(Math.sin(t * 5));
    for (const [ry, rx, w] of [[-12, 7, 2], [-11, 6, 4], [-10, 5, 6], [-9, 4, 8]]) R(rx - 1, ry + bob, w + 2, 1, '#0b1a14');   // contorno
    R(7, -12 + bob, 2, 1, '#eaffd8'); R(6, -11 + bob, 4, 1, '#eaffd8'); R(5, -10 + bob, 6, 1, '#9be8b8'); R(4, -9 + bob, 8, 1, '#9be8b8');
    R(7, -8 + bob, 2, 2, '#9be8b8');
  }
  ctx.restore();
}

function escurecerSimples(cor) { return cor === '#4c7e8e' ? '#35616f' : '#523750'; }

/** Gene no chão: dupla hélice flutuando com halo; some quando o gene já foi encontrado. */
export function drawGenePickup(ctx, gene, x, y, ts, camX, camY, t) {
  if (!gene) return;
  const px = Math.round(x * ts - camX); const py = Math.round(y * ts - camY);
  const bob = Math.round(Math.sin(t * 2.5 + x) * 1.5);
  ctx.save();
  ctx.fillStyle = 'rgba(0,0,0,0.28)'; ctx.fillRect(px + 4, py + 15, 8, 1);   // sombra no chão
  drawGeneIcon(ctx, gene.cor, px + 8, py + 8 + bob, 14, t);
  ctx.restore();
}

/** Ícone do Salto Elástico: uma lula (manto pontudo, nadadeiras, olhos grandes e tentáculos que ondulam como num jato). */
function drawLula(ctx, cx, cy, t) {
  const manto = [2, 4, 6, 8, 8, 8, 8];
  manto.forEach((w, i) => { ctx.fillStyle = i < 3 ? '#35c4a8' : '#2aa08c'; ctx.fillRect(cx - w / 2, cy - 8 + i, w, 1); });
  ctx.fillStyle = '#0f3d38'; ctx.fillRect(cx - 4, cy - 2, 1, 2); ctx.fillRect(cx + 3, cy - 2, 1, 2);                   // contorno do manto
  ctx.fillStyle = '#1c6f66'; ctx.fillRect(cx - 6, cy - 6, 2, 2); ctx.fillRect(cx + 4, cy - 6, 2, 2);                   // nadadeiras
  ctx.fillRect(cx - 7, cy - 5, 1, 1); ctx.fillRect(cx + 6, cy - 5, 1, 1);
  ctx.fillStyle = '#7ff0d0'; ctx.fillRect(cx - 1, cy - 7, 1, 3);                                                        // brilho do manto
  ctx.fillStyle = '#2aa08c'; ctx.fillRect(cx - 4, cy, 9, 2);                                                           // cabeça
  ctx.fillStyle = '#f4fff0'; ctx.fillRect(cx - 4, cy - 1, 3, 3); ctx.fillRect(cx + 2, cy - 1, 3, 3);                   // olhos
  ctx.fillStyle = '#10240f'; ctx.fillRect(cx - 3, cy, 1, 2); ctx.fillRect(cx + 3, cy, 1, 2);
  for (let i = 0; i < 5; i++) {                                                                                         // tentáculos
    for (let j = 0; j < 6; j++) {
      const xx = cx - 4 + i * 2 + Math.round(Math.sin(t * 6 + i * 1.3 + j * 0.7) * 1.3 * (j / 4));
      ctx.fillStyle = j > 4 ? '#c8ffe8' : (j % 2 ? '#1f8070' : '#2aa08c'); ctx.fillRect(xx, cy + 2 + j, 1, 1);
    }
  }
}

/** v1.40.0 — Instante Vital: gota de essência suspensa num anel que quase não se move (o tempo hesita). Só visual. */
function drawInstanteVital(ctx, cx, cy, t) {
  const lento = Math.sin(t * 0.9);   // o anel respira devagar
  ctx.fillStyle = 'rgba(157,255,210,0.22)'; disco(ctx, cx, cy, 9 + Math.round(lento), 'rgba(157,255,210,0.22)');
  // anel de 12 pontos que gira muito devagar; um ponto mais claro marca o "ponteiro"
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2 + t * 0.35; const x = Math.round(cx + Math.cos(a) * 7); const y = Math.round(cy + Math.sin(a) * 7);
    ctx.fillStyle = i === 0 ? '#ffffff' : (i % 3 === 0 ? '#7fe8bf' : '#2b8f77'); ctx.fillRect(x, y, 1, 1);
  }
  // gota: contorno escuro, corpo verde, brilho âmbar no núcleo
  ctx.fillStyle = '#0a2a22'; ctx.fillRect(cx - 1, cy - 5, 3, 1); ctx.fillRect(cx - 3, cy - 4, 7, 7); ctx.fillRect(cx - 2, cy + 3, 5, 1);
  ctx.fillStyle = '#2b8f77'; ctx.fillRect(cx - 1, cy - 4, 3, 1); ctx.fillRect(cx - 2, cy - 3, 5, 6);
  ctx.fillStyle = '#7fe8bf'; ctx.fillRect(cx - 1, cy - 2, 2, 3);
  ctx.fillStyle = '#f1c94f'; ctx.fillRect(cx, cy - 1, 1, 2);
  ctx.fillStyle = '#ffffff'; ctx.fillRect(cx - 1, cy - 3, 1, 1);
}

export function drawMutacao(ctx, ability, x, y, ts, camX, camY, t) {
  const bob = Math.round(Math.sin(t * 3) * 2); const cor = COR_HABILIDADE[ability] || '#ffffff';
  const cx = Math.round(x * ts - camX + ts / 2); const cy = Math.round(y * ts - camY + ts / 2 + bob);
  ctx.globalAlpha = 0.25 + 0.15 * Math.sin(t * 4); disco(ctx, cx, cy, 8, cor);   // brilho pulsando
  ctx.globalAlpha = 1;
  if (ability === 'wallJump') {
    drawMudaAracnidea(ctx, cx, cy, t); return;   // casca da Tecelã com a luz do Limo (arte procedural nova)
  }
  if (ability === 'saltoElastico') { drawLula(ctx, cx, cy, t); return; }
  if (ability === 'instanteVital') { drawInstanteVital(ctx, cx, cy, t); return; }
  if (MUTACOES_COM_SPRITE.includes(ability)) { drawSpriteMutacao(ctx, ability, cx, cy, t); return; }   // pseudópode · tendril · membrana (js/render/mutacao-sprites.js)
  disco(ctx, cx, cy, 5, '#1a2a1e'); disco(ctx, cx, cy, 4, cor);
  ctx.fillStyle = '#ffffff'; ctx.fillRect(cx - 2, cy - 2, 2, 2);
}

/** Desenha todos os objetos da sala atual do jogo (chamado entre as camadas e o jogador). */
/** Ferida do deus: abertura que sangra e pulsa; curada vira cicatriz. Anel de progresso enquanto o jogador segura. */
function drawFerida(ctx, curada, prog, tempoCura, x, y, ts, camX, camY, t) {
  const px = Math.round(x * ts - camX); const py = Math.round(y * ts - camY);
  ctx.save();
  if (curada) {
    ctx.fillStyle = '#8f5a66'; ctx.fillRect(px + 7, py + 3, 2, 10); ctx.fillStyle = '#c98a94'; ctx.fillRect(px + 7, py + 4, 1, 8);
  } else {
    const pulso = 0.5 + 0.5 * Math.sin(t * 3.2);
    ctx.fillStyle = '#3a0a18'; ctx.fillRect(px + 3, py + 1, 10, 14); ctx.fillRect(px + 2, py + 4, 12, 8);
    ctx.fillStyle = `rgba(217,60,80,${(0.55 + 0.35 * pulso).toFixed(2)})`; ctx.fillRect(px + 5, py + 3, 6, 10);
    ctx.fillStyle = '#ff9aa8'; ctx.fillRect(px + 7, py + 5 + (pulso > 0.5 ? 1 : 0), 2, 3);
    ctx.fillStyle = '#9be05a'; ctx.fillRect(px + 7, py + 12 + (((t * 14) % 6) | 0), 1, 2);   // gota de ácido
  }
  if (prog && !prog.falta && tempoCura > 0) {
    ctx.strokeStyle = '#eaffd8'; ctx.lineWidth = 2; ctx.beginPath();
    ctx.arc(px + 8, py + 8, 11, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.min(1, prog.t / tempoCura)); ctx.stroke();
  }
  ctx.restore();
}

export function drawEntities(ctx, game, camX, camY) {
  const d = game.roomData; if (!d) return;
  const ts = d.tileSize; const t = game.metrics.totalSteps / 60; const progresso = game.progress; const abil = progresso ? progresso.abilities : game.player.abilities;
  for (const e of d.entities || []) {
    if (game.vivo?.oculta?.(e.x, e.y)) continue;   // v1.38.0: recompensa dentro de câmara secreta ainda fechada
    if (e.type === 'checkpoint') {
      const cp = progresso && progresso.checkpoint;
      drawCheckpoint(ctx, !!(cp && cp.sala === game.roomId && cp.id === e.id), e.x, e.y, ts, camX, camY, t, game._checkpointPerto === e);
    } else if (e.type === 'gene') {
      if (!(progresso && progresso.genes && progresso.genes.has(e.gene))) drawGenePickup(ctx, geneDe(e.gene), e.x, e.y, ts, camX, camY, t);
    } else if (e.type === 'ferida') {
      drawFerida(ctx, !!(progresso && progresso.collected.has(chaveItem(game.roomId, e.id))), game._cura && game._cura.id === e.id ? game._cura : null, game.config?.mecanicas?.ferida?.tempoCura ?? 0.9, e.x, e.y, ts, camX, camY, t);
    } else if (e.type === 'cura') {
      drawCura(ctx, e.x, e.y, ts, camX, camY, t);
    } else if (e.type === 'vida' && !(progresso && progresso.collected.has(chaveItem(game.roomId, e.id)))) {
      drawVida(ctx, e.x, e.y, ts, camX, camY, t);
    } else if (e.type === 'encaixe' && !(progresso && progresso.collected.has(chaveItem(game.roomId, e.id)))) {
      drawEncaixe(ctx, e.x, e.y, ts, camX, camY, t);
    } else if (e.type === 'presenca') {   // v1.50.0: silhueta da Tecelã atrás dos fios (não é coletável, não colide, não luta)
      if (e.kind === 'tecela') drawPresencaTecela(ctx, Math.round(e.x * ts + ts / 2 - camX), Math.round(e.y * ts + ts / 2 - camY), t, game.player ? Math.hypot(game.player.centerX - (e.x * ts + ts / 2), game.player.centerY - (e.y * ts + ts / 2)) / ts : 99);
    } else if (e.type === 'npc') {   // v1.43: NPC fica sempre (não é coletável); o balão aparece quando o Limo está perto
      const arte = ARTE_NPC[e.npc]; if (arte) {
        const vivo = game.npcsVivos?.get(e.id);   // v1.45: NPC com rotina é desenhado na posição VIVA, com estado e direção
        const px = Math.round((vivo ? vivo.x : e.x * ts) - camX); const alt = ALTURA_NPC[e.npc] ?? 16; const py = Math.round((vivo ? vivo.y : e.y * ts) - camY) - (alt - 16);   // figura mais alta cresce para cima
        const falando = game._npcFalando === e;
        const aguarda = !progresso?.descobertas?.has?.(chaveNpc(e.npc, 'conversou'));   // v1.51.0: ainda não conversou → a aura chama a atenção
        if (aguarda && !falando) desenharAuraFio(ctx, px, py, t);
        const dNpc = game.player ? Math.hypot(game.player.centerX - (vivo ? vivo.centerX : (e.x + 0.5) * ts), game.player.centerY - (vivo ? vivo.centerY : (e.y + 0.5) * ts)) / ts : 99;
        arte(ctx, px, py, t, falando, vivo?.estado ?? 'parado', vivo?.facing ?? 1, dNpc <= 3);   // o último argumento só a Jardineira usa (abre a flor ao se aproximar)
        if (game._npcPerto === e && game.suspended !== 'dialogo') desenharConvite(ctx, px, py, t);
        else if (!falando && dNpc <= 6) desenharNomeNpc(ctx, px, py, e.nome || 'Fio Solto', Math.max(0, Math.min(1, (6.5 - dNpc) / 1.5)));   // v1.51.0: o nome aparece ao se aproximar
      }
    } else if (e.type === 'echo' && !(progresso && progresso.collected.has(chaveItem(game.roomId, e.id)))) {
      if (ehCasulo(game.roomId, e.id)) drawCasulo(ctx, e.x, e.y, ts, camX, camY, t, game.player ? Math.hypot(game.player.centerX / ts - (e.x + 0.5), game.player.centerY / ts - (e.y + 0.5)) : 99);   // v1.51.0: casulo vazio (informação importante)
      else drawEco(ctx, e.x, e.y, ts, camX, camY, t);
    } else if (e.type === 'mutation' && (!e.requiresBoss || progresso?.bossesDefeated?.includes(e.requiresBoss)) && ABILITIES[e.ability] && !(progresso && progresso.collected.has(chaveItem(game.roomId, e.id)))) {
      drawMutacao(ctx, e.ability, e.x, e.y, ts, camX, camY, t);
    }
  }
}

/** Silhueta da Tecelã: corpo escuro, oito patas que balançam, brilho roxo e fios que vibram mais quanto mais perto o Limo chega (`distTiles`). Sem olhos nítidos: ainda não é hora. */
export function drawPresencaTecela(ctx, px, py, t, distTiles = 99) {
  const perto = Math.max(0, Math.min(1, (12 - distTiles) / 8)); const tremor = (0.4 + perto * 1.6) * Math.sin(t * (6 + perto * 10));
  ctx.save();
  const g = ctx.createRadialGradient(px, py, 2, px, py, 34); g.addColorStop(0, `rgba(150,100,210,${(0.28 + perto * 0.18).toFixed(3)})`); g.addColorStop(1, 'rgba(150,100,210,0)');
  ctx.fillStyle = g; ctx.fillRect(px - 36, py - 36, 72, 72);
  ctx.strokeStyle = `rgba(232,216,255,${(0.28 + perto * 0.3).toFixed(3)})`; ctx.lineWidth = 1;   // fios esticados até as paredes
  for (const [dx, dy] of [[-30, -10], [30, -12], [-26, 14], [28, 10], [0, -28]]) { ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + dx * 0.5 + tremor, py + dy * 0.5); ctx.lineTo(px + dx, py + dy + tremor * 0.5); ctx.stroke(); }
  ctx.strokeStyle = 'rgba(12,6,20,0.92)'; ctx.lineWidth = 1.5;
  for (let i = 0; i < 8; i++) { const lado = i < 4 ? -1 : 1; const k = i % 4; const bal = Math.sin(t * 1.4 + i) * 1.5 + (k % 2 ? tremor * 0.3 : 0);
    ctx.beginPath(); ctx.moveTo(px + lado * 3, py + (k - 1.5) * 1.5); ctx.lineTo(px + lado * (9 + k * 2), py - 6 - k * 2 + bal); ctx.lineTo(px + lado * (14 + k * 3), py + 4 + k * 3 + bal); ctx.stroke(); }
  ctx.fillStyle = 'rgba(12,6,20,0.95)'; ctx.beginPath(); ctx.ellipse(px, py, 6, 4.5, 0, 0, Math.PI * 2); ctx.fill(); ctx.beginPath(); ctx.ellipse(px + 7, py + 1, 5, 4, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = `rgba(154,111,208,${(0.35 + 0.25 * Math.sin(t * 2)).toFixed(3)})`; ctx.fillRect(px - 2, py - 2, 1, 1); ctx.fillRect(px + 1, py - 2, 1, 1);
  ctx.restore();
}
