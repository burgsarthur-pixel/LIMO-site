// =====================================================================
// COMPORTAMENTO DAS CRIATURAS (v1.39.0) — lógica pura, sem DOM.
// Cada espécie tem um CÉREBRO próprio (não é um parâmetro dentro de um sistema único):
//   Rastejante  → PRESA:        patrulha, descansa, foge de predadores e quando ferido; acuado, luta
//   Saltador    → PREDADOR:     caça rastejantes (e os prefere a Limo se estiverem mais perto), fica saciado e dorme, espreita quem fica parado
//   Couraçado   → TERRITORIAL:  guarda uma área (anel de aviso + área defendida), volta para casa, expulsa predadores, nunca foge
//   Esporo      → TÍMIDO:       não persegue quem corre; chega perto de quem fica quieto; foge quando ferido ou perturbado
//   Chefes      → sem cérebro (ciclos próprios em combate.js/enemy.js)
// O cérebro NÃO reescreve o Enemy: decide `alvo` (Limo, uma presa, um invasor ou ninguém) e escreve `enemy.ia`
// ({repouso, fugir, velMul, espreita, alerta}), que o Enemy lê em poucos pontos. Sem cérebro tudo continua como antes.
// Desempenho: pensa a 10 Hz com fases escalonadas; só criaturas vivas da sala; sem alocação por quadro.
// =====================================================================
import { criarRng } from './vida-eco.js';

export const TEMPERAMENTOS = Object.freeze({
  normal: { visao: 1, fuga: 0.4, descanso: 1, acorda: 1, territorio: 1 },
  manso: { visao: 0.75, fuga: 0.6, descanso: 1.6, acorda: 0.8, territorio: 0.85 },        // raízes depois do Guardião: param de lutar contra si mesmas
  sentinela: { visao: 0.9, fuga: 0.4, descanso: 1.8, acorda: 0.8, territorio: 0.7 },      // couraçados do núcleo depois do Mastigador
  sonolento: { visao: 0.6, fuga: 0.5, descanso: 2.4, acorda: 0.6, territorio: 0.6 },      // tudo depois do Coração: o Deus volta a dormir
});

const TICK = 0.1;
const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);

class Cerebro {
  constructor(e, { rng = criarRng(1), temperamento = 'normal', ts = 16 } = {}) {
    this.e = e; this.rng = rng; this.ts = ts; this.temperamento = TEMPERAMENTOS[temperamento] ? temperamento : 'normal'; this.k = TEMPERAMENTOS[this.temperamento];
    this.modo = 'patrulha'; this.tModo = 0; this.acc = rng() * TICK; this.alvo = null; this.alvoCriatura = null;
    this.proxDescanso = this._sorteioDescanso(); this.eventos = [];
    e.ia = { repouso: false, fugir: false, velMul: 1, espreita: false, alerta: false, ameaca: null };
    e.cerebro = this; e.sight = e.cfg.sight;   // visão base, ajustada pelo temperamento
    e.cfg.sight = Math.round(e.cfg.sight * this.k.visao);
  }
  get ia() { return this.e.ia; }
  _sorteioDescanso() { return (6 + this.rng() * 8) / this.k.descanso; }
  _muda(modo, dur = 0) { if (this.modo !== modo) { this.modo = modo; this.tModo = dur; this.eventos.push(modo); } else this.tModo = Math.max(this.tModo, dur); }
  /** Quem a criatura persegue neste quadro (Limo, uma presa, um invasor) — nulo = ninguém. */
  alvoPara() { return this.alvo; }
  acordar() { if (this.modo === 'descansa' || this.modo === 'saciado') { this.modo = 'patrulha'; this.tModo = 0; this.proxDescanso = this._sorteioDescanso(); } }
  ouvir(ruido) { const e = this.e; if (this.modo === 'descansa' && dist(e.centerX, e.centerY, ruido.x, ruido.y) < ruido.r * this.k.acorda) { this.acordar(); this.eventos.push('acordou'); } }
  /** Chamado a 10 Hz. ctx = {limo:{x,y,vx,vy,vivo,atacando}, criaturas[], mapa} */
  pensar(dt, ctx) {
    this.acc += dt; if (this.acc < TICK) return false; const d = this.acc; this.acc = 0; this.tModo = Math.max(0, this.tModo - d);
    const e = this.e; if (!e.alive || e.intro) return false;
    this._tick(d, ctx); return true;
  }
  _tick() { /* cada espécie sobrescreve */ }
  _limoPerto(ctx, raioX, raioY = 48) { const l = ctx.limo; return l.vivo && Math.abs(l.x - this.e.centerX) <= raioX && Math.abs(l.y - this.e.centerY) <= raioY; }
  _descansoCiclico(d, ctx, acorda) {   // patrulha ↔ descansa, comum a quem dorme; a espécie decide quando é seguro
    if (this.modo === 'descansa') { this.ia.repouso = true; if (this.tModo <= 0 || ctx.limo.vivo && dist(this.e.centerX, this.e.centerY, ctx.limo.x, ctx.limo.y) < acorda || this.e.hurtTimer > 0) this.acordar(); return; }
    this.ia.repouso = false;
    if ((this.proxDescanso -= d) <= 0 && this.modo === 'patrulha' && this.e.attackState === 'stalk' && this.e.contacts.down) { this.proxDescanso = this._sorteioDescanso(); this._muda('descansa', 3 + this.rng() * 3); this.ia.repouso = true; }
  }
}

/** Rastejante: presa. */
export class CerebroPresa extends Cerebro {
  _tick(d, ctx) {
    const e = this.e; const ia = this.ia; const l = ctx.limo; this.alvo = null;
    // ameaça: predador por perto (Saltador) ou Limo quando a criatura está machucada
    let ameaca = null; let dm = 78;
    for (const o of ctx.criaturas) if (o !== e && o.alive && o.cfg.kind === 'leaper') { const dd = Math.abs(o.centerX - e.centerX); if (dd < dm && Math.abs(o.centerY - e.centerY) < 30) { dm = dd; ameaca = o; } }
    const ferido = e.life < e.maxLife * this.k.fuga + 0.001 && e.maxLife > 1 || (e.life <= 1 && e.maxLife >= 2);
    if (!ameaca && ferido && l.vivo && this._limoPerto(ctx, 110, 40)) ameaca = { centerX: l.x, centerY: l.y };
    if (ameaca && this.modo !== 'acuado') { this._muda('foge', 2.5); ia.ameaca = ameaca; }
    if (this.modo === 'foge') {
      ia.repouso = false; ia.fugir = true; ia.velMul = 1.35;
      if (e.fugaBloqueada) { this._muda('acuado', 3); ia.fugir = false; }   // sem saída: encara
      else if (this.tModo <= 0) { this.modo = 'patrulha'; ia.fugir = false; ia.velMul = 1; ia.ameaca = null; }
      return;
    }
    ia.fugir = false; ia.velMul = 1;
    if (this.modo === 'acuado') { if (this.tModo <= 0) this.modo = 'patrulha'; if (l.vivo) this.alvo = l.ref || l; return; }
    this._descansoCiclico(d, ctx, 38);
    if (this.modo === 'descansa') return;
    if (l.vivo) this.alvo = l.ref || l;
  }
}

/** Saltador: predador de rastejantes. */
export class CerebroPredador extends Cerebro {
  constructor(e, o) { super(e, o); this.sacia = 0; }
  aoCacar() { this.sacia = 8; this._muda('saciado', 5); this.eventos.push('cacou'); }
  _tick(d, ctx) {
    const e = this.e; const ia = this.ia; const l = ctx.limo; this.alvo = null; this.alvoCriatura = null; ia.espreita = false; ia.velMul = 1;
    this.sacia = Math.max(0, this.sacia - d);
    if (this.modo === 'saciado') { ia.repouso = true; if (this.tModo <= 0 || e.hurtTimer > 0 || (l.vivo && dist(e.centerX, e.centerY, l.x, l.y) < 30)) { ia.repouso = false; this.modo = 'patrulha'; this.proxDescanso = this._sorteioDescanso(); } return; }
    // presa mais próxima
    let presa = null; let dp = e.cfg.sight * 1.4;
    if (this.sacia <= 0) for (const o of ctx.criaturas) if (o !== e && o.alive && o.cfg.kind === 'crawler') { const dd = Math.abs(o.centerX - e.centerX); if (dd < dp && Math.abs(o.centerY - e.centerY) < 28) { dp = dd; presa = o; } }
    const dl = l.vivo ? Math.abs(l.x - e.centerX) : Infinity; const veLimo = l.vivo && dl <= e.cfg.sight && Math.abs(l.y - e.centerY) <= e.cfg.sightY;
    if (presa && (!veLimo || dp < dl * 0.7)) { this.alvo = presa; this.alvoCriatura = presa; this._muda('caca', 1); ia.repouso = false; return; }
    this._descansoCiclico(d, ctx, 34);
    if (this.modo === 'descansa') return;
    if (this.modo === 'caca') this.modo = 'patrulha';
    if (!veLimo) return;
    this.alvo = l.ref || l;
    const parado = Math.abs(l.vx) < 20 && Math.abs(l.vy) < 30;
    if (parado && dl > (e.cfg.saltoAlcance || 110) * 0.9) { ia.espreita = true; ia.velMul = 0.4; this._muda('espreita', 0.5); } else if (this.modo === 'espreita') this.modo = 'patrulha';
  }
}

/** Couraçado: guarda um território. */
export class CerebroTerritorial extends Cerebro {
  constructor(e, o) { super(e, o); this.raio = 80 * this.k.territorio; this.anel = 36; this.provocado = 0; this.rosnouEm = -9; }
  _tick(d, ctx) {
    const e = this.e; const ia = this.ia; const l = ctx.limo; this.alvo = null; this.alvoCriatura = null; ia.alerta = false; ia.velMul = 1; this.provocado = Math.max(0, this.provocado - d);
    const hx = e.home.x + e.body.w / 2; const dhome = Math.abs(e.centerX - hx);
    // invasor: predador dentro do território
    let invasor = null; let di = this.raio;
    for (const o of ctx.criaturas) if (o !== e && o.alive && o.cfg.kind === 'leaper') { const dd = Math.abs(o.centerX - hx); if (dd < di && Math.abs(o.centerY - e.centerY) < 30) { di = dd; invasor = o; } }
    const dl = l.vivo ? Math.abs(l.x - hx) : Infinity; const dy = l.vivo ? Math.abs(l.y - e.centerY) : Infinity;
    if (l.atacando && dl < this.raio + this.anel && dy < 40) this.provocado = 4;
    const dentro = dl <= this.raio && dy <= e.cfg.sightY; const noAnel = !dentro && dl <= this.raio + this.anel && dy <= e.cfg.sightY;
    if (dhome > this.raio + 24 && this.modo === 'defende') { this._muda('volta', 2); }   // longe demais de casa: desiste
    if (invasor && (!dentro || Math.abs(invasor.centerX - e.centerX) < Math.abs(l.x - e.centerX))) { this.alvo = invasor; this.alvoCriatura = invasor; this._muda('expulsa', 1); ia.repouso = false; return; }
    if (dentro || (this.provocado > 0 && dl < this.raio + this.anel)) { this.alvo = l.ref || l; this._muda('defende', 1); ia.repouso = false; if (this.modo === 'volta') this.modo = 'defende'; return; }
    if (noAnel) {   // aviso: encara e rosna uma vez, parado
      ia.alerta = true; ia.velMul = 0; ia.repouso = false; e.facing = l.x >= e.centerX ? 1 : -1; this._muda('alerta', 1);
      if (e.t - this.rosnouEm > 3.5) { this.rosnouEm = e.t; e.audioEvents.push('aviso_escudada'); }
      return;
    }
    if (this.modo === 'defende' || this.modo === 'alerta' || this.modo === 'expulsa') this._muda('volta', 1.5);
    if (dhome > 10) { ia.repouso = false; ia.velMul = 0.7; e.facing = hx > e.centerX ? 1 : -1; if (this.modo !== 'volta') this._muda('volta', 1); return; }
    if (this.modo === 'volta') this.modo = 'patrulha';
    this._descansoCiclico(d, ctx, this.anel);   // sentinela dorme em casa; acorda no anel
  }
}

/** Esporo: tímido e curioso. */
export class CerebroVoador extends Cerebro {
  constructor(e, o) { super(e, o); this.perturbado = 0; }
  _tick(d, ctx) {
    const e = this.e; const ia = this.ia; const l = ctx.limo; this.alvo = null; ia.fugir = false; ia.velMul = 1; this.perturbado = Math.max(0, this.perturbado - d);
    const dx = l.vivo ? l.x - e.centerX : Infinity; const dd = l.vivo ? dist(e.centerX, e.centerY, l.x, l.y) : Infinity;
    const ferido = e.life < e.maxLife && e.maxLife > 1 || e.hurtTimer > 0;
    if (l.atacando && dd < 90) this.perturbado = 2;
    if (this.modo === 'foge' && this.tModo > 0) { ia.fugir = true; ia.velMul = 1.3; ia.ameaca = { centerX: l.x, centerY: l.y }; return; }
    if (ferido && dd < 120) { this._muda('foge', 2.2); ia.fugir = true; ia.ameaca = { centerX: l.x, centerY: l.y }; return; }
    if (this.modo === 'foge') this.modo = 'vaga';
    if (this.modo === 'descansa') { ia.repouso = true; if (this.tModo <= 0 || dd < 50 * this.k.acorda || e.hurtTimer > 0) this.acordar(); return; }
    ia.repouso = false;
    if (dd > e.cfg.sight * 1.5) { if ((this.proxDescanso -= d) <= 0) { this.proxDescanso = this._sorteioDescanso(); this._muda('descansa', 3 + this.rng() * 3); ia.repouso = true; } return; }
    const rapido = Math.abs(l.vx) > 90 || Math.abs(l.vy) > 160;
    if (this.perturbado > 0 || dd < 46) { this.alvo = l.ref || l; this._muda('incomodado', 1); return; }       // perturbado ou invadido: ataca
    if (rapido) { this._muda('arisco', 0.6); return; }                                                  // não persegue quem corre
    if (Math.abs(dx) <= e.cfg.sight) { this.alvo = l.ref || l; ia.velMul = 0.55; this._muda('curioso', 0.6); }
  }
}

export function criarCerebro(e, opcoes) {
  if (!e || e.cfg.kind === 'boss' || e.bossId) return null;
  const C = { crawler: CerebroPresa, leaper: CerebroPredador, armored: CerebroTerritorial, flyer: CerebroVoador }[e.cfg.kind];
  return C ? new C(e, opcoes) : null;
}

/** Gerencia a sala: pensa, resolve caça/defesa entre criaturas e propaga ruído de Limo. */
export class Ecologia {
  constructor({ rng = criarRng(21), onEvento = null } = {}) { this.rng = rng; this.onEvento = onEvento; this.ruidos = []; this._atacava = false; this._investia = false; this.stats = { caçadas: 0, expulsoes: 0, fugas: 0, descansos: 0 }; }

  /** Fixa os cérebros da lista de criaturas. `temperamentoDe(enemy)` devolve o nome do temperamento. */
  static povoar(enemies, { ts = 16, semente = 1, temperamentoDe = () => 'normal' } = {}) {
    const rng = criarRng(semente); let n = 0;
    for (const e of enemies) if (criarCerebro(e, { rng: criarRng((rng() * 1e9) | 0), temperamento: temperamentoDe(e), ts })) n++;
    return n;
  }

  ruido(x, y, r) { this.ruidos.push({ x, y, r, t: 0.4 }); }

  /** @param limo {x,y,vx,vy,vivo,atacando,investindo} */
  atualizar(dt, enemies, limo, mapa = null) {
    if (limo.atacando && !this._atacava) this.ruido(limo.x, limo.y, 120);
    if (limo.investindo && !this._investia) this.ruido(limo.x, limo.y, 150);
    this._atacava = !!limo.atacando; this._investia = !!limo.investindo;
    for (const r of this.ruidos) r.t -= dt; if (this.ruidos.length) this.ruidos = this.ruidos.filter((r) => r.t > 0);
    const ctx = { limo, criaturas: enemies, mapa };
    for (const e of enemies) {
      const c = e.cerebro; if (!c || !e.alive) continue;
      for (const r of this.ruidos) c.ouvir(r);
      c.pensar(dt, ctx);
      if (c.eventos.length) { for (const ev of c.eventos) this._noteia(ev, e, limo); c.eventos.length = 0; }
      this._resolverCriaturas(e, enemies, c);
    }
  }

  _noteia(ev, e, limo) {
    if (ev === 'foge') this.stats.fugas++; else if (ev === 'descansa') this.stats.descansos++; else if (ev === 'expulsa') this.stats.expulsoes++;
    this.onEvento?.(ev, e, limo);
  }

  /** Predador/territorial acertando uma criatura. Não envolve Limo nem chefes. */
  _resolverCriaturas(atacante, enemies, c) {
    const v = c.alvoCriatura; if (!v || !v.alive || v.cfg.kind === 'boss' || atacante.attackState !== 'act') return;
    const a = atacante.body; const b = v.body; const m = 3;
    if (!(a.x - m < b.x + b.w && a.x + a.w + m > b.x && a.y - m < b.y + b.h && a.y + a.h + m > b.y) || v.hurtTimer > 0) return;
    const r = v.receberGolpe({ dano: atacante.cfg.kind === 'armored' ? 2 : 1, origemX: atacante.centerX, empurrao: 90, tipo: 'criatura' });
    if (r.morreu) {
      if (c.aoCacar) { c.aoCacar(); this.stats.caçadas++; this.onEvento?.('cacou', atacante, null, v); }
      else this.onEvento?.('expulsou', atacante, null, v);
    }
  }
}
