// =====================================================================
// TENDRIL — extensão orgânica da mutação (segurar = estender; soltar = recolher)
// Lógica pura o suficiente para ser testada sem DOM. Todo movimento passa por
// moveBody (as colisões do jogo): nada atravessa paredes, pisos ou tetos.
//  fases: idle → extending → connected → retract → idle      (alvo válido)
//         idle → miss → retract → idle                        (sem alvo: retrai sem efeito)
//  alvos: âncora orgânica (puxa Limo) · objeto interativo (ativa) · inimigo (puxa leve / corta ataque / pesado resiste)
// =====================================================================
import { moveBody } from '../world/collision.js';

export const TENDRIL_DEFAULTS = {
  alcance: 104,            // px (6,5 tiles)
  velocidadePuxao: 92,     // px/s
  toleranciaLinha: 2,      // passo da checagem de paredes
  conoMin: 0.75,           // cos do semiângulo da mira (≈41°): cobre as 8 direções sem sobrepor demais
  chegada: 5,              // distância (px) em que Limo "chega" à âncora e fica pendurado
  distanciaInimigo: 26,    // inimigo puxado para a distância de ~1,5 tile (não esmaga Limo)
  tempoExtensao: 0.10, tempoMiss: 0.16, tempoRetracao: 0.14,
  bloqueioMax: 0.5,        // s parado e longe da âncora (preso numa parede) → solta
  // --- física do puxão (elástico): Limo é lançado em direção à âncora, passa dela, balança e, se soltar em movimento, é ARREMESSADO ---
  rigidez: 28,             // 1/s²: aceleração = rigidez × (distância − corda) → forte de longe, suave de perto
  aceleracaoMax: 1100,     // px/s² (teto do puxão)
  velocidadeMax: 250,      // px/s (teto da velocidade enquanto preso)
  cordaRepouso: 16,        // px: distância em que o elástico não puxa mais
  gravidadeFator: 0.35,    // fração da gravidade que age enquanto preso (balança em vez de despencar)
  amortecimento: 2.0,      // 1/s: o balanço vai morrendo
  controleBalanco: 280,    // px/s²: ←/→ empurram o balanço
  impulsoSolta: 1.15,      // ao soltar/pular em movimento, a velocidade ganha este bônus (limitada por velocidadeSolta)
  velocidadeSolta: 300,    // px/s: teto da velocidade de arremesso
  tempoLancamento: 0.5,    // s sem atrito horizontal depois de soltar (o impulso não morre na hora)
};

/** Direção digitada nas 8 direções (null se nenhuma tecla/stick). Diagonais normalizadas. */
export function direcaoDaEntrada(input) {
  const x = (input?.isDown?.('right') ? 1 : 0) - (input?.isDown?.('left') ? 1 : 0);
  const y = (input?.isDown?.('down') ? 1 : 0) - (input?.isDown?.('up') ? 1 : 0);
  if (!x && !y) return null;
  const n = Math.hypot(x, y);
  return { x: x / n, y: y / n };
}

export function pontoAlvo(alvo) {
  if (alvo?.point) return { x: alvo.point.x, y: alvo.point.y };
  const b = alvo?.body || alvo;
  if (!b || !Number.isFinite(b.x)) return null;
  return { x: b.x + (b.w || 0) / 2, y: b.y + (b.h || 0) / 2 };
}

export function linhaBloqueada(mapa, a, b, tolerancia = 2) {
  const d = Math.hypot(b.x - a.x, b.y - a.y);
  if (!mapa || !d) return false;
  const passos = Math.ceil(d / Math.max(2, tolerancia));
  for (let i = 1; i < passos; i++) {
    const t = i / passos;
    if (mapa.isSolidPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)) return true;
  }
  return false;
}

/** Ponto onde a Tendril para ao estender sem alvo: no alcance, ou antes da primeira parede. */
export function pontoLivre(mapa, origem, dir, alcance, passo = 2) {
  let ult = { x: origem.x, y: origem.y };
  for (let d = passo; d <= alcance; d += passo) {
    const p = { x: origem.x + dir.x * d, y: origem.y + dir.y * d };
    if (mapa?.isSolidPoint?.(p.x, p.y)) return ult;
    ult = p;
  }
  return { x: origem.x + dir.x * alcance, y: origem.y + dir.y * alcance };
}

export function dentroDoCone(origem, ponto, direcao, alcance, conoMin = TENDRIL_DEFAULTS.conoMin) {
  const dx = ponto.x - origem.x; const dy = ponto.y - origem.y;
  const d = Math.hypot(dx, dy);
  return d <= alcance && d > 0 && (dx * direcao.x + dy * direcao.y) / d >= conoMin;
}

/** UM único alvo: o mais próximo dentro do alcance e do cone da mira, sem parede no meio. */
export function escolherAlvo({ origem, direcao, alcance, candidatos = [], mapa, tolerancia = 2, conoMin = TENDRIL_DEFAULTS.conoMin }) {
  const validos = candidatos.map((alvo, indice) => {
    const ponto = pontoAlvo(alvo);
    if (!ponto || !dentroDoCone(origem, ponto, direcao, alcance, conoMin)) return null;
    if (linhaBloqueada(mapa, origem, ponto, tolerancia)) return null;
    return { alvo, ponto, distancia: Math.hypot(ponto.x - origem.x, ponto.y - origem.y), indice };
  }).filter(Boolean);
  validos.sort((a, b) => a.distancia - b.distancia || a.indice - b.indice);
  return validos[0] || null;
}

function alvoDeDados(e, ts) {
  if (!e || !['tendrilAnchor', 'tendrilObject'].includes(e.type)) return null;
  const w = e.w ?? 1; const h = e.h ?? 1;
  return { ...e, source: e, body: { x: (e.x || 0) * ts, y: (e.y || 0) * ts, w: w * ts, h: h * ts }, tendrilKind: e.type === 'tendrilAnchor' ? 'anchor' : 'object' };
}

/** Âncoras e objetos da sala (objetos já ativados saem da lista) + todos os inimigos vivos. */
export function alvosDaSala(roomData, enemies, ts, jaAtivado = null) {
  const dados = (roomData?.entities || []).map((e) => alvoDeDados(e, ts)).filter((a) => a && !(a.tendrilKind === 'object' && jaAtivado?.(a.source)));
  const inimigos = (enemies || []).filter((e) => e.alive).map((enemy) => ({ enemy, body: enemy.body, tendrilKind: 'enemy' }));
  return [...dados, ...inimigos];
}

const SEM_ANIMACAO = ['room-change', 'dead', 'paused'];   // estes encerramentos limpam tudo na hora

export class TendrilController {
  constructor(config = {}) {
    this.config = { ...TENDRIL_DEFAULTS, ...(config.abilities?.tendril || {}), ...(config.tendril || {}) };
    this.lastAim = null;
    this.events = [];
    this.reset();
  }

  /** Limpa o estado (a última direção de mira é preservada). */
  reset() {
    this._soltarJogador();
    this.active = false; this.phase = 'idle'; this.target = null; this.point = null; this.t = 0; this.reason = null;
    this.aim = this.lastAim || { x: 1, y: 0 }; this.mirando = false; this.gasta = false; this.missAim = null;
    this.tip = null; this._tipDe = null; this._semAvanco = 0; this._interrompeu = false;
  }

  drenarEventos() { const e = this.events; this.events = []; return e; }

  _soltarJogador() { if (this._player) this._player.tendrilPulling = false; }

  /** Encerra com segurança: solta Limo, para o puxão e (salvo troca de sala/morte/pausa) anima a retração. */
  stop(reason = 'released') {
    if (this.phase === 'idle' || this.phase === 'retract') { if (this.phase === 'idle') this._soltarJogador(); return; }
    if (SEM_ANIMACAO.includes(reason)) { this.reset(); return; }
    if (this._player?.tendrilPulling && (reason === 'released' || reason === 'cancel')) this._arremessar(this._player);   // solta em movimento = lançado
    this._soltarJogador();
    if (reason === 'target-lost' || reason === 'blocked') this.events.push('lost');
    if (['cancel', 'target-lost', 'blocked'].includes(reason)) { this.gasta = true; this.missAim = null; }   // só uma nova tentativa depois de soltar o botão
    this._tipDe = this.tip ? { ...this.tip } : null;
    this.active = false; this.phase = 'retract'; this.target = null; this.point = null; this.t = 0; this.reason = reason;
  }

  _tentar(ctx, origem) {
    const { player, mapa, roomData, enemies = [], jaAtivado = null } = ctx;
    const candidatos = alvosDaSala(roomData, enemies, mapa.tileSize, jaAtivado);
    const achado = escolherAlvo({ origem, direcao: this.aim, alcance: this.config.alcance, candidatos, mapa, tolerancia: this.config.toleranciaLinha, conoMin: this.config.conoMin });
    this.t = 0; this._player = player; this._interrompeu = false; this._semAvanco = 0;
    if (!achado) {   // sem alvo: estende até o limite livre e recolhe, sem efeito algum
      this.phase = 'miss'; this.point = pontoLivre(mapa, origem, this.aim, this.config.alcance); this.missAim = { ...this.aim };
      this.gasta = true; this.events.push('miss'); return;
    }
    this.target = achado.alvo; this.point = achado.ponto; this.phase = 'extending';
  }

  _aoConectar(ctx, origem) {
    const alvo = this.target; this.phase = 'connected'; this.active = true; this.t = 0;
    this.events.push('connect');
    if (alvo.tendrilKind === 'anchor') this._player.tendrilPulling = true;
    else if (alvo.tendrilKind === 'object') ctx.activate?.(alvo);
    else if (alvo.tendrilKind === 'enemy') {
      const en = alvo.enemy;
      if (en.tendrilInterruptible && en.interromperAtaque?.()) { this._interrompeu = true; this.events.push('interrupt'); }
      if (!en.tendrilPullable) this.events.push('resist');
    }
    ctx.logger?.info?.('habilidades', `Tendril conectada (${alvo.tendrilKind}).`);
  }

  update(dt, ctx = {}) {
    const { player, input, mapa, paused = false, transition = false } = ctx;
    const segurando = !!input?.isDown?.('tendril');
    const pode = !!(player && input && mapa && player.hasAbility?.('tendril') && !paused && !transition && player.life > 0 && player.state !== 'dead' && !(player.hurtTimer > 0));

    if (this.phase === 'retract') {   // anima a volta até Limo
      this.t += dt;
      if (this.t >= this.config.tempoRetracao) { const gasta = this.gasta && segurando; const miss = this.missAim; this.reset(); this.gasta = gasta; this.missAim = miss; }
      else if (player && this._tipDe) { const u = this.t / this.config.tempoRetracao; this.tip = { x: this._tipDe.x + (player.centerX - this._tipDe.x) * u, y: this._tipDe.y + (player.centerY - this._tipDe.y) * u }; }
      return;
    }
    if (!pode || !segurando) {
      if (this.phase !== 'idle') this.stop(paused ? 'paused' : (!player || player.life <= 0 || player.state === 'dead') ? 'dead' : transition ? 'room-change' : 'released');
      this.mirando = false; this.gasta = false; return;
    }
    this._player = player; this._mapaAtual = mapa;
    const entrada = direcaoDaEntrada(input);
    if (entrada) this.lastAim = entrada;
    this.aim = this.lastAim || { x: player.facing === -1 ? -1 : 1, y: 0 };
    this.mirando = true;
    const origem = { x: player.centerX, y: player.centerY };

    if (this.phase === 'idle') {
      if (this.gasta && this.missAim && this.aim.x * this.missAim.x + this.aim.y * this.missAim.y < 0.9) this.gasta = false;   // mirou outro lado: nova tentativa
      if (!this.gasta) this._tentar(ctx, origem);
      if (this.phase === 'idle') return;
    }
    this.t += dt;
    const c = this.config;

    if (this.phase === 'miss') {
      const u = Math.min(1, this.t / c.tempoMiss); this.tip = { x: origem.x + (this.point.x - origem.x) * u, y: origem.y + (this.point.y - origem.y) * u };
      if (this.t >= c.tempoMiss) this.stop('miss');
      return;
    }

    // --- extending / connected: o alvo precisa continuar válido ---
    const alvo = this.target;
    if (alvo.tendrilKind === 'enemy') { if (!alvo.enemy.alive) { this.stop('target-lost'); return; } this.point = pontoAlvo(alvo.enemy); }
    if (Math.hypot(this.point.x - origem.x, this.point.y - origem.y) > c.alcance * 1.6 || linhaBloqueada(mapa, origem, this.point, c.toleranciaLinha)) { this.stop('target-lost'); return; }
    if (input.wasPressed?.('jump') || input.wasPressed?.('dash')) { this.stop('cancel'); return; }   // pulo/investida cancelam e agem normalmente

    if (this.phase === 'extending') {
      const u = Math.min(1, this.t / c.tempoExtensao); this.tip = { x: origem.x + (this.point.x - origem.x) * u, y: origem.y + (this.point.y - origem.y) * u };
      if (this.t >= c.tempoExtensao) this._aoConectar(ctx, origem);
      return;
    }

    this.tip = { x: this.point.x, y: this.point.y };
    if (alvo.tendrilKind === 'anchor') this._puxarJogador(dt, player, origem, input, mapa);
    else if (alvo.tendrilKind === 'enemy' && alvo.enemy.tendrilPullable) this._puxarInimigo(dt, alvo.enemy, mapa, origem);
    else if (alvo.tendrilKind === 'enemy' && alvo.enemy.tendrilInterruptible && !this._interrompeu && alvo.enemy.interromperAtaque?.()) { this._interrompeu = true; this.events.push('interrupt'); }
  }

  /**
   * Puxão ELÁSTICO: a âncora age como uma mola (força ∝ distância − corda), então Limo é lançado na direção dela, ganha velocidade,
   * passa direto, balança como pêndulo (gravidade parcial + amortecimento) e responde a ←/→. Soltar em movimento = arremesso.
   * Todo deslocamento passa por moveBody: paredes, pisos e tetos continuam intransponíveis.
   */
  _puxarJogador(dt, player, origem, input, mapa) {
    const c = this.config; const ph = player.config?.physics || {};
    const dx = this.point.x - origem.x; const dy = this.point.y - origem.y; const d = Math.hypot(dx, dy) || 1;
    let ax = 0; let ay = (ph.gravity ?? 1000) * c.gravidadeFator;
    if (d > c.cordaRepouso) { const a = Math.min(c.aceleracaoMax, c.rigidez * (d - c.cordaRepouso)); ax += (dx / d) * a; ay += (dy / d) * a; }
    ax += (input?.axisX?.() || 0) * c.controleBalanco;
    player.vx += ax * dt; player.vy += ay * dt;
    const amort = Math.exp(-c.amortecimento * dt); player.vx *= amort; player.vy *= amort;
    const v = Math.hypot(player.vx, player.vy); if (v > c.velocidadeMax) { player.vx *= c.velocidadeMax / v; player.vy *= c.velocidadeMax / v; }
    moveBody(this._mapaAtual, player.body, player.vx * dt, player.vy * dt, {}, player.contacts);
    const ct = player.contacts || {};
    if ((ct.left && player.vx < 0) || (ct.right && player.vx > 0)) player.vx = 0;
    if (ct.up && player.vy < 0) player.vy = 0;
    if (ct.down && player.vy > 0) player.vy = 0;
    player.onGround = !!ct.down;
    const parado = Math.hypot(player.vx, player.vy) < 10 && Math.hypot(this.point.x - player.centerX, this.point.y - player.centerY) > c.cordaRepouso + 24;
    this._semAvanco = parado ? this._semAvanco + dt : 0;
    if (this._semAvanco >= c.bloqueioMax) this.stop('blocked');
  }

  /** Soltar/pular em movimento: mantém a inércia (com bônus) e tira o atrito horizontal por um instante → arremesso. */
  _arremessar(player) {
    if (!player) return;
    const c = this.config; const v = Math.hypot(player.vx || 0, player.vy || 0); if (v < 40) return;
    const k = Math.min(c.impulsoSolta, c.velocidadeSolta / v); player.vx *= k; player.vy *= k;
    player.launchT = c.tempoLancamento; this.events.push('arremesso');
  }

  _puxarInimigo(dt, enemy, mapa, origem) {
    const c = this.config; const dx = origem.x - this.point.x; const dy = origem.y - this.point.y; const d = Math.hypot(dx, dy);
    enemy.tendrilHold = 0.12;
    if (d <= c.distanciaInimigo) { if (!enemy.tendrilAtordoado) { enemy.tendrilAtordoado = true; enemy.atordoar?.(1.2, 'puxado'); } return; }
    enemy.tendrilAtordoado = false;
    const passo = Math.min(c.velocidadePuxao * dt, d - c.distanciaInimigo);
    moveBody(mapa, enemy.body, (dx / d) * passo, (dy / d) * passo, {}, enemy.contacts);
  }
}
