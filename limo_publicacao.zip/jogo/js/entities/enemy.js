// =====================================================================
// INIMIGOS DO ECOSSISTEMA
//  - rastejante: patrulha e persegue sem cair em beiradas
//  - esporo (flyer): paira e acompanha o jogador no ar
//  - saltador (leaper): dá saltos periódicos ao perseguir
//  - couraçado (armored): variante terrestre resistente configurada nos dados
//  - chefe (boss): grande, resistente e com padrões anunciados
// =====================================================================
import { criarDevorador, atualizarDevorador, CAIXA_DEVORADOR } from './devorador-movimento.js';
import { moveBody, probeGround, createContacts } from '../world/collision.js';
import { PADROES, PADRAO_POR_CHEFE, atualizarChefePadrao } from './combate.js';

export const ENEMY_DEFAULTS = {
  w: 12, h: 10, speed: 30, life: 1, damage: 1,
  sight: 120, sightY: 40,
  patrolFactor: 0.6,
  gravity: 400, maxFall: 200,
  turnDelay: 0.25,
  hurtTime: 0.25,
  leapSpeed: 155, leapCooldown: 1.45,
  chargeWindup: 0.60, chargeDuration: 0.30, chargeCooldown: 1.4,
  chargeRange: 104, chargeSpeed: 148,
  stitchWindup: 0.86, stitchDuration: 0.72,
  returnWindup: 0.62, returnOut: 0.25, returnHook: 0.16, returnBack: 0.33,
  pulseWindup: 0.82, pulseDuration: 0.50,
  // v1.35: comportamentos próprios (todos anunciados: o corpo se prepara ANTES de ferir)
  boteAviso: 0.45, boteDur: 0.22, boteVel: 150, boteAlcance: 46, boteRecup: 0.55, boteCd: 1.6,
  saltoAviso: 0.40, saltoVx: 75, saltoAlcance: 110, saltoRecup: 0.35,
  escudadaAviso: 0.70, escudadaDur: 0.35, escudadaVel: 112, escudadaAlcance: 76, escudadaRecup: 0.85, escudadaCd: 2.0,
  mergulhoAviso: 0.55, mergulhoDur: 0.55, mergulhoVel: 150, mergulhoAlcance: 84, mergulhoRecup: 0.75, mergulhoCd: 1.9,
};

const ENEMY_NAMES = {
  crawler: 'Rastejante', flyer: 'Esporo', leaper: 'Saltador', armored: 'Couraçado', boss: 'Chefe',
};

/** Como cada espécie reage à Tendril: leves podem ser puxados; o chefe (pesado) resiste ao puxão mas tem o ataque interrompido. */
export const TENDRIL_POR_ESPECIE = {
  crawler: { puxavel: true }, flyer: { puxavel: true }, leaper: { puxavel: true },
  armored: { puxavel: false, interrompivel: false }, boss: { puxavel: false, interrompivel: true },
};

export class Enemy {
  constructor(x, y, w = ENEMY_DEFAULTS.w, h = ENEMY_DEFAULTS.h, speed = ENEMY_DEFAULTS.speed, life = ENEMY_DEFAULTS.life, opts = {}) {
    this.cfg = { ...ENEMY_DEFAULTS, ...opts };
    this.body = { x, y, w, h };
    this.vx = 0; this.vy = 0;
    this.speed = speed;
    this.facing = opts.facing || 1;
    this.damage = this.cfg.damage;
    this.life = life; this.maxLife = life;
    this.alive = true;
    this.chasing = false;
    this.hurtTimer = 0; this.turnTimer = 0;
    this.contacts = createContacts();
    this.t = 0; this.home = { x, y };
    this.name = opts.name || ENEMY_NAMES[opts.kind] || ENEMY_NAMES.crawler;
    this.bossId = opts.bossId || null;
    this.jumpTimer = 0.55;
    this.attackState = 'stalk';
    this.attackTimer = 0;
    this.attackCooldown = opts.kind === 'boss' ? 0.7 : 0;
    this.attackDir = this.facing;
    this.attackKind = null;
    this.attackIndex = 0;
    this.attackOriginX = null; // origem fixa: o aviso da Tecelã continua fiel à rota durante a investida
    this.attackZones = [];
    this.audioEvents = []; // exclusivamente cosmético
    this.pedidos = [];     // pedidos ao jogo (ex.: invocar filhotes); o Game drena
    this.attackDur = 1; this.impactoT = 0; this.impactoDir = 1; this.guardaQuebrada = 0; this.motivoStun = null;
    this.anuncio = null; this.padraoAtual = null; this.filhotes = []; this.alvoMergulho = null;
    // Só a Tecelã usa o ciclo completo; chefes futuros mantêm o padrão legado.
    this.bossPattern = opts.bossPattern || null;
    const tp = TENDRIL_POR_ESPECIE[opts.kind] || TENDRIL_POR_ESPECIE.crawler;
    this.tendrilPullable = opts.tendrilPullable ?? !!tp.puxavel;          // leve: pode ser puxado até Limo
    this.tendrilInterruptible = opts.tendrilInterruptible ?? !!tp.interrompivel;   // ataque anunciado pode ser cortado
    this.tendrilHold = 0;                                                  // >0: preso pela Tendril (não anda sozinho)
    // Peso: leves (rastejante, esporo, saltador) são empurrados por golpes; couraçados e chefes não saem do lugar.
    this.pesado = opts.pesado ?? (opts.kind === 'armored' || opts.kind === 'boss');
    this.ia = null; this.cerebro = null; this.fugaBloqueada = false;   // v1.39.0: preenchidos por entities/comportamento.js (sem cérebro, nada muda)
  }

  /** Corta um telegráfico anunciado: o inimigo fica exposto em recuperação. */
  interromperAtaque() {
    const anunciando = this.attackState === 'windup' || this.attackState === 'charge' || /Windup$/.test(this.attackState);
    if (!this.alive || !anunciando) return false;
    this.attackState = 'recovery'; this.attackTimer = 0.9; this.attackCooldown = this.cfg.chargeCooldown; this.vx = 0;
    this.attackKind = null; this.attackZones = [];
    return true;
  }

  drenarEventosAudio() { const eventos = this.audioEvents; this.audioEvents = []; return eventos; }
  drenarPedidos() { const p = this.pedidos; this.pedidos = []; return p; }

  /** O corpo está se preparando para ferir (anúncio): o desenho agacha/brilha e o jogador pode contra-atacar. */
  get telegrafando() { return this.alive && (this.attackState === 'telegraph' || this.attackState === 'padraoWindup' || /Windup$/.test(this.attackState || '')); }
  /** 0..1: quanto do anúncio já passou (para animar a antecipação). */
  get telegrafoFracao() { return this.telegrafando ? Math.max(0, Math.min(1, 1 - this.attackTimer / (this.attackDur || 1))) : 0; }
  get atordoado() { return this.attackState === 'stun'; }
  /** Recuperação do ataque: o inimigo está exposto (janela de contra-ataque). */
  get exposto() { return this.alive && (this.attackState === 'recovery' || this.attackState === 'stun'); }

  /** Atordoa um inimigo comum: cancela o ataque e o deixa exposto. Chefes não atordoam (têm janela de recuperação). */
  atordoar(t = 1.2, motivo = 'atordoado') {
    if (!this.alive || this.cfg.kind === 'boss' || this.intro) return false;
    this.attackState = 'stun'; this.attackTimer = t; this.attackDur = t; this.vx = 0; this.attackZones = []; this.attackKind = null; this.motivoStun = motivo;
    this.audioEvents.push('atordoar'); return true;
  }

  /** Couraçado: a guarda cobre a frente enquanto ele não está atordoado nem se recuperando. */
  guardaAtiva(origemX = null) {
    if (this.cfg.kind !== 'armored' || this.guardaQuebrada > 0 || this.exposto) return false;
    return origemX == null ? true : Math.sign(origemX - this.centerX || this.facing) === this.facing;
  }

  /**
   * Golpe com consequências. `tipo`: 'golpe' (Pseudópode) | 'investida' | 'pisao' | 'tendril'.
   * Devolve { resultado, morreu }: 'dano' · 'aparado' · 'guarda_quebrada' · 'contragolpe' · 'exposto' · 'ignorado'.
   *   - Couraçado de frente: aparado (sem dano); a Investida quebra a guarda; o 3º golpe do combo a atravessa; o pisão vem de cima.
   *   - Acertar um inimigo comum NO ANÚNCIO é contragolpe: ataque cancelado, +1 de dano e atordoamento.
   *   - Chefe na recuperação: sem dano extra, mas o feedback marca a janela ("exposto").
   */
  receberGolpe({ dano = 1, origemX = null, empurrao = 90, tipo = 'golpe', passo = 0 } = {}) {
    if (!this.alive || this.intro || this.hurtTimer > 0) return { resultado: 'ignorado', morreu: false };
    let resultado = 'dano'; let n = dano;
    if (this.guardaAtiva(origemX) && tipo !== 'pisao') {
      if (tipo === 'investida') { this.guardaQuebrada = 1.4; resultado = 'guarda_quebrada'; }
      else if (tipo === 'golpe' && passo >= 2) { this.guardaQuebrada = 0.6; resultado = 'guarda_quebrada'; }
      else { this.impactoT = 0.16; this.impactoDir = origemX != null && origemX < this.centerX ? 1 : -1; this.audioEvents.push('aparar'); return { resultado: 'aparado', morreu: false }; }
    } else if (this.cfg.kind !== 'boss' && this.telegrafando) { n += 1; resultado = 'contragolpe'; }
    else if (this.cfg.kind === 'boss' && this.exposto) resultado = 'exposto';
    const morreu = this.takeHit(n, origemX, empurrao);
    if (!morreu && (resultado === 'guarda_quebrada' || resultado === 'contragolpe')) this.atordoar(resultado === 'contragolpe' ? 0.9 : 1.4, resultado);
    return { resultado, morreu };
  }

  /** Cria a entidade com os pés apoiados na célula declarada pela sala. */
  static fromSpawn(sp, tileSize) {
    const kind = sp.kind || 'crawler';
    const tx = sp.tileX ?? Math.floor(sp.x / tileSize);
    const ty = sp.tileY ?? Math.floor(sp.y / tileSize);
    if (kind === 'flyer') {
      const w = 10; const h = 9;
      return new Enemy((tx + 0.5) * tileSize - w / 2, (ty + 0.5) * tileSize - h / 2,
        w, h, sp.speed ?? 45, sp.life ?? 1, {
          kind, sight: 110, sightY: 90, damage: sp.damage ?? 1, name: sp.name,
        });
    }

    const dimensoes = {
      crawler: [12, 10], leaper: [12, 11], armored: [16, 14], boss: [26, 20],
    }[kind] || [ENEMY_DEFAULTS.w, ENEMY_DEFAULTS.h];
    const [w, h] = dimensoes;
    const opts = {
      kind,
      facing: sp.facing === -1 ? -1 : 1,
      damage: sp.damage ?? (kind === 'boss' ? 2 : 1),
      name: sp.name,
      bossId: sp.bossId,
      bossPattern: PADRAO_POR_CHEFE[sp.bossId] || null,
    };
    if (kind === 'boss') Object.assign(opts, {
      sight: 320, sightY: 110, chargeWindup: 0.60, chargeDuration: 0.30,
      chargeCooldown: 1.45, chargeRange: 116, chargeSpeed: Math.max(135, (sp.speed ?? 40) * 3.4),
      gravity: 520, maxFall: 260, stitchWindup: 0.86, stitchDuration: 0.72,
      returnWindup: 0.62, returnOut: 0.25, returnHook: 0.16, returnBack: 0.33, pulseWindup: 0.82, pulseDuration: 0.50,
    });
    return new Enemy((tx + 0.5) * tileSize - w / 2, (ty + 1) * tileSize - h,
      w, h, sp.speed ?? (kind === 'boss' ? 40 : ENEMY_DEFAULTS.speed),
      sp.life ?? (kind === 'boss' ? 5 : ENEMY_DEFAULTS.life), opts);
  }

  get centerX() { return this.body.x + this.body.w / 2; }
  get centerY() { return this.body.y + this.body.h / 2; }

  /** Há chão logo à frente? (só faz sentido quando está apoiado) */
  _temChaoAdiante(mapa) {
    const b = this.body;
    return !!probeGround(mapa, { x: b.x + this.facing * 6, y: b.y, w: b.w, h: b.h }, false);
  }

  _virar() {
    if (this.turnTimer > 0) return;
    this.facing = -this.facing; this.turnTimer = this.cfg.turnDelay;
  }

  update(dt, mapa, player) {
    if (!this.alive || this.intro) return;
    this.hurtTimer = Math.max(0, this.hurtTimer - dt);
    this.turnTimer = Math.max(0, this.turnTimer - dt);
    if (this.tendrilHold > 0) {   // preso pela Tendril: só a gravidade age (o puxão é aplicado pelo controlador)
      this.tendrilHold -= dt; this.vx = 0; this.jumpTimer = Math.max(this.jumpTimer, 0.4);
      if (this.cfg.kind === 'flyer') this.vy = 0; else this.vy = Math.min(this.vy + this.cfg.gravity * dt, this.cfg.maxFall);
      moveBody(mapa, this.body, 0, this.vy * dt, {}, this.contacts);
      if (this.contacts.down || this.contacts.up) this.vy = 0;
      return;
    }
    if (this.cfg.kind === 'flyer') { this._updateFlyer(dt, mapa, player); return; }
    if (this.cfg.kind === 'boss') { this._updateBoss(dt, mapa, player); return; }

    this._updateTerrestre(dt, mapa, player);
  }

  /** Rastejante (bote), Saltador (salto anunciado) e Couraçado (escudada): perseguem, ANUNCIAM, atacam e ficam expostos. */
  _updateTerrestre(dt, mapa, player) {
    const c = this.cfg; const k = c.kind;
    this.t += dt; this.jumpTimer = Math.max(0, this.jumpTimer - dt); this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    this.impactoT = Math.max(0, this.impactoT - dt); this.guardaQuebrada = Math.max(0, this.guardaQuebrada - dt);
    const noChao = this.contacts.down; const st = this.attackState;
    const mover = () => {
      this.vy = Math.min(this.vy + c.gravity * dt, c.maxFall);
      moveBody(mapa, this.body, this.vx * dt, this.vy * dt, {}, this.contacts);
      if (this.contacts.down || this.contacts.up) this.vy = 0;
    };
    let dx = 0; let dy = 0; this.chasing = false;
    if (player && player.life > 0) {
      dx = player.centerX - this.centerX; dy = player.centerY - this.centerY;
      if (Math.abs(dx) <= c.sight && Math.abs(dy) <= c.sightY) { this.chasing = true; if (Math.abs(dx) > 2 && st === 'stalk') this.facing = Math.sign(dx); }
    }
    if (st === 'stun') { this.vx *= 0.85; this.attackTimer -= dt; mover(); if (this.attackTimer <= 0) { this.attackState = 'stalk'; this.attackCooldown = Math.max(this.attackCooldown, 0.5); } return; }
    if (st === 'telegraph') {   // agachado/escudo erguido: parado, avisando
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) this._executarAtaqueLeve();
      return;
    }
    if (st === 'act') { this._agirLeve(dt, mover); return; }
    if (st === 'recovery') { this.vx *= 0.8; this.attackTimer -= dt; mover(); if (this.attackTimer <= 0) this.attackState = 'stalk'; return; }

    // --- v1.39.0: comportamento da espécie (descansar, fugir, andar devagar) ---
    const ia = this.ia; this.fugaBloqueada = false;
    if (ia?.repouso && st === 'stalk') { this.vx *= 0.8; this.chasing = false; mover(); return; }
    const fugindo = !!(ia?.fugir && ia.ameaca);
    if (fugindo) { this.chasing = false; this.facing = Math.sign(this.centerX - ia.ameaca.centerX) || this.facing; }
    // --- perseguição / patrulha ---
    if (noChao && !this._temChaoAdiante(mapa)) { if (fugindo) this.fugaBloqueada = true; else if (this.chasing) { /* segura na beirada */ } else this._virar(); }
    const livre = noChao && this.chasing && this.hurtTimer <= 0 && !fugindo;
    if (livre) {   // gatilhos de ataque: sempre começam por um ANÚNCIO
      if (k === 'crawler' && this.attackCooldown <= 0 && Math.abs(dx) <= c.boteAlcance && Math.abs(dy) <= 14) return this._anunciar('bote', c.boteAviso);
      if (k === 'leaper' && this.jumpTimer <= 0 && Math.abs(dx) <= c.saltoAlcance) return this._anunciar('salto', c.saltoAviso);
      if (k === 'armored' && this.attackCooldown <= 0 && Math.abs(dx) <= c.escudadaAlcance && Math.abs(dy) <= 18) return this._anunciar('escudada', c.escudadaAviso);
    }
    const parado = (this.chasing || fugindo) && noChao && !this._temChaoAdiante(mapa);
    const vel = (fugindo ? this.speed * (ia.velMul || 1.3) : (this.chasing ? this.speed : this.speed * c.patrolFactor) * (ia ? ia.velMul : 1));
    if (this.hurtTimer > 0) this.vx *= 0.9;
    else this.vx = parado ? 0 : this.facing * vel;
    mover();
    if (fugindo) { if ((this.contacts.left && this.facing < 0) || (this.contacts.right && this.facing > 0)) this.fugaBloqueada = true; }   // sem saída: o cérebro decide lutar
    else if (this.contacts.left) { this.facing = 1; this.turnTimer = c.turnDelay; }
    else if (this.contacts.right) { this.facing = -1; this.turnTimer = c.turnDelay; }
    if (this.body.y > mapa.pixelHeight + 64) this.alive = false;
  }

  _anunciar(tipo, duracao) {
    this.attackKind = tipo; this.attackState = 'telegraph'; this.attackTimer = duracao; this.attackDur = duracao; this.attackDir = this.facing; this.vx = 0;
    this.audioEvents.push(`aviso_${tipo}`);
  }

  _executarAtaqueLeve() {
    const c = this.cfg; this.attackState = 'act'; this.attackDir = this.facing; this.audioEvents.push(this.attackKind);
    if (this.attackKind === 'bote') { this.attackTimer = c.boteDur; this.vx = this.attackDir * c.boteVel; this.vy = -55; }
    else if (this.attackKind === 'salto') { this.attackTimer = 1.4; this.vy = -c.leapSpeed; this.vx = this.attackDir * c.saltoVx; this.noAr = false; }
    else { this.attackTimer = c.escudadaDur; this.vx = this.attackDir * c.escudadaVel; }
  }

  _agirLeve(dt, mapa_mover) {
    const c = this.cfg; this.attackTimer -= dt; mapa_mover();
    const parede = (this.contacts.left && this.attackDir < 0) || (this.contacts.right && this.attackDir > 0);
    const fim = (recup, cd) => { this.attackState = 'recovery'; this.attackTimer = recup; this.attackDur = recup; this.attackCooldown = cd; this.vx = 0; this.attackKind = null; };
    if (this.attackKind === 'salto') {
      if (!this.contacts.down) this.noAr = true;
      if (parede) this.vx = 0;
      if ((this.noAr && this.contacts.down) || this.attackTimer <= 0) { fim(c.saltoRecup, 0); this.jumpTimer = c.leapCooldown; }
      return;
    }
    if (parede) { this.atordoar(this.attackKind === 'escudada' ? 1.3 : 1.0, 'parede'); this.audioEvents.push('bate_parede'); return; }   // errou: bateu na parede e ficou tonto
    if (this.attackTimer <= 0) { if (this.attackKind === 'bote') fim(c.boteRecup, c.boteCd); else fim(c.escudadaRecup, c.escudadaCd); }
  }

  /** Distância real do Bote/Retorno: deslocamento, meio corpo e folga para leitura do jogador. */
  _alcanceMelee(tipo) {
    const c = this.cfg;
    const deslocamento = tipo === 'return' ? c.chargeSpeed * 0.9 * c.returnOut : c.chargeSpeed * c.chargeDuration;
    return Math.round(deslocamento + this.body.w / 2 + 10);
  }

  /** Zonas visuais e de dano da Tecelã. Cada rota é anunciada e a área acesa é exatamente a que pode ferir. */
  _atualizarZonasTecela(mapa) {
    this.attackZones = [];
    const b = this.body; const yChao = Math.round(b.y + b.h - 7);
    const faixas = [32, 136, 240, 344].filter((x) => x < mapa.pixelWidth - 20);
    // A Costura atravessa a arena como uma onda. Cada ponto avisa antes e fica aceso pouco tempo,
    // deixando corredores largos em vez de transformar a sala num teste de mobilidade avançada.
    const costura = (ativa) => faixas.map((x, i) => {
      const ordem = this.attackDir > 0 ? i : faixas.length - 1 - i;
      const fase = ativa ? 1 - Math.max(0, this.attackTimer) / this.cfg.stitchDuration : 0;
      const inicio = 0.08 + ordem * 0.12;
      return { tipo: 'ground', x, y: yChao, w: 50, h: 7, active: ativa && fase >= inicio && fase < inicio + 0.34,
        telegraph: !ativa || fase < inicio, phase: fase, start: inicio, damage: this.damage, originX: x + 25 };
    });
    // A rota usa a origem do ataque, não a posição atual do chefe: o fio não desliza enquanto ela investe.
    const rota = (alcance, ativa) => {
      const origem = this.attackOriginX ?? this.centerX;
      const x = this.attackDir > 0 ? origem : origem - alcance;
      return { tipo: 'path', x, y: yChao, w: alcance, h: 7, active: ativa, telegraph: !ativa,
        damage: this.damage, originX: origem };
    };
    if (this.attackState === 'weaveStitchWindup') this.attackZones = costura(false);
    else if (this.attackState === 'weaveStitch') this.attackZones = costura(true);
    else if (this.attackState === 'weaveTearWindup' || this.attackState === 'weaveTear') {
      const alcance = this._alcanceMelee('tear');
      this.attackZones = [rota(alcance, this.attackState === 'weaveTear')];
    } else if (this.attackState === 'weaveReturnWindup' || this.attackState === 'weaveReturnOut' || this.attackState === 'weaveReturnBack') {
      this.attackZones = [rota(this._alcanceMelee('return'), this.attackState !== 'weaveReturnWindup')];
    } else if (this.attackState === 'weavePulseWindup') {
      // O aviso começa no mesmo raio do pulso para a área segura não parecer encolher no impacto.
      this.attackZones = [{ tipo: 'ring', x: this.centerX, y: this.centerY, r: 18, thickness: 5, active: false, phase: 0 }];
    } else if (this.attackState === 'weavePulse') {
      const progresso = 1 - Math.max(0, this.attackTimer) / this.cfg.pulseDuration;
      this.attackZones = [{ tipo: 'ring', x: this.centerX, y: this.centerY, r: 18 + 104 * progresso, thickness: 7, active: true, phase: progresso, damage: this.damage, originX: this.centerX }];
    }
  }

  _iniciarAtaqueTecela() {
    const ciclo = ['tear', 'stitch', 'return', 'pulse'];
    this.attackKind = ciclo[this.attackIndex++ % ciclo.length]; this.audioEvents.push(`teia_${this.attackKind}_aviso`); this.attackDir = this.facing; this.attackOriginX = this.centerX; this.vx = 0;
    if (this.attackKind === 'tear') { this.attackState = 'weaveTearWindup'; this.attackTimer = this.cfg.chargeWindup; }
    else if (this.attackKind === 'stitch') { this.attackState = 'weaveStitchWindup'; this.attackTimer = this.cfg.stitchWindup; }
    else if (this.attackKind === 'return') { this.attackState = 'weaveReturnWindup'; this.attackTimer = this.cfg.returnWindup; }
    else { this.attackState = 'weavePulseWindup'; this.attackTimer = this.cfg.pulseWindup; }
  }

  /** Tecelã: ciclo fixo de quatro ataques, todos anunciados e com recuperação para contra-ataque. */
  _updateTecela(dt, mapa, player, mover, dx, noChao) {
    const c = this.cfg;
    if (this.attackState === 'weaveTearWindup') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) { this.audioEvents.push('teia_tear'); this.attackState = 'weaveTear'; this.attackTimer = c.chargeDuration; }
    } else if (this.attackState === 'weaveTear') {
      this.vx = this.attackDir * c.chargeSpeed; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0 || this.contacts.left || this.contacts.right) this._encerrarAtaqueTecela(0.82, 1.15);
    } else if (this.attackState === 'weaveStitchWindup') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) { this.audioEvents.push('teia_stitch'); this.attackState = 'weaveStitch'; this.attackTimer = c.stitchDuration; }
    } else if (this.attackState === 'weaveStitch') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) this._encerrarAtaqueTecela(0.90, 1.20);
    } else if (this.attackState === 'weaveReturnWindup') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) { this.audioEvents.push('teia_return'); this.attackState = 'weaveReturnOut'; this.attackTimer = c.returnOut; }
    } else if (this.attackState === 'weaveReturnOut') {
      this.vx = this.attackDir * c.chargeSpeed * 0.9; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0 || this.contacts.left || this.contacts.right) { this.attackState = 'weaveReturnHook'; this.attackTimer = c.returnHook; this.vx = 0; }
    } else if (this.attackState === 'weaveReturnHook') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) { this.attackState = 'weaveReturnBack'; this.attackTimer = c.returnBack; }
    } else if (this.attackState === 'weaveReturnBack') {
      this.vx = -this.attackDir * c.chargeSpeed * 0.95; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0 || this.contacts.left || this.contacts.right) this._encerrarAtaqueTecela(0.88, 1.28);
    } else if (this.attackState === 'weavePulseWindup') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) { this.audioEvents.push('teia_pulse'); this.attackState = 'weavePulse'; this.attackTimer = c.pulseDuration; }
    } else if (this.attackState === 'weavePulse') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) this._encerrarAtaqueTecela(0.95, 1.45);
    } else if (this.attackState === 'recovery') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) { this.attackState = 'stalk'; this.attackKind = null; }
    } else {
      // Bote e Retorno só começam dentro do alcance real; Costura continua podendo cobrir a arena.
      const proximo = ['tear', 'stitch', 'return', 'pulse'][this.attackIndex % 4];
      const limite = proximo === 'stitch' ? c.sight : proximo === 'pulse' ? 150 : this._alcanceMelee(proximo) + 16;
      const perto = this.chasing && Math.abs(dx) <= Math.min(c.sight, limite);
      if (noChao && perto && this.attackCooldown <= 0) this._iniciarAtaqueTecela();
      else {
        if (noChao && !this._temChaoAdiante(mapa)) this.vx = this.chasing ? 0 : this.facing * this.speed * c.patrolFactor;
        else this.vx = this.chasing ? this.facing * this.speed : this.facing * this.speed * c.patrolFactor;
        mover();
      }
    }
    this._atualizarZonasTecela(mapa);
  }

  _encerrarAtaqueTecela(recuperacao, cooldown) {
    this.attackState = 'recovery'; this.attackTimer = recuperacao; this.attackCooldown = cooldown; this.vx = 0;
  }

  /** Chefe: aproxima-se, anuncia o ataque e recupera antes de poder repetir. */
  _updateBoss(dt, mapa, player) {
    if (this.bossPattern === 'devorador') { this._updateDevorador(dt, mapa, player); return; }
    const c = this.cfg; const b = this.body;
    this.t += dt; this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    const noChao = this.contacts.down;
    let dx = 0; let dy = 0; this.chasing = false;
    if (player && player.life > 0) {
      dx = player.centerX - this.centerX; dy = player.centerY - this.centerY;
      if (Math.abs(dx) <= c.sight && Math.abs(dy) <= c.sightY) {
        this.chasing = true; if (Math.abs(dx) > 2) this.facing = Math.sign(dx);
      }
    }
    const mover = () => {
      this.vy = Math.min(this.vy + c.gravity * dt * (this.vy > 0 ? 1.15 : 1), c.maxFall);
      moveBody(mapa, b, this.vx * dt, this.vy * dt, {}, this.contacts);
      if (this.contacts.down || this.contacts.up) this.vy = 0;
      if (this.contacts.left) this.facing = 1; else if (this.contacts.right) this.facing = -1;
    };
    this.impactoT = Math.max(0, this.impactoT - dt);
    if (this.bossPattern === 'tecelã') this._updateTecela(dt, mapa, player, mover, dx, noChao);
    else if (PADROES[this.bossPattern]) atualizarChefePadrao(this, dt, { mapa, player, mover, dx, noChao });
    else this._updateBossLegado(dt, mapa, player, mover, dx, noChao);
    if (b.y > mapa.pixelHeight + 64) this.alive = false;
  }

  /** Devorador de Flores: movimentação de devorador-movimento.js. Sem ataques nesta etapa. */
  _updateDevorador(dt, mapa, player) {
    if (!this.devorador) {
      this.body.w = CAIXA_DEVORADOR.w; this.body.h = CAIXA_DEVORADOR.h;
      this.devorador = criarDevorador(this.body.x, this.body.y, { facing: this.facing || -1, semente: 7 });
      this.devorador.corpo = this.body;          // o corpo do chefe é o corpo da movimentação
      this.devorador.contacts = this.contacts;
      this._faixaDevorador = { x0: this.body.x - 120, x1: this.body.x + this.body.w + 120 };
    }
    const alvo = player && player.life > 0 ? { cx: player.centerX, cy: player.centerY } : null;
    atualizarDevorador(this.devorador, dt, mapa, alvo, this._faixaDevorador);
    this.facing = this.devorador.facing;
    if (this.body.y > mapa.pixelHeight + 64) this.alive = false;
  }

  _updateBossLegado(dt, mapa, player, mover, dx, noChao) {
    const c = this.cfg;
    if (this.attackState === 'windup') {
      this.vx = 0; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0) { this.attackState = 'charge'; this.attackTimer = c.chargeDuration; this.attackDir = this.facing; }
    } else if (this.attackState === 'charge') {
      this.vx = this.attackDir * c.chargeSpeed; this.attackTimer -= dt; mover();
      if (this.attackTimer <= 0 || this.contacts.left || this.contacts.right) { this.attackState = 'recovery'; this.attackTimer = 0.56; this.attackCooldown = c.chargeCooldown; this.vx = 0; }
    } else if (this.attackState === 'recovery') {
      this.vx = 0; this.attackTimer -= dt; mover(); if (this.attackTimer <= 0) this.attackState = 'stalk';
    } else {
      const perto = this.chasing && Math.abs(dx) <= c.chargeRange;
      if (noChao && perto && this.attackCooldown <= 0) { this.attackState = 'windup'; this.attackTimer = c.chargeWindup; this.attackDir = this.facing; this.vx = 0; }
      else { this.vx = noChao && !this._temChaoAdiante(mapa) ? (this.chasing ? 0 : this.facing * this.speed * c.patrolFactor) : (this.chasing ? this.facing * this.speed : this.facing * this.speed * c.patrolFactor); mover(); }
    }
  }

  /** Voador: paira; ao ficar sobre o jogador ANUNCIA (treme, brilha, mostra a trajetória), mergulha e fica exposto. */
  _updateFlyer(dt, mapa, player) {
    const c = this.cfg; const b = this.body; this.t += dt; this.attackCooldown = Math.max(0, this.attackCooldown - dt); this.impactoT = Math.max(0, this.impactoT - dt);
    const st = this.attackState;
    if (st === 'stun') {   // sem asas: afunda devagar
      this.attackTimer -= dt; this.vx *= 0.9; this.vy = Math.min(this.vy + 260 * dt, 90);
      moveBody(mapa, b, this.vx * dt, this.vy * dt, {}, this.contacts); if (this.contacts.down) this.vy = 0;
      if (this.attackTimer <= 0) { this.attackState = 'stalk'; this.attackCooldown = Math.max(this.attackCooldown, 0.8); }
      return;
    }
    if (st === 'telegraph') {
      this.attackTimer -= dt; this.vx = 0; this.vy = -8; moveBody(mapa, b, 0, this.vy * dt, {}, this.contacts);
      if (this.attackTimer <= 0 && this.alvoMergulho) {
        const ax = this.alvoMergulho.x - this.centerX; const ay = this.alvoMergulho.y - this.centerY; const d = Math.hypot(ax, ay) || 1;
        this.vx = (ax / d) * c.mergulhoVel; this.vy = (ay / d) * c.mergulhoVel; this.facing = ax >= 0 ? 1 : -1;
        this.attackState = 'act'; this.attackTimer = c.mergulhoDur; this.audioEvents.push('mergulho');
      }
      return;
    }
    if (st === 'act') {
      this.attackTimer -= dt; moveBody(mapa, b, this.vx * dt, this.vy * dt, {}, this.contacts);
      const bateu = this.contacts.down || this.contacts.up || this.contacts.left || this.contacts.right;
      if (bateu || this.attackTimer <= 0) { this.attackState = 'recovery'; this.attackTimer = bateu ? c.mergulhoRecup + 0.35 : c.mergulhoRecup; this.attackDur = this.attackTimer; this.attackCooldown = c.mergulhoCd; this.vx = 0; this.vy = 0; this.attackKind = null; if (bateu) this.audioEvents.push('bate_parede'); }
      return;
    }
    if (st === 'recovery') {   // ofegante: pousa leve e ainda está exposto
      this.attackTimer -= dt; this.vx *= 0.9; this.vy = Math.min(this.vy + 120 * dt, 38); moveBody(mapa, b, this.vx * dt, this.vy * dt, {}, this.contacts);
      if (this.attackTimer <= 0) this.attackState = 'stalk';
      return;
    }
    let alvoX = this.home.x + Math.sin(this.t * 1.3) * 40;
    let alvoY = this.home.y + Math.sin(this.t * 2.4) * 6; let vmax = 40;
    this.chasing = false;
    const ia = this.ia;   // v1.39.0: o Esporo descansa pairando em casa e foge de verdade quando está tímido/ferido
    if (ia?.repouso) { alvoX = this.home.x; alvoY = this.home.y; vmax = 12; player = null; }
    else if (ia?.fugir && ia.ameaca) { const lado = Math.sign(this.centerX - ia.ameaca.centerX) || 1; alvoX = b.x + lado * 60; alvoY = b.y - 28; vmax = this.speed * (ia.velMul || 1.3); player = null; }
    if (player && player.life > 0) {
      const dx = player.centerX - this.centerX; const dy = player.centerY - this.centerY;
      if (Math.abs(dx) <= c.sight && Math.abs(dy) <= c.sightY) {
        this.chasing = true; alvoX = player.centerX - b.w / 2;
        alvoY = player.centerY - b.h / 2 - 6 + Math.sin(this.t * 6) * 3; vmax = this.speed * (ia ? ia.velMul : 1);
        if (this.attackCooldown <= 0 && this.hurtTimer <= 0 && Math.abs(dx) <= c.mergulhoAlcance && dy >= 6 && dy <= 76) {   // em cima do jogador: anuncia
          this.alvoMergulho = { x: player.centerX, y: player.centerY }; this._anunciar('mergulho', c.mergulhoAviso); this.vx = 0; this.vy = 0; return;
        }
      }
    }
    if (this.hurtTimer > 0) { this.vx *= 0.9; this.vy *= 0.9; }
    else { const lim = (v) => Math.max(-vmax, Math.min(vmax, v)); this.vx = lim((alvoX - b.x) * 3); this.vy = lim((alvoY - b.y) * 3); }
    moveBody(mapa, b, this.vx * dt, this.vy * dt, {}, this.contacts);
    if (Math.abs(this.vx) > 4) this.facing = Math.sign(this.vx);
  }

  /** Leva dano (pisão ou investida). Devolve true se morreu. */
  takeHit(n = 1, origemX = null, empurrao = 90) {
    if (!this.alive || this.intro || this.hurtTimer > 0) return false;
    this.life -= n; this.hurtTimer = this.cfg.hurtTime; this.impactoT = 0.2; this.impactoDir = origemX != null && origemX < this.centerX ? 1 : -1;
    if (!this.pesado) {   // só os leves vão para trás
      if (origemX != null) this.vx = (this.centerX >= origemX ? 1 : -1) * empurrao;
      this.vy = -90;
    }
    if (this.life <= 0) { this.alive = false; return true; }
    return false;
  }

  collidesWith(b) {
    return this.body.x < b.x + b.w && this.body.x + this.body.w > b.x && this.body.y < b.y + b.h && this.body.y + this.body.h > b.y;
  }
}
