// =====================================================================
// DEVORADOR DE FLORES — movimentação (Etapa 2.4.3). Sem ataques, dano ou combate.
// Quadrúpede pesado: a velocidade acelera e freia com inércia; o ritmo das patas nasce da velocidade (o pé fica parado no chão
// enquanto o corpo passa, e só então avança), para não haver deslize. Colisão com o cenário pelo mesmo sistema dos outros inimigos
// (moveBody, probeGround). Nunca anda para uma beirada: vira antes de cair. Reposiciona-se dentro dos limites da arena.
// Estados: repouso (respira e vigia), andar (patrulha), virar (pausa de meia-volta), aproximar (vai até Limo),
// reposicionar (volta ao centro da arena quando perde Limo de vista).
// =====================================================================
import { moveBody, probeGround, createContacts } from '../world/collision.js';
import { PASSO_DEVORADOR } from '../render/devorador-art.js';

/** Caixa de colisão provisória (decisão do E0 ainda pendente). O sprite 64×40 é centrado nela e apoiado na base. */
export const CAIXA_DEVORADOR = Object.freeze({ w: 40, h: 28 });
export const CFG_DEVORADOR = Object.freeze({
  gravidade: 520, queda: 640,
  vPatrulha: 13, vAprox: 24, vReposicao: 16,   // px/s
  acel: 2.6,                                    // inércia: a velocidade tende à meta nesta taxa (1/s)
  visao: 200, visaoY: 110, distParada: 34,      // alcance para perceber Limo
  pausaMin: 1.6, pausaMax: 3.4, pausaVigia: 1.8, virarT: 0.6,
  margem: 10,
  ciclo: 0.3,                                   // fração do ciclo de passos por (velocidade / PASSO)
  ciclo_respiracao: 4.2,
});

/** Estado inicial. `x`, `y` é o canto superior esquerdo da caixa de colisão. */
export function criarDevorador(x, y, opcoes = {}) {
  return {
    corpo: { x, y, w: CAIXA_DEVORADOR.w, h: CAIXA_DEVORADOR.h },
    vx: 0, vy: 0, facing: opcoes.facing ?? -1,
    contacts: createContacts(),
    modo: 'repouso', timer: 1.2, proximo: 'andar', facingAlvo: 0, virou: false,
    alvoX: null, perseguiu: false, semente: opcoes.semente ?? 7,
    passo: null,            // null = pose de repouso; 0..1 = fase do ciclo de passos
    resp: 0,                // respiração 0..1
    balanco: 0, tempo: 0,
  };
}

function aleatorio(e) {               // gerador determinístico (reprodutível nos testes)
  e.semente = (e.semente * 1103515245 + 12345) & 0x7fffffff;
  return e.semente / 0x7fffffff;
}
/** Há chão numa direção (true), ou há uma beirada logo à frente (false)? */
function chaoNaDirecao(mapa, e, dir) {
  const x = dir > 0 ? e.corpo.x + e.corpo.w + 2 : e.corpo.x - 4;
  return probeGround(mapa, { x, y: e.corpo.y, w: 2, h: e.corpo.h }) !== null;
}
function virarPara(e, dir, proximo) {
  e.modo = 'virar'; e.timer = CFG_DEVORADOR.virarT; e.facingAlvo = dir; e.virou = false; e.proximo = proximo;
}
function sortearPausa(e) { return CFG_DEVORADOR.pausaMin + (CFG_DEVORADOR.pausaMax - CFG_DEVORADOR.pausaMin) * aleatorio(e); }

/**
 * Avança o movimento por `dtBruto` segundos.
 * `alvo`: {cx, cy} do Limo, ou null. `limites`: {x0, x1} da arena em pixels do mundo, ou null (sem limite lateral).
 */
export function atualizarDevorador(e, dtBruto, mapa, alvo = null, limites = null) {
  const dt = Math.min(dtBruto, 0.05);
  const C = CFG_DEVORADOR;
  e.tempo += dt;
  const cx = e.corpo.x + e.corpo.w / 2; const cy = e.corpo.y + e.corpo.h / 2;
  const x0 = limites ? limites.x0 : -Infinity; const x1 = limites ? limites.x1 : Infinity;
  const vendo = !!alvo && Math.abs(alvo.cx - cx) <= C.visao && Math.abs(alvo.cy - cy) <= C.visaoY;
  const dAlvo = alvo ? alvo.cx - cx : 0;
  const dirAlvo = Math.sign(dAlvo) || e.facing;
  const noChao = e.contacts.down;
  const parede = (e.facing < 0 && e.contacts.left) || (e.facing > 0 && e.contacts.right);
  const beiraEsq = e.corpo.x <= x0 + C.margem; const beiraDir = e.corpo.x + e.corpo.w >= x1 - C.margem;
  const sairia = (e.facing < 0 && beiraEsq) || (e.facing > 0 && beiraDir) || (noChao && !chaoNaDirecao(mapa, e, e.facing)) || parede;

  // 1) decisões de troca de estado (não acontecem durante a meia-volta)
  if (vendo) e.perseguiu = true;
  if (e.modo !== 'virar') {
    if (sairia && (e.modo === 'andar' || e.modo === 'aproximar' || e.modo === 'reposicionar')) {
      if (e.modo === 'aproximar') { e.modo = 'repouso'; e.timer = C.pausaVigia; }   // perto de uma beirada, Limo fica do outro lado: vigia
      else virarPara(e, -e.facing, 'andar');
    } else if (vendo && Math.abs(dAlvo) > C.distParada) {
      if (dirAlvo !== e.facing) {
        if (chaoNaDirecao(mapa, e, dirAlvo) || !noChao) virarPara(e, dirAlvo, 'aproximar');
        else { e.modo = 'repouso'; e.timer = C.pausaVigia; }
      } else if (e.modo !== 'aproximar') e.modo = 'aproximar';
    } else if (vendo) {                                   // Limo está perto: encara e vigia
      if (dirAlvo !== e.facing) virarPara(e, dirAlvo, 'repouso');
      else if (e.modo === 'aproximar' || e.modo === 'andar') { e.modo = 'repouso'; e.timer = C.pausaVigia; }
    } else if (e.perseguiu) {                              // perdeu Limo de vista: volta ao centro da arena
      e.modo = 'reposicionar';
      e.alvoX = limites ? (x0 + x1) / 2 : e.corpo.x;
    }
  }

  // 2) comportamento do estado atual: velocidade alvo e tempos
  let vxAlvo = 0;
  switch (e.modo) {
    case 'repouso':
      e.timer -= dt;
      if (e.timer <= 0) {
        if (aleatorio(e) < 0.35 && chaoNaDirecao(mapa, e, -e.facing) && !vendo) virarPara(e, -e.facing, 'andar');
        else { e.modo = 'andar'; e.timer = 2 + 2 * aleatorio(e); }
      }
      break;
    case 'andar':
      vxAlvo = e.facing * C.vPatrulha;
      e.timer -= dt;
      if (e.timer <= 0) { e.modo = 'repouso'; e.timer = sortearPausa(e); }
      break;
    case 'aproximar':
      vxAlvo = e.facing * C.vAprox;
      break;
    case 'reposicionar': {
      const falta = e.alvoX - cx;
      if (Math.abs(falta) < 5) { e.modo = 'repouso'; e.timer = sortearPausa(e); e.perseguiu = false; }
      else { if (Math.sign(falta) !== e.facing) { virarPara(e, Math.sign(falta), 'reposicionar'); break; } vxAlvo = e.facing * C.vReposicao; }
      break;
    }
    case 'virar':
      e.timer -= dt;
      if (!e.virou && e.timer <= C.virarT * 0.5) { e.facing = e.facingAlvo; e.virou = true; }
      if (e.timer <= 0) {
        e.modo = e.proximo;
        if (e.modo === 'andar') e.timer = 2 + 2 * aleatorio(e);
        if (e.modo === 'repouso') e.timer = C.pausaVigia;
      }
      break;
  }

  // 3) inércia: a velocidade chega ao alvo devagar (corpo pesado)
  e.vx += (vxAlvo - e.vx) * Math.min(1, C.acel * dt);
  if (e.vx > -0.05 && e.vx < 0.05 && vxAlvo === 0) e.vx = 0;

  // 4) gravidade e colisão com o cenário
  e.vy = Math.min(e.vy + C.gravidade * dt, C.queda);
  moveBody(mapa, e.corpo, e.vx * dt, e.vy * dt, {}, e.contacts);
  if (e.contacts.down || e.contacts.up) e.vy = 0;

  // 5) ritmo das patas: anda enquanto o corpo se move no chão; ao parar, termina o ciclo e volta à pose de repouso
  const andando = e.contacts.down && Math.abs(e.vx) > 2;
  const avanco = Math.abs(e.vx) * C.ciclo / PASSO_DEVORADOR * dt;
  if (andando) e.passo = ((e.passo ?? 0) + avanco) % 1;
  else if (e.passo !== null) { e.passo += Math.max(avanco, 0.6 * dt); if (e.passo >= 1) e.passo = null; }

  // 6) respiração e balanço das partes soltas
  e.resp = (e.resp + dt / C.ciclo_respiracao) % 1;
  e.balanco = andando ? Math.sin(2 * Math.PI * (e.passo ?? 0)) * 0.9 : Math.sin(e.tempo * 1.2) * 0.8;
  return e;
}
