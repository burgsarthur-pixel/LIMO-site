// =====================================================================
// COMBATE v1.35 — padrões de chefe RECONHECÍVEIS (lógica pura, sem DOM).
//
// Todo chefe (menos a Tecelã, que tem seu ciclo próprio em enemy.js) segue a mesma gramática:
//     ANÚNCIO (nome + cor + som próprio + zona acesa)  →  ATAQUE  →  RECUPERAÇÃO (exposto: hora do contra-ataque)
// e repete SEMPRE a mesma ordem, para o jogador aprender o ciclo. Cada ataque tem cor, som e forma de zona própria.
//
// Zonas (`attackZones`) são as mesmas da Tecelã: o desenho (renderer.drawBossZones) e o dano (game._contatoAtaqueChefe)
// só leem `active`, então "o que está aceso é exatamente o que fere".
// =====================================================================
const yc = (e) => Math.round(e.body.y + e.body.h - 7);          // linha do chão sob o chefe
const alcanceDaInvestida = (e) => Math.round(e.cfg.chargeSpeed * e.cfg.chargeDuration + e.body.w / 2 + 10);

/** Pede ao jogo para criar filhotes (o jogo drena `pedidos`). Respeita um teto de filhotes vivos. */
function invocar(e, kind, quantidade, teto = 2) {
  e.filhotes = (e.filhotes || []).filter((f) => f.alive);
  const faltam = Math.min(quantidade, teto - e.filhotes.length);
  for (let i = 0; i < faltam; i++) {
    const lado = (e.filhotes.length + i) % 2 === 0 ? -1 : 1;
    e.pedidos.push({ tipo: 'invocar', kind, x: e.centerX + lado * 46, y: e.body.y + e.body.h - 2, dono: e });
  }
  return faltam;
}

const rota = (e, ativa, alcance) => {
  const origem = e.attackOriginX ?? e.centerX; const x = e.attackDir > 0 ? origem : origem - alcance;
  return { tipo: 'path', x, y: yc(e), w: alcance, h: 7, active: ativa, telegraph: !ativa, damage: e.damage, originX: origem };
};

/** Coluna que sobe do chão (aviso fino → pilar aceso). */
const coluna = (x, ativa, e, fase, altura = 64) => ({ tipo: 'coluna', x: x - 9, y: yc(e) + 7 - altura, w: 18, h: altura, active: ativa, telegraph: !ativa, phase: fase, damage: e.damage, originX: x });

export const PADROES = {
  // Pastor das Vísceras: chama o rebanho, cavalga e pisa. Verde-sepulcral.
  pastor: {
    cor: '#9be36b',
    ciclo: [
      { id: 'chamado', nome: 'CHAMADO', windup: 0.95, ativo: 0.25, recup: 1.0, cd: 1.1, alcance: 420,
        zonas: (e, estado, fase) => (estado === 'windup' ? [-1, 1].map((l) => ({ tipo: 'ground', x: e.centerX + l * 46 - 7, y: yc(e), w: 14, h: 7, active: false, telegraph: true, phase: fase, damage: 0 })) : []),
        aoAtivar: (e) => invocar(e, 'crawler', 2, 2) },
      { id: 'cavalgada', nome: 'CAVALGADA', windup: 0.6, ativo: 0.35, recup: 0.8, cd: 1.0, alcance: 150,
        zonas: (e, estado) => [rota(e, estado === 'ativo', alcanceDaInvestida(e))],
        mover: (e) => e.attackDir * e.cfg.chargeSpeed * 1.05 },
      { id: 'pisada', nome: 'PISADA', windup: 0.8, ativo: 0.5, recup: 1.0, cd: 1.2, alcance: 130,
        zonas: (e, estado, fase) => (estado === 'windup'
          ? [{ tipo: 'ring', x: e.centerX, y: yc(e) + 3, r: 10 + 10 * fase, thickness: 3, active: false, phase: fase }]
          : [-1, 1].map((l) => { const alc = 14 + 112 * fase; return { tipo: 'ground', x: l < 0 ? e.centerX - e.body.w / 2 - alc : e.centerX + e.body.w / 2, y: yc(e), w: alc, h: 7, active: true, phase: fase, damage: e.damage, originX: e.centerX }; })) },
    ],
  },
  // Mastigador do Pulso: mordida seca, onda de lanes e rugido. Rosa-brasa.
  mastigador: {
    cor: '#ff6a8a',
    ciclo: [
      { id: 'mordida', nome: 'MORDIDA', windup: 0.55, ativo: 0.22, recup: 0.7, cd: 0.9, alcance: 110,
        zonas: (e, estado) => [rota(e, estado === 'ativo', Math.round(e.cfg.chargeSpeed * 0.22 + e.body.w / 2 + 10))],
        mover: (e) => e.attackDir * e.cfg.chargeSpeed * 1.15 },
      { id: 'onda', nome: 'ONDA', windup: 0.75, ativo: 0.8, recup: 1.0, cd: 1.1, alcance: 300,
        zonas: (e, estado, fase) => {
          const faixas = [-2, -1, 1, 2].map((k) => ({ k, x: e.centerX + k * 100 - 22 }));
          return faixas.map(({ k, x }, i) => {
            const ordem = Math.abs(k) - 1; const inicio = 0.1 + ordem * 0.3;
            const ativa = estado === 'ativo' && fase >= inicio && fase < inicio + 0.32;
            return { tipo: 'ground', x, y: yc(e), w: 44, h: 7, active: ativa, telegraph: !ativa && (estado === 'windup' || fase < inicio), phase: fase, damage: e.damage, originX: x + 22, i };
          });
        } },
      { id: 'rugido', nome: 'RUGIDO', windup: 0.85, ativo: 0.6, recup: 1.05, cd: 1.2, alcance: 320,
        zonas: (e, estado, fase) => (estado === 'windup'
          ? [{ tipo: 'ring', x: e.centerX, y: e.centerY, r: 16, thickness: 5, active: false, phase: 0 }]
          : [{ tipo: 'ring', x: e.centerX, y: e.centerY, r: 16 + 120 * fase, thickness: 7, active: true, phase: fase, damage: e.damage, originX: e.centerX }]) },
    ],
  },
  // Coração Residual: duas batidas, pilares do chão e chamado de esporos. Vermelho-vivo.
  coracao: {
    cor: '#ff4d6a',
    ciclo: [
      { id: 'sistole', nome: 'SÍSTOLE', windup: 0.85, ativo: 0.95, recup: 1.1, cd: 1.2, alcance: 420,
        zonas: (e, estado, fase) => {
          if (estado === 'windup') return [{ tipo: 'ring', x: e.centerX, y: e.centerY, r: 18, thickness: 5, active: false, phase: 0 }];
          const um = Math.min(1, fase / 0.5); const dois = fase > 0.4 ? Math.min(1, (fase - 0.4) / 0.55) : 0;
          const lista = [{ tipo: 'ring', x: e.centerX, y: e.centerY, r: 18 + 112 * um, thickness: 7, active: fase < 0.6, phase: fase, damage: e.damage, originX: e.centerX }];
          if (dois > 0) lista.push({ tipo: 'ring', x: e.centerX, y: e.centerY, r: 18 + 112 * dois, thickness: 7, active: true, phase: fase, damage: e.damage, originX: e.centerX });
          return lista;
        } },
      { id: 'espinhos', nome: 'PILARES', windup: 0.95, ativo: 0.35, recup: 1.0, cd: 1.1, alcance: 420,
        zonas: (e, estado, fase) => { const xs = e.pilaresX || []; return xs.map((x) => coluna(x, estado === 'ativo', e, fase)); },
        aoIniciar: (e, ctx) => { const px = ctx.player ? ctx.player.centerX : e.centerX; e.pilaresX = [px - 56, px, px + 56]; } },
      { id: 'chamado', nome: 'ESPOROS', windup: 0.8, ativo: 0.25, recup: 1.0, cd: 1.1, alcance: 420,
        zonas: (e, estado, fase) => (estado === 'windup' ? [{ tipo: 'ring', x: e.centerX, y: e.body.y - 4, r: 6 + 8 * fase, thickness: 3, active: false, phase: fase }] : []),
        aoAtivar: (e) => invocar(e, 'flyer', 2, 2) },
    ],
  },
};

/** Id de padrão por chefe (bossId = "sala:entidade"). A Tecelã tem ciclo próprio em enemy.js. */
export const PADRAO_POR_CHEFE = {
  'jardim_lago:devorador_flores': 'devorador',   // Devorador de Flores: movimentação (sem padrão de ataque nesta etapa)
  'raizes_guardiao:guardiao_raizes': 'tecelã',
  'nucleo_salao:mastigador_pulso': 'mastigador',
  'nucleo_coracao:coracao_residual': 'coracao',
};

function zonas(e, def, estado, fase, ctx) {
  const p = e.padraoAtual; if (!p) return [];
  return p.zonas(e, estado, fase, ctx).map((z) => ({ cor: def.cor, ...z }));
}

/** Um passo do chefe: perseguir → anunciar → atacar → recuperar. Chame no lugar do ataque legado. */
export function atualizarChefePadrao(e, dt, ctx) {
  const { mapa, player, mover, dx, noChao } = ctx; const def = PADROES[e.bossPattern]; const c = e.cfg;
  const p = e.padraoAtual; const st = e.attackState;
  if (st === 'padraoWindup') {
    e.vx = 0; e.attackTimer -= dt; mover();
    if (e.attackTimer <= 0) { e.attackState = 'padraoAtivo'; e.attackTimer = p.ativo; e.attackDur = p.ativo; e.audioEvents.push(`atq_${p.id}`); p.aoAtivar?.(e, ctx); }
  } else if (st === 'padraoAtivo') {
    e.vx = p.mover ? p.mover(e) : 0; e.attackTimer -= dt; mover();
    if (e.attackTimer <= 0 || (p.mover && (e.contacts.left || e.contacts.right))) {
      e.attackState = 'recovery'; e.attackTimer = p.recup; e.attackDur = p.recup; e.attackCooldown = p.cd; e.vx = 0; e.anuncio = null;
      e.expostoAte = p.recup; e.recuperando = p;   // janela de contra-ataque (feedback mais forte nos golpes)
    }
  } else if (st === 'recovery') {
    e.vx = 0; e.attackTimer -= dt; mover();
    if (e.attackTimer <= 0) { e.attackState = 'stalk'; e.attackKind = null; e.padraoAtual = null; e.recuperando = null; }
  } else {
    const prox = def.ciclo[e.attackIndex % def.ciclo.length];
    const perto = e.chasing && Math.abs(dx) <= Math.min(c.sight, prox.alcance);
    if (noChao && perto && e.attackCooldown <= 0) {
      e.padraoAtual = prox; e.attackIndex++; e.attackKind = prox.id; e.attackState = 'padraoWindup'; e.attackTimer = prox.windup; e.attackDur = prox.windup;
      e.attackDir = e.facing; e.attackOriginX = e.centerX; e.vx = 0; e.anuncio = { texto: prox.nome, cor: def.cor };
      e.audioEvents.push(`aviso_${prox.id}`); prox.aoIniciar?.(e, ctx);
    } else {
      if (noChao && !e._temChaoAdiante(mapa)) e.vx = e.chasing ? 0 : e.facing * e.speed * c.patrolFactor;
      else e.vx = e.chasing ? e.facing * e.speed : e.facing * e.speed * c.patrolFactor;
      mover();
    }
  }
  const estado = e.attackState === 'padraoWindup' ? 'windup' : e.attackState === 'padraoAtivo' ? 'ativo' : null;
  if (estado && e.padraoAtual) {
    const dur = estado === 'windup' ? e.padraoAtual.windup : e.padraoAtual.ativo;
    e.attackZones = zonas(e, def, estado, 1 - Math.max(0, e.attackTimer) / dur, ctx);
  } else e.attackZones = [];
}
