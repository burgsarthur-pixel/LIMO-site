// =====================================================================
// ECOSSISTEMA VIVO (v1.38.0) — lógica pura, sem DOM, só visual (não toca colisão, dano nem save).
// Reaproveita as molas do ReacaoTiles (js/render/tile-reacao.js): em vez de só reagir ao TOQUE, a decoração agora percebe a
// APROXIMAÇÃO do Limo e tem vida própria:
//   planta  curva-se na direção do Limo quando ele chega perto (curiosa)
//   raiz    pendurada recua quando ele chega perto (arisca) e balança sozinha, no ritmo lento da respiração do Deus
//   fungo   solta uma nuvem de esporos e acende uma luz curta quando o Limo chega perto (com tempo de recarga)
//   esporelitos  pontinhos de luz que vagam em volta dos fungos/lanternas: fogem se o Limo corre, se aproximam se ele fica quieto
// Só quem está na tela é processado. `nivel` 0 = desligado, 1 = leve (Android), 2 = completo.
// =====================================================================

export function criarRng(semente = 1) {   // mulberry32: determinístico (testes) e barato
  let s = semente >>> 0;
  return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
export const hashTexto = (txt = '') => { let h = 2166136261; for (let i = 0; i < txt.length; i++) { h ^= txt.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
export function hexParaRgb(hex = '#caff91') { const n = parseInt(hex.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }

/** Nível de qualidade: 2 completo, 1 leve (Android/aparelho fraco), 0 desligado. `config.render.vida.nivel` manda; senão detecta. */
export function nivelDeVida(config, nav = (typeof navigator !== 'undefined' ? navigator : null)) {
  const v = config?.render?.vida; if (v && v.ligado === false) return 0;
  if (v && Number.isInteger(v.nivel)) return Math.max(0, Math.min(2, v.nivel));
  const ua = nav?.userAgent || ''; return /Android|iPhone|iPad|Mobile/i.test(ua) ? 1 : 2;
}

const RAIO = { planta: 32, raiz: 34, fungo: 38 };

export class Ecossistema {
  /** @param reacao ReacaoTiles  @param opcoes {rng, nivel} */
  constructor(reacao, { rng = criarRng(7), nivel = 2 } = {}) {
    this.reacao = reacao; this.rng = rng; this.nivel = nivel;
    this.orgs = []; this._cadeias = null;
    this.stats = { curvas: 0, recuos: 0, esporos: 0, balancos: 0 };
  }

  /** Classifica as cadeias do ReacaoTiles (replanejado quando o mapa muda). */
  _classificar() {
    const r = this.reacao; if (this._cadeias === r.cadeias) return; this._cadeias = r.cadeias;
    const ts = r.mapa.tileSize; const rng = this.rng; this.orgs = [];
    for (const ch of r.cadeias) {
      const p = ch.perfil; if (p.tipo === 'treme' || p.tipo === 'nenhuma') continue;
      const kind = p.tipo === 'esmaga' ? 'fungo' : p.ancora === 'up' ? 'raiz' : 'planta';
      const c0 = ch.celulas[0]; const cN = ch.celulas[ch.celulas.length - 1];
      this.orgs.push({ ch, kind, cx: c0.tx * ts + ts / 2, cy: ((c0.ty + cN.ty) / 2) * ts + ts / 2, perto: false, cd: rng() * 3, sway: 0.5 + rng() * 4, luminoso: !!p.esporos || /glow|lamp/i.test(String(p.cor)) });
    }
  }

  /**
   * @param jogador {cx,cy,vx,vy}  @param vista {x,y,w,h} janela da câmera em px do mundo
   * @param fx {luz(l)} opcional (LuzesFx)
   */
  atualizar(dt, jogador, vista, fx = null, respira = 0) {
    const r = this.reacao; if (!this.nivel || !r || !r.ligado) return;
    this._classificar(); if (!this.orgs.length) return;
    const m = 28; const x0 = vista.x - m; const x1 = vista.x + vista.w + m; const y0 = vista.y - m; const y1 = vista.y + vista.h + m;
    const rng = this.rng; const raizAmp = 0.16 + 0.12 * respira;
    for (const o of this.orgs) {
      if (o.cx < x0 || o.cx > x1 || o.cy < y0 || o.cy > y1) { o.perto = false; continue; }
      o.cd -= dt;
      const dx = jogador.cx - o.cx; const dy = jogador.cy - o.cy; const d2 = dx * dx + dy * dy; const R = RAIO[o.kind];
      if (!o.perto && d2 < R * R) { o.perto = true; this._reagir(o, dx, fx); }
      else if (o.perto && d2 > (R + 14) * (R + 14)) o.perto = false;
      if ((o.sway -= dt) <= 0) {   // vida própria: um empurrãozinho aleatório de tempos em tempos (a mola faz o resto)
        o.sway = (o.kind === 'raiz' ? 2.4 : 3.6) + rng() * 4;
        if (o.kind !== 'fungo') { r.empurrar(o.ch, (rng() < 0.5 ? -1 : 1) * (o.kind === 'raiz' ? raizAmp : 0.12), 0.5); this.stats.balancos++; }
      }
    }
  }

  _reagir(o, dx, fx) {
    const r = this.reacao; const lado = dx >= 0 ? 1 : -1;
    if (o.kind === 'planta') { r.empurrar(o.ch, lado * 0.42, 0.8); this.stats.curvas++; }
    else if (o.kind === 'raiz') { r.empurrar(o.ch, -lado * 0.5, 0.9); this.stats.recuos++; }
    else if (o.cd <= 0) {   // fungo: nuvem de esporos + luz curta, depois descansa
      o.cd = 3.5 + this.rng() * 3;
      r.empurrar(o.ch, lado * 0.3, 0.6);
      const antes = r.esporos.length; r._soltarEsporos?.(o.ch, this.nivel >= 2 ? 4 : 2, -lado * 0.6); this.stats.esporos += r.esporos.length - antes;
      fx?.add?.({ x: o.cx, y: o.cy - 4, raio: 22, cor: hexParaRgb(o.ch.perfil.cor), dur: 0.35, intens: 0.45 });
    }
  }

  get quantidade() { return this.orgs.length; }
}

export class Esporelitos {
  /** @param mapa TileMap  @param orgs lista do Ecossistema  @param opcoes {rng, nivel, solido(x,y)} */
  constructor(mapa, orgs, { rng = criarRng(11), nivel = 2, solido = () => false } = {}) {
    this.rng = rng; this.solido = solido; this.lista = [];
    const n = nivel >= 2 ? 8 : nivel === 1 ? 4 : 0; const ts = mapa.tileSize;
    const casas = orgs.filter((o) => o.luminoso).map((o) => [o.cx, o.cy - ts * 0.8]);
    for (let i = 0; i < n; i++) {
      let h = casas.length ? casas[Math.floor(rng() * casas.length)] : null;
      for (let k = 0; !h && k < 60; k++) { const x = (1 + rng() * (mapa.width - 2)) * ts; const y = (1 + rng() * (mapa.height - 2)) * ts; if (!solido(x, y)) h = [x, y]; }
      if (!h) continue;
      this.lista.push({ hx: h[0], hy: h[1], x: h[0], y: h[1], vx: 0, vy: 0, fase: rng() * 6.28, raio: 8 + rng() * 14, medo: 0 });
    }
  }

  atualizar(dt, t, jogador, vista) {
    dt = Math.min(dt, 1 / 30);
    const velJ = Math.hypot(jogador.vx || 0, jogador.vy || 0);
    for (const e of this.lista) {
      if (e.x < vista.x - 60 || e.x > vista.x + vista.w + 60 || e.y < vista.y - 60 || e.y > vista.y + vista.h + 60) continue;   // fora da tela: congela
      let ax = (e.hx + Math.cos(t * 0.6 + e.fase) * e.raio - e.x) * 1.3; let ay = (e.hy + Math.sin(t * 0.8 + e.fase * 1.3) * e.raio * 0.6 - e.y) * 1.3;
      const dx = e.x - jogador.cx; const dy = e.y - jogador.cy; const d = Math.hypot(dx, dy) || 1;
      e.medo = Math.max(0, e.medo - dt);
      if (d < 46 && velJ > 70) { ax += (dx / d) * 170; ay += (dy / d) * 170; e.medo = 0.6; }                 // foge de quem corre
      else if (d > 18 && d < 90 && velJ < 24) { ax -= (dx / d) * 20; ay -= (dy / d) * 20; }                  // chega perto de quem fica quieto
      e.vx = (e.vx + ax * dt) * (1 - 1.6 * dt); e.vy = (e.vy + ay * dt) * (1 - 1.6 * dt);
      const nx = e.x + e.vx * dt; const ny = e.y + e.vy * dt;
      if (this.solido(nx, ny)) { e.vx *= -0.3; e.vy *= -0.3; } else { e.x = nx; e.y = ny; }
    }
  }
}
