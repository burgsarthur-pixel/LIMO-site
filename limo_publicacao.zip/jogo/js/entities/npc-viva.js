// =====================================================================
// NPC COM ROTINA (v1.45.0) — lógica pura, sem DOM: testável em Node.
// Não é inimigo, não tem corpo físico, não colide, não entra em `game.enemies`. A entidade `npc` da sala (roomData.entities) NUNCA é alterada:
// a posição viva mora aqui. Sem `rotina`, o NPC continua uma estátua (comportamento da v1.43/1.44).
//
// Posição e estado vêm de `estadoNoTempo` (js/world/npc-dados.js): função pura do TEMPO LOCAL, que só avança quando o NPC não está parado
// por motivo de reação ou conversa. Por isso ele retoma exatamente de onde parou e nunca sai do chão entre as âncoras.
// Reações a 10 Hz (TICK, mesma cadência do Cerebro das criaturas), com fase aleatória por NPC; o resto por quadro é só somar dt e ler a função.
//   atento     o Limo está perto (raioTiles): para e vira para ele; passados `maxSeg` s ignora até o Limo sair e voltar
//   assustado  uma criatura acordada está perto (raioTiles, mesma altura): fica encolhido por `durMin` s depois que ela sai
//   conversa   `pausar('conversa')` (o Game faz ao abrir o diálogo): para e olha para o Limo
// `eventos` recebe o nome de cada estado em que ele ENTRA (ex.: 'descansa', 'trabalha', 'assustado'): gancho para a memória do catálogo (Etapa 3).
// Nada disso é salvo.
// =====================================================================
import { compilarRotina, estadoNoTempo } from '../world/npc-dados.js';

export const TICK_NPC = 0.1;
const MAX_EVENTOS = 8;
export const SEG_OBSERVAR = 2;
export const HABITOS_OBSERVAVEIS = new Set(['descansa', 'trabalha', 'assustado']);

export class NpcViva {
  /** `rotina` = uma rotina de npc-dados.js (já escolhida por `rotinaVigente`). `inicio` = segundos do relógio do mundo (o ciclo "já estava rodando"). */
  static criar(entidade, rotina, { ts = 16, nivel = 2, rng = null, inicio = 0 } = {}) { return new NpcViva(entidade, rotina, { ts, nivel, rng, inicio }); }

  constructor(entidade, rotina, { ts, nivel, rng, inicio }) {
    this.e = entidade; this.id = entidade.id; this.ts = ts; this.rotina = rotina; this.comp = compilarRotina(rotina, ts); this.reacoes = rotina.reacoes || {};
    this.fixo = nivel <= 0;                                   // aparelho que desliga a vida do mundo: fica parado na âncora inicial
    const c = this.comp.ciclo; this.tLocal = (((inicio || 0) % c) + c) % c;
    this.acc = (rng ? rng() : 0) * TICK_NPC;
    this.pausas = new Set(); this.assustadoT = 0; this.tAtento = 0; this.ignorando = false; this._atento = false; this._virado = 0;
    this.estado = 'parado'; this.facing = 1; this.x = this.comp.inicial.x; this.y = this.comp.inicial.y; this.eventos = [];
    this._obsEstado = null; this._obsT = 0; this._obsFeitos = new Set();
    this._base = { estado: 'parado', x: 0, y: 0, facing: 1, prog: 0 };
    if (this.fixo) return;
    this._aplicar(true);
  }

  get centerX() { return this.x + this.ts / 2; }
  get centerY() { return this.y + this.ts / 2; }
  get pausado() { return this.pausas.size > 0 || this.assustadoT > 0 || this._atento; }

  pausar(motivo) { this.pausas.add(motivo); }
  retomar(motivo) { this.pausas.delete(motivo); }
  /** Vira o NPC para um ponto (px do mundo); vale enquanto durar a pausa de conversa ou a atenção. */
  virarPara(xPx) { this._virado = xPx >= this.centerX ? 1 : -1; this.facing = this._virado; }

  /** Todo quadro. `ctx` = { limo: {x, y, vivo}, criaturas: [{alive, centerX, centerY, ia}] }. Sem alocação. */
  atualizar(dt, ctx) {
    if (this.fixo) return;
    this.acc += dt;
    if (this.acc >= TICK_NPC) { const d = this.acc; this.acc = 0; this._pensar(d, ctx); }
    if (!this.pausado) this.tLocal += dt;
    this._aplicar(false);
  }

  /**
   * v1.47.0 (Etapa 3): memória do que se OBSERVA. Chame todo quadro com `naTela`. Devolve o hábito ('descansa' | 'trabalha' | 'assustado') uma única vez,
   * depois que o Limo viu o NPC nesse estado por `SEG_OBSERVAR` s seguidos na tela; fora disso devolve null. Sem alocação, sem save (quem registra é o Game).
   */
  observar(dt, naTela) {
    const h = HABITOS_OBSERVAVEIS.has(this.estado) ? this.estado : null;
    if (!naTela || !h || h !== this._obsEstado) { this._obsEstado = h; this._obsT = 0; return null; }
    this._obsT += dt;
    if (this._obsT < SEG_OBSERVAR || this._obsFeitos.has(h)) return null;
    this._obsFeitos.add(h); return h;
  }

  _pensar(d, ctx) {
    const ts = this.ts; const R = this.reacoes; const l = ctx?.limo;
    const rc = R.criaturaPerto; let medo = false;
    if (rc && ctx?.criaturas) {
      const rx = rc.raioTiles * ts;
      for (const c of ctx.criaturas) {
        if (!c.alive || c.ia?.repouso) continue;               // criatura dormindo não assusta
        if (Math.abs(c.centerX - this.centerX) <= rx && Math.abs(c.centerY - this.centerY) <= ts * 2) { medo = true; break; }
      }
    }
    if (medo) this.assustadoT = rc.durMin ?? 3; else if (this.assustadoT > 0) this.assustadoT = Math.max(0, this.assustadoT - d);
    const rl = R.limoPerto; let perto = false;
    if (rl && l?.vivo) perto = Math.abs(l.x - this.centerX) <= rl.raioTiles * ts && Math.abs(l.y - this.centerY) <= ts * 2;
    if (perto) { this.tAtento += d; if (this.tAtento > (rl.maxSeg ?? 8)) this.ignorando = true; } else { this.tAtento = 0; this.ignorando = false; }
    this._atento = perto && !this.ignorando;
    if (this._atento && l) this._virado = l.x >= this.centerX ? 1 : -1; else if (!this.pausas.has('conversa')) this._virado = 0;
  }

  _aplicar(inicial) {
    const b = estadoNoTempo(this.comp, this.tLocal, this._base);
    this.x = b.x; this.y = b.y;
    this.facing = this._virado || b.facing;
    const novo = this.assustadoT > 0 ? 'assustado' : (this._atento || this.pausas.has('conversa')) ? 'atento' : b.estado;
    if (novo !== this.estado) { this.estado = novo; if (!inicial) { if (this.eventos.length >= MAX_EVENTOS) this.eventos.shift(); this.eventos.push(novo); } }
  }
}
