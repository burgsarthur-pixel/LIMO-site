// =====================================================================
// ANIMAÇÃO DO LIMO — escolhe a POSE (deformação, inclinação, olhar, expressão) para cada situação.
// Só visual: não altera física nem hitbox. A mola de squash existente continua somando por cima.
// Também detecta transições (pulo, pouso, passos, derrapagem...) e as devolve como EVENTOS para o áudio
// e como EFEITOS (drenarFx) para as partículas: o mesmo gatilho faz o som E a gosma saltar.
//
// v1.27.0 — o que há de novo (tudo só visual):
//  · SUAVIZAÇÃO: a pose-alvo muda de uma vez, mas deformação/offset chegam a ela em poucos quadros (sem "pops" entre situações);
//    golpe e dano usam taxa alta para continuarem secos.
//  · INCLINAÇÃO ELÁSTICA (pose.inclina): mola subamortecida que inclina o topo do corpo — pende para a frente correndo,
//    fica para trás ao acelerar (inércia do gel), antecipa a investida (recua antes) e estala no fim dela.
//  · IDLE VIVO: bolhas sobem do corpo de tempos em tempos e, depois de um tempo parado, o Limo dá uma tremida.
//  · GIRO: ao inverter o lado parado, o corpo achata rapidinho.
//
// Prioridade das situações (a primeira que valer):
//  morto > ataque > hurt > investida > Tendril (puxando / pendurado / mirando) > parede > ar (subindo / topo / caindo)
//  > chão: derrapando > correndo > agachado > parado (respira, pisca, olha em volta, cansado com pouca vida)
// =====================================================================
import { clamp } from '../core/math.js';

export const NEUTRO = Object.freeze({ sx: 1, sy: 1, ox: 0, oy: 0, inclina: 0, olhar: Object.freeze({ x: 0, y: 0 }), piscar: 0, expressao: 'normal', tremor: 0, situacao: 'parado' });

const voltaBack = (x) => { const c = 1.70158; const t = x - 1; return 1 + (c + 1) * t * t * t + c * t * t; };   // easeOutBack: nasce passando um pouco do tamanho

/** Pose sem memória (usada quando não há animador): só o que dá para decidir olhando o estado atual. */
export function poseBasica(player) {
  const p = { ...NEUTRO, olhar: { x: 0, y: 0 } };
  if (player.state === 'dead') Object.assign(p, { sx: 1.5, sy: 0.3, expressao: 'morto', situacao: 'morto' });
  else if (player.state === 'hurt') Object.assign(p, { sx: 1.2, sy: 0.82, expressao: 'dor', tremor: 1, situacao: 'dano' });
  else if (player.state === 'dashing') Object.assign(p, { sx: 1.35, sy: 0.75, ox: (player.facing || 1) * 2, expressao: 'foco', situacao: 'investida' });
  return p;
}

export class LimoAnimator {
  constructor({ rand = Math.random } = {}) {
    this.rand = rand; this.t = 0; this.events = []; this.pose = { ...NEUTRO, olhar: { x: 0, y: 0 } };
    this._ant = null; this._resets = null; this.apareceT = 1; this.pousoT = 0; this.pousoForca = 0; this.passoT = 0; this.passoLado = 0;
    this.parado = 0; this.piscaEm = 1.5 + this.rand() * 3; this.piscaT = 0; this.olhaEm = 4; this.olhaT = 0; this.olhaDir = 0; this._derrapou = false;
    this.fx = []; this.lean = { x: 0, v: 0 }; this.suave = null; this.bolhaEm = 1.2 + this.rand() * 2; this.tremidaEm = 7 + this.rand() * 5; this.tremidaT = 0; this.viraT = 0; this._face = null;
  }
  drenarEventos() { const e = this.events; this.events = []; return e; }
  /** Efeitos visuais (partículas) pedidos neste quadro: { tipo, escala }. Inclui os eventos de som e os que só existem para o visual. */
  drenarFx() { const e = this.fx; this.fx = []; return e; }
  _ev(tipo, escala = 1) { this.events.push({ tipo, escala }); this._fx(tipo, escala); }
  _fx(tipo, escala = 1) { if (this.fx.length < 24) this.fx.push({ tipo, escala }); }

  update(dt, player, ctx = {}) {
    const { tendril = null, melee = null, foco = null, input = null } = ctx;
    this.t += dt;
    if (this._resets !== (player.resets ?? 0)) { this._resets = player.resets ?? 0; this.apareceT = 0; this._ant = null; this.pousoT = 0; this.suave = null; this.lean.x = 0; this.lean.v = 0; this._fx('surgir'); }   // (re)nasceu: anima o surgimento
    this.apareceT = Math.min(1, this.apareceT + dt / 0.42);
    const a = this._ant; const noChao = !!player.onGround; const vx = player.vx || 0; const vy = player.vy || 0; const face = player.facing === -1 ? -1 : 1;
    const maxV = player.config?.physics?.maxSpeed || 100;

    // ---------- transições → eventos de som ----------
    if (a) {
      if (a.noChao && !noChao && vy < -50 && player.state !== 'dead') this._ev('pulo');
      if ((player.squidFx || 0) > (a.squid || 0) + 0.2) this._ev('pulo_duplo');
      if (!a.noChao && noChao && player.state !== 'dead') {
        const f = clamp(a.vy / 420, 0.15, 1); this.pousoT = 0.18; this.pousoForca = f; this._ev(a.vy > 260 ? 'pouso_forte' : 'pouso', f);
      }
      if (!a.dashing && player.dashing) { this._ev('investida'); this.lean.v -= face * 34; }                // antecipação: o topo recua antes de disparar
      if (a.dashing && !player.dashing) this.lean.v += face * 46;                                         // continuação: estala para a frente ao terminar
      if (!a.hurt && player.state === 'hurt') { this._fx('respingo'); this.lean.v -= face * 55; }          // dano: espirra gosma e o topo é jogado para trás
      const parede = (player.contacts?.left || player.contacts?.right) && !noChao;
      if (parede && !a.parede) this._ev('parede');
      a.parede = parede;
    }
    // passos: ritmo acompanha a velocidade
    const correndo = noChao && Math.abs(vx) > 20 && player.state !== 'dead' && player.state !== 'hurt';
    if (correndo) { this.passoT -= dt; if (this.passoT <= 0) { this.passoT = clamp(34 / Math.abs(vx), 0.17, 0.4); this.passoLado ^= 1; this._ev('passo', this.passoLado ? 1 : 0.75); } } else this.passoT = 0;
    const derrapando = noChao && Math.abs(vx) > 40 && Math.sign(vx) !== face;   // desliza para um lado enquanto já olha para o outro (inversão em velocidade)
    if (derrapando && !this._derrapou) this._ev('derrapar', clamp(Math.abs(vx) / maxV, 0.3, 1)); this._derrapou = derrapando;

    // ---------- escolha da pose ----------
    const p = { sx: 1, sy: 1, ox: 0, oy: 0, olhar: { x: 0, y: 0 }, piscar: 0, expressao: 'normal', tremor: 0, situacao: 'parado' };
    const set = (sit, o) => { p.situacao = sit; Object.assign(p, o); };
    const dirAtaque = melee?.dir || face;
    const baixaVida = player.maxLife > 1 && player.life <= 1 && player.life > 0;
    if (player.state === 'dead') { set('morto', { sx: 1.5, sy: 0.3, expressao: 'morto' }); }
    else if (melee && melee.fase && melee.fase !== 'idle') {   // golpe de pseudópode: recua, estica pra frente, relaxa
      const c = melee.cfgPasso; const u = melee.t;
      if (melee.direcao === 'cima' || melee.direcao === 'baixo') {   // golpe vertical: corpo estica no eixo do golpe e o olhar acompanha
        const s = melee.direcao === 'cima' ? -1 : 1; const ativo = melee.fase === 'ativo';
        set('ataque', { sx: ativo ? 0.86 : 1.05, sy: ativo ? 1.28 : 0.92, oy: s * (ativo ? 2 : -1), expressao: 'foco', olhar: { x: 0, y: s } });
      }
      else if (melee.fase === 'inicio') set('ataque', { sx: 0.88, sy: 1.12, ox: -dirAtaque * 1.5, expressao: 'foco', olhar: { x: dirAtaque, y: 0 } });
      else if (melee.fase === 'ativo') set('ataque', { sx: 1.3 + 0.08 * melee.passo, sy: 0.84, ox: dirAtaque * 3, expressao: 'foco', olhar: { x: dirAtaque, y: 0 } });
      else set('ataque', { sx: 1.1, sy: 0.95, ox: dirAtaque * 1, olhar: { x: dirAtaque, y: 0 } });
      void c; void u;
    } else if (foco && foco.ativo && player.state !== 'hurt') {   // foco: encolhe, concentra e vibra até curar
      const u = foco.progresso; set('foco', { sx: 1.08 - 0.12 * u, sy: 0.9 + 0.14 * u, oy: 0, expressao: 'foco', tremor: 0.4 + 0.8 * u, olhar: { x: 0, y: -0.3 } });
    } else if (player.state === 'hurt') { set('dano', { sx: 1.2, sy: 0.82, expressao: 'dor', tremor: 1 }); }
    else if (player.state === 'dashing') { set('investida', { sx: 1.35, sy: 0.75, ox: face * 2, expressao: 'foco', olhar: { x: face, y: 0 } }); }
    else if (tendril && player.tendrilPulling && tendril.point) {   // preso a uma âncora: estica rumo a ela; ao chegar, balança pendurado
      const dx = tendril.point.x - player.centerX; const dy = tendril.point.y - player.centerY; const d = Math.hypot(dx, dy) || 1;
      const chegou = d <= 30 && Math.hypot(vx, vy) < 40;   // perto e quase parado: balança pendurado; em movimento: esticado/arremessado
      const vert = Math.abs(dy) > Math.abs(dx);
      if (!chegou) set('puxado', { sx: vert ? 0.86 : 1.2, sy: vert ? 1.22 : 0.88, ox: (dx / d) * 1.5, expressao: 'foco', olhar: { x: dx / d, y: dy / d } });
      else set('pendurado', { sx: 0.95, sy: 1.1, ox: Math.sin(this.t * 3) * 1.5, oy: Math.sin(this.t * 6) * 0.4, olhar: { x: Math.sin(this.t * 1.5), y: 0.3 } });
    } else if (tendril && (tendril.mirando || (tendril.phase !== 'idle' && tendril.phase !== 'retract'))) {   // mirando/estendendo: olha pro alvo e se inclina
      const ax = tendril.aim?.x || 0; const ay = tendril.aim?.y || 0;
      set('mirando', { ox: ax * 1.2, sy: ay < -0.5 ? 1.1 : 0.97, sx: ay < -0.5 ? 0.94 : 1.05, expressao: 'foco', olhar: { x: ax, y: ay } });
    } else if ((player.contacts?.left || player.contacts?.right) && !noChao) {   // agarrado/deslizando na parede
      const lado = player.contacts.left ? -1 : 1;
      set('parede', { ox: lado * 1.5, sy: 1.12, sx: 0.92, expressao: 'foco', olhar: { x: 0, y: -1 } });
    } else if (!noChao) {
      if (vy < -30) { const s = Math.min(0.2, -vy / 700); set('subindo', { sy: 1 + s, sx: 1 - s * 0.6, olhar: { x: 0, y: -0.6 } }); }
      else if (vy > 30) { const s = Math.min(0.25, vy / 600); set('caindo', { sy: 1 + s, sx: 1 - s * 0.55, expressao: vy > 380 ? 'susto' : 'normal', olhar: { x: 0, y: 0.8 } }); }
      else set('topo', { sy: 0.96, sx: 1.05 });   // ponto mais alto: redondinho, flutuando
    } else if (derrapando) {
      set('derrapando', { sx: 0.86, sy: 1.1, ox: -face * 1.5, expressao: 'foco' });
    } else if (Math.abs(vx) > 8) {
      const s = clamp(Math.abs(vx) / maxV, 0.2, 1); const bob = Math.sin(this.t * (9 + 13 * s));
      set('correndo', { sy: 1 + 0.07 * bob * s, sx: 1 - 0.04 * bob * s, ox: Math.sign(vx) * 1.2 * s, oy: 0, olhar: { x: Math.sign(vx), y: 0 } });
    } else if (input?.isDown?.('down')) {
      set('agachado', { sy: 0.8, sx: 1.15, olhar: { x: 0, y: 0.5 } });
    } else {   // parado: respira, pisca, olha em volta; cansado quando a vida está no fim
      this.parado += dt; const resp = Math.sin(this.t * (baixaVida ? 1.4 : 2.25));
      set('parado', { sy: (baixaVida ? 0.94 : 1) + (baixaVida ? 0.05 : 0.035) * resp, sx: 1 - 0.02 * resp, expressao: baixaVida ? 'cansado' : 'normal' });
      if (this.parado > 4) { this.olhaEm -= dt; if (this.olhaEm <= 0) { this.olhaT = 1.2; this.olhaDir = this.rand() < 0.5 ? -1 : 1; this.olhaEm = 2.5 + this.rand() * 3; } }
      if (this.olhaT > 0) { this.olhaT -= dt; p.olhar = { x: this.olhaDir, y: 0 }; }
      this.bolhaEm -= dt; if (this.bolhaEm <= 0) { this._fx('bolha', baixaVida ? 0.6 : 1); this.bolhaEm = (baixaVida ? 3.2 : 1.8) + this.rand() * 2.6; }   // bolhas de gás sobem da gosma
      this.tremidaEm -= dt; if (this.tremidaEm <= 0 && this.parado > 3) { this.tremidaT = 0.45; this.tremidaEm = 7 + this.rand() * 6; this._fx('tremida'); }   // sacode a gosma
    }
    if (p.situacao !== 'parado') { this.parado = 0; this.olhaT = 0; }
    if (this.tremidaT > 0) { this.tremidaT -= dt; const k = Math.max(0, this.tremidaT / 0.45); const o = Math.sin(this.t * 55) * k; p.sx += 0.08 * o; p.sy -= 0.06 * o; p.tremor = Math.max(p.tremor, 0.5 * k); }
    if (this._face !== null && face !== this._face && noChao && p.situacao !== 'morto') this.viraT = 0.12;   // giro: achata de leve ao inverter o lado
    this._face = face; if (this.viraT > 0) { this.viraT -= dt; const k = Math.max(0, this.viraT / 0.12); p.sx *= 1 - 0.1 * k; p.sy *= 1 + 0.06 * k; }

    // piscar (qualquer situação viva, exceto olhos já fechados/focados)
    this.piscaEm -= dt; if (this.piscaEm <= 0 && this.piscaT <= 0) { this.piscaT = 0.12; this.piscaEm = 2.2 + this.rand() * 3.2; }
    if (this.piscaT > 0) { this.piscaT -= dt; if (!['morto', 'dor', 'susto'].includes(p.expressao)) p.piscar = 1; }

    // suavização: as deformações da situação nova são alcançadas em poucos quadros, em vez de saltar
    const taxa = ({ ataque: 60, dano: 70, morto: 40, investida: 50, foco: 18, parado: 14, topo: 16 })[p.situacao] ?? 26;
    if (!this.suave) this.suave = { sx: p.sx, sy: p.sy, ox: p.ox, oy: p.oy };
    const kk = 1 - Math.exp(-taxa * dt);
    for (const c of ['sx', 'sy', 'ox', 'oy']) { this.suave[c] += (p[c] - this.suave[c]) * kk; p[c] = this.suave[c]; }

    // inclinação elástica: pende para a frente com a velocidade e fica para trás ao acelerar (inércia do gel)
    const acel = player.config?.physics?.acceleration || 900; const ax = a ? (vx - a.vx) / Math.max(dt, 1e-3) : 0;
    const vivo = player.state !== 'dead' && player.state !== 'hurt';
    const alvoLean = vivo ? clamp((vx / maxV) * 1.4 - clamp(ax / acel, -1.2, 1.2) * 1.5, -2, 2) : 0;
    const h = Math.min(dt, 1 / 30); this.lean.v += (-170 * (this.lean.x - alvoLean) - 11 * this.lean.v) * h; this.lean.x = clamp(this.lean.x + this.lean.v * h, -2.6, 2.6);
    p.inclina = this.lean.x;

    // recuperação do pouso e surgimento (somam por cima da pose)
    if (this.pousoT > 0) { this.pousoT -= dt; const k = this.pousoT / 0.18; p.sx *= 1 + 0.14 * k * this.pousoForca; p.sy *= 1 - 0.12 * k * this.pousoForca; }
    if (this.apareceT < 1) { const e = clamp(voltaBack(this.apareceT), 0.05, 1.15); p.sx *= e; p.sy *= e; }
    if (baixaVida && p.expressao === 'normal') p.expressao = 'cansado';

    this.pose = p;
    this._ant = { noChao, vy, vx, dashing: !!player.dashing, hurt: player.state === 'hurt', squid: player.squidFx || 0, parede: a ? a.parede : false };
  }
}
