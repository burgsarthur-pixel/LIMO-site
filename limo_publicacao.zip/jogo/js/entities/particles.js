// =====================================================================
// SISTEMA DE PARTÍCULAS: rasto de dash no chão/ar, aterragem e atrito na parede.
// v1.27.0: + bolhas (idle), faíscas (golpe, dano, membrana), anéis de onda (surgir, membrana) e o roteador
// `porEvento`, que transforma os efeitos pedidos pelo LimoAnimator (passo, pulo, derrapar, parede, investida,
// bolha, tremida, respingo, surgir) em gosma. Só visual: nada aqui toca física, hitbox ou dano.
// =====================================================================
export class ParticleSystem {
  constructor() {
    this.trail = [];
    this.landing = [];
    this.wall = [];
    this.goo = [];
    this.bolhas = []; this.faiscas = []; this.aneis = [];
  }

  reset() {
    this.trail = [];
    this.landing = [];
    this.wall = [];
    this.goo = [];
    this.bolhas = []; this.faiscas = []; this.aneis = [];
  }

  /** Gotas orgânicas no estilo da Tendril: contorno, volume e brilho são desenhados pelo player-art. */
  spawnGooBurst(x, y, { quantidade = 3, direcaoX = 0, direcaoY = -0.35, velocidade = 46, abertura = 34, vida = 0.42, cor = '#55ce67' } = {}) {
    for (let i = 0; i < quantidade && this.goo.length < 80; i++) {
      const lateral = (Math.random() - 0.5) * abertura;
      const impulso = velocidade * (0.7 + Math.random() * 0.45);
      this.goo.push({
        x: x + (Math.random() * 4 - 2), y: y + (Math.random() * 3 - 1),
        vx: direcaoX * impulso + lateral,
        vy: direcaoY * impulso - Math.random() * 10,
        vida: vida * (0.78 + Math.random() * 0.32),
        maxVida: vida,
        raio: Math.random() < 0.22 ? 2 : 1,
        cor,
      });
    }
  }


  // --- v1.27.0: bolhas, faíscas, anéis e roteador de eventos ---

  /** Bolha de gás que sobe do corpo, balança e estoura em duas faíscas. */
  spawnBolha(x, y, escala = 1) {
    if (this.bolhas.length >= 10) return;
    this.bolhas.push({ x, y, vy: -(9 + Math.random() * 9), fase: Math.random() * 6.28, amp: 3 + Math.random() * 3, vida: 0.9 + Math.random() * 0.7 * escala, maxVida: 1.4, raio: Math.random() < 0.3 ? 2 : 1 });
  }

  /** Faísca de 1 px (ou 2): cor própria, gravidade opcional. */
  spawnFaiscas(x, y, { quantidade = 4, direcaoX = 0, direcaoY = -1, velocidade = 60, abertura = 90, vida = 0.3, gravidade = 120, cores = ['#caff91'], tamanho = 1 } = {}) {
    for (let i = 0; i < quantidade && this.faiscas.length < 48; i++) {
      const ang = Math.atan2(direcaoY, direcaoX) + (Math.random() - 0.5) * (abertura * Math.PI / 180);
      const v = velocidade * (0.6 + Math.random() * 0.6);
      this.faiscas.push({ x, y, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v, g: gravidade, vida: vida * (0.7 + Math.random() * 0.5), maxVida: vida, cor: cores[(Math.random() * cores.length) | 0], tam: tamanho });
    }
  }

  /** Anel de onda (círculo pontilhado que cresce e some). */
  spawnAnel(x, y, { raioIni = 3, raioFim = 14, vida = 0.35, cor = '#caff91' } = {}) {
    if (this.aneis.length >= 6) this.aneis.shift();
    this.aneis.push({ x, y, raioIni, raioFim, vida, maxVida: vida, cor });
  }

  /** Membrana absorveu um contato com espinhos: onda roxa + estilhaços de epiderme. */
  spawnMembrana(cx, cy) {
    this.spawnAnel(cx, cy, { raioIni: 5, raioFim: 17, vida: 0.4, cor: '#c58cff' });
    this.spawnFaiscas(cx, cy, { quantidade: 12, direcaoX: 0, direcaoY: -1, abertura: 360, velocidade: 70, vida: 0.38, gravidade: 90, cores: ['#c58cff', '#e2ccff', '#a98ce0'] });
  }

  /** Golpe do Pseudópode acertou algo: faíscas da cor da carne (douradas no golpe forte) + respingos de gosma. */
  spawnImpacto(x, y, dir = 1, forte = false) {
    this.spawnFaiscas(x, y, { quantidade: forte ? 9 : 5, direcaoX: dir, direcaoY: -0.25, abertura: 110, velocidade: forte ? 110 : 80, vida: forte ? 0.34 : 0.26, gravidade: 160, cores: forte ? ['#ffe135', '#fff3a5', '#ffd0a4'] : ['#ffd0a4', '#e88f7f', '#caff91'] });
    this.spawnGooBurst(x, y, { quantidade: forte ? 4 : 2, direcaoX: dir * 0.5, direcaoY: -0.4, velocidade: forte ? 70 : 46, abertura: 70, vida: 0.36 });
    if (forte) this.spawnAnel(x, y, { raioIni: 2, raioFim: 11, vida: 0.25, cor: '#ffe135' });
  }

  /** Golpe pesado (guarda quebrada, contragolpe, chefe exposto): onda dupla + leque de faíscas + gosma. */
  spawnImpactoPesado(x, y, dir = 1, cor = '#ffe135') {
    this.spawnAnel(x, y, { raioIni: 3, raioFim: 20, vida: 0.32, cor }); this.spawnAnel(x, y, { raioIni: 1, raioFim: 12, vida: 0.2, cor: '#ffffff' });
    this.spawnFaiscas(x, y, { quantidade: 12, direcaoX: dir, direcaoY: -0.2, abertura: 200, velocidade: 130, vida: 0.4, gravidade: 170, cores: [cor, '#fff3a5', '#ffffff'] });
    this.spawnGooBurst(x, y, { quantidade: 5, direcaoX: dir * 0.4, direcaoY: -0.4, velocidade: 80, abertura: 140, vida: 0.4 });
  }

  /** Golpe aparado: chuva curta de faíscas frias na direção contrária ao golpe. */
  spawnAparar(x, y, dir = 1) {
    this.spawnFaiscas(x, y, { quantidade: 7, direcaoX: -dir, direcaoY: -0.3, abertura: 100, velocidade: 110, vida: 0.22, gravidade: 140, cores: ['#cfe7ff', '#ffffff', '#8fb8ff'] });
    this.spawnAnel(x, y, { raioIni: 1, raioFim: 7, vida: 0.14, cor: '#cfe7ff' });
  }

  /** Morte de inimigo: explosão de gosma na cor da espécie + anel que se dissolve. */
  spawnMorte(x, y, cor = '#b07cff') {
    this.spawnGooBurst(x, y, { quantidade: 9, direcaoX: 0, direcaoY: -0.5, velocidade: 90, abertura: 300, vida: 0.55, cor });
    this.spawnFaiscas(x, y, { quantidade: 8, direcaoX: 0, direcaoY: -1, abertura: 360, velocidade: 80, vida: 0.5, gravidade: 90, cores: [cor, '#ffffff'] });
    this.spawnAnel(x, y, { raioIni: 3, raioFim: 16, vida: 0.3, cor });
  }

  /** Swoosh do golpe: poucas gotas arrancadas do braço, na direção do golpe. */
  spawnGolpe(x, y, dir = 1, passo = 0) {
    this.spawnGooBurst(x, y, { quantidade: 1 + passo, direcaoX: dir * 0.8, direcaoY: -0.1, velocidade: 60 + passo * 20, abertura: 26, vida: 0.22 });
  }

  /** Roteador: efeito pedido pelo LimoAnimator → partículas. `p` = jogador (body, centerX, facing, vx). */
  porEvento(ev, p) {
    if (!ev || !p || !p.body) return;
    const b = p.body; const cx = b.x + b.w / 2; const pe = b.y + b.h; const face = p.facing === -1 ? -1 : 1; const e = ev.escala ?? 1; const vx = p.vx || 0;
    switch (ev.tipo) {
      case 'passo':   // poeira de gosma atrás do pé que pisa
        this.spawnGooBurst(cx - Math.sign(vx || face) * 3 + (e > 0.9 ? 2 : -2), pe - 1, { quantidade: 1, direcaoX: -Math.sign(vx || face) * 0.5, direcaoY: -0.4, velocidade: 18 + 10 * e, abertura: 14, vida: 0.2 });
        break;
      case 'pulo':   // impulso: gosma esguicha para os lados na decolagem
        this.spawnGooBurst(cx, pe - 1, { quantidade: 3, direcaoY: -0.1, velocidade: 44, abertura: 96, vida: 0.28 });
        this.spawnAnel(cx, pe - 1, { raioIni: 2, raioFim: 9, vida: 0.2, cor: '#84ed77' });
        break;
      case 'investida':   // faíscas douradas na largada
        this.spawnFaiscas(cx - face * 3, b.y + b.h / 2, { quantidade: 5, direcaoX: -face, direcaoY: 0, abertura: 70, velocidade: 90, vida: 0.22, gravidade: 30, cores: ['#ffe135', '#fff3a5', '#caff91'] });
        break;
      case 'parede':   // splat contra a parede
        this.spawnGooBurst(p.contacts?.left ? b.x : b.x + b.w, b.y + b.h * 0.5, { quantidade: 3, direcaoX: p.contacts?.left ? 0.6 : -0.6, direcaoY: -0.2, velocidade: 30, abertura: 70, vida: 0.3 });
        break;
      case 'derrapar':   // freada: gosma é jogada para a frente, raspando o chão
        this.spawnGooBurst(cx, pe - 1, { quantidade: 3, direcaoX: Math.sign(vx) * 0.9, direcaoY: -0.35, velocidade: 40 + 20 * e, abertura: 30, vida: 0.26 });
        break;
      case 'pouso_forte':   // onda baixa no chão (o respingo vem do player.js)
        this.spawnAnel(cx, pe - 1, { raioIni: 3, raioFim: 16, vida: 0.26, cor: '#84ed77' });
        break;
      case 'bolha': this.spawnBolha(cx + (Math.random() * 6 - 3), b.y + 2, e); break;
      case 'tremida':   // gotas sacudidas para os dois lados
        this.spawnGooBurst(b.x, b.y + b.h * 0.55, { quantidade: 2, direcaoX: -1, direcaoY: -0.3, velocidade: 54, abertura: 40, vida: 0.34 });
        this.spawnGooBurst(b.x + b.w, b.y + b.h * 0.55, { quantidade: 2, direcaoX: 1, direcaoY: -0.3, velocidade: 54, abertura: 40, vida: 0.34 });
        break;
      case 'respingo':   // dano: gosma e faíscas brancas em todas as direções
        this.spawnGooBurst(cx, b.y + b.h / 2, { quantidade: 7, direcaoY: -0.4, velocidade: 78, abertura: 150, vida: 0.46 });
        this.spawnFaiscas(cx, b.y + b.h / 2, { quantidade: 6, direcaoY: -0.5, abertura: 360, velocidade: 90, vida: 0.26, cores: ['#f4fff0', '#caff91'] });
        break;
      case 'surgir':   // (re)nascimento: anel e jato de gosma
        this.spawnAnel(cx, pe - 3, { raioIni: 3, raioFim: 18, vida: 0.4, cor: '#caff91' });
        this.spawnGooBurst(cx, pe - 2, { quantidade: 8, direcaoY: -0.9, velocidade: 64, abertura: 120, vida: 0.44 });
        this.spawnFaiscas(cx, pe - 4, { quantidade: 6, direcaoY: -1, abertura: 120, velocidade: 60, vida: 0.4, gravidade: 60, cores: ['#ffe135', '#fff3a5'] });
        break;
      default: break;
    }
  }

  // --- Rasto Contínuo (no chão) e Partículas Dinâmicas (Chão e Ar) ---
  spawnDash(bodyX, bodyY, bodyW, bodyH, facing, onGround) {
    if (onGround) {
      // 1. A faixa horizontal contínua logo na base dos pés
      this.trail.unshift({
        x: bodyX + (facing > 0 ? 0 : 4),
        y: bodyY + bodyH - 3,
        w: bodyW - 4,
        h: 3,
        vida: 0.4,
        tipo: 'faixa'
      });
      
      // 2. Pedacinhos dinâmicos de gelatina que se soltam e ficam no chão
      for (let i = 0; i < 2; i++) {
        this.trail.unshift({
          x: bodyX + (facing > 0 ? 2 : bodyW - 4) + (Math.random() * 8 - 4),
          y: bodyY + bodyH - (Math.random() * 4 + 2),
          vx: -facing * (Math.random() * 20 + 5),
          vy: -(Math.random() * 15 + 2),
          w: Math.random() < 0.5 ? 3 : 2,
          h: Math.random() < 0.5 ? 3 : 2,
          vida: 0.45,
          tipo: 'pedaco'
        });
      }
    } else {
      // 3. Partículas de dispersão aérea para o dash no ar
      for (let i = 0; i < 3; i++) {
        this.trail.unshift({
          x: bodyX + bodyW / 2 + (Math.random() * 10 - 5),
          y: bodyY + bodyH / 2 + (Math.random() * 10 - 5),
          vx: -facing * (Math.random() * 40 + 10),
          vy: Math.random() * 20 - 10,
          w: 2,
          h: 2,
          vida: 0.25,
          tipo: 'ar'
        });
      }
    }

    const origemX = bodyX + bodyW / 2 - facing * (onGround ? bodyW * 0.35 : 2);
    const origemY = bodyY + bodyH * (onGround ? 0.82 : 0.5);
    this.spawnGooBurst(origemX, origemY, {
      quantidade: onGround ? 1 : 2, direcaoX: -facing, direcaoY: onGround ? -0.18 : 0,
      velocidade: onGround ? 34 : 46, abertura: onGround ? 18 : 34, vida: onGround ? 0.3 : 0.24,
    });
    if (this.trail.length > 25) this.trail.pop();
  }

  /** Pulo duplo: o rastro da investida, mas na vertical (faixa sob os pés + pedaços de gosma que caem). */
  spawnAirJump(bodyX, bodyY, bodyW, bodyH) {
    const cx = bodyX + bodyW / 2;
    this.trail.unshift({ x: cx - 1 + (Math.random() * 4 - 2), y: bodyY + bodyH, w: 3, h: 6, vida: 0.35, tipo: 'faixa' });
    for (let i = 0; i < 2; i++) {
      this.trail.unshift({ x: cx + (Math.random() * 8 - 4), y: bodyY + bodyH - 2, vx: Math.random() * 16 - 8, vy: Math.random() * 40 + 15, w: 2, h: 3, vida: 0.3, tipo: 'ar' });
    }
    this.spawnGooBurst(cx, bodyY + bodyH - 1, { quantidade: 4, direcaoY: 0.7, velocidade: 42, abertura: 28, vida: 0.36 });
    if (this.trail.length > 25) this.trail.pop();
  }

  /** Tinta de lula: nuvem escura que expande e desacelera (sai embaixo do Limo no pulo duplo, como a lula fugindo). */
  spawnTinta(bodyX, bodyY, bodyW, bodyH) {
    const cx = bodyX + bodyW / 2;
    for (let i = 0; i < 9; i++) {
      const a = Math.random() * Math.PI;   // leque para baixo
      this.trail.unshift({ x: cx + (Math.random() * 6 - 3), y: bodyY + bodyH - 1, vx: Math.cos(a) * (14 + Math.random() * 26) * (Math.random() < 0.5 ? -1 : 1), vy: 18 + Math.random() * 38,
        w: 2 + ((Math.random() * 3) | 0), h: 2 + ((Math.random() * 3) | 0), vida: 0.45 + Math.random() * 0.35, tipo: 'tinta', cor: Math.random() < 0.5 ? '#1b1033' : '#2d1a52' });
    }
    this.spawnGooBurst(cx, bodyY + bodyH - 1, { quantidade: 3, direcaoY: 0.65, velocidade: 34, abertura: 32, vida: 0.38, cor: '#2d1a52' });
    if (this.trail.length > 45) this.trail.length = 45;
  }

  spawnLanding(floorX, floorY, vyAoChegar) {
    const qtd = Math.min(8, Math.max(3, Math.floor(vyAoChegar / 40)));
    for (let i = 0; i < qtd; i++) {
      this.landing.push({
        x: floorX + (Math.random() * 12 - 6),
        y: floorY - 2,
        vx: (Math.random() - 0.5) * 60,
        vy: -Math.random() * 30 - 10,
        vida: 0.5,
        tamanho: Math.random() < 0.4 ? 3 : 2
      });
    }
    this.spawnGooBurst(floorX, floorY - 1, {
      quantidade: qtd, direcaoY: -0.5, velocidade: Math.min(90, 30 + vyAoChegar * 0.12),
      abertura: 76, vida: 0.46,
    });
  }

  // --- Atrito na Parede (Wall Slide) ---
  spawnWallSlide(wallDir, bodyX, bodyY, bodyH) {
    const particleX = wallDir < 0 ? bodyX : bodyX + 12;
    const particleY = bodyY + Math.random() * bodyH;

    this.wall.push({
      x: particleX,
      y: particleY,
      vx: wallDir * (Math.random() * 15 + 5),
      vy: Math.random() * 20 + 10,
      vida: 0.4,
      tamanho: 2
    });
    this.spawnGooBurst(particleX, particleY, { quantidade: 1, direcaoX: wallDir, direcaoY: 0.2, velocidade: 26, abertura: 12, vida: 0.28 });
  }

  // --- Atualizar todas as partículas ---
  update(dt) {
    // 1. Rasto de Dash (Chão e Ar)
    for (let i = this.trail.length - 1; i >= 0; i--) {
      let p = this.trail[i];
      if (p.tipo === 'tinta') { p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.95; p.vy *= 0.96; p.w += dt * 6; p.h += dt * 6; }
      if (p.tipo === 'pedaco' || p.tipo === 'ar') {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        if (p.tipo === 'pedaco' && p.vy > 0) {
          p.vy += 150 * dt;
          p.vx *= 0.85;
        }
      }
      p.vida -= dt;
      if (p.vida <= 0) this.trail.splice(i, 1);
    }

    // 2. Gotas orgânicas (mesma inércia curta e peso da Tendril, sem colisão/gameplay).
    for (let i = this.goo.length - 1; i >= 0; i--) {
      const g = this.goo[i];
      g.x += g.vx * dt;
      g.y += g.vy * dt;
      g.vy += 180 * dt;
      g.vx *= Math.exp(-2.4 * dt);
      g.vida -= dt;
      if (g.vida <= 0) this.goo.splice(i, 1);
    }

    // 3. Partículas de Aterragem
    for (let i = this.landing.length - 1; i >= 0; i--) {
      let lp = this.landing[i];
      lp.x += lp.vx * dt;
      lp.y += lp.vy * dt;
      lp.vy += 120 * dt;
      lp.vida -= dt;
      if (lp.vida <= 0) this.landing.splice(i, 1);
    }

    // 4. v1.27.0 — bolhas (sobem balançando e estouram), faíscas e anéis
    for (let i = this.bolhas.length - 1; i >= 0; i--) {
      const bo = this.bolhas[i]; bo.fase += dt * 5; bo.y += bo.vy * dt; bo.x += Math.cos(bo.fase) * bo.amp * dt; bo.vida -= dt;
      if (bo.vida <= 0) { this.spawnFaiscas(bo.x, bo.y, { quantidade: 2, direcaoY: -1, abertura: 360, velocidade: 18, vida: 0.14, gravidade: 0, cores: ['#caff91', '#f4fff0'] }); this.bolhas.splice(i, 1); }
    }
    for (let i = this.faiscas.length - 1; i >= 0; i--) {
      const f = this.faiscas[i]; f.x += f.vx * dt; f.y += f.vy * dt; f.vy += f.g * dt; f.vx *= Math.exp(-1.6 * dt); f.vida -= dt;
      if (f.vida <= 0) this.faiscas.splice(i, 1);
    }
    for (let i = this.aneis.length - 1; i >= 0; i--) { this.aneis[i].vida -= dt; if (this.aneis[i].vida <= 0) this.aneis.splice(i, 1); }

    // 3. Partículas de Parede (Wall Slide)
    for (let i = this.wall.length - 1; i >= 0; i--) {
      let wp = this.wall[i];
      wp.x += wp.vx * dt;
      wp.y += wp.vy * dt;
      wp.vida -= dt;
      if (wp.vida <= 0) this.wall.splice(i, 1);
    }
  }
}
