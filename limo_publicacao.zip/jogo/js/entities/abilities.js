// =====================================================================
// HABILIDADES / MUTAÇÕES DO LIMO
// =====================================================================

export const ABILITIES = {
  investida: {
    id: 'investida',
    uso: 'Botão de investida (celular) · Shift / K',
    nome: 'Investida (Dash)',
    icone: '⚡', curto: 'Investida',
    descricao: 'Permite dar um impulso rápido na direção horizontal.',
    frases: ['A carne do deus se contrai em você.', 'Lance-se à frente e rompa o que o detém.'],
    implementada: true,
  },
  saltoElastico: {
    id: 'saltoElastico',
    uso: 'Toque em pular de novo, no ar',
    nome: 'Salto Elástico',
    icone: '🦑', curto: 'Pulo duplo',
    descricao: 'Lula-gosma: um pulo extra no ar, com jato de tinta.',
    frases: ['Braços de lula brotam do seu corpo no ar.', 'Jorre tinta e salte uma segunda vez.'],
    implementada: true,
    extraJumps: 1,
    speedFactor: 0.9,
  },
  wallJump: {
    id: 'wallJump',
    uso: 'Encoste na parede e toque em pular',
    nome: 'Salto na Parede',
    icone: '🕷', curto: 'Parede',
    descricao: 'Gosma de patas de aranha: agarra e salta nas paredes.',
    frases: ['Patas finas brotam da sua gosma ao tocar a parede.', 'Agarre-se e salte de parede em parede.'],
    implementada: true,
  },
  membrana: {
    id: 'membrana',
    uso: 'Passiva: absorve 1 contato a cada 2,4 s',
    nome: 'Membrana Protetora',
    icone: '◈', curto: 'Membrana',
    descricao: 'A epiderme de vigília do Deus: absorve um contato com espinhos a cada 2,4 segundos.',
    frases: ['A primeira pele do Deus se recorda de você.', 'Espinhos cedem diante de uma cicatriz que escolheu proteger.'],
    implementada: true,
  },
  pseudopode: {
    id: 'pseudopode',
    uso: 'Botão de ataque (celular) · J / C — 3 toques = combo',
    nome: 'Pseudópode',
    icone: '◖', curto: 'Pseudópode',
    descricao: 'O músculo de memória do Deus: golpe orgânico em combo de 3 que rompe paredes rachadas.',
    frases: ['Uma lembrança muscular desperta dentro de Limo.', 'Projete o corpo. Golpeie o que tentou mantê-lo fechado.'],
    implementada: true,
  },
  tendril: {
    id: 'tendril',
    uso: 'Segure o botão da Tendril (celular) · V e mire numa âncora',
    nome: 'Tendril',
    icone: '〰', curto: 'Tendril',
    descricao: 'O fio de conexão do Deus: extensão orgânica que alcança âncoras, objetos e criaturas compatíveis.',
    frases: ['Um nervo antigo reconhece o mundo além da pele.', 'Estenda-se. Tudo que o Deus tocou ainda pode responder.'],
    implementada: true,
    alcance: 104,
    velocidadePuxao: 92,
  },
  instanteVital: {
    id: 'instanteVital',
    uso: 'Passiva: ao concluir uma cura (Foco), o mundo desacelera por um instante',
    nome: 'Instante Vital',
    icone: '⏳', curto: 'Instante',
    descricao: 'Uma essência que o organismo guardou: ao concluir uma cura, o mundo desacelera por um instante. Não protege de dano.',
    frases: ['O corpo do Deus guardou um instante para você.', 'Quando a ferida se fecha, o tempo hesita.'],
    rotulo: 'ESSÊNCIA PRESERVADA',
    implementada: true,
  },
};

/** Lista dos IDs de todas as habilidades registradas no jogo */
export const ABILITY_IDS = Object.keys(ABILITIES);

/** Transforma array ['investida'] ou objeto {investida: true} num dicionário booleano limpo */
export function normalizeAbilities(inicial = {}) {
  const mapa = {};
  for (const id of ABILITY_IDS) {
    if (Array.isArray(inicial)) {
      mapa[id] = inicial.includes(id);
    } else if (typeof inicial === 'object' && inicial !== null) {
      mapa[id] = !!inicial[id];
    } else {
      mapa[id] = false;
    }
  }
  return mapa;
}

/** Converte string ou array de requisitos para um array limpo de strings */
export function normalizeRequires(requires) {
  if (!requires) return [];
  if (Array.isArray(requires)) return requires;
  if (typeof requires === 'string') return [requires];
  return [];
}

/** Confere se o conjunto de habilidades do jogador satisfaz os requisitos da passagem */
export function checkRequirement(abilitiesPlayer, requires) {
  const requisitoLista = normalizeRequires(requires);
  if (requisitoLista.length === 0) return { ok: true, missing: [] };

  const mapaJogador = normalizeAbilities(abilitiesPlayer);
  const faltantes = requisitoLista.filter((req) => !mapaJogador[req]);

  return {
    ok: faltantes.length === 0,
    missing: faltantes,
  };
}
