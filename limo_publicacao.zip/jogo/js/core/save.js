// =====================================================================
// SALVAMENTO: valida, migra e preserva uma cópia anterior sem derrubar o jogo.
// =====================================================================
import { SAVE_FORMAT, SAVE_VERSION } from './progress.js';
import { ABILITY_IDS } from '../entities/abilities.js';

export const CHAVE_SAVE = 'limo.save';
export const CHAVE_BACKUP = 'limo.save.backup';

const cloneJson = (valor) => JSON.parse(JSON.stringify(valor));

/** Converte formatos antigos para o formato atual, sem alterar a entrada. */
export function migrarSave(bruto) {
  if (!bruto || typeof bruto !== 'object' || Array.isArray(bruto)) return { ok: false, estado: 'corrompido', erro: 'o salvamento não é um objeto' };
  if (bruto.formato !== SAVE_FORMAT) return { ok: false, estado: 'corrompido', erro: `formato desconhecido (${JSON.stringify(bruto.formato)})` };
  if (!Number.isInteger(bruto.versao)) return { ok: false, estado: 'corrompido', erro: 'o salvamento não informa uma versão inteira' };
  if (bruto.versao > SAVE_VERSION) return { ok: false, estado: 'incompativel', versao: bruto.versao, erro: `salvamento da versão ${bruto.versao}; este jogo lê até a versão ${SAVE_VERSION}` };
  let dados = cloneJson(bruto); const origem = dados.versao;
  while (dados.versao < SAVE_VERSION) {
    if (dados.versao === 1) {
      // v2 torna explícitos campos que saves antigos podiam não ter.
      if (!Array.isArray(dados.bancos)) dados.bancos = [];
      if (dados.final === undefined) dados.final = null;
      dados.versao = 2;
    } else return { ok: false, estado: 'incompativel', versao: dados.versao, erro: `não existe migração da versão ${dados.versao}` };
  }
  return { ok: true, dados, migrou: origem !== dados.versao, versaoOrigem: origem };
}

/** Confere um salvamento já convertido de JSON contra o mundo atual. */
export function validateSave(d, mundo) {
  const errors = []; const warnings = [];
  if (!d || typeof d !== 'object' || Array.isArray(d)) return { errors: ['o salvamento não é um objeto'], warnings };
  if (d.formato !== SAVE_FORMAT) errors.push(`formato desconhecido (${JSON.stringify(d.formato)})`);
  if (d.versao !== SAVE_VERSION) errors.push(`versão ${JSON.stringify(d.versao)} (este jogo lê a versão ${SAVE_VERSION})`);
  const h = d.habilidades;
  if (!h || typeof h !== 'object') errors.push('faltam as habilidades');
  else for (const [k, v] of Object.entries(h)) { if (!ABILITY_IDS.includes(k)) errors.push(`habilidade desconhecida "${k}"`); else if (typeof v !== 'boolean') errors.push(`habilidade "${k}" deve ser verdadeiro/falso`); }
  for (const campo of ['coletados', 'visitadas', 'bloqueiosDescobertos', 'passagensAbertas', 'chefesDerrotados', 'bancos', 'descobertas']) {
    if (d[campo] !== undefined && !(Array.isArray(d[campo]) && d[campo].every((x) => typeof x === 'string'))) errors.push(`"${campo}" deve ser uma lista de textos`);
  }
  if (d.essencia !== undefined && !(Number.isInteger(d.essencia) && d.essencia >= 0)) errors.push('"essencia" deve ser um inteiro >= 0');
  if (d.encaixesExtra !== undefined && !(Number.isInteger(d.encaixesExtra) && d.encaixesExtra >= 0)) errors.push('"encaixesExtra" deve ser um inteiro >= 0');
  if (d.estatisticas !== undefined && (!d.estatisticas || typeof d.estatisticas !== 'object' || Array.isArray(d.estatisticas))) errors.push('"estatisticas" deve ser um objeto');
  if (d.final !== undefined && d.final !== null && typeof d.final !== 'string') errors.push('"final" deve ser texto ou nulo');
  if (d.genes !== undefined) {
    const g = d.genes;
    if (!g || typeof g !== 'object' || Array.isArray(g)) errors.push('"genes" deve ser um objeto {obtidos, equipados}');
    else for (const k of ['obtidos', 'equipados']) if (g[k] !== undefined && !(Array.isArray(g[k]) && g[k].every((x) => typeof x === 'string'))) errors.push(`"genes.${k}" deve ser uma lista de textos`);
  }
  const cp = d.checkpoint;
  if (cp !== null && cp !== undefined) {
    if (typeof cp !== 'object' || typeof cp.sala !== 'string' || typeof cp.id !== 'string') errors.push('checkpoint inválido');
    else if (mundo) {
      const sala = mundo.get(cp.sala);
      if (!sala) errors.push(`o checkpoint está na sala "${cp.sala}", que não existe mais`);
      else if (!sala.entities.some((e) => e.type === 'checkpoint' && e.id === cp.id)) errors.push(`o checkpoint "${cp.id}" não existe mais na sala "${cp.sala}"`);
    }
  }
  if (mundo && errors.length === 0) for (const s of d.visitadas || []) if (!mundo.has(s)) warnings.push(`sala visitada "${s}" não existe mais (ignorada)`);
  return { errors, warnings };
}

export class SaveStore {
  constructor(obterStorage = () => globalThis.localStorage) { this._obter = obterStorage; }
  _storage() { try { return this._obter() || null; } catch (e) { return null; } }
  disponivel() { const s = this._storage(); if (!s) return false; try { s.setItem(`${CHAVE_SAVE}.__teste`, '1'); s.removeItem(`${CHAVE_SAVE}.__teste`); return true; } catch (e) { return false; } }
  _lerChave(s, chave, mundo) {
    let texto; try { texto = s.getItem(chave); } catch (e) { return { estado: 'indisponivel', erro: 'o navegador bloqueou a leitura do armazenamento' }; }
    if (texto === null || texto === undefined) return { estado: 'sem-save' };
    let bruto; try { bruto = JSON.parse(texto); } catch (e) { return { estado: 'corrompido', erro: 'o arquivo de salvamento não é um JSON válido' }; }
    const mig = migrarSave(bruto); if (!mig.ok) return mig;
    const validacao = validateSave(mig.dados, mundo);
    if (validacao.errors.length) return { estado: 'corrompido', erro: validacao.errors[0], erros: validacao.errors };
    return { estado: 'ok', dados: mig.dados, avisos: validacao.warnings, migrou: mig.migrou, versaoOrigem: mig.versaoOrigem };
  }
  ler(mundo = null) {
    const s = this._storage(); if (!s) return { estado: 'indisponivel', erro: 'o navegador não permite acessar o armazenamento' };
    const principal = this._lerChave(s, CHAVE_SAVE, mundo);
    if (principal.estado === 'ok') {
      if (principal.migrou) this.gravar(principal.dados);
      return principal;
    }
    const reserva = this._lerChave(s, CHAVE_BACKUP, mundo);
    if (reserva.estado === 'ok') {
      try { s.setItem(CHAVE_SAVE, JSON.stringify(reserva.dados)); } catch (e) { /* continuar ainda é seguro */ }
      return { ...reserva, recuperado: true, avisoRecuperacao: 'O último salvamento estava inválido; foi recuperada a cópia anterior.' };
    }
    return principal;
  }
  gravar(dados) {
    const s = this._storage(); if (!s) return { ok: false, error: 'armazenamento indisponível' };
    let texto; try { texto = JSON.stringify(dados); } catch (e) { return { ok: false, error: 'não foi possível preparar o salvamento' }; }
    try {
      const anterior = s.getItem(CHAVE_SAVE);
      if (anterior !== null) s.setItem(CHAVE_BACKUP, anterior);
      s.setItem(CHAVE_SAVE, texto);
      if (s.getItem(CHAVE_SAVE) !== texto) return { ok: false, error: 'a gravação não foi confirmada' };   // conferência: alguns navegadores móveis falham sem lançar erro
      return { ok: true };
    } catch (e) { return { ok: false, error: e && e.name === 'QuotaExceededError' ? 'armazenamento cheio' : 'não foi possível gravar' }; }
  }
  exportar(mundo = null) { const lido = this.ler(mundo); return lido.estado === 'ok' ? { ok: true, texto: JSON.stringify(lido.dados, null, 2), dados: lido.dados } : { ok: false, error: lido.erro || 'não há progresso válido para exportar' }; }
  importar(texto, mundo = null) {
    let bruto; try { bruto = JSON.parse(texto); } catch (e) { return { ok: false, error: 'o arquivo escolhido não é um JSON válido' }; }
    const mig = migrarSave(bruto); if (!mig.ok) return { ok: false, error: mig.erro };
    const validacao = validateSave(mig.dados, mundo); if (validacao.errors.length) return { ok: false, error: validacao.errors[0] };
    const gravado = this.gravar(mig.dados); return gravado.ok ? { ok: true, migrou: mig.migrou } : gravado;
  }
  apagar({ incluirBackup = true } = {}) { const s = this._storage(); try { s?.removeItem(CHAVE_SAVE); if (incluirBackup) s?.removeItem(CHAVE_BACKUP); return true; } catch (e) { return false; } }
}
