// =====================================================================
// ENTRADA: estado de entrada + adaptadores (teclado, toque, gamepad)
//
// Ideia central: cada AÇÃO (esquerda, pulo...) pode ser segurada por várias
// FONTES ao mesmo tempo (tecla A, botão de toque, gamepad). A ação só é
// liberada quando TODAS as fontes soltarem. Assim, soltar um botão libera
// somente o comando correspondente e o personagem não "fica andando sozinho".
// =====================================================================

export const ACTIONS = ['left', 'right', 'up', 'down', 'jump', 'dash', 'tendril', 'attack', 'foco', 'interact'];

export class InputState {
  constructor() {
    this._fontes = {};     // ação -> Set de fontes que a seguram
    this._apertou = {};    // ação -> true no passo em que foi apertada (borda de subida)
    this._soltou = {};     // ação -> true no passo em que foi solta
    for (const a of ACTIONS) { this._fontes[a] = new Set(); this._apertou[a] = false; this._soltou[a] = false; }
  }

  setSource(acao, fonte, pressionado) {
    const set = this._fontes[acao];
    if (!set) throw new Error(`Ação desconhecida: ${acao}`);
    const estavaPressionada = set.size > 0;
    if (pressionado) set.add(fonte); else set.delete(fonte);
    const estaPressionada = set.size > 0;
    if (!estavaPressionada && estaPressionada) this._apertou[acao] = true;
    if (estavaPressionada && !estaPressionada) this._soltou[acao] = true;
  }

  isDown(acao) { return this._fontes[acao].size > 0; }
  wasPressed(acao) { return this._apertou[acao]; }
  wasReleased(acao) { return this._soltou[acao]; }
  /** -1 (esquerda), 0 (parado ou as duas direções juntas) ou +1 (direita). */
  axisX() { return (this.isDown('right') ? 1 : 0) - (this.isDown('left') ? 1 : 0); }

  /** Chamar ao FIM de cada passo fixo da física: limpa os "eventos de um quadro só". */
  endStep() { for (const a of ACTIONS) { this._apertou[a] = false; this._soltou[a] = false; } }

  /** Solta tudo (ex.: aba perdeu o foco). */
  releaseAll() {
    for (const a of ACTIONS) {
      if (this._fontes[a].size > 0) this._soltou[a] = true;
      this._fontes[a].clear();
    }
  }

  releaseSourcesWithPrefix(prefixo) {
    for (const a of ACTIONS) {
      const tinha = this._fontes[a].size > 0;
      for (const f of [...this._fontes[a]]) if (f.startsWith(prefixo)) this._fontes[a].delete(f);
      if (tinha && this._fontes[a].size === 0) this._soltou[a] = true;
    }
  }
}

// ---------------------------------------------------------------------
// TECLADO
// ---------------------------------------------------------------------
export function attachKeyboard(input, config, alvo = window, comandos = {}) {
  const teclas = () => config.controls.keyboard;
  const digitando = (e) => {
    const t = e.target;
    const tag = t && t.tagName ? String(t.tagName).toLowerCase() : '';
    return tag === 'input' || tag === 'textarea' || tag === 'select' || !!(t && t.isContentEditable);
  };
  const acoesDaTecla = (code) => {
    const lista = [];
    for (const [acao, codigos] of Object.entries(teclas().actions)) if (codigos.includes(code)) lista.push(acao);
    return lista;
  };

  const aoApertar = (e) => {
    // Em campos de texto (painel de debug) não roubamos letras, mas teclas de função (F3...) continuam valendo.
    if (digitando(e) && !/^F\d+$/.test(e.code)) return;
    const cmd = teclas().commands;
    if (digitando(e) && !cmd.debug.includes(e.code) && !(cmd.editor || []).includes(e.code)) return;
    if (cmd.pause.includes(e.code)) { if (!e.repeat) comandos.pause?.(); e.preventDefault?.(); return; }
    if ((cmd.editor || []).includes(e.code)) { if (!e.repeat) comandos.toggleEditor?.(); if (comandos.toggleEditor) e.preventDefault?.(); return; }
    if (cmd.debug.includes(e.code)) { if (!e.repeat) comandos.toggleDebug?.(); if (comandos.toggleDebug) e.preventDefault?.(); return; }
    const acoes = acoesDaTecla(e.code);
    if (!acoes.length) return;
    e.preventDefault?.();
    for (const a of acoes) input.setSource(a, `kbd:${e.code}`, true);
  };
  const aoSoltar = (e) => {
    for (const a of acoesDaTecla(e.code)) input.setSource(a, `kbd:${e.code}`, false); // sempre solta, mesmo digitando
  };
  const aoPerderFoco = () => input.releaseAll();

  alvo.addEventListener('keydown', aoApertar);
  alvo.addEventListener('keyup', aoSoltar);
  alvo.addEventListener('blur', aoPerderFoco);
  return () => {
    alvo.removeEventListener('keydown', aoApertar);
    alvo.removeEventListener('keyup', aoSoltar);
    alvo.removeEventListener('blur', aoPerderFoco);
  };
}

// ---------------------------------------------------------------------
// TOQUE: lógica pura (testável) + ligação com o DOM
// ---------------------------------------------------------------------

/** Botão que pode ser segurado por vários dedos; só solta quando o último dedo sai. */
export class HoldTracker {
  constructor(input, acao) {
    this.input = input; this.acao = acao; this.fonte = `touch:${acao}`; this.dedos = new Set();
  }
  down(id) { this.dedos.add(id); this.input.setSource(this.acao, this.fonte, true); }
  up(id) { if (!this.dedos.delete(id)) return; if (this.dedos.size === 0) this.input.setSource(this.acao, this.fonte, false); }
  clear() { this.dedos.clear(); this.input.setSource(this.acao, this.fonte, false); }
}

/**
 * JOYSTICK de 8 direções: o vetor do dedo (a partir do centro) vira {x,y} em {-1,0,1}.
 * Zona morta no centro; cada direção ocupa um setor de 45° (diagonais incluídas).
 */
export function joystickDirection(dx, dy, raio, zonaMorta = 0.28) {
  if (!(raio > 0) || Math.hypot(dx, dy) / raio < zonaMorta) return { x: 0, y: 0 };
  const i = ((Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) % 8) + 8) % 8;   // 0=direita, 2=baixo, 4=esquerda, 6=cima
  return [{ x: 1, y: 0 }, { x: 1, y: 1 }, { x: 0, y: 1 }, { x: -1, y: 1 }, { x: -1, y: 0 }, { x: -1, y: -1 }, { x: 0, y: -1 }, { x: 1, y: -1 }][i];
}

export class DpadTracker {
  constructor(input) { this.input = input; this.dedos = new Map(); }
  setDirection(id, dir, baixo = false) { this.dedos.set(id, { dir, baixo, vy: 0 }); this._aplicar(); }
  /** Joystick: vec = {x,y} de joystickDirection. */
  setStick(id, vec) { this.dedos.set(id, { dir: vec.x, baixo: false, vy: vec.y }); this._aplicar(); }
  release(id) { this.dedos.delete(id); this._aplicar(); }
  clear() { this.dedos.clear(); this._aplicar(); }
  refresh() { this._aplicar(); }
  /**
   * Horizontal: sempre (as diagonais também andam). Vertical (↑/↓): só em direção vertical pura — a menos que a Tendril
   * esteja sendo segurada (modo de mira), quando as diagonais também entram. Assim correr com o polegar meio torto nunca vira "↓".
   */
  _aplicar() {
    const mira = this.input.isDown('tendril');
    let esq = false; let dir = false; let baixo = false; let cima = false;
    for (const d of this.dedos.values()) {
      if (d.dir < 0) esq = true; else if (d.dir > 0) dir = true;
      if (d.baixo) baixo = true;
      if (d.vy > 0 && (mira || d.dir === 0)) baixo = true;
      if (d.vy < 0 && (mira || d.dir === 0)) cima = true;
    }
    this.input.setSource('left', 'touch:dpad', esq);
    this.input.setSource('right', 'touch:dpad', dir);
    this.input.setSource('down', 'touch:dpad', baixo);
    this.input.setSource('up', 'touch:dpad', cima);
  }
}

/** Liga os elementos HTML (#dpad e [data-action]) aos rastreadores acima. */
export function attachTouch(input, raiz) {
  const limpezas = [];
  const dpadEl = raiz.querySelector('#dpad');
  const dpad = new DpadTracker(input);
  if (dpadEl) {
    const knob = dpadEl.querySelector('.stick-knob');
    const mostrar = () => {
      for (const k of ['left', 'right', 'up', 'down']) dpadEl.classList.toggle(k, input.isDown(k));
    };
    const atualizar = (e) => {   // joystick: posição do dedo relativa ao centro do círculo
      const r = dpadEl.getBoundingClientRect(); const raio = r.width / 2;
      const dx = e.clientX - (r.left + raio); const dy = e.clientY - (r.top + r.height / 2);
      dpad.setStick(e.pointerId, joystickDirection(dx, dy, raio));
      if (knob) { const m = Math.hypot(dx, dy) || 1; const k = Math.min(m, raio * 0.55) / m; knob.style.transform = `translate(${(dx * k).toFixed(1)}px, ${(dy * k).toFixed(1)}px)`; }
      mostrar();
    };
    const aoApertar = (e) => { e.preventDefault(); dpadEl.setPointerCapture?.(e.pointerId); atualizar(e); dpadEl.classList.toggle('pressed', true); };   // `pressed`: o CSS devolve a cor original enquanto há dedo
    const aoMover = (e) => { if (dpad.dedos.has(e.pointerId)) atualizar(e); };
    const aoSoltar = (e) => { dpad.release(e.pointerId); if (knob && dpad.dedos.size === 0) knob.style.transform = ''; if (dpad.dedos.size === 0) dpadEl.classList.toggle('pressed', false); mostrar(); };
    dpadEl.addEventListener('pointerdown', aoApertar);
    dpadEl.addEventListener('pointermove', aoMover);
    for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) dpadEl.addEventListener(ev, aoSoltar);
    limpezas.push(() => { dpad.clear(); if (knob) knob.style.transform = ''; dpadEl.classList.toggle('pressed', false); mostrar(); });
  }
  const botoes = [];
  for (const el of raiz.querySelectorAll('[data-action]')) {
    const acao = el.dataset.action;
    const tracker = new HoldTracker(input, acao);
    const aoApertar = (e) => { e.preventDefault(); el.setPointerCapture?.(e.pointerId); tracker.down(e.pointerId); el.classList.add('pressed'); if (acao === 'tendril') dpad.refresh(); };
    const aoSoltar = (e) => { tracker.up(e.pointerId); if (tracker.dedos.size === 0) el.classList.remove('pressed'); if (acao === 'tendril') dpad.refresh(); };
    el.addEventListener('pointerdown', aoApertar);
    for (const ev of ['pointerup', 'pointercancel', 'lostpointercapture']) el.addEventListener(ev, aoSoltar);
    el.addEventListener('contextmenu', (e) => e.preventDefault());
    botoes.push({ tracker, el });
  }
  raiz.addEventListener?.('contextmenu', (e) => e.preventDefault());
  return () => { for (const l of limpezas) l(); for (const b of botoes) { b.tracker.clear(); b.el.classList.remove('pressed'); } };
}

// ---------------------------------------------------------------------
// GAMEPAD (opcional: sem controle conectado, nada acontece e nada quebra)
// ---------------------------------------------------------------------
export class GamepadPoller {
  constructor(input, config, nav = (typeof navigator !== 'undefined' ? navigator : null), comandos = {}) {
    this.input = input; this.config = config; this.nav = nav; this.comandos = comandos;
    this.ativo = false; this._startAntes = false; this._botoesAntes = new Set(); this._ultimoTempo = 0;
  }

  poll() {
    let pad = null;
    try {
      const lista = this.nav && typeof this.nav.getGamepads === 'function' ? this.nav.getGamepads() : null;
      if (lista) for (const p of lista) { if (p && p.connected) { pad = p; break; } }
    } catch (e) { pad = null; }

    if (!pad) {
      if (this.ativo) { this.input.releaseSourcesWithPrefix('pad:'); this.ativo = false; }
      this._startAntes = false; this._botoesAntes.clear(); this._ultimoTempo = 0;
      this.comandos.onGamepadFrame?.(null, { down: new Set(), pressed: new Set(), released: new Set(), dt: 0, connected: false });
      return false;
    }
    this.ativo = true;
    const g = this.config.controls.gamepad;
    const ax = pad.axes?.[0] || 0; const ay = pad.axes?.[1] || 0;
    const botao = (i) => !!(pad.buttons?.[i] && (pad.buttons[i].pressed || pad.buttons[i].value > 0.5));
    const algum = (lista) => (lista || []).some(botao);
    const down = new Set();
    for (let i = 0; i < (pad.buttons?.length || 0); i++) if (botao(i)) down.add(i);
    const pressed = new Set([...down].filter((i) => !this._botoesAntes.has(i)));
    const released = new Set([...this._botoesAntes].filter((i) => !down.has(i)));
    const agora = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    const dt = this._ultimoTempo ? Math.min(0.05, Math.max(0, (agora - this._ultimoTempo) / 1000)) : 0;
    this._ultimoTempo = agora; this._botoesAntes = down;

    this.input.setSource('left', 'pad:left', ax < -g.deadzone || algum(g.left));
    this.input.setSource('right', 'pad:right', ax > g.deadzone || algum(g.right));
    this.input.setSource('up', 'pad:up', ay < -g.deadzone || algum(g.up));
    this.input.setSource('down', 'pad:down', ay > g.deadzone || algum(g.down));
    this.input.setSource('jump', 'pad:jump', algum(g.jump));
    this.input.setSource('dash', 'pad:dash', algum(g.dash));
    this.input.setSource('tendril', 'pad:tendril', algum(g.tendril));
    this.input.setSource('attack', 'pad:attack', algum(g.attack));
    this.input.setSource('foco', 'pad:foco', algum(g.foco));

    if (pressed.has(g.pauseButton)) this.comandos.pause?.();
    const editorAtivo = !!this.comandos.editorActive?.();
    if (!editorAtivo && pressed.has(g.mapButton)) this.comandos.toggleMap?.();
    if (!editorAtivo && pressed.has(g.debugButton)) this.comandos.toggleDebug?.();
    if (!editorAtivo && pressed.has(g.editorButton)) this.comandos.toggleEditor?.();
    this.comandos.onGamepadFrame?.(pad, { down, pressed, released, dt, connected: true });
    return true;
  }
}
