// =====================================================================
// CONSOLE DE DEBUG CENTRALIZADO
// Guarda mensagens por categoria, evita repetição (×N) e limita o tamanho.
// Não depende do navegador: funciona também nos testes em Node.
// =====================================================================

export const LOG_CATEGORIES = [
  'fisica', 'colisoes', 'tilemap', 'carregamento', 'transicoes', 'combate',
  'inimigos', 'habilidades', 'salvamento', 'interface', 'erros', 'geral',
];
export const LOG_LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };

export class Logger {
  constructor(opcoes = {}) {
    this.maxEntries = opcoes.maxEntries ?? 300;
    this.dedupeWindowMs = opcoes.dedupeWindowMs ?? 1000;
    this.now = opcoes.now ?? (() => Date.now());
    this.mirrorToConsole = !!opcoes.mirrorToConsole;
    this.entries = [];
    this._recentes = new Map(); // chave -> entrada (para agrupar repetições)
    this._assinantes = new Set();
    this._seq = 0;
  }

  log(categoria, nivel, mensagem, dados) {
    const t = this.now();
    const chave = `${categoria}|${nivel}|${mensagem}`;
    const anterior = this._recentes.get(chave);
    if (anterior && anterior.viva && t - anterior.ultimo <= this.dedupeWindowMs) {
      anterior.count++;
      anterior.ultimo = t;
      this._avisar(anterior);
      return anterior;
    }
    const entrada = { id: ++this._seq, time: t, ultimo: t, category: categoria, level: nivel, message: mensagem, data: dados, count: 1, viva: true };
    this.entries.push(entrada);
    this._recentes.set(chave, entrada);
    while (this.entries.length > this.maxEntries) {
      const velha = this.entries.shift();
      velha.viva = false;
      const k = `${velha.category}|${velha.level}|${velha.message}`;
      if (this._recentes.get(k) === velha) this._recentes.delete(k);
    }
    if (this.mirrorToConsole || nivel === 'error') {
      const fn = nivel === 'error' ? console.error : nivel === 'warn' ? console.warn : console.log;
      fn(`[${categoria}] ${mensagem}`, dados ?? '');
    }
    this._avisar(entrada);
    return entrada;
  }

  debug(cat, msg, dados) { return this.log(cat, 'debug', msg, dados); }
  info(cat, msg, dados) { return this.log(cat, 'info', msg, dados); }
  warn(cat, msg, dados) { return this.log(cat, 'warn', msg, dados); }
  error(cat, msg, dados) { return this.log(cat, 'error', msg, dados); }

  /** Filtra por categoria e nível mínimo. */
  query({ category = null, minLevel = 'debug' } = {}) {
    const min = LOG_LEVELS[minLevel] ?? 0;
    return this.entries.filter((e) => (!category || e.category === category) && LOG_LEVELS[e.level] >= min);
  }

  /** Último erro registrado (ou null). */
  lastError(categoria = null) {
    for (let i = this.entries.length - 1; i >= 0; i--) {
      const e = this.entries[i];
      if (e.level === 'error' && (!categoria || e.category === categoria)) return e;
    }
    return null;
  }

  clear() { this.entries.length = 0; this._recentes.clear(); this._avisar(null); }
  subscribe(fn) { this._assinantes.add(fn); return () => this._assinantes.delete(fn); }
  _avisar(entrada) { for (const fn of this._assinantes) fn(entrada); }

  toText(lista = this.entries) {
    return lista.map((e) => {
      const hora = new Date(e.time).toISOString().slice(11, 19);
      return `${hora} [${e.category}] ${e.level.toUpperCase()} ${e.message}${e.count > 1 ? ` ×${e.count}` : ''}`;
    }).join('\n');
  }
}
