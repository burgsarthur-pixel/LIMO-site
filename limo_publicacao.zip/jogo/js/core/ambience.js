// =====================================================================
// AMBIENTAÇÃO VIVA (sem DOM, testável): batimento do deus + gotejamento do teto.
//  - pulse: 0..1, "lub-dub" a cada ~3,2 s (Blasphemous/Hollow Knight: o mundo respira junto com você)
//  - gotas pingam do teto de verdade (acham o teto e o chão de cada coluna da sala) e espirram ao cair
// =====================================================================
/** Duração de uma respiração completa do Deus (s). Bem mais lenta que o batimento (3,2 s): dá escala ao corpo. */
export const CICLO_RESPIRACAO = 9.5;

export class Ambience {
  constructor() { this.t = 0; this.pulse = 0; this.respira = 0; this.goteiras = []; this.drops = []; this.splashes = []; this._espera = 0; this.onSplash = null; }   // onSplash(x,y): gancho do clima por bioma (v1.38.0)

  /** Calcula, por coluna, onde fica a ponta do teto e onde a gota vai cair. */
  prepare(map) {
    this.goteiras = []; this.drops = []; this.splashes = [];
    const sol = map?.layers?.solid; if (!sol) return;
    const { width: W, height: H, tileSize: ts } = map;
    for (let x = 1; x < W - 1; x++) {
      let y = 0; while (y < H && sol[y * W + x] !== 0) y++;               // atravessa o teto sólido
      if (y === 0 || y >= H - 2) continue;
      let y1 = y + 1; while (y1 < H && sol[y1 * W + x] === 0) y1++;        // primeiro sólido abaixo = chão
      if (y1 < H && y1 - y >= 2) this.goteiras.push({ x: x * ts + ts / 2, y0: y * ts, y1: y1 * ts });
    }
  }

  update(dt, camX = 0, viewW = 320) {
    this.t += dt;
    this.respira = 0.5 - 0.5 * Math.cos((this.t / CICLO_RESPIRACAO) * Math.PI * 2);   // 0..1: o corpo inspira e expira devagar (v1.33.0)
    const p = this.t % 3.2;                                                  // lub (0 s) ... dub (0,3 s)
    this.pulse = Math.max(Math.exp(-p * 9), p > 0.3 ? 0.65 * Math.exp(-(p - 0.3) * 9) : 0);
    this._espera -= dt;
    if (this._espera <= 0 && this.drops.length < 6) {
      this._espera = 0.5 + Math.random() * 1.3;
      const vis = this.goteiras.filter((g) => g.x > camX - 24 && g.x < camX + viewW + 24);
      if (vis.length) { const g = vis[Math.floor(Math.random() * vis.length)]; this.drops.push({ x: g.x + (Math.random() * 6 - 3), y: g.y0, vy: 0, y1: g.y1 }); }
    }
    for (let i = this.drops.length - 1; i >= 0; i--) {
      const d = this.drops[i]; d.vy += 420 * dt; d.y += d.vy * dt;
      if (d.y >= d.y1) {
        this.onSplash?.(d.x, d.y1);
        for (let k = 0; k < 3; k++) this.splashes.push({ x: d.x, y: d.y1 - 1, vx: (Math.random() - 0.5) * 40, vy: -20 - Math.random() * 25, vida: 0.35 });
        this.drops.splice(i, 1);
      }
    }
    for (let i = this.splashes.length - 1; i >= 0; i--) {
      const s = this.splashes[i]; s.x += s.vx * dt; s.y += s.vy * dt; s.vy += 200 * dt; s.vida -= dt;
      if (s.vida <= 0) this.splashes.splice(i, 1);
    }
  }
}
