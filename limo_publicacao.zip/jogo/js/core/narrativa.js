// Executor da narrativa de Raízes (v1.50.0). Lógica pura (sem canvas): decide QUANDO um acontecimento de js/world/narrativa-dados.js vale e entrega
// `apresenta` ao Game, que sabe mostrar (balão, toast, clarão de memória, pulso). Cada acontecimento acontece uma vez (`hist:<id>` em descobertas).
import { BEATS, RASTROS, CHAVE_BEAT, SEG_BALAO } from '../world/narrativa-dados.js';
import { cumpre } from '../world/npc-dados.js';

export class Narrativa {
  /** @param o {progress, salaId, ts, apresentar(apresenta, beat), beats?} Sem `progress` (editor/expedição/sandbox) nada acontece. */
  constructor({ progress = null, salaId, ts = 16, apresentar = () => {}, beats = BEATS }) {
    this.progress = progress; this.ts = ts; this.apresentar = apresentar;
    this.beats = progress ? beats.filter((b) => b.sala === salaId && !progress.descobertas.has(CHAVE_BEAT(b.id))) : [];
    this._espera = new Map(); this.disparados = [];
  }

  get ativa() { return this.beats.length > 0; }

  /** Todo quadro (fora de pausa e de cena). `limo` = centro do Limo em pixels. */
  atualizar(dt, limo) {
    if (!this.beats.length) return;
    for (const b of this.beats.slice()) {
      const q = b.quando || {}; if (q.fase) continue;
      if (!cumpre(b.requer, this.progress)) { this._espera.delete(b.id); continue; }
      if (q.perto) {
        const d = Math.hypot(limo.x / this.ts - q.perto.x, limo.y / this.ts - q.perto.y);
        if (d > q.perto.raio) { this._espera.delete(b.id); continue; }
      }
      const t = (this._espera.get(b.id) || 0) + dt; this._espera.set(b.id, t);
      if (t >= (b.atraso || 0)) this._disparar(b);
    }
  }

  /** Eventos do jogo que não são estado (hoje: vida do chefe). `fase`: { chefe, frac } = fração atual de vida. */
  evento(tipo, dados) {
    if (tipo !== 'fase') return;
    for (const b of this.beats.slice()) {
      const f = b.quando?.fase; if (!f || f.chefe !== dados.chefe || dados.frac > f.frac) continue;
      if (cumpre(b.requer, this.progress)) this._disparar(b);
    }
  }

  _disparar(b) {
    if (!this.beats.includes(b)) return;
    // o grupo apresenta só o primeiro que vale; os outros somem desta sala (sem marcar: não aconteceram)
    this.beats = this.beats.filter((x) => x !== b && !(b.grupo && x.grupo === b.grupo));
    this.progress.descobertas.add(CHAVE_BEAT(b.id)); this.disparados.push(b.id);
    this.apresentar(b.apresenta || {}, b);
  }
}

/** Linha de balões: cada fala entra `dur` segundos depois da anterior. Devolve [{quem, texto, espera, dur}]. */
export function agendarBalao(balao) {
  const dur = balao.dur || SEG_BALAO; const ini = balao.espera || 0; return (balao.falas || []).map((texto, i) => ({ quem: balao.quem, texto, espera: ini + i * dur, t: 0, dur }));
}

/**
 * Pontos (em pixels) de um rastro de fios que segue o chão. `solido(x,y)` em tiles. Para cada coluna: a partir de y0 sobe até achar ar e desce até achar chão.
 * Só guarda os pontos onde a altura muda (e as pontas), então o fio vira uma linha de degraus costurados.
 */
export function tracarRastro(spec, solido, ts = 16, alturaMax = 64) {
  const pts = [];
  for (const { x0, x1, y0 } of spec.trechos) {
    let ant = null;
    for (let x = x0; x <= x1; x++) {
      let y = y0; let n = 0; while (solido(x, y) && n++ < alturaMax) y--; if (n >= alturaMax) { ant = null; continue; }
      n = 0; while (!solido(x, y + 1) && n++ < alturaMax) y++; if (n >= alturaMax) { ant = null; continue; }
      if (ant !== y) { if (ant !== null) pts.push([x * ts, (ant + 1) * ts - 1.5]); pts.push([x * ts, (y + 1) * ts - 1.5]); ant = y; }
      if (x === x1) pts.push([(x + 1) * ts, (y + 1) * ts - 1.5]);
    }
  }
  return pts;
}
export const rastrosDaSala = (salaId) => RASTROS.filter((r) => r.sala === salaId);
