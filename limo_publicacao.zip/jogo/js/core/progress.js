// =====================================================================
// PROGRESSO DO JOGADOR: o que muda durante a campanha e precisa ser SALVO.
// (Posição exata NÃO é salva: ao continuar, o jogador volta ao último checkpoint.)
// =====================================================================
import { normalizeAbilities } from '../entities/abilities.js';
import { ENCAIXES_BASE, geneDe, geneImplementado, encaixesUsados } from '../entities/genes.js';

export const SAVE_FORMAT = 'limo-save';
export const SAVE_VERSION = 2;
export const chaveItem = (sala, id) => `${sala}:${id}`;

export class Progress {
  constructor(habilidadesIniciais = {}) {
    this.abilities = normalizeAbilities(habilidadesIniciais);  // {investida, saltoElastico, membrana}: true/false
    this.collected = new Set();       // itens permanentes já pegos ("sala:id"): mutações
    this.visited = new Set();         // salas visitadas (mapa de exploração)
    this.blockedFound = new Set();    // passagens seladas que o jogador já descobriu ("sala:passagem")
    this.opened = new Set();          // passagens que estavam seladas e já foram atravessadas
    this.checkpoint = null;           // {sala, id} do último checkpoint
    this.bancos = new Set();          // checkpoints já descobertos ("sala:id"): destinos da viagem rápida
    this.bossesDefeated = [];         // reservado para a Etapa 5
    this.descobertas = new Set();     // v1.39.0: catálogo (criaturas vistas/observadas, acontecimentos). Campo opcional no save: sem migração
    this.final = null;                // final escolhido (vigilia|despertar|fusao)
    this.essencia = 0;                // orbes guardados quando a vida está cheia: pagam a cura das Feridas do Deus
    this.genes = new Set();           // genes já encontrados (ids de entities/genes.js)
    this.genesEquipados = [];         // genes equipados (só se troca descansando num Casulo de Repouso)
    this.encaixesExtra = 0;           // Bulbos de Encaixe já colhidos (cada um = +1 encaixe de gene, permanente)
    this.tempoJogo = 0;               // segundos de jogo na campanha
    this.mortes = 0;                  // vezes que o Limo caiu
  }

  /** Encaixes disponíveis (cresce no futuro com melhorias). */
  get encaixes() { return ENCAIXES_BASE + Math.max(0, this.encaixesExtra | 0); }
  get encaixesEmUso() { return encaixesUsados(this.genesEquipados); }

  obterGene(id) { if (!geneImplementado(id) || this.genes.has(id)) return false; this.genes.add(id); return true; }

  /** Regra de equipar: precisa ter o gene, não estar equipado e caber nos encaixes livres. */
  podeEquipar(id) {
    const g = geneDe(id);
    if (!g || !g.implementado) return { ok: false, motivo: 'Espaço ainda vazio.' };
    if (!this.genes.has(id)) return { ok: false, motivo: 'Gene ainda não encontrado.' };
    if (this.genesEquipados.includes(id)) return { ok: false, motivo: 'Já equipado.' };
    if (this.encaixesEmUso + g.custo > this.encaixes) return { ok: false, motivo: 'Sem encaixes livres.' };
    return { ok: true, motivo: '' };
  }
  equiparGene(id) { const r = this.podeEquipar(id); if (r.ok) this.genesEquipados.push(id); return r; }
  desequiparGene(id) { const i = this.genesEquipados.indexOf(id); if (i < 0) return false; this.genesEquipados.splice(i, 1); return true; }
  /** Equipa se estiver desequipado, senão desequipa. Devolve {ok, equipado, motivo}. */
  alternarGene(id) {
    if (this.genesEquipados.includes(id)) { this.desequiparGene(id); return { ok: true, equipado: false, motivo: '' }; }
    const r = this.equiparGene(id); return { ok: r.ok, equipado: r.ok, motivo: r.motivo };
  }

  static novo(config) { return new Progress(config.abilities.initial); }

  clone() {
    const p = new Progress(this.abilities);
    p.collected = new Set(this.collected); p.visited = new Set(this.visited);
    p.blockedFound = new Set(this.blockedFound); p.opened = new Set(this.opened);
    p.checkpoint = this.checkpoint ? { ...this.checkpoint } : null; p.bossesDefeated = [...this.bossesDefeated]; p.essencia = this.essencia; p.bancos = new Set(this.bancos); p.final = this.final;
    p.descobertas = new Set(this.descobertas); p.genes = new Set(this.genes); p.genesEquipados = [...this.genesEquipados]; p.encaixesExtra = this.encaixesExtra; p.tempoJogo = this.tempoJogo; p.mortes = this.mortes;
    return p;
  }

  toSave() {
    return {
      formato: SAVE_FORMAT, versao: SAVE_VERSION, salvoEm: new Date().toISOString(),
      checkpoint: this.checkpoint ? { ...this.checkpoint } : null,
      habilidades: { ...this.abilities },
      coletados: [...this.collected].sort(), visitadas: [...this.visited].sort(),
      bloqueiosDescobertos: [...this.blockedFound].sort(), passagensAbertas: [...this.opened].sort(),
      chefesDerrotados: [...this.bossesDefeated], descobertas: [...this.descobertas].sort(), essencia: this.essencia, bancos: [...this.bancos].sort(), final: this.final || null,
      genes: { obtidos: [...this.genes].sort(), equipados: [...this.genesEquipados] },
      encaixesExtra: this.encaixesExtra | 0, estatisticas: { tempo: Math.round(this.tempoJogo), mortes: this.mortes | 0 },
    };
  }

  /** Restaura a partir de um salvamento JÁ VALIDADO (ver validateSave). */
  static fromSave(d) {
    const p = new Progress(d.habilidades);
    p.collected = new Set(d.coletados || []); p.visited = new Set(d.visitadas || []);
    p.blockedFound = new Set(d.bloqueiosDescobertos || []); p.opened = new Set(d.passagensAbertas || []);
    p.checkpoint = d.checkpoint ? { sala: d.checkpoint.sala, id: d.checkpoint.id } : null; p.bossesDefeated = [...(d.chefesDerrotados || [])]; p.descobertas = new Set((d.descobertas || []).filter((x) => typeof x === 'string')); p.essencia = Math.max(0, Math.floor(Number(d.essencia) || 0));
    p.final = typeof d.final === 'string' ? d.final : null;
    p.bancos = new Set((Array.isArray(d.bancos) ? d.bancos : []).filter((k) => typeof k === 'string'));
    p.encaixesExtra = Number.isInteger(d.encaixesExtra) && d.encaixesExtra > 0 ? Math.min(d.encaixesExtra, 20) : 0;   // antes dos genes: define quantos cabem
    const est = d.estatisticas && typeof d.estatisticas === 'object' ? d.estatisticas : {};
    p.tempoJogo = Number.isFinite(est.tempo) && est.tempo > 0 ? est.tempo : 0; p.mortes = Number.isInteger(est.mortes) && est.mortes > 0 ? est.mortes : 0;
    const g = d.genes && typeof d.genes === 'object' ? d.genes : {};   // saves antigos não têm genes
    p.genes = new Set((Array.isArray(g.obtidos) ? g.obtidos : []).filter(geneImplementado));
    for (const id of Array.isArray(g.equipados) ? g.equipados : []) if (p.genes.has(id) && !p.genesEquipados.includes(id) && p.podeEquipar(id).ok) p.genesEquipados.push(id);
    if (p.checkpoint) p.bancos.add(`${p.checkpoint.sala}:${p.checkpoint.id}`);   // saves antigos: o último checkpoint já conta como descoberto
    return p;
  }
}
