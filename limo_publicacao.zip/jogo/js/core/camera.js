// =====================================================================
// CÂMERA: segue o jogador suavemente, aplica Screen Shake e nunca mostra além da sala.
// Se a sala for menor que a tela, ela fica centralizada.
// =====================================================================


import { clamp as limitar } from './math.js';

export class Camera {
  constructor(config) {
    this.config = config;
    this.x = 0;
    this.y = 0;
    this.shakeTimer = 0;
    this.shakeIntensity = 0;
  }

  get viewWidth() { return this.config.render.internalWidth; }
  get viewHeight() { return this.config.render.internalHeight; }

  /** Dispara um tremor de ecrã com intensidade e duração (em segundos). */
  shake(intensidade = 4, duracao = 0.2) {
    this.shakeIntensity = intensidade;
    this.shakeTimer = Math.max(this.shakeTimer, duracao);
  }

  clampToRoom(larguraSala, alturaSala) {
    this.x = larguraSala <= this.viewWidth ? (larguraSala - this.viewWidth) / 2 : limitar(this.x, 0, larguraSala - this.viewWidth);
    this.y = alturaSala <= this.viewHeight ? (alturaSala - this.viewHeight) / 2 : limitar(this.y, 0, alturaSala - this.viewHeight);
  }

  /** Posiciona a câmera de uma vez (usado ao entrar numa sala ou teleportar). */
  snapTo(alvoX, alvoY, larguraSala, alturaSala) {
    this.x = alvoX - this.viewWidth / 2;
    this.y = alvoY - this.viewHeight / 2;
    this.clampToRoom(larguraSala, alturaSala);
  }

  /** Suavização independente do FPS e atualização do Screen Shake. */
  follow(alvoX, alvoY, dt, larguraSala, alturaSala) {
    const a = 1 - Math.exp(-this.config.camera.followSpeed * dt);
    this.x += (alvoX - this.viewWidth / 2 - this.x) * a;
    this.y += (alvoY - this.viewHeight / 2 - this.y) * a;

    // Atualiza o temporizador do Screen Shake
    if (this.shakeTimer > 0) {
      this.shakeTimer -= dt;
    }

    // Mantém a câmara nos limites da sala
    this.clampToRoom(larguraSala, alturaSala);
  }

  /** Retorna as coordenadas finais da câmara com o desvio de Screen Shake aplicado (sem alterar a posição base de seguimento). */
  getRenderPosition() {
    let offsetX = 0;
    let offsetY = 0;

    if (this.shakeTimer > 0) {
      // Gera um desvio aleatório proporcional à intensidade atual
      offsetX = (Math.random() * 2 - 1) * this.shakeIntensity;
      offsetY = (Math.random() * 2 - 1) * this.shakeIntensity;
    }

    return {
      x: Math.round(this.x + offsetX),
      y: Math.round(this.y + offsetY)
    };
  }

  /** Faixa em que o CENTRO da câmera pode ficar (usado para desenhar os limites no debug). */
  centerRange(larguraSala, alturaSala) {
    const hw = this.viewWidth / 2; const hh = this.viewHeight / 2;
    const pequenaL = larguraSala <= this.viewWidth; const pequenaA = alturaSala <= this.viewHeight;
    return {
      minX: pequenaL ? larguraSala / 2 : hw, maxX: pequenaL ? larguraSala / 2 : larguraSala - hw,
      minY: pequenaA ? alturaSala / 2 : hh, maxY: pequenaA ? alturaSala / 2 : alturaSala - hh,
    };
  }
}
