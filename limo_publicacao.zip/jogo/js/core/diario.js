// =====================================================================
// CATÁLOGO DE DESCOBERTAS (v1.39.0) — lógica pura, sem DOM. Revela o organismo aos poucos.
// O que é GUARDADO (progress.descobertas, só textos): conhecimento sobre criaturas e acontecimentos.
//   cri:<especie>:visto | :derrotado | :h:<hábito>   (hábito = comportamento OBSERVADO: descansa, foge, caça...)
//   evt:<id>                                          (mudanças do mundo, segredos, murais...)
// O que é DERIVADO do progresso que já existia (nada novo no save): regiões (visited), mutações (abilities/genes),
// chefes (bossesDefeated), segredos e murais (collected). Cada entrada tem 3 estados: oculta (??? + dica), vista, completa.
// =====================================================================
import { ABILITIES } from '../entities/abilities.js';
import { GENES } from '../entities/genes.js';
import { REVELACOES } from './story.js';
import { CHEFES } from '../ui/world-map.js';
import { EVOLUCAO } from '../world/evolucao.js';
import { SEGREDOS, MURAIS } from '../world/vida-dados.js';

export const CATEGORIAS = Object.freeze([
  { id: 'criaturas', nome: 'CRIATURAS' }, { id: 'regioes', nome: 'REGIÕES' }, { id: 'mutacoes', nome: 'MUTAÇÕES' },
  { id: 'chefes', nome: 'CHEFES' }, { id: 'notas', nome: 'NOTAS' },
]);

/** Espécies comuns. `habitos`: o que só se aprende OBSERVANDO (a chave é o modo reportado pelo cérebro). */
export const CRIATURAS = Object.freeze({
  crawler: {
    nome: 'Rastejante', papel: 'Presa',
    visto: 'Uma célula baixa que arrasta o corpo pelo chão. Ela patrulha e avisa antes de dar o bote.',
    derrotado: 'O bote é anunciado: um agachar curto. Quem desvia a deixa exposta.',
    habitos: { descansa: 'Para e se encolhe de tempos em tempos. Acorda se você chega perto ou faz barulho.', foge: 'Quando está ferida ou há um Saltador perto, ela foge.', acuado: 'Sem saída, ela encara e luta.' },
    dica: 'Vive nas Raízes.',
  },
  leaper: {
    nome: 'Saltador', papel: 'Predador',
    visto: 'Esguio e nervoso. Anuncia o salto dobrando o corpo.',
    derrotado: 'O salto é longo mas previsível; o pouso o deixa vulnerável.',
    habitos: { caca: 'Caça Rastejantes e os prefere a você, quando estão mais perto.', saciado: 'Depois de caçar, fica saciado e dorme sem se importar com nada.', espreita: 'Se você fica parado, ele se aproxima devagar, espreitando.', descansa: 'Também descansa entre as caçadas.' },
    dica: 'Aparece em todos os biomas.',
  },
  armored: {
    nome: 'Couraçado', papel: 'Sentinela territorial',
    visto: 'Blindado e lento. Parece guardar o lugar onde está.',
    derrotado: 'A escudada é anunciada pelo escudo erguido. Quebre a guarda com investida ou golpe pesado.',
    habitos: { alerta: 'Antes de atacar, encara e rosna: é o aviso do território.', defende: 'Dentro da sua área, ele persegue. Fora, desiste e volta para casa.', expulsa: 'Expulsa Saltadores que invadem seu território.', descansa: 'Dorme em casa. Acorda quando você entra no aviso.' },
    dica: 'Guarda áreas do Jardim e do Núcleo.',
  },
  flyer: {
    nome: 'Esporo', papel: 'Voador tímido',
    visto: 'Flutua em volta do próprio canto. Mergulha quando se sente ameaçado.',
    derrotado: 'O mergulho é anunciado por uma subida. Depois dele, o Esporo fica ofegante.',
    habitos: { arisco: 'Não persegue quem corre.', curioso: 'Se aproxima devagar de quem fica quieto.', foge: 'Quando machucado, foge para o alto.', descansa: 'Paira parado em casa quando ninguém olha.', incomodado: 'Se você chega perto demais ou o perturba, ele ataca.' },
    dica: 'Voa em todas as regiões.',
  },
});

export const BIOMAS = Object.freeze({
  raizes: { nome: 'Raízes', texto: 'O corpo mais antigo do Deus. Tudo aqui cresce para dentro, buscando calor.', curiosidade: 'As raízes balançam sozinhas, no ritmo lento do sono do Deus.' },
  jardim: { nome: 'Jardim das Lanternas', texto: 'Onde o Deus sonha em verde. As lanternas acendem com quem passa.', curiosidade: 'Cada lanterna é uma célula que decidiu brilhar em vez de pensar.' },
  nucleo: { nome: 'Núcleo', texto: 'O pulso do organismo. Tudo aqui responde ao coração.', curiosidade: 'A luz do Núcleo bate com o coração: quando ele falha, a sala escurece.' },
});

/** Curiosidades sobre o organismo: aparecem quando a condição é cumprida (e dão motivo para voltar a procurar). */
export const CURIOSIDADES = Object.freeze([
  { id: 'respira', titulo: 'O Deus respira', texto: 'O ar das cavernas sobe e desce. Não é vento: é a respiração do Deus, lenta, de quem sonha.', dica: 'Explore mais salas.', req: (c) => c.visitadas >= 3 },
  { id: 'celulas', titulo: 'Células lembradas', texto: 'As criaturas não nascem: são células que lembram ter sido livres.', dica: 'Encontre dois tipos de criatura.', req: (c) => c.especiesVistas >= 2 },
  { id: 'cadeia', titulo: 'O organismo se come', texto: 'Saltadores caçam Rastejantes. O Deus se alimenta de si mesmo, devagar.', dica: 'Observe um Saltador caçar.', req: (c) => c.tem('cri:leaper:h:caca') },
  { id: 'territorio', titulo: 'O que o Deus guarda', texto: 'Couraçados guardam áreas pequenas com ferocidade. Quanto mais temida a perda, mais forte a guarda.', dica: 'Aproxime-se de um Couraçado sem entrar na área dele.', req: (c) => c.tem('cri:armored:h:alerta') },
  { id: 'timidez', titulo: 'Esporos não são soldados', texto: 'Os Esporos só atacam quando se sentem encurralados. O resto do tempo, fogem do barulho.', dica: 'Observe um Esporo fugir ou ficar curioso.', req: (c) => c.tem('cri:flyer:h:foge') || c.tem('cri:flyer:h:curioso') || c.tem('cri:flyer:h:arisco') },
  { id: 'sono', titulo: 'Quem dorme não sonha', texto: 'As criaturas que descansam não perdem a vida: ela só espera.', dica: 'Veja uma criatura descansar.', req: (c) => c.habitosComDescanso >= 1 },
  { id: 'tecedor', titulo: 'Quem tece sozinho', texto: 'Fio Solto tece sem plateia, num ritmo só dele. Parece lembrar de algo a cada laço.', dica: 'Veja Fio Solto trabalhar.', req: (c) => c.tem('npc:fio_solto:h:trabalha') },
  { id: 'repouso_fio', titulo: 'Descanso de quem vigia', texto: 'Mesmo Fio Solto descansa: fecha os olhos e deixa os fios caírem. O corpo do Deus ensina a esperar.', dica: 'Veja Fio Solto descansar.', req: (c) => c.tem('npc:fio_solto:h:descansa') },
  { id: 'medo_fio', titulo: 'Medo de quem tece', texto: 'Criaturas acordadas encolhem Fio Solto. Ele não luta: espera a sombra passar.', dica: 'Veja Fio Solto se assustar com uma criatura.', req: (c) => c.tem('npc:fio_solto:h:assustado') },
  { id: 'lanternas', titulo: 'Lanternas', texto: 'No Jardim, o brilho é uma forma de pensar.', dica: 'Visite o Jardim.', req: (c) => c.biomas.has('jardim') },
  { id: 'pulso', titulo: 'O pulso', texto: 'No Núcleo, as luzes batem com o coração do Deus. Aprenda o ritmo e você aprende a ir mais fundo.', dica: 'Visite o Núcleo.', req: (c) => c.biomas.has('nucleo') },
  { id: 'murais', titulo: 'Quem pintou?', texto: 'Alguém contou a história do Deus nas paredes, em pictogramas. Procure onde a luz alcança.', dica: 'Descubra um mural.', req: (c) => c.murais >= 1 },
  { id: 'rastro', titulo: 'O rastro', texto: 'Quando o corpo do Deus se agita, as câmaras escondidas vazam fiapos de luz. É a hora de seguir o rastro até a rocha que respira.', dica: 'Fique perto de uma câmara escondida durante um evento ambiental.', req: (c) => c.tem('evt:rastro') },
  { id: 'cavidades', titulo: 'Cavidades', texto: 'Há câmaras escondidas atrás da rocha viva. Algumas cedem ao toque; outras, ao golpe.', dica: 'Encontre uma câmara secreta.', req: (c) => c.segredos >= 1 },
]);

export const chaveCriatura = (kind, sufixo) => `cri:${kind}:${sufixo}`;

/** Marca algo como descoberto. Devolve {nova, titulo, texto} — o jogo mostra um aviso curto quando `nova`. */
export function registrar(progress, chave) {
  if (!progress) return { nova: false };
  progress.descobertas ||= new Set();
  if (progress.descobertas.has(chave)) return { nova: false };
  progress.descobertas.add(chave);
  return { nova: true, ...rotuloDe(chave) };
}

function rotuloDe(chave) {
  const [tipo, id, sub, hab] = chave.split(':');
  if (tipo === 'cri') {
    const c = CRIATURAS[id]; if (!c) return { titulo: chave };
    if (sub === 'visto') return { titulo: c.nome, texto: 'registrado no catálogo' };
    if (sub === 'derrotado') return { titulo: c.nome, texto: 'ponto fraco anotado' };
    if (sub === 'h') return { titulo: c.nome, texto: `hábito novo: ${hab}` };
  }
  if (tipo === 'evt') { const ev = evento(id); return { titulo: ev?.titulo || id, texto: 'acontecimento registrado' }; }
  return { titulo: chave };
}

const evento = (id) => Object.values(EVOLUCAO).find((v) => v.id === id) || null;

/** Quanto o jogador já sabe: contexto para as condições e para os contadores. */
function contexto(progress, world) {
  const d = progress?.descobertas || new Set(); const visitadas = progress?.visited || new Set(); const biomas = new Set();
  for (const s of visitadas) { const b = world?.get?.(s)?.biome; if (b) biomas.add(b); }
  let murais = 0; let segredos = 0; for (const k of progress?.collected || []) { if (k.includes(':mural_')) murais++; else if (k.includes(':segredo_')) segredos++; }
  const especiesVistas = Object.keys(CRIATURAS).filter((k) => d.has(chaveCriatura(k, 'visto'))).length;
  const habitosComDescanso = Object.keys(CRIATURAS).filter((k) => d.has(chaveCriatura(k, 'h:descansa'))).length;
  return { tem: (k) => d.has(k), visitadas: visitadas.size, biomas, murais, segredos, especiesVistas, habitosComDescanso };
}

/** Monta as 5 abas. Cada item: {id, titulo, estado: 'oculto'|'visto'|'completo', sub, linhas[], dica, novo?}. Sem DOM. */
export function construirCatalogo(progress, world) {
  const d = progress?.descobertas || new Set(); const ctx = contexto(progress, world);
  const abas = {};

  abas.criaturas = Object.entries(CRIATURAS).map(([kind, c]) => {
    const visto = d.has(chaveCriatura(kind, 'visto')); const derrotado = d.has(chaveCriatura(kind, 'derrotado'));
    const hab = Object.keys(c.habitos); const sabidos = hab.filter((h) => d.has(chaveCriatura(kind, `h:${h}`)));
    if (!visto) return { id: kind, titulo: '???', estado: 'oculto', sub: '', linhas: ['Criatura ainda não encontrada.'], dica: c.dica };
    const linhas = [c.visto];
    if (derrotado) linhas.push('— Combate —', c.derrotado); else linhas.push('— Combate —', 'Derrote uma para descobrir o ponto fraco.');
    linhas.push('— Hábitos —');
    for (const h of hab) linhas.push(d.has(chaveCriatura(kind, `h:${h}`)) ? `• ${c.habitos[h]}` : '• ???  (observe-a)');
    const completo = derrotado && sabidos.length === hab.length;
    return { id: kind, titulo: c.nome, estado: completo ? 'completo' : 'visto', sub: `${c.papel} · hábitos ${sabidos.length}/${hab.length}`, linhas };
  });

  const salas = world?.ids?.() || [];
  abas.regioes = Object.entries(BIOMAS).map(([b, info]) => {
    const dele = salas.filter((s) => world.get(s)?.biome === b); const vis = dele.filter((s) => progress?.visited?.has(s));
    if (!vis.length) return { id: b, titulo: '???', estado: 'oculto', sub: '', linhas: ['Região ainda não visitada.'], dica: b === 'raizes' ? 'Comece pelo início.' : 'Avance no corpo do Deus.' };
    const linhas = [info.texto, `Salas: ${vis.length}/${dele.length}`, '— Já visitadas —', ...vis.map((s) => `• ${world.get(s).name || s}`)];
    if (vis.length < dele.length) linhas.push(`• ??? (+${dele.length - vis.length})`);
    const feitos = progress?.bossesDefeated || [];
    return { id: b, titulo: info.nome, estado: vis.length === dele.length ? 'completo' : 'visto', sub: `${vis.length}/${dele.length} salas`, linhas, _curiosidade: info.curiosidade, _feitos: feitos.length };
  });

  const ab = Object.values(ABILITIES).filter((a) => a.implementada);
  const mut = ab.map((a) => progress?.abilities?.[a.id]
    ? { id: a.id, titulo: a.nome, estado: 'completo', sub: a.curto || '', linhas: [a.descricao, '', `Uso: ${a.uso}`, '', ...(a.frases || [])] }
    : { id: a.id, titulo: '???', estado: 'oculto', sub: '', linhas: ['Mutação ainda não encontrada.'], dica: 'Procure em salas guardadas.' });
  const gn = GENES.filter((g) => g.implementado).map((g) => progress?.genes?.has(g.id)
    ? { id: g.id, titulo: g.nome, estado: 'completo', sub: `Gene · custo ${g.custo}`, linhas: [g.desc, '', 'Equipe em um Casulo de Repouso.'] }
    : { id: g.id, titulo: '???', estado: 'oculto', sub: 'Gene', linhas: ['Gene ainda não encontrado.'], dica: 'Explore para encontrá-lo.' });
  abas.mutacoes = [...mut, ...gn];

  const feitos = progress?.bossesDefeated || [];
  abas.chefes = CHEFES.filter((c) => !world || world.has?.(c.sala) !== false).map((c) => {
    const derrotado = feitos.includes(c.id); const visto = derrotado || progress?.visited?.has(c.sala);
    if (!visto) return { id: c.id, titulo: '???', estado: 'oculto', sub: '', linhas: ['Chefe ainda não encontrado.'], dica: 'Alguma sala guarda um chefe.' };
    const rev = REVELACOES[c.id]; const linhas = [c.dica];
    if (derrotado && rev) linhas.push('', ...rev.linhas, '', `“${rev.frase}”`); else linhas.push('', 'Ainda de pé.');
    const mudou = derrotado ? Object.values(EVOLUCAO).find((v) => v.chefe === c.id) : null; if (mudou) linhas.push('', `Efeito no mundo: ${mudou.titulo}.`);
    return { id: c.id, titulo: c.nome, estado: derrotado ? 'completo' : 'visto', sub: derrotado ? 'Derrotado' : 'Encontrado', linhas };
  });

  const notas = [];
  for (const ev of Object.values(EVOLUCAO)) {
    const k = `evt:${ev.id}`; const tem = d.has(k);
    notas.push(tem ? { id: k, titulo: ev.titulo, estado: 'completo', sub: 'Acontecimento', linhas: [ev.texto, '', ...ev.mudancas.map((m) => `• ${m.descricao}`)] }
      : (feitos.includes(ev.chefe) ? { id: k, titulo: ev.titulo, estado: 'visto', sub: 'Algo mudou', linhas: ['Algo mudou no corpo do Deus. Volte às regiões já visitadas e procure.'], dica: ev.dicaBusca }
        : { id: k, titulo: '???', estado: 'oculto', sub: '', linhas: ['Ainda não aconteceu.'], dica: 'Derrote um chefe.' }));
  }
  const segs = Object.values(SEGREDOS).flat().length; const murTotal = MURAIS.length;
  notas.push({ id: 'seg', titulo: 'Câmaras escondidas', estado: ctx.segredos ? (ctx.segredos >= segs ? 'completo' : 'visto') : 'oculto', sub: ctx.segredos ? `${ctx.segredos}/${segs}` : '', linhas: ctx.segredos ? [`Você achou ${ctx.segredos} de ${segs}.`, 'Algumas cedem ao toque; outras, ao golpe.'] : ['Nenhuma achada ainda.'], dica: 'Desconfie de paredes que respiram.' });
  notas.push({ id: 'mur', titulo: 'Murais do Deus', estado: ctx.murais ? (ctx.murais >= murTotal ? 'completo' : 'visto') : 'oculto', sub: ctx.murais ? `${ctx.murais}/${murTotal}` : '', linhas: ctx.murais ? [`Você viu ${ctx.murais} de ${murTotal}.`, 'Eles contam a história do Deus em ordem.'] : ['Nenhum visto ainda.'], dica: 'A luz do Limo revela pinturas.' });
  for (const c of CURIOSIDADES) notas.push(c.req(ctx) ? { id: `cur:${c.id}`, titulo: c.titulo, estado: 'completo', sub: 'Curiosidade', linhas: [c.texto] } : { id: `cur:${c.id}`, titulo: '???', estado: 'oculto', sub: '', linhas: ['Uma curiosidade sobre o organismo.'], dica: c.dica });
  for (const [b, info] of Object.entries(BIOMAS)) if (ctx.biomas.has(b)) notas.push({ id: `bio:${b}`, titulo: info.nome, estado: 'completo', sub: 'Curiosidade', linhas: [info.curiosidade] });
  abas.notas = notas;
  return abas;
}

/** Contagens para a barra de progresso: {total, achados, porAba:{id:{total,achados}}, percent}. */
export function resumoDoCatalogo(progress, world) {
  const abas = construirCatalogo(progress, world); let total = 0; let achados = 0; const porAba = {};
  for (const [id, itens] of Object.entries(abas)) { const t = itens.length; const a = itens.filter((i) => i.estado !== 'oculto').length; porAba[id] = { total: t, achados: a }; total += t; achados += a; }
  return { total, achados, porAba, percent: total ? Math.round((achados / total) * 100) : 0 };
}

/** Quebra texto em linhas de no máximo `n` caracteres (fonte monoespaçada), sem cortar palavras. */
export function quebrarTexto(texto, n) {
  const out = [];
  for (const par of String(texto).split('\n')) {
    if (!par.trim()) { out.push(''); continue; }
    let linha = '';
    for (const palavra of par.split(/\s+/)) {
      if (!linha) linha = palavra; else if ((linha + ' ' + palavra).length <= n) linha += ' ' + palavra; else { out.push(linha); linha = palavra; }
      while (linha.length > n) { out.push(linha.slice(0, n)); linha = linha.slice(n); }
    }
    if (linha) out.push(linha);
  }
  return out;
}
