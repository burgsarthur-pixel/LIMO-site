// =====================================================================
// MÚSICA DE FUNDO — violão de nylon melancólico, 100% sintetizado (sem arquivos de áudio).
//  · renderPluck(): uma corda dedilhada (Karplus-Strong) renderizada numa Float32Array.
//  · GeradorMusica: compõe um compasso por vez (arpejo + melodia esparsa) em tom menor; puro e testável (sem DOM, sem Web Audio).
//  O AudioDirector (audio.js) agenda esses eventos no Web Audio, com reverb e crossfade por bioma.
//  Para ajustar o clima: mexa em PERFIS_MUSICA (andamento, acordes, brilho, densidade, volume).
// =====================================================================

export const midiParaHz = (m) => 440 * Math.pow(2, (m - 69) / 12);

/**
 * Acordes de violão (MIDI): `baixo` = corda grave; `cordas` = 4 notas agudas, da mais grave para a mais aguda.
 * Voicings de mão aberta, como num violão de verdade (E2 = 40 é a corda mais grave).
 */
export const ACORDES = {
  Am: { baixo: 45, cordas: [52, 57, 60, 64] },   G: { baixo: 43, cordas: [50, 55, 59, 62] },
  F: { baixo: 41, cordas: [48, 53, 57, 60] },    E7: { baixo: 40, cordas: [52, 56, 59, 62] },
  Dm: { baixo: 38, cordas: [50, 53, 57, 62] },   Bb: { baixo: 46, cordas: [53, 58, 62, 65] },
  Gm: { baixo: 43, cordas: [50, 55, 58, 62] },   A: { baixo: 45, cordas: [52, 57, 61, 64] },
  Em: { baixo: 40, cordas: [47, 52, 55, 59] },   Dm7: { baixo: 38, cordas: [48, 53, 57, 60] },
  C: { baixo: 48, cordas: [52, 55, 60, 64] },    Fmaj7: { baixo: 41, cordas: [48, 52, 57, 64] },
};

/** Todas as notas (MIDI) de um acorde pelo nome. */
export const notasDoAcorde = (nome) => { const a = ACORDES[nome]; return a ? [a.baixo, ...a.cordas] : []; };

/** Padrões de dedilhado em colcheias: 'b' = baixo, 0..3 = corda aguda (0 = mais grave), null = pausa. */
export const PADROES = [
  ['b', 1, 2, 3, 2, 1, 2, 1],
  ['b', 2, 1, 2, 3, 2, 1, 2],
  ['b', null, 1, 2, null, 3, 2, 1],
  ['b', 1, 2, 1, 3, 1, 2, null],
];

/**
 * Um perfil por bioma. bpm = andamento (a colcheia é bpm×2) · progressoes = ciclos de acordes (1 compasso cada) ·
 * escala = classes de altura permitidas à melodia · brilho 0..1 (nylon escuro → mais claro) · vol = volume de cada nota ·
 * densidade 0..1 = chance de cada nota do dedilhado soar (menos = mais respiro) · melodia 0..1 = chance de uma nota cantada por compasso ·
 * pausa = chance de um compasso quase vazio (só o baixo) · reverb 0..1 = quanto de "caverna" na mistura.
 */
export const PERFIS_MUSICA = {
  // Raízes: lá menor, cadência andaluza (Am–G–F–E7). Escuro, lento, caverna úmida.
  raizes: {
    bpm: 50, brilho: 0.30, vol: 0.056, densidade: 0.86, melodia: 0.55, pausa: 0.10, reverb: 0.55,
    escala: [9, 11, 0, 2, 4, 5, 7], melodiaFaixa: [64, 74],
    progressoes: [['Am', 'G', 'F', 'E7'], ['Am', 'Dm', 'F', 'E7'], ['Am', 'F', 'G', 'E7']],
  },
  // Jardim: ré menor, um pouco mais claro e aberto, mas ainda triste.
  jardim: {
    bpm: 56, brilho: 0.48, vol: 0.050, densidade: 0.80, melodia: 0.50, pausa: 0.14, reverb: 0.48,
    escala: [2, 4, 5, 7, 9, 10, 0], melodiaFaixa: [66, 77],
    progressoes: [['Dm', 'Bb', 'Gm', 'A'], ['Dm', 'C', 'Bb', 'A'], ['Dm', 'Gm', 'Bb', 'A']],
  },
  // Núcleo: mi frígio (o bII dá o aperto no peito). Mais lento, mais vazio, mais eco.
  nucleo: {
    bpm: 42, brilho: 0.22, vol: 0.054, densidade: 0.68, melodia: 0.38, pausa: 0.22, reverb: 0.75,
    escala: [4, 5, 7, 9, 11, 0, 2], melodiaFaixa: [59, 71],
    progressoes: [['Em', 'F', 'Em', 'Dm7'], ['Em', 'Dm7', 'F', 'Em'], ['Em', 'F', 'Dm7', 'Em']],
  },
};

// ---------------------------------------------------------------------
// Corda dedilhada (Karplus-Strong com afinação fracionária)
// ---------------------------------------------------------------------
/**
 * Renderiza uma nota de violão de nylon. Retorna Float32Array normalizada (pico = 1).
 * @param {number} sr taxa de amostragem · @param {number} hz frequência · @param {{brilho?:number,duracao?:number,rand?:()=>number}} opcoes
 */
export function renderPluck(sr, hz, { brilho = 0.35, duracao = null, rand = Math.random } = {}) {
  // Tempo de decaimento (T60): graves soam mais, agudos morrem rápido, como nylon.
  const t60 = Math.max(1.0, Math.min(3.6, 3.0 * Math.pow(110 / hz, 0.35)));
  const dur = duracao ?? Math.min(4, t60 * 1.15);
  const total = Math.floor(sr * dur);
  const atraso = sr / hz - 0.5;                      // o filtro de média atrasa meia amostra
  const N = Math.max(2, Math.floor(atraso - 0.1)); const d = atraso - N;   // d em [0,1,1,1)
  const C = (1 - d) / (1 + d);                       // all-pass de afinação fina
  const rho = Math.min(0.9996, Math.pow(10, -3 / (hz * t60)));   // perda por volta para atingir o T60

  // Excitação: ruído suavizado (dedo + unha macia) com posição de palheta (comb) para um timbre mais "redondo".
  const exc = new Float32Array(N + 2); let ant = 0; const suave = 0.55 + (1 - brilho) * 0.38;
  for (let i = 0; i < exc.length; i++) { ant = suave * ant + (1 - suave) * (rand() * 2 - 1); exc[i] = ant; }
  const pos = Math.max(1, Math.round(N * 0.18));
  for (let i = exc.length - 1; i >= pos; i--) exc[i] -= 0.8 * exc[i - pos];
  let media = 0; for (let i = 0; i < exc.length; i++) media += exc[i]; media /= exc.length; for (let i = 0; i < exc.length; i++) exc[i] -= media;

  const saida = new Float32Array(total); const L = N + 1; const anel = new Float32Array(L);   // buffer circular: guarda y[n-L..n-1]
  let aps = 0, apEntradaAnt = 0;                      // estado do all-pass
  let ymax = 0; let w = 0;
  for (let n = 0; n < total; n++) {
    let y;
    if (n < exc.length) y = exc[n];
    else {
      const s = 0.5 * (anel[(w + 1) % L] + anel[w]);  // média de y[n-N] e y[n-N-1]
      const a = C * (s - aps) + apEntradaAnt; apEntradaAnt = s; aps = a;
      y = rho * a;
    }
    anel[w] = y; w = (w + 1) % L; saida[n] = y;
    const ay = Math.abs(y); if (ay > ymax) ymax = ay;
  }
  // normaliza e aplica uma soltura curta no fim (sem estalo)
  const g = ymax > 0 ? 1 / ymax : 1; const fade = Math.min(total, Math.floor(sr * 0.06));
  for (let i = 0; i < total; i++) saida[i] *= g;
  for (let i = 0; i < fade; i++) saida[total - 1 - i] *= i / fade;
  // ataque de 1,5 ms (tira o clique do primeiro sample)
  const ataque = Math.min(total, Math.floor(sr * 0.0015)); for (let i = 0; i < ataque; i++) saida[i] *= i / ataque;
  return saida;
}

// ---------------------------------------------------------------------
// Compositor de compassos
// ---------------------------------------------------------------------
export class GeradorMusica {
  constructor(perfil, rand = Math.random) {
    this.perfil = perfil; this.rand = rand;
    this.prog = this._sortearProgressao(); this.idx = 0; this.compassosFeitos = 0; this.melodiaAnt = null; this.padraoAnt = -1;
  }
  _sortearProgressao() { const p = this.perfil.progressoes; return p[Math.floor(this.rand() * p.length)]; }
  get colcheia() { return 60 / this.perfil.bpm / 2; }
  get duracaoCompasso() { return this.colcheia * 8; }

  /** Próxima nota da melodia: passo curto a partir da anterior, preferindo notas do acorde (soa cantada, não aleatória). */
  _notaMelodia(acorde) {
    const { escala, melodiaFaixa } = this.perfil; const [lo, hi] = melodiaFaixa;
    const toques = new Set([acorde.baixo, ...acorde.cordas].map((m) => ((m % 12) + 12) % 12));
    const permitidas = new Set([...escala, ...toques]);
    const cand = []; const ref = this.melodiaAnt ?? (lo + hi) / 2;
    for (let m = lo; m <= hi; m++) {
      const pc = ((m % 12) + 12) % 12; if (!permitidas.has(pc)) continue;
      const dist = Math.abs(m - ref); if (dist === 0 && this.melodiaAnt != null && this.rand() < 0.6) continue;   // evita repetir
      cand.push({ m, w: (toques.has(pc) ? 3 : 1) * Math.exp(-dist / 2.6) });
    }
    let soma = 0; for (const c of cand) soma += c.w; let r = this.rand() * soma;
    for (const c of cand) { r -= c.w; if (r <= 0) return (this.melodiaAnt = c.m); }
    return (this.melodiaAnt = cand[cand.length - 1]?.m ?? lo);
  }

  /**
   * Gera o próximo compasso. Retorna { dur, acorde, eventos:[{t, midi, vel, pan, tipo}] } com `t` em segundos desde o início do compasso.
   * Humaniza timing e dinâmica; omite notas (respiro); às vezes canta uma melodia lenta por cima.
   */
  proximoCompasso() {
    const p = this.perfil; const r = this.rand; const ol = this.colcheia;
    if (this.idx >= this.prog.length) { this.idx = 0; if (r() < 0.45) this.prog = this._sortearProgressao(); }
    const nome = this.prog[this.idx]; const acorde = ACORDES[nome]; const primeiro = this.idx === 0; this.idx++; this.compassosFeitos++;
    const eventos = []; const vazio = r() < p.pausa;
    const humano = () => (r() - 0.5) * 0.026;        // ±13 ms de imprecisão de dedo
    const pan = (midi) => Math.max(-0.5, Math.min(0.5, (midi - 55) / 40));   // graves à esquerda, agudos à direita

    // dedilhado
    let k; do { k = Math.floor(r() * PADROES.length); } while (k === this.padraoAnt && PADROES.length > 1 && r() < 0.7); this.padraoAnt = k;
    const padrao = PADROES[k];
    for (let i = 0; i < 8; i++) {
      const alvo = padrao[i]; if (alvo == null) continue;
      const ehBaixo = alvo === 'b'; const midi = ehBaixo ? acorde.baixo : acorde.cordas[alvo];
      if (vazio && !ehBaixo) continue;
      if (!ehBaixo && r() > p.densidade) continue;   // respiro
      if (ehBaixo && i > 0 && r() > p.densidade + 0.1) continue;
      const acento = i === 0 ? 1 : (i % 2 === 0 ? 0.82 : 0.66); const vel = Math.min(1, acento * (ehBaixo ? 1 : 0.72 + midi / 400) * (0.88 + r() * 0.24));
      eventos.push({ t: Math.max(0, i * ol + (i === 0 ? Math.abs(humano()) : humano())), midi, vel, pan: pan(midi), tipo: ehBaixo ? 'baixo' : 'dedilhado' });
    }
    // início de frase: às vezes o acorde é "rasgado" bem de leve (3 notas, 28 ms de intervalo)
    if (primeiro && !vazio && r() < 0.5) {
      [acorde.cordas[0], acorde.cordas[1], acorde.cordas[2]].forEach((midi, j) => eventos.push({ t: 0.03 + j * 0.028, midi, vel: 0.34 - j * 0.04, pan: pan(midi), tipo: 'rasgado' }));
    }
    // melodia esparsa: 1 nota longa e, às vezes, uma segunda curta depois
    if (!vazio && r() < p.melodia) {
      const quando = [0, 2, 4, 6][Math.floor(r() * 4)] * ol + 0.02 + Math.abs(humano());
      const m1 = this._notaMelodia(acorde); eventos.push({ t: quando, midi: m1, vel: 0.78 + r() * 0.15, pan: pan(m1), tipo: 'melodia' });
      if (r() < 0.38 && quando + ol * 1.5 < this.duracaoCompasso) { const m2 = this._notaMelodia(acorde); eventos.push({ t: quando + ol * (1.5 + (r() < 0.5 ? 0 : 0.5)), midi: m2, vel: 0.62 + r() * 0.12, pan: pan(m2), tipo: 'melodia' }); }
    }
    eventos.sort((a, b) => a.t - b.t);
    return { dur: this.duracaoCompasso, acorde: nome, eventos };
  }
}
