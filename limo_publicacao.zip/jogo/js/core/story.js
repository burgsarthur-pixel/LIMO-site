// HISTÓRIA: falas dos chefes (exibidas ao derrotá-los) e finais. Texto de ecos fica em data/rooms/*.json.
export const BOSS_QUOTES = {
  'Tecelã das Raízes': ['LUTO', 'Não era você que eu queria ferir. Era a ferida dentro de mim.'],
  'Mastigador do Pulso': ['RITMO', 'Se você me acordar, terá de aceitar o que sonhei.'],
  'Coração Residual': ['IDENTIDADE', 'Eu dormia para não lembrar. Você acordou para esquecer.'],
};

export const ENDING_INTRO = 'O Deus desperta em fragmentos. Você é a última célula consciente. O que fazer com o corpo que o sonhou?';
export const ENDINGS = [
  { id: 'vigilia', nome: 'VIGÍLIA', lema: 'Guardar o sono do Deus.', texto: 'Você se recolhe nas raízes e guarda o sono do Deus. O corpo não morre, mas nunca acorda. Limo vela eternamente, lembrando por ele.' },
  { id: 'despertar', nome: 'DESPERTAR', lema: 'Devolver cada órgão e acordá-lo.', texto: 'Você devolve cada órgão e o Deus abre os olhos. O mundo dentro dele se desfaz como um sonho. Limo é a última lembrança, e agora a primeira palavra.' },
  { id: 'fusao', nome: 'FUSÃO', lema: 'Dissolver-se no pulso.', texto: 'Você se dissolve no pulso. Deus e célula tornam-se um só ritmo, sem dormir nem acordar. Tudo que existe dentro dele continua, diferente.' },
];

export const BIOME_CLEAN = {
  'Tecelã das Raízes': 'As Raízes da Carne param de convulsionar. O primeiro órgão foi lembrado.',
  'Pastor das Vísceras': 'A névoa do Jardim se dissipa. As criaturas do rebanho enfim descansam.',
  'Mastigador do Pulso': 'O ritmo do Núcleo se estabiliza. O Coração Residual desperta ao fundo.',
};

// ---- cartões de história (prólogo, revelações de chefe, capítulos) ----
// Arco: 01 DESPERTAR (Raízes) · 02 CONEXÃO (Jardim) · 03 DILÚVIO (Núcleo) · 04 DECISÃO (Vigília, Despertar ou Fusão).
export const PROLOGO = {
  id: 'prologo', titulo: 'O DEUS ADORMECIDO', tema: 'DESPERTAR',
  linhas: ['Sob o mundo, um corpo colossal agoniza.', 'Limo acorda sem memória, dentro dele.', 'Cada mutação é um órgão recuperado.', 'Cada vitória, um despertar parcial.'],
};

export const CAPITULOS = [
  { id: 'despertar', n: 1, nome: 'DESPERTAR', sub: 'Sobrevivência e fuga' },
  { id: 'conexao', n: 2, nome: 'CONEXÃO', sub: 'Compreensão do organismo' },
  { id: 'diluvio', n: 3, nome: 'DILÚVIO', sub: 'O ritmo cardíaco' },
  { id: 'decisao', n: 4, nome: 'DECISÃO', sub: 'Vigília, Despertar ou Fusão' },
];

/** Revelação ao derrotar cada chefe (id = `${sala}:${entidade}`, o mesmo de progress.bossesDefeated). */
export const REVELACOES = {
  'raizes_guardiao:guardiao_raizes': { id: 'guardiao', titulo: 'Tecelã das Raízes', tema: 'LUTO', linhas: ['A Tecelã tentou conter a ferida, e a ferida acabou prendendo a ela.', 'Por um instante, as raízes param de lutar contra si mesmas.'], frase: 'Obrigada por me soltar antes que eu me esquecesse.', capitulo: 'conexao' },
  'jardim_lago:pastor_visceras': { id: 'pastor', titulo: 'Pastor das Vísceras', tema: 'REPRODUÇÃO', linhas: ['Ele conduzia o rebanho até a água escura.', 'Eram criaturas parecidas com Limo, e ele as guardava como se fossem suas.'], frase: 'Nós sonhamos com uma forma que se perdeu. Você se parece com ela.', capitulo: 'diluvio' },
  'nucleo_salao:mastigador_pulso': { id: 'mastigador', titulo: 'Mastigador do Pulso', tema: 'RITMO', linhas: ['Guardava o ritmo do coração do Deus.', 'O pulso agora responde a você.'], frase: 'Se você me acordar, terá de aceitar o que sonhei.', capitulo: null },
  'nucleo_coracao:coracao_residual': { id: 'coracao', titulo: 'Coração Residual', tema: 'IDENTIDADE', linhas: ['A memória corporal do Deus.', 'Ele replicava tudo o que Limo aprendeu.'], frase: 'Eu dormia para não lembrar. Você acordou para esquecer.', capitulo: 'decisao' },
};

export function revelacaoDoChefe(bossId) { return REVELACOES[bossId] || null; }

/** Capítulo atual pelo progresso: cada chefe principal derrotado abre o seguinte. */
export function capituloAtual(progress) {
  const feitos = progress?.bossesDefeated || [];
  if (feitos.includes('nucleo_coracao:coracao_residual')) return CAPITULOS[3];
  if (feitos.includes('raizes_guardiao:guardiao_raizes')) return CAPITULOS[1];
  return CAPITULOS[0];
}

/** Balanço da jornada para a tela de encerramento: memórias (ecos), mutações e chefes. `salas` = lista de dados de sala. */
export function resumoDaJornada(progress, salas = []) {
  let total = 0; let achadas = 0;
  for (const d of salas) for (const e of d.entities || []) if (e.type === 'echo') { total++; if (progress?.collected?.has?.(`${d.id}:${e.id}`)) achadas++; }
  const mut = Object.values(progress?.abilities || {}).filter(Boolean).length; const chefes = (progress?.bossesDefeated || []).length;
  return { memorias: achadas, memoriasTotal: total, mutacoes: mut, chefes, texto: `Memórias ${achadas}/${total} · Mutações ${mut} · Chefes ${chefes}/${Object.keys(REVELACOES).length}` };
}
export const nomeDoFinal = (id) => (ENDINGS.find((f) => f.id === id) || {}).nome || null;
