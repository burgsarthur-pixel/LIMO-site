// Funções numéricas pequenas compartilhadas (antes cada arquivo tinha a sua cópia).
export const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
export const clamp01 = (v) => Math.max(0, Math.min(1, v));
export const lerp = (a, b, k) => a + (b - a) * k;
/** smoothstep: 0→1 com início e fim suaves. */
export const suave = (x) => x * x * (3 - 2 * x);
