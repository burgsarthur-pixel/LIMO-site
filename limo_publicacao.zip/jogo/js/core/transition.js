// =====================================================================
// TRANSIÇÃO ENTRE SALAS: máquina de estados mínima (sem DOM, testável em Node).
//  out -> a tela "fecha" como uma pupila em volta do jogador; ao terminar, executa `aoFechar` (troca a sala)
//  in  -> a nova sala "abre" em volta do jogador.
// `cover` vai de 0 (tela livre) a 1 (tudo escuro) já suavizado (smoothstep).
// =====================================================================

import { suave } from './math.js';

export class Transition {
  constructor() { this.cor = null; this.phase = null; this.t = 0; this.dur = 0; this.cx = 0; this.cy = 0; this.aoFechar = null; }
  get active() { return this.phase !== null; }
  get cover() {
    if (!this.phase) return 0;
    const p = suave(Math.min(1, this.t / (this.dur || 1)));
    return this.phase === 'out' ? p : 1 - p;
  }
  /** Fecha a tela em `dur` s e então chama `aoFechar`. Com dur <= 0 chama na hora. */
  out(dur, cx, cy, aoFechar, cor = null) {
    this.cor = cor;
    if (dur <= 0) { aoFechar?.(); return; }
    this.phase = 'out'; this.t = 0; this.dur = dur; this.cx = cx; this.cy = cy; this.aoFechar = aoFechar;
  }
  /** Abre a tela em `dur` s. */
  in(dur, cx, cy, cor = undefined) {
    if (cor !== undefined) this.cor = cor;
    if (dur <= 0) { this.phase = null; return; }
    this.phase = 'in'; this.t = 0; this.dur = dur; this.cx = cx; this.cy = cy; this.aoFechar = null;
  }
  update(dt) {
    if (!this.phase) return;
    this.t += dt;
    if (this.t < this.dur) return;
    const fn = this.aoFechar; const eraSaida = this.phase === 'out';
    this.phase = null; this.aoFechar = null;
    if (eraSaida) fn?.();
  }
}
