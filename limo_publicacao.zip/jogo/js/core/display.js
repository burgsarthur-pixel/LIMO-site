// =====================================================================
// ESCALA DA TELA: calcula o tamanho do canvas na tela do aparelho.
// Usa escala INTEIRA (em pixels físicos) para a pixel art ficar nítida.
// =====================================================================

/**
 * @param availWidth/availHeight  área disponível em pixels CSS
 * @param dpr                     devicePixelRatio (ex.: 2.75 em muitos Android)
 * @returns {{cssWidth, cssHeight, scale, integer}}  scale = pixels físicos por pixel interno
 */
export function computeDisplaySize({ availWidth, availHeight, dpr = 1, internalWidth, internalHeight, maxIntegerScale = 0, pixelPerfect = true }) {
  const fisicoL = availWidth * dpr;
  const fisicoA = availHeight * dpr;
  const cabe = Math.min(fisicoL / internalWidth, fisicoA / internalHeight);
  let escala = pixelPerfect ? Math.floor(cabe) : cabe;
  let inteira = pixelPerfect;
  if (escala < 1) { escala = Math.max(cabe, 0.1); inteira = false; } // tela minúscula: escala fracionária
  if (maxIntegerScale > 0 && escala > maxIntegerScale) escala = maxIntegerScale;
  return { cssWidth: (internalWidth * escala) / dpr, cssHeight: (internalHeight * escala) / dpr, scale: escala, integer: inteira };
}
