// =====================================================================
// JOGO: junta tudo e controla o tempo.
//
//  frame()        -> chamado pelo navegador a cada quadro de tela (requestAnimationFrame)
//   ├─ fixedUpdate() -> LÓGICA/FÍSICA, sempre em passos de 1/60 s (pode rodar 0, 1 ou vários por quadro)
//   └─ render()      -> só DESENHA; não altera o estado do jogo
//
// Esta classe não toca no DOM diretamente: a interface entra por `ui` e o desenho por
// `renderer`, que são opcionais. Por isso dá para testá-la em Node.
// =====================================================================
import { BOSS_QUOTES, ENDINGS, ENDING_INTRO, BIOME_CLEAN, PROLOGO, revelacaoDoChefe, capituloAtual, resumoDaJornada } from './story.js';
import { Player } from '../entities/player.js';
import { Camera } from './camera.js';
import { LAYER_NAMES } from '../world/tilemap.js';
import { rectsOverlap } from '../world/collision.js';
import { Progress, chaveItem } from './progress.js';
import { ABILITIES, ABILITY_IDS, normalizeRequires } from '../entities/abilities.js';
import { Enemy } from '../entities/enemy.js';
import { moveBody, createContacts } from '../world/collision.js';
import { tecelaColapso } from '../render/tecela-sprite.js';
import { Transition } from './transition.js';
import { LuzesFx, planoDeTransicao } from '../render/polimento.js';
import { passagensDaHabilidade, formatarTempo } from '../ui/progressao.js';
import { Ambience } from './ambience.js';
import { World } from '../world/world.js';
import { gerarExpedicao } from '../world/procedural.js';
import { buildPassages } from '../world/passages.js';
import { findSafeVerticalLanding } from '../world/arrival-placement.js';
import { bloqueiaLuz, invalidarOpacidade } from '../render/lighting.js';
import { tocaBorda } from '../world/borda.js';
import { TendrilController } from '../entities/tendril.js';
import { AudioDirector } from './audio.js';
import { MeleeCombo } from '../entities/melee.js';
import { ReacaoTiles, corposReativos } from '../render/tile-reacao.js';
import { Foco } from '../entities/foco.js';
import { InstanteVital } from '../entities/instante-vital.js';
import { calcularModificadores, geneDe, checkGenes } from '../entities/genes.js';
import { LimoAnimator } from '../entities/limo-anim.js';
import { Ecologia } from '../entities/comportamento.js';   // v1.39.0: comportamento próprio por espécie
import { Narrativa, agendarBalao, tracarRastro, rastrosDaSala } from './narrativa.js';
import { ehCasulo } from '../world/narrativa-dados.js';   // v1.51.0
import { ALTURA_NPC } from '../render/npc-art.js';   // v1.51.0: figura alta: a fala nasce do topo
import { escolherFalas, rotinaVigente, chaveNpc, CHEFE_TECELA, MAX_NPCS_COM_ROTINA_POR_SALA } from '../world/npc-dados.js';   // v1.44.0: fala conforme o progresso · v1.45.0: rotina
import { NpcViva } from '../entities/npc-viva.js';
import { criarRng, hashTexto } from '../entities/vida-eco.js';
import { ajustarInimigos, temperamentoPara, aplicarNoMapa, aplicarMudanca, evolucoesAtivas, chaveVista } from '../world/evolucao.js';   // v1.39.0: o mundo evolui após os chefes
import { registrar as registrarDescoberta, chaveCriatura, CRIATURAS } from './diario.js';   // v1.39.0: catálogo de descobertas
import { MundoVivo, nivelDeVida } from '../entities/mundo-vivo.js';   // v1.38.0: ecossistema, segredos, murais e clima

const agora = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

export class Game {
  constructor({ config, logger, input, catalog = null, renderer = null, ui = null, audio = null }) {
    this.config = config; this.logger = logger; this.input = input;
    this.catalog = catalog; this.renderer = renderer; this.ui = ui;
    this.player = new Player(config, logger); this.player.anim = new LimoAnimator();   // poses e eventos de som do Limo
    this.camera = new Camera(config);
    this.map = null; this.roomData = null; this.spawn = { x: 0, y: 0 };
    this.enemies = [];     // Lista de inimigos ativos na sala
    this.npcsVivos = new Map(); this._ctxNpc = { limo: { x: 0, y: 0, vivo: false }, criaturas: null };   // v1.45.0: NPCs com rotina da sala atual (id → NpcViva)
    this.roomEnemies = []; // Dados brutos dos inimigos vindos do carregador de salas
    this.passages = [];    // aberturas visíveis na parede (só desenho)
    this.transition = new Transition(); // íris de carne entre salas
    this.canvasToast = null; this.ambience = new Ambience(); this.cutscene = null; this.bossIntro = null; this.bossArenaLocked = false; this.flash = 0; this.orbs = []; this.visualFx = []; this.areaTitle = null; // clarão de item, orbes de vida, título de área
    this.hitStop = 0;      // congelamento curto ao acertar um inimigo (impacto)
    this.tendril = new TendrilController(config);
    this.melee = new MeleeCombo(config);   // ataque básico em combo de 3
    this.instante = new InstanteVital(config.abilities?.instanteVital);   // v1.40.0: Instante Vital — escala de tempo do MUNDO (nunca do jogador)
    this.foco = new Foco(config);          // cura por foco: golpes enchem o material biológico
    this.audio = audio || new AudioDirector(); this._historia = [];   // fila de cartões de história   // música/sons sintetizados (mudo e inerte sem Web Audio)

    this.running = false; this.paused = false;
    this.editing = false;     // true enquanto o editor de mapas está aberto (a física fica parada)
    this.customRender = null; // se definido, desenha no lugar da cena de jogo (usado pelo editor)
    this.accumulator = 0; this.lastTime = null; this._rafId = null;
    this.deadTimer = 0; this.defeatShown = false;
    this.beforeFrame = null; // gancho (ex.: ler o gamepad)
    this._ultimoVyChao = 0;   // Controlo de velocidade para o gatilho de aterragem
    this._passagemChegadaBloqueada = null; // bloqueia apenas a passagem de retorno até o jogador se afastar
    this.arrivalTransition = null; // animação protegida de chegada por uma abertura vertical inferior

    this.metrics = { fps: 0, dt: 0, frameMs: 0, updateMs: 0, renderMs: 0, stepsLastFrame: 0, totalSteps: 0, slowFrames: 0 };
    // Estado do debug (só é usado em modo dev; fica aqui para o desenho e o painel enxergarem o mesmo objeto)
    this.debug = {
      overlays: { transitions: false, hitboxes: false, spriteBox: false, solids: false, platforms: false, damage: false, roomBounds: false, cameraBounds: false, entities: false, gridTiles: false },
      layers: Object.fromEntries(LAYER_NAMES.map((n) => [n, true])),
      teleportOnClick: false,
      editorGrid: false,   // grade do editor (começa desligada; a tecla G e o botão do editor alteram o mesmo valor)
      visual: true,   // mestre: desliga TODOS os desenhos de debug sem perder as escolhas
      render: { autotileBorders: true, organicBackground: true, lighting: true, tileReacao: true, vida: true, depthVolume: true, depthParallax: true },   // diagnóstico: cada camada visual pode ser isolada
    };
    this.player.onDeath = () => { this.deadTimer = 0; this.tendril.stop('dead'); this.melee.cancelar(); this.foco.cancelar('morte'); this.foco.reset(); this.instante?.reset(); this.audio.tocar('morte'); };
    this.player.onDamage = () => { this.tendril.stop('damage'); this.melee.cancelar(); this.foco.cancelar('dano'); this.audio.tocar('dano'); };

    // ---- Etapa 3: mundo (várias salas), progresso e salvamento ----
    this.world = null; this.progress = null; this.saveStore = null;
    this.roomId = null; this.suspended = null;          
    this.sandbox = false; this._progressoReal = null;   
    this._tempoJogo = 0; this._chaveHab = ''; this._avisos = new Map(); this._errosConexao = new Set(); this._avisouSave = false;
  }

  /** Liga o mundo (todas as salas), o progresso (habilidades, itens, mapa) e o salvamento. */
  attachWorld({ world, progress, saveStore = null }) {
    this.world = world; this.progress = progress; this.saveStore = saveStore;
    this.player.abilities = progress.abilities;
  }

  /** Mensagem curta: desenhada DENTRO do canvas (fica sempre sobre o jogo) e espelhada no aviso oculto para leitores de tela. */
  toast(texto, ms = 2600) { this.canvasToast = { texto, t: 0, dur: ms / 1000 }; this.ui?.toast?.show(texto, ms); }

  // ---------------- sala ----------------
  get luzesFx() { return (this._luzesFx ||= new LuzesFx()); }

  _instalarSala(sala) {
    this.map = sala.map; this.roomData = sala.data; this.spawn = sala.spawn; this.roomId = sala.data.id;
    this.bossIntro = null; this.bossArenaLocked = false;
    this.roomEnemies = sala.enemies || [];
    if (this.progress && this.progress.novaHabilidade && this.roomId !== this._salaDaNovaHabilidade) this.progress.novaHabilidade = null;
    this.audio.setBioma(sala.data.biome); this.luzesFx?.itens && (this.luzesFx.itens.length = 0);
    this.audio.setSalaAcustica(sala.data.width ?? this.map?.width, sala.data.height ?? this.map?.height);
    if (this.audio.ctx) this.audio.tocar('entrada_sala', 0.72);
    this.passages = buildPassages(sala.data);
    this.orbs = []; this.visualFx = [];
    this._abrirPassagens();
    this.ambience.prepare(this.map);
    this.reacaoTiles = new ReacaoTiles(this.map, this.config.render.tileReacao || {});   // v1.28.0: decoração reativa (só visual)
    this._criarInimigos();             // inimigos da sala nova (antes ficavam os da sala anterior)
    this._aplicarBarreiras();
    this._prepararVivos(); this._prepararParedesFrageis();
    this._criarMundoVivo();
    this._criarNpcsVivos();            // v1.45.0
    this._prepararEvolucao();
  }

  /**
   * v1.45.0: NPCs com rotina da sala. Só entidades `npc` que têm rotina em npc-dados.js (as demais seguem estátuas). Máx. 3 por sala.
   * A entidade em roomData.entities não é tocada; a posição viva mora no NpcViva. O ciclo "já estava rodando": começa no relógio do mundo.
   */
  _criarNpcsVivos() {
    this.npcsVivos = new Map(); const prog = this.sandbox || this.expedicao ? null : this.progress; const ts = this.map.tileSize;
    for (const e of this.roomData?.entities || []) {
      if (e.type !== 'npc' || this.npcsVivos.size >= MAX_NPCS_COM_ROTINA_POR_SALA) continue;
      const rot = rotinaVigente(e.npc, prog); if (!rot) continue;
      this.npcsVivos.set(e.id, NpcViva.criar(e, rot, { ts, nivel: this._nivelVida, rng: criarRng(hashTexto(`${this.roomId}:${e.id}`)), inicio: this._tempoJogo || 0 }));
    }
  }

  /** v1.38.0: um MundoVivo por sala. Os tiles falsos dos segredos já descobertos viram ar aqui (antes da primeira colisão). */
  _criarMundoVivo() {
    const ts = this.map.tileSize; const fx = this.luzesFx; this._nivelVida = nivelDeVida(this.config);
    this.vivo = new MundoVivo({
      mapa: this.map, roomData: this.roomData, progress: this.sandbox || this.expedicao ? null : this.progress, reacao: this.reacaoTiles,
      nivel: this._nivelVida, solido: (x, y) => bloqueiaLuz(this.map, x, y), lightRadius: this.config.render.lightRadius ?? 70,
      onSegredo: (def) => this._segredoDescoberto(def, ts),
      onMural: (def, n, total) => this._muralDescoberto(def, n, total),
      onRastro: () => { if (this.progress && !this.sandbox && !this.expedicao) this._descobrir('evt:rastro', 'Algo vaza da rocha durante o evento'); },   // v1.47.0
    });
    this.ambience.onSplash = (x, y) => this.vivo?.atmosfera?.respingo(x, y, fx);
    // v1.50.0: narrativa das Raízes (só em jogo real: sem progresso, no sandbox e na expedição nada acontece)
    this.baloes = []; this.lembranca = null; this.despertar = null; this._tecelaFase = false;
    this.rastros = rastrosDaSala(this.roomId).map((spec) => ({ spec, pts: tracarRastro(spec, (x, y) => bloqueiaLuz(this.map, x, y), ts) }));
    this.narrativa = new Narrativa({ progress: this.sandbox || this.expedicao ? null : this.progress, salaId: this.roomId, ts, apresentar: (ap) => this._apresentarNarrativa(ap) });
    invalidarOpacidade(this.map);
  }
  /** v1.50.0: mostra um acontecimento da narrativa (balão, toast, clarão de memória, pulso). */
  _apresentarNarrativa(ap) {
    if (ap.pulso) { this.flash = Math.max(this.flash || 0, 0.35); this.player?.squash?.kick?.(1.2); }
    if (ap.despertar) this.despertar = { t: 0, dur: ap.despertar.dur || 3 };   // v1.51.0: escuridão que se abre em volta do Limo
    if (ap.balao) this.baloes.push(...agendarBalao(ap.balao));
    if (ap.toast) this.toast(ap.toast, 4200);
    if (ap.lembranca) { this.lembranca = { linhas: ap.lembranca.linhas, t: 0, dur: ap.lembranca.dur || 4 }; this.audio?.tocar?.('mural'); }   // v1.51.0: um sino curto marca a lembrança
  }
  /** Onde um balão deve nascer (pixels do mundo): Limo, NPC vivo ou entidade de presença. */
  posicaoDeFala(quem) {
    const ts = this.map.tileSize;
    if (quem === 'limo') return this.player ? { x: this.player.centerX, y: this.player.y } : null;
    if (quem?.npc) { const e = (this.roomData.entities || []).find((x) => x.type === 'npc' && x.npc === quem.npc); if (!e) return null; const v = this.npcsVivos?.get(e.id); return { x: (v ? v.x : e.x * ts) + ts / 2, y: (v ? v.y : e.y * ts) - 2 - ((ALTURA_NPC[quem.npc] ?? 16) - 16) }; }
    if (quem?.presenca) { const e = (this.roomData.entities || []).find((x) => x.type === 'presenca' && x.id === quem.presenca); return e ? { x: e.x * ts + ts / 2, y: e.y * ts - 6 } : null; }
    return null;
  }
  _atualizarNarrativa(dt) {
    for (const b of this.baloes) { if (b.espera > 0) b.espera -= dt; else b.t += dt; }
    if (this.baloes.length) this.baloes = this.baloes.filter((b) => b.t < b.dur);
    if (this.lembranca) { this.lembranca.t += dt; if (this.lembranca.t >= this.lembranca.dur) this.lembranca = null; }
    if (this.despertar) { this.despertar.t += dt; if (this.despertar.t >= this.despertar.dur) this.despertar = null; }
    if (!this.narrativa?.ativa || !this.player) return;
    this.narrativa.atualizar(dt, { x: this.player.centerX, y: this.player.centerY });
    const tec = this.enemies.find((e) => e.alive && e.bossPattern === 'tecelã' && !e.intro);
    if (tec && !this._tecelaFase && tec.life <= tec.maxLife * 0.5) { this._tecelaFase = true; this.narrativa.evento('fase', { chefe: CHEFE_TECELA, frac: tec.life / tec.maxLife }); }
  }

  /** v1.39.0: refaz no mapa o que os chefes derrotados mudaram. O que o jogador já viu entra em silêncio; o novo espera entrar na tela. */
  _prepararEvolucao() {
    this._evoPend = []; this._avisosMundo = this._avisosMundo || []; if (!this.progress || this.sandbox || this.expedicao) return;
    const derrotados = this.progress.bossesDefeated || []; const r = aplicarNoMapa(this.map, this.roomId, derrotados, this.progress.descobertas || new Set());
    this._evoPend = r.pendentes; if (r.efeitos.length) invalidarOpacidade(this.map);
    const naSala = ajustarInimigos(this.roomEnemies, this.roomId, derrotados, this.map.tileSize).filter((e) => e.kind !== 'boss' && !e.bossId);   // as criaturas desta sala (a lista `enemies` ainda é a da sala anterior)
    for (const evo of evolucoesAtivas(derrotados)) {   // mudanças de criaturas: avisa ao entrar na primeira sala em que se aplicam
      const c = evo.criaturas; const aqui = c.novos.some((n) => n.sala === this.roomId) || c.migracoes.some((m) => m.para.sala === this.roomId)
        || c.temperamentos.some((t) => (t.bioma === '*' || t.bioma === this.roomData?.biome) && naSala.some((e) => !t.kind || (e.kind || 'crawler') === t.kind));
      if (aqui && !this.progress.descobertas?.has(`evt:${evo.id}`) && !evo.mudancas.length) this._noticiarEvolucao(evo, 1.6);
    }
  }
  _noticiarEvolucao(evo, atraso = 0) {
    const r = registrarDescoberta(this.progress, `evt:${evo.id}`); if (!r.nova) return;
    this._avisosMundo.push({ t: atraso, texto: evo.aviso, ms: 4200 }); this.saveProgress('evolucao');
  }
  /** Mudanças pendentes entram em cena quando ficam na tela: a raiz se desfaz, o cipó brota, o jogador percebe. */
  _verEvolucao(dt) {
    if (!this._evoPend?.length) return; const c = this.camera; const ts = this.map.tileSize;
    for (let i = this._evoPend.length - 1; i >= 0; i--) {
      const { evo, m } = this._evoPend[i];
      if (!m.celulas.some(([x, y]) => x * ts > c.x - 8 && x * ts < c.x + c.viewWidth + 8 && y * ts > c.y - 8 && y * ts < c.y + c.viewHeight + 8)) continue;
      this._evoPend.splice(i, 1);
      const efeitos = aplicarMudanca(this.map, evo, m); invalidarOpacidade(this.map);
      for (const f of efeitos) {
        if (f.tipo === 'abrir') this.vivo?.segredos?.dissolvendo.push({ x: f.x, y: f.y, id: f.id, v: f.v, t: 0 });
        this.luzesFx.add({ x: (f.x + 0.5) * ts, y: (f.y + 0.5) * ts, raio: 34, cor: f.tipo === 'abrir' ? [255, 190, 110] : [180, 255, 190], dur: 0.7, intens: 0.8 });
      }
      this.audio.tocar('segredo'); this._impacto(0.05, 2);
      registrarDescoberta(this.progress, chaveVista(evo.id, this.roomId));
      this.toast(m.tipo === 'abrir' ? 'Uma raiz se desfaz: um caminho novo.' : 'Cipós brotam onde antes não havia nada.', 3600);
      const r = registrarDescoberta(this.progress, `evt:${evo.id}`); this.saveProgress('evolucao');
      this.logger.info('mundo', `Mudança de mundo vista: ${evo.id} em ${this.roomId}${r.nova ? ' (nova)' : ''}.`);
    }
  }
  /** Agenda e mostra os avisos curtos (ex.: o mundo mudou) sem atropelar a transição de sala. */
  _tocarAvisos(dt) {
    if (!this._avisosMundo?.length) return; const a = this._avisosMundo[0]; a.t -= dt; if (a.t <= 0) { this._avisosMundo.shift(); this.toast(a.texto, a.ms); }
  }
  /** Eventos que as criaturas geram (descansar, fugir, caçar...): o que o jogador OBSERVA entra no catálogo. */
  _eventoDeCriatura(ev, e, vitima) {
    if (!this.progress || this.sandbox) return; const kind = e.cfg?.kind; const spec = CRIATURAS[kind]; if (!spec) return;
    const perto = Math.abs(e.centerX - this.player.centerX) < 200 && Math.abs(e.centerY - this.player.centerY) < 150; if (!perto) return;
    const hab = ev === 'cacou' ? 'caca' : ev === 'expulsou' ? 'expulsa' : ev; if (!spec.habitos[hab]) return;
    this._descobrir(chaveCriatura(kind, `h:${hab}`), `${spec.nome}: hábito novo`);
    if (ev === 'cacou' && spec.habitos.saciado) this._descobrir(chaveCriatura(kind, 'h:saciado'));
  }
  _descobrir(chave, texto = null) {
    const r = registrarDescoberta(this.progress, chave); if (!r.nova) return false;
    if (texto) this.toast(`CATÁLOGO · ${texto}`, 2400);
    const agora = (this._tempoJogo || 0); if (agora - (this._ultimoSaveCatalogo ?? -99) > 6) { this._ultimoSaveCatalogo = agora; this.saveProgress('catalogo'); }
    return true;
  }
  _segredoDescoberto(def, ts) {
    const c = def.camara; this.audio.tocar('segredo'); this._impacto(0.05, 3);
    this.luzesFx.add({ x: (c.x + c.w / 2) * ts, y: (c.y + c.h / 2) * ts, raio: 54, cor: [255, 230, 170], dur: 0.5, intens: 0.9 });
    this.toast(def.texto, 2800); this.logger.info('mundo', `Segredo "${def.id}" descoberto em ${this.roomId}.`);
    invalidarOpacidade(this.map);
    if (this.progress && !this.sandbox) this.saveProgress('segredo');
  }
  _muralDescoberto(def, n, total) {
    const ts = this.map.tileSize; this.audio.tocar('mural');
    this.luzesFx.add({ x: (def.x + 1.5) * ts, y: (def.y + 1) * ts, raio: 40, cor: [255, 240, 200], dur: 0.45, intens: 0.7 });
    this.toast(`${def.legenda}  (${n}/${total})`, 3800); this.logger.info('mundo', `Mural "${def.id}" visto (${n}/${total}).`);
    if (this.progress && !this.sandbox) this.saveProgress('mural');
  }

  _criarInimigos() {
    const derrotados = this.progress?.bossesDefeated || [];
    const evolui = this.progress && !this.sandbox && !this.expedicao;   // v1.39.0: criaturas migram/nascem conforme os chefes derrotados
    const spawns = evolui ? ajustarInimigos(this.roomEnemies, this.roomId, derrotados, this.map.tileSize) : this.roomEnemies;
    this.enemies = spawns
      .filter((en) => !en.bossId || !derrotados.includes(en.bossId))
      .map((en) => Enemy.fromSpawn(en, this.map.tileSize));
    // v1.39.0: cada espécie ganha seu cérebro (chefes ficam de fora); o temperamento vem dos chefes já derrotados
    this.ecologia = new Ecologia({ onEvento: (ev, e, limo, vitima) => this._eventoDeCriatura(ev, e, vitima) }); this._criaturasVistas = new Set();
    if (evolui || this.progress) Ecologia.povoar(this.enemies, { ts: this.map.tileSize, semente: (this.roomId || '').length * 131 + 7, temperamentoDe: (e) => temperamentoPara(e.cfg.kind, this.roomData?.biome, derrotados) });
    // A Tecelã já existe como casulo ao entrar no ninho; ela só acorda no gatilho narrativo.
    for (const en of this.enemies) if (en.bossPattern === 'tecelã') { en.intro = true; en.introPhase = 'casulo'; en.introT = 0; en.attackZones = []; }
    // Sala com ferida curada: o deus se acalma e as criaturas comuns nascem mais fracas
    const menos = this.config.mecanicas?.ferida?.inimigoMenosVida ?? 1;
    if (menos > 0 && (this.roomData?.entities || []).some((e) => e.type === 'ferida' && this._feridaCurada(e))) {
      for (const en of this.enemies) if (en.cfg?.kind !== 'boss') en.life = Math.max(1, en.life - menos);
    }
  }

  setRoom(sala) {
    this._instalarSala(sala);
    this.restartRoom();
    this.logger.info('transicoes', `Sala ativa: ${sala.data.id}.`);
  }

  /** Vai para outra sala do mundo. Mantém vida, velocidade zerada e habilidades. */
  enterRoom(roomId, { spawnPx = null, healFull = false, arrivalConnection = null } = {}) {
    this.tendril.stop('room-change'); this.melee.cancelar(); this.foco.cancelar('sala'); this.instante?.reset();
    this._aplicarGenes();   // o progresso pode ter sido trocado (novo jogo, continuar, expedição): refaz os efeitos dos genes
    const sala = this.world.build(roomId);
    this._instalarSala(sala);
    const p = spawnPx || sala.spawn;
    const nova = !!this.progress && !this.progress.visited.has(roomId);
    if (nova) this.areaTitle = { texto: sala.data.name || roomId, t: 0 };   // título da área na 1ª visita
    if (healFull) this.player.reset(p.x, p.y);
    else { this.player.teleport(p.x, p.y); this.player.lastSafe = { x: p.x, y: p.y }; }
    this._passagemChegadaBloqueada = arrivalConnection || null;
    this.arrivalTransition = null;
    // Chegada cinemática por qualquer lado da sala.
    // A câmera revela primeiro a sala; só depois o personagem executa o movimento de entrada.
    const chegada = arrivalConnection && (sala.data.connections || []).find((c) => c.id === arrivalConnection);
    if (chegada?.trigger) {
      const t = chegada.trigger;
      const lado = t.x <= 0 ? 'left'
        : t.x + t.w >= sala.data.width ? 'right'
        : t.y <= 0 ? 'up'
        : t.y + t.h >= sala.data.height ? 'down' : null;
      const corpo = { ...this.player.body, x: p.x, y: p.y };
      let alvo = null;
      let modo = 'horizontal';

      if (lado === 'down' || lado === 'up') {
        // Entrada pela borda inferior: salto para dentro.
        // Entrada pela borda superior: queda para dentro, até encontrar piso real.
        const pouso = findSafeVerticalLanding(this.map, corpo, p, t, lado === 'down' ? 'up' : 'down');
        if (pouso) {
          alvo = pouso;
          modo = lado === 'up' ? 'queda' : 'salto';
        }
      } else if (lado === 'left' || lado === 'right') {
        // Entradas laterais: pequeno deslocamento cinematográfico para dentro da sala.
        const sentido = lado === 'left' ? 1 : -1;
        const passo = this.map.tileSize;
        for (const distancia of [0.25, 0.125]) {
          const x = Math.max(0, Math.min(this.map.pixelWidth - corpo.w, p.x + sentido * passo * distancia));
          let livre = true;
          this.map.forEachCollidable(x, p.y, corpo.w, corpo.h, (c) => {
            if (c.kind === 'solid' && rectsOverlap(x, p.y, corpo.w, corpo.h, c.x, c.y, c.w, c.h)) livre = false;
          });
          if (livre) { alvo = { x, y: p.y, groundInfo: null }; break; }
        }
      }

      if (alvo) {
        this.player.teleport(p.x, p.y);
        this.player.onGround = false; this.player.groundInfo = null;
        this.player.vx = 0; this.player.vy = 0; this.player.dashing = false;
        this.player.dashTimer = 0; this.player.tendrilPulling = false;
        this.player.jumpBuffer = 0; this.player.dropThroughTimer = 0;
        this.player.contacts = createContacts();
        this.arrivalTransition = {
          fromX: p.x, fromY: p.y, x: alvo.x, y: alvo.y,
          mode: modo, hold: 0.42, t: 0, duration: modo === 'horizontal' ? 0.42 : 0.68,
          arcHeight: modo === 'salto' ? Math.min(15, Math.max(8, Math.abs(p.y - alvo.y) * 0.12)) : 0,
          groundInfo: alvo.groundInfo || null,
        };
        this.logger.info('transicoes', `Entrada cinematica (${lado}) em ${sala.data.id}; modo ${modo}.`);
      } else {
        this.logger.warn('transicoes', `Sem ponto seguro de entrada cinematica (${lado}) em ${sala.data.id}; mantido spawn original.`);
      }
    }
    if (this.world && this.progress) this._recalcularVidaMax(healFull);
    this.progress?.visited.add(roomId);
    this.snapCamera(); this.accumulator = 0;
    this.transition.in(this._planoTransicao?.in ?? this.config.transition?.inTime ?? 0.4, this.player.centerX - this.camera.x, this.player.centerY - this.camera.y); this._planoTransicao = null;
    this.logger.info('transicoes', `Entrou na sala "${roomId}".`);
  }

  /** Faz o buraco de verdade: tira os tiles sólidos das passagens abertas, para o Limo poder entrar andando. */
  _abrirPassagens() {
    const m = this.map; if (!m) return; const ts = m.tileSize;
    for (const p of this.passages) {
      if (!p.conn || p.locked) continue;
      for (let ty = p.y / ts; ty < (p.y + p.h) / ts; ty++) for (let tx = p.x / ts; tx < (p.x + p.w) / ts; tx++) {
        if (m.inBounds(tx, ty) && m.layers.solid && m.layers.solid[ty * m.width + tx] !== 0) m.setTileId('solid', tx, ty, 0);
      }
    }
  }

  _aplicarBarreiras() {
    if (!this.world || !this.progress || !this.map) return;
    const genes = this.progress.genesEquipados || [];
    const bloqueiosDoMundo = this.world.barrierRects(this.roomId, this.progress.abilities, this.roomData, genes);
    const bloqueiosDaArena = this.bossArenaLocked ? (this.roomData.connections || []).map((c) => ({ ...this.world.triggerRect(this.roomData, c), connId: c.id, bossGate: true })) : [];
    const bloqueios = [...bloqueiosDoMundo, ...bloqueiosDaArena];
    this.map.setBarriers(bloqueios);
    this._chaveHab = this._chaveAtual();
    const trancadas = new Set(bloqueios.map((r) => r.connId));
    const cores = new Map();   // membrana selada por gene ganha a cor do gene que falta
    for (const c of this.roomData.connections || []) { const f = checkGenes(genes, c.requerGene).missing[0]; if (f && geneDe(f)) cores.set(c.id, geneDe(f).cor); }
    this.passages = buildPassages(this.roomData, trancadas, cores);
    this._abrirPassagens();
  }

  /** Assinatura do que abre/fecha passagens: mutações obtidas + genes equipados (mudou → refaz as barreiras). */
  _chaveAtual() { return `${ABILITY_IDS.map((id) => (this.progress.abilities[id] ? 1 : 0)).join('')}|${(this.progress.genesEquipados || []).join(',')}`; }

  /** Fecha a arena com barreiras reversíveis, sem alterar os tiles da sala. */
  _trancarArenaDoChefe(trancar) {
    if (this.bossArenaLocked === trancar) return;
    this.bossArenaLocked = trancar; this._aplicarBarreiras();
    this.audio.tocar(trancar ? 'arena_fecha' : 'arena_abre');
  }

  _iniciarIntroducaoTecela(boss) {
    if (this.bossIntro || !boss?.alive || boss.bossPattern !== 'tecelã') return false;
    boss.intro = true; boss.introPhase = 'casulo'; boss.introT = 0; boss.attackState = 'idle'; boss.attackZones = [];
    this.bossIntro = { boss, phase: 'casulo', t: 0, quote: null, somRuptura: false, tremorPouso: false };
    this._trancarArenaDoChefe(true);
    this.tendril.stop('introducao-chefe'); this.melee.cancelar(); this.foco.cancelar('introducao-chefe');
    this.audio.tocar('teia_nasce');
    return true;
  }

  /** Linha do tempo única: não depende de toque e nunca reinicia uma fase. */
  _atualizarIntroducaoTecela(dt) {
    const c = this.bossIntro; if (!c) return false;
    c.t += dt; c.boss.introT = c.t;
    // casulo treme (0–1.4s) → casca rasga e a Tecelã sai (1.4–3.4s) → fala. A arte lê boss.introT.
    if (c.t < 1.4) { c.phase = 'casulo'; c.boss.introPhase = 'casulo'; c.quote = null; }
    else if (c.t < 3.4) {
      if (!c.somRuptura) { c.somRuptura = true; this.audio.tocar('teia_ruptura'); this._impacto(0.04, 2.5); }
      if (!c.tremorPouso && c.t > 2.4) { c.tremorPouso = true; this.audio.tocar('arena_fecha'); this._impacto(0.05, 3.5); }   // patas pousando
      c.phase = 'ruptura'; c.boss.introPhase = 'ruptura'; c.quote = null;
    }
    else if (c.t < 6.6) { c.phase = 'fala'; c.boss.introPhase = 'fala'; c.quote = 'Pequena larva... eu também tentei fugir.'; }
    else if (c.t < 10.3) { c.phase = 'fala-final'; c.boss.introPhase = 'fala-final'; c.quote = 'A ferida me costurou de volta. Agora ela me faz lutar.'; }
    else {
      c.boss.intro = false; c.boss.introPhase = null; c.boss.attackState = 'idle'; c.boss.attackZones = [];
      this.bossIntro = null; this.input.endStep();
      this.audio.nota('triangle', 120, 190, 0.22, 0.04);
      return true;
    }
    this.input.endStep();
    return true;
  }

  /** ENREDO: enfileira um cartão (uma única vez por jogo, gravado no progresso); `depois` roda ao fechá-lo. */
  contarHistoria(card, atraso = 0, depois = null) {
    const chave = chaveItem('historia', card.id);
    if (this.progress?.collected?.has(chave)) return false;
    this.progress?.collected?.add(chave); this._historia.push({ card, atraso, depois }); return true;
  }
  _processarHistoria(dt) {
    if (!this._historia?.length || this.suspended || this.transition.active || this.paused || !this.ui?.screens?.showStory) return;
    const f = this._historia[0]; f.atraso -= dt; if (f.atraso > 0) return;
    this._historia.shift(); this.suspended = 'historia'; this.input.releaseAll();
    this.ui.screens.showStory(f.card, () => { if (this.suspended === 'historia') this.suspended = null; this.input.releaseAll(); this.input.endStep(); this.saveProgress('historia'); f.depois?.(); });
  }

  /** VIAGEM RÁPIDA (pelo mapa): vai para um checkpoint já descoberto. Recusa com chefe vivo na sala, durante transição ou morto. */
  viajarPara(sala, id) {
    const chave = `${sala}:${id}`; const d = this.world?.get?.(sala);
    if (!this.progress?.bancos?.has(chave) || !d || this.sandbox || this.expedicao) return false;
    const e = d.entities.find((x) => x.type === 'checkpoint' && x.id === id); if (!e) return false;
    if (this.transition.active || this.player.life <= 0 || this.player.state === 'dead') return false;
    if (this.enemies.some((en) => en.alive && en.cfg?.kind === 'boss')) { this.toast('Não dá para viajar com um chefe por perto.'); return false; }
    this.progress.checkpoint = { sala, id };
    this.enterRoom(sala, { spawnPx: this.world.spawnPx(d, e), healFull: true });
    this.input.releaseAll(); this.input.endStep(); this.toast(`Viagem rápida: ${d.name || sala}`);
    this.logger.info('salvamento', `Viagem rápida para "${chave}".`); this.saveProgress('viagem');
    return true;
  }

  /** PAREDES RACHADAS: entidades `paredeFragil` marcam um retângulo sólido da sala que cede ao ataque básico (hp = golpes de dano 1). */
  _prepararParedesFrageis() {
    const ts = this.map.tileSize; this._paredes = [];
    for (const e of this.roomData?.entities || []) {
      if (e.type !== 'paredeFragil') continue;
      const quebrada = this.progress?.collected?.has(chaveItem(this.roomId, e.id));
      if (quebrada) { this._abrirFerida({ abre: [{ x: e.x, y: e.y, w: e.w, h: e.h }] }); continue; }
      this._paredes.push({ e, id: e.id, hp: e.hp ?? 4, hpMax: e.hp ?? 4, golpeEm: -9, body: { x: e.x * ts, y: e.y * ts, w: e.w * ts, h: e.h * ts } });
    }
  }
  _golpearParede(w, passo, c) {
    w.hp -= c.dano; w.golpeEm = this._tempoJogo || 0;
    if (w.hp > 0) { this.audio.tocar('acerto'); this._impacto(0.03, 2); return; }
    this._paredes = this._paredes.filter((x) => x !== w);
    this._abrirFerida({ abre: [{ x: w.e.x, y: w.e.y, w: w.e.w, h: w.e.h }] });
    if (this.progress) this.progress.collected.add(chaveItem(this.roomId, w.id));
    this.audio.tocar('quebrar'); this._impacto(0.08, 5); this.toast(w.e.text || 'A parede rachada cede.', 2600);
    this.vivo?.segredos?.paredeQuebrada(w.id);   // v1.38.0: parede que guarda uma câmara secreta revela a câmara
    this.logger.info('mundo', `Parede rachada "${w.id}" quebrada.`);
    if (this.progress) this.saveProgress('segredo');
  }

  /** Morreu: volta ao último checkpoint (em qualquer sala) com a vida cheia. */
  respawnAtCheckpoint() {
    if (!this.world || !this.progress || this.sandbox) { this.restartRoom(); return; }
    let sala = this.expedicao ? this.expedicao.inicio : this.config.rooms.startRoom; let px = null;
    const cp = this.progress.checkpoint;
    if (cp && this.world.has(cp.sala)) {
      const d = this.world.get(cp.sala); const e = d.entities.find((x) => x.type === 'checkpoint' && x.id === cp.id);
      if (e) { sala = cp.sala; px = this.world.spawnPx(d, e); }
    }
    this.enterRoom(sala, { spawnPx: px, healFull: true });
    this.input.releaseAll(); this.input.endStep();
    this.deadTimer = 0; this.defeatShown = false; this.ui?.screens?.showDefeat(false);
    this.logger.info('combate', `Renasceu em "${sala}".`);
  }

  /** Volta ao mundo da campanha se uma expedição procedural estava ativa. */
  _sairDaExpedicao() { if (this.expedicao && this.mundoCampanha) { this.world = this.mundoCampanha; } this.expedicao = null; }

  /** EXPEDIÇÃO PROCEDURAL (estilo Dead Cells): salas geradas por semente; não grava no save da campanha. */
  startExpedition(semente = Date.now() % 1000000, salas = 7) {
    if (!this.expedicao && this.world) this.mundoCampanha = this.world;
    const exp = gerarExpedicao(semente, { salas });
    const mundo = new World(this.config, this.catalog, this.logger);
    for (const s of exp.salas) mundo.addRoom(s);
    this.expedicao = { semente, inicio: exp.inicio };
    this.attachWorld({ world: mundo, progress: Progress.novo(this.config), saveStore: this.saveStore });
    this.enterRoom(exp.inicio, { healFull: true });
    this.input.releaseAll(); this.input.endStep();
    this.deadTimer = 0; this.defeatShown = false; this.ui?.screens?.showDefeat(false); this.suspended = null;
    this.toast(`Expedição #${semente} — sobreviva e avance para a direita`, 3200);
    this.logger.info('procedural', `Expedição iniciada (semente ${semente}, ${salas} salas).`);
  }

  startNewGame() {
    this._sairDaExpedicao(); this.saveStore?.apagar();
    this.progress = Progress.novo(this.config); this.player.abilities = this.progress.abilities;
    this.enterRoom(this.config.rooms.startRoom, { healFull: true });
    this.input.releaseAll(); this.input.endStep();
    this.deadTimer = 0; this.defeatShown = false; this.ui?.screens?.showDefeat(false);
    this.suspended = null; this.saveProgress('novo-jogo');
    this._historia = []; this.contarHistoria(PROLOGO, 0.3);
    this.logger.info('salvamento', 'Novo jogo iniciado.');
  }

  continueGame(dados) {
    this._sairDaExpedicao();
    this.progress = Progress.fromSave(dados); this.player.abilities = this.progress.abilities;
    this.respawnAtCheckpoint(); this.suspended = null;
    this.logger.info('salvamento', 'Jogo continuado a partir do último checkpoint.');
  }

  saveProgress(motivo) {
    if (this.sandbox || this.expedicao || !this.saveStore || !this.progress) return false;   // expedição nunca grava por cima da campanha
    const r = this.saveStore.gravar(this.progress.toSave());
    if (!r.ok) {
      this.logger.error('salvamento', `Não foi possível salvar (${r.error}).`);
      if (!this._avisouSave) { this._avisouSave = true; this.toast('Não foi possível salvar o progresso neste navegador.'); }
      return false;
    }
    this.logger.debug('salvamento', `Progresso salvo (${motivo}).`);
    this._ultimoSalvo = new Date(); this.avisoSalvo = 1.4;   // ícone discreto "salvo" no canto
    return true;
  }

  /** Salvar por vontade do jogador (menu de pausa): confirma na tela, pois o salvamento automático é silencioso. */
  salvarAgora() {
    const ok = this.saveProgress('manual');
    this.toast(ok ? 'Progresso salvo.' : 'Não foi possível salvar. Use EXPORTAR PROGRESSO como garantia.', 2400);
    return ok;
  }

  /** Linha de informação do menu de pausa. */
  infoSalvamento() {
    const p = this.progress; if (!p) return '';
    const hora = this._ultimoSalvo ? `Salvo às ${this._ultimoSalvo.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : 'Salvamento automático ativo';
    return `${hora} · ${formatarTempo(p.tempoJogo)} · ${p.mortes | 0} queda(s)`;
  }

  beginSandbox() {
    if (this.sandbox) return;
    this._progressoReal = this.progress; this.sandbox = true;
    if (this.progress) { this.progress = this.progress.clone(); this.player.abilities = this.progress.abilities; }
  }

  endSandbox() {
    if (!this.sandbox) return;
    this.sandbox = false; this.progress = this._progressoReal; this._progressoReal = null;
    if (this.progress) this.player.abilities = this.progress.abilities;
    if (this.world && this.progress) this.respawnAtCheckpoint();
  }

  restartRoom() {
    if (!this.map) return;
    this.player.reset(this.spawn.x, this.spawn.y);
    this.tendril.reset(); this.instante?.reset();
    this.lastTime = null; 
    
    this._criarInimigos();

    this.input.releaseAll(); this.input.endStep();
    this.snapCamera();
    this.deadTimer = 0; this.defeatShown = false;
    this.ui?.screens?.showDefeat(false);
    this.accumulator = 0;
    this._ultimoVyChao = 0;
    this.logger.info('geral', 'Sala reiniciada.');
  }

  snapCamera() { if (this.map) this.camera.snapTo(this.player.centerX, this.player.centerY, this.map.pixelWidth, this.map.pixelHeight); }

  // ---------------- lógica (passo fixo síncrono) ----------------
  fixedUpdate(dt) {
    this._processarHistoria(dt);
    this.audio.tick(dt);
    if (!this.map) return;
    const t0 = agora();
    this._tempoJogo += dt;
    if (this.progress && !this.paused && !this.suspended && !this.sandbox && !this.expedicao) this.progress.tempoJogo += dt;
    this.avisoSalvo = Math.max(0, (this.avisoSalvo || 0) - dt);
    // Fechando a tela para trocar de sala: só câmera e animação andam (sem física, inimigos ou novos gatilhos)
    if (this.transition.phase === 'out') {
      this.transition.update(dt);
      this.camera.follow(this.player.centerX, this.player.centerY, dt, this.map.pixelWidth, this.map.pixelHeight);
      return;
    }
    this.transition.update(dt);
    this.flash = Math.max(0, this.flash - dt); this.luzesFx.update(dt);
    { const chefe = this.enemies?.find((e) => e.alive && e.cfg.kind === 'boss' && !e.intro); this.audio?.setTensao?.(chefe ? (chefe.attackState !== 'stalk' ? 1 : 0.6) : 0); }
    this.ambience.update(dt * (this.instante?.escala ?? 1), this.camera.x, this.camera.viewWidth);   // esfíncteres (pulso) seguem o tempo do mundo
    if (this.areaTitle && (this.areaTitle.t += dt) > 2.8) this.areaTitle = null;
    if (this.canvasToast && (this.canvasToast.t += dt) > this.canvasToast.dur) this.canvasToast = null;
    // Cena de mutação: o mundo fica parado até o jogador confirmar (ou 12 s)
    if (this.cutscene) {
      const c = this.cutscene; c.t += dt;
      if ((c.t > 2.4 && (this.input.wasPressed('jump') || this.input.wasPressed('dash'))) || c.t > 12) { this.cutscene = null; this.input.releaseAll(); }
      this.input.endStep();
      return;
    }
    // Hit-stop: congela a lógica por instantes após um golpe, dando peso ao impacto
    if (this.hitStop > 0) { this.hitStop -= dt; return; }
    this.instante?.update(dt); const dtMundo = dt * (this.instante?.escala ?? 1);   // v1.40.0: só inimigos/ambiente usam dtMundo; jogador, golpe, foco e câmera seguem em dt

    if (this.arrivalTransition) {
      const a = this.arrivalTransition;
      const anteriorX = this.player.body.x, anteriorY = this.player.body.y;
      if (a.hold > 0) {
        a.hold = Math.max(0, a.hold - dt);
        this.player.teleport(a.fromX, a.fromY);
        this.player.vx = 0; this.player.vy = 0;
        this.player.onGround = false; this.player.groundInfo = null;
        this.player.state = 'idle';
        this._atualizarBloqueioDaChegada();
        this.input.endStep();
        this.camera.follow(this.player.centerX, this.player.centerY, dt, this.map.pixelWidth, this.map.pixelHeight);
        return;
      }
      a.t = Math.min(a.duration, a.t + dt);
      const u = a.t / a.duration;
      const suave = u * u * (3 - 2 * u);
      const arco = a.mode === 'salto' ? Math.sin(Math.PI * u) * a.arcHeight : 0;
      const progresso = a.mode === 'queda' ? u * u : suave;
      const x = a.fromX + (a.x - a.fromX) * progresso;
      const y = a.fromY + (a.y - a.fromY) * progresso - arco;

      // Estado cinemático exclusivo: não chama Player.update, não aplica gravidade,
      // dano de tiles, inimigos, ataques ou gatilhos até o pouso estar concluído.
      this.player.teleport(x, y);
      this.player.vx = dt > 0 ? (x - anteriorX) / dt : 0;
      this.player.vy = dt > 0 ? (y - anteriorY) / dt : 0; // apenas para a pose visual
      this.player.onGround = false; this.player.groundInfo = null;
      this.player.invuln = Math.max(this.player.invuln, 0.12);
      this.player.state = this.player.vy < -12 ? 'jumping' : 'falling';

      const animChegada = (this.player.anim ||= new LimoAnimator());
      animChegada.update(dt, this.player, { tendril: this.tendril, melee: this.melee, foco: this.foco, input: this.input });
      for (const ev of animChegada.drenarEventos()) this.audio.tocar(ev.tipo, ev.escala);
      for (const fx of (animChegada.drenarFx?.() || [])) this.player.particles?.porEvento?.(fx, this.player);
      this._atualizarBloqueioDaChegada(); // libera a porta assim que o corpo realmente se afasta

      if (u >= 1) {
        this.player.teleport(a.x, a.y);
        this.player.vx = 0; this.player.vy = 0;
        this.player.onGround = !!a.groundInfo; this.player.groundInfo = a.groundInfo;
        this.player.contacts = createContacts(); this.player.contacts.down = true;
        this.player.state = this.player.onGround ? 'idle' : 'falling'; this.player.safeTimer = 0;
        this.player.lastSafe = { x: a.x, y: a.y };
        this.player.airDashesLeft = this.config.dash.airDashes;
        this.player.airJumpsLeft = this.config.abilities.saltoElastico?.extraJumps || 1;
        this.player.invuln = Math.max(this.player.invuln, 0.55);
        this.arrivalTransition = null;
      }
      this.input.endStep();
      this.camera.follow(this.player.centerX, this.player.centerY, dt, this.map.pixelWidth, this.map.pixelHeight);
      return;
    }

    
    if (this.world && this.progress && this._chaveAtual() !== this._chaveHab) {
      this._aplicarBarreiras();
    }

    // Ninho da Tecelã: só o retângulo explicitamente marcado na sala desperta o casulo.
    const tecela = this.enemies.find((e) => e.alive && e.bossPattern === 'tecelã');
    const gatilho = this.roomData?.bossIntro?.trigger; const ts = this.map.tileSize;
    const noGatilho = gatilho && this.player.centerX >= gatilho.x * ts && this.player.centerX <= (gatilho.x + gatilho.w) * ts && this.player.centerY >= gatilho.y * ts && this.player.centerY <= (gatilho.y + gatilho.h) * ts;
    if (!this.bossIntro && !this.bossArenaLocked && tecela && noGatilho) this._iniciarIntroducaoTecela(tecela);
    if (this._atualizarIntroducaoTecela(dt)) {
      this.camera.follow(this.player.centerX, this.player.centerY, dt, this.map.pixelWidth, this.map.pixelHeight);
      return;
    }

    this.player.update(dt, this.input, this.map);
    this._atualizarVivos(dt, dtMundo);
    this.tendril.update(dt, {
      player: this.player, input: this.input, mapa: this.map,
      roomData: this.roomData, enemies: this.enemies,
      paused: this.paused, transition: this.transition.active,
      activate: (alvo) => this._ativarAlvoTendril(alvo), jaAtivado: (e) => this._feridaCurada(e), logger: this.logger,
    });
    this.melee.update(dt, {
      player: this.player, input: this.input, mapa: this.map, enemies: this.enemies, paredes: this._paredes || [], paused: this.paused, transition: this.transition.active,
      onParede: (w, passo, c) => this._golpearParede(w, passo, c),
      onPogo: (v) => this._pogo(v),
      onHit: (en, morreu, passo, c, res = 'dano') => this._feedbackAcerto(en, morreu, passo, c, res),
    });
    for (const ev of this.melee.drenarEventos()) { this.audio.tocar(ev); if (/^golpe/.test(ev)) this._particulasSwoosh(); }
    this.foco.update(dt, {
      player: this.player, input: this.input, melee: this.melee, paused: this.paused, transition: this.transition.active,
      onCura: () => { this.player.squash?.kick?.(3); this._impacto(0.04, 1.5); this._instanteVital(); },
    });
    for (const ev of this.foco.drenarEventos()) {
      if (ev === 'focoVazio') this.toast(`Material biológico insuficiente (${this.foco.material}/${this.foco.config.custo}). Golpeie inimigos para encher.`, 2200);
      this.audio.tocar(ev);
    }
    for (const ev of this.tendril.drenarEventos()) this._tocarSomTendril(ev);
    const anim = (this.player.anim ||= new LimoAnimator());   // (também cobre jogadores trocados em testes/ferramentas)
    anim.update(dt, this.player, { tendril: this.tendril, melee: this.melee, foco: this.foco, input: this.input });
    for (const ev of anim.drenarEventos()) this.audio.tocar(ev.tipo, ev.escala);
    for (const fx of (anim.drenarFx?.() || [])) this.player.particles?.porEvento?.(fx, this.player);   // partículas do mesmo gatilho do som

    // Processamento de objetos, mutações, checkpoints e passagens de borda
    if (this.world && this.progress && this.player.life > 0) {
      this._atualizarBloqueioDaChegada();
      if (!this.arrivalTransition) { this._processarObjetos(); this._processarConexoes(); }
    }

    // --- v1.39.0: ecologia (cérebros das espécies), mudanças de mundo e catálogo ---
    this._verEvolucao(dt); this._tocarAvisos(dt);
    if (this.ecologia && this.enemies.length) {
      const p = this.player; const cam = this.camera;
      this.ecologia.atualizar(dtMundo, this.enemies, { x: p.centerX, y: p.centerY, vx: p.vx, vy: p.vy, vivo: p.life > 0, atacando: this.melee.fase !== 'idle', investindo: !!p.dashing, ref: p }, this.map);
      if (this.progress && !this.sandbox) for (const e of this.enemies) {   // primeira vez que uma espécie aparece na tela
        if (e.cfg.kind === 'boss' || !CRIATURAS[e.cfg.kind] || this._criaturasVistas.has(e.cfg.kind)) continue;
        if (e.centerX > cam.x && e.centerX < cam.x + cam.viewWidth && e.centerY > cam.y && e.centerY < cam.y + cam.viewHeight) { this._criaturasVistas.add(e.cfg.kind); this._descobrir(chaveCriatura(e.cfg.kind, 'visto'), `${CRIATURAS[e.cfg.kind].nome} registrado`); }
      }
    }
    // --- Atualização e colisão dos Inimigos ---
    for (const enemy of this.enemies) {
      if (!enemy.alive) continue;
      enemy.update(dtMundo, this.map, enemy.cerebro ? enemy.cerebro.alvoPara() : this.player);
      const perto = Math.abs(enemy.centerX - this.player.centerX) < 220 && Math.abs(enemy.centerY - this.player.centerY) < 160;
      for (const ev of enemy.drenarEventosAudio?.() || []) if (perto || enemy.bossId) this.audio.tocar(ev);
      for (const ped of enemy.drenarPedidos?.() || []) this._invocarFilhote(ped, enemy);
      if (!this.arrivalTransition && this.player.life > 0 && enemy.collidesWith(this.player.body)) this._contatoInimigo(enemy);
      if (!this.arrivalTransition && this.player.life > 0) this._contatoAtaqueChefe(enemy);
    }
    if (this.reacaoTiles) { this.reacaoTiles.ligado = this.debug.render.tileReacao !== false && this.config.render.tileReacao?.ligado !== false; this.reacaoTiles.atualizar(dt, corposReativos(this)); }
    if (this.npcsVivos.size) {   // v1.45.0: rotina dos NPCs (tempo do mundo: o Instante Vital também os desacelera)
      const c = this._ctxNpc; c.limo.x = this.player.centerX; c.limo.y = this.player.centerY; c.limo.vivo = this.player.life > 0; c.criaturas = this.enemies;
      const cam = this.camera; const registra = this.progress && !this.sandbox && !this.expedicao;
      for (const n of this.npcsVivos.values()) {
        n.atualizar(dtMundo, c);
        if (!registra) continue;   // v1.47.0: o que o Limo vê o NPC fazer (≥ 2 s na tela) entra no catálogo
        const naTela = n.centerX > cam.x && n.centerX < cam.x + cam.viewWidth && n.centerY > cam.y && n.centerY < cam.y + cam.viewHeight;
        const h = n.observar(dtMundo, naTela); if (h) this._descobrir(chaveNpc(n.e.npc, `h:${h}`), `${n.e.nome || "NPC"}: hábito novo`);
      }
    }
    if (this.vivo) {   // v1.38.0: vida própria, segredos, murais e clima (só visual, exceto abrir a rocha falsa de um segredo)
      const cam = this.camera; this.vivo.nivel = this.debug.render.vida === false ? 0 : this._nivelVida;
      this.vivo.atualizar(dtMundo, { x: this.player.body.x, y: this.player.body.y, w: this.player.body.w, h: this.player.body.h, vx: this.player.vx, vy: this.player.vy }, { x: cam.x, y: cam.y, w: cam.viewWidth, h: cam.viewHeight ?? this.config.render.internalHeight }, this._tempoJogo, this.luzesFx, this.ambience.respira);
    }
    this._atualizarNarrativa(dt);   // v1.50.0
    const atm = this.vivo?.atmosfera; if (atm?.aviso) { if (!this.sandbox) this.toast(atm.aviso, 2600); atm.aviso = null; }   // v1.47.0: evento ambiental raro
    this._atualizarOrbes(dt);
    this._atualizarVisualFx(dt);
    for (const e of this.enemies) if (!e.alive && e.bossPattern === 'tecelã') this.visualFx.push({ t: 0, dir: e.attackDir || e.facing || 1, vy: 0, contacts: createContacts(), body: { x: e.body.x, y: e.body.y, w: e.body.w, h: e.body.h } });   // só visual
    if (this.enemies.some((e) => !e.alive)) this.enemies = this.enemies.filter((e) => e.alive);

    this.input.endStep(); 
    this.camera.follow(this.player.centerX, this.player.centerY, dt, this.map.pixelWidth, this.map.pixelHeight);

    // --- Gatilho de Screen Shake ao Aterrar de Queda Forte ---
    if (this.player.onGround) {
      if (this._ultimoVyChao > 480) {
        const intensidade = Math.min(6, (this._ultimoVyChao - 480) / 70 + 2);
        this.camera.shake(intensidade, 0.22);
      }
      this._ultimoVyChao = 0;
    } else {
      if (this.player.vy > 0) {
        this._ultimoVyChao = this.player.vy;
      }
    }

    if (this.player.life <= 0) {
      if (this.deadTimer === 0 && this.progress && !this.sandbox && !this.expedicao) this.progress.mortes = (this.progress.mortes | 0) + 1;
      this.deadTimer += dt;
      if (this.deadTimer >= 0.9 && !this.defeatShown) { this.defeatShown = true; this.ui?.screens?.showDefeat(true); }
    }
    this.metrics.totalSteps++;
    this._tempoLogica = (this._tempoLogica || 0) + (agora() - t0);
  }

  /** v1.40.0 — Instante Vital: chamado SÓ quando o Foco conclui uma cura (onCura). Sem a habilidade, nada acontece. */
  _instanteVital() {
    if (!this.progress?.abilities?.instanteVital && !this.player?.abilities?.instanteVital) return false;
    if (!this.instante?.iniciar()) return false;
    this.audio.tocar('instanteVital');
    this.luzesFx?.add?.({ x: this.player.centerX, y: this.player.centerY, raio: 38, cor: [150, 255, 200], dur: 0.35, intens: 0.9 });
    return true;
  }

  /** Material do foco vem de dano confirmado, independentemente de ser golpe, investida ou pisão. */
  _ganharMaterialBiologico(dano = 1) {
    const ganho = this.foco?.ganhar?.(dano) ?? 0;
    if (ganho > 0) this.player?.squash?.kick?.(0.7);
    return ganho;
  }

  /** Jogador × inimigo: investida e pisão derrotam; ambos também geram material para o Foco. */
  _contatoInimigo(enemy) {
    const p = this.player; const pes = p.body.y + p.body.h;
    const pisao = p.vy > 40 && pes - enemy.body.y <= enemy.body.h * 0.75;
    if (p.dashing || pisao) {
      // takeHit só informa morte; a janela de invulnerabilidade impede ganhar material repetido pelo mesmo contato.
      const acertou = enemy.alive && enemy.hurtTimer <= 0;
      const r = enemy.receberGolpe ? enemy.receberGolpe({ dano: 1, origemX: p.centerX, empurrao: this.config?.dash?.enemyKnockback, tipo: p.dashing ? 'investida' : 'pisao' })
        : { resultado: 'dano', morreu: enemy.takeHit(1, p.centerX, this.config?.dash?.enemyKnockback) };
      const morreu = !!r.morreu;
      if (acertou && r.resultado !== 'aparado') this._ganharMaterialBiologico(1);
      if (morreu) this._registrarDerrotaInimigo(enemy);
      if (pisao) {   // pisão: quica e devolve o salto extra e a investida (encadear pisões entre inimigos)
        const el = p.hasAbility?.('saltoElastico') ? 0.75 : 0.6;
        p.vy = -this.config.physics.jumpSpeed * el; p.onGround = false; p.squash?.kick(3);
        if (r.resultado !== 'ignorado') { p.airJumpsLeft = this.config?.abilities?.saltoElastico?.extraJumps || 1; p.airDashesLeft = this.config?.dash?.airDashes ?? p.airDashesLeft; p.dashCooldown = 0; }
      } else if (p.dashing) {   // investida: o impacto joga o Limo para trás (aparado: recuo forte)
        p.recuarDaInvestida?.(r.resultado === 'aparado' ? 1.3 : morreu ? 0.6 : 1);
      }
      if (acertou || r.resultado === 'aparado') {
        if (this._feedbackAcerto) this._feedbackAcerto(enemy, morreu, 0, { dano: 1, impacto: [0.04, 2.2] }, r.resultado, true);
        else if (!pisao && acertou) { this.audio?.tocar?.('acerto'); this._impacto?.(0.04, 2.2); }
      }
      return;
    }
    if (this._membranaAbsorve?.(enemy)) return;
    p.takeDamage(enemy.damage, enemy.centerX);
    this._impacto(0.05, 2.5);
  }

  /** Membrana: absorve UM contato com inimigo/ataque (recarga compartilhada com os espinhos) e atordoa os leves ao redor. */
  _membranaAbsorve(enemy) {
    const p = this.player;
    if (!p.hasAbility?.('membrana') || p.membranaCooldown > 0 || p.invuln > 0) return false;
    p.membranaCooldown = 2.4; p.membranaFlash = 0.32; p.squash?.kick(1.5);
    p.particles?.spawnMembrana?.(p.centerX, p.body.y + p.body.h / 2);
    this.audio?.tocar?.('membrana_reflexo');
    for (const o of this.enemies) if (o.alive && o.cfg.kind !== 'boss' && Math.hypot(o.centerX - p.centerX, o.centerY - p.centerY) < 60) o.atordoar?.(1.0, 'reflexo');
    this._impacto(0.05, 2);
    this.logger?.info('habilidades', 'A Membrana absorveu o contato com o inimigo.');
    return true;
  }

  /** Feedback de acerto por resultado: som, partículas, hitstop e tremor proporcionais ao peso do golpe. */
  _feedbackAcerto(en, morreu, passo, c, res = 'dano', jaContou = false) {
    const som = { dano: 'acerto', aparado: 'aparar', guarda_quebrada: 'quebra_guarda', contragolpe: 'contragolpe', exposto: 'acerto_pesado', ignorado: null }[res];
    if (som) this.audio.tocar(som);
    if (res === 'aparado') { if (en) { this.player?.particles?.spawnAparar?.(en.centerX + en.facing * 6, en.centerY, en.facing); this.luzesFx.add({ x: en.centerX + en.facing * 6, y: en.centerY, raio: 22, cor: [200, 225, 255], dur: 0.12, intens: 0.8 }); } this._impacto(0.03, 1.5); return; }
    if (en && !jaContou) { this._particulasGolpe(en, passo); this._ganharMaterialBiologico(c.dano); }
    const pesado = res === 'guarda_quebrada' || res === 'contragolpe' || res === 'exposto';
    if (en && pesado) this.player?.particles?.spawnImpactoPesado?.(en.centerX, en.centerY - 2, this.player.facing || 1, res === 'contragolpe' ? '#ff9a4d' : '#ffe135');
    if (en) this.luzesFx.add({ x: en.centerX, y: en.centerY, raio: pesado ? 44 : 28, cor: pesado ? [255, 210, 120] : [255, 240, 200], dur: pesado ? 0.22 : 0.14, intens: pesado ? 1 : 0.8 });
    if (pesado) this.flash = Math.max(this.flash, 0.06);
    if (morreu) { if (en) { this.player?.particles?.spawnMorte?.(en.centerX, en.centerY, en.cfg?.kind === 'boss' ? '#ff5577' : '#b07cff'); this.luzesFx.add({ x: en.centerX, y: en.centerY, raio: 52, cor: [255, 200, 220], dur: 0.3, intens: 1 }); this._registrarDerrotaInimigo(en); } return; }
    const k = res === 'guarda_quebrada' ? 1.8 : res === 'contragolpe' ? 1.5 : res === 'exposto' ? 1.3 : 1;
    this._impacto(c.impacto[0] * k, c.impacto[1] * k);
  }

  _invocarFilhote(ped, dono) {
    if (ped.tipo !== 'invocar') return;
    const ts = this.map.tileSize;
    const f = Enemy.fromSpawn({ kind: ped.kind, tileX: Math.floor(ped.x / ts), tileY: Math.floor((ped.y - 1) / ts) - (ped.kind === 'flyer' ? 2 : 0), life: 1 }, ts);
    f.dono = dono; this.enemies.push(f); dono.filhotes.push(f);
    this.player?.particles?.spawnFaiscas?.(ped.x, ped.y - 6);
  }

  /** Zonas especiais de chefes. A Tecelã expõe costuras, rotas e pulsos, sempre com aviso visual antes do dano. */
  _contatoAtaqueChefe(enemy) {
    const zonas = enemy.attackZones || []; const p = this.player; const b = p.body;
    for (const z of zonas) {
      if (!z.active) continue;
      let acertou = false;
      if (z.tipo === 'ground' || z.tipo === 'path' || z.tipo === 'coluna') acertou = rectsOverlap(b.x, b.y, b.w, b.h, z.x, z.y, z.w, z.h);
      else if (z.tipo === 'ring') {
        const dx = p.centerX - z.x; const dy = p.centerY - z.y;
        const alcance = z.thickness + Math.max(b.w, b.h) * 0.5;
        acertou = Math.abs(Math.hypot(dx, dy) - z.r) <= alcance;
      }
      if (acertou && this._membranaAbsorve?.(enemy)) break;
      if (acertou && p.takeDamage(z.damage ?? enemy.damage, z.originX ?? enemy.centerX)) {
        this._impacto(0.05, 2.5);
        break; // invulnerabilidade protege contra sobreposição de zonas no mesmo quadro
      }
    }
  }

  _registrarDerrotaInimigo(enemy) {
    this.logger.info('combate', `${enemy.name || 'Inimigo'} derrotado.`);
    if (!enemy.bossId) this.audio.tocar('inimigo_cai');
    if (!enemy.bossId && this.progress && !this.sandbox && CRIATURAS[enemy.cfg?.kind]) this._descobrir(chaveCriatura(enemy.cfg.kind, 'derrotado'), `${CRIATURAS[enemy.cfg.kind].nome}: ponto fraco anotado`);
    if (enemy.bossPattern === 'tecelã' && this.bossArenaLocked) this._trancarArenaDoChefe(false);
    if (enemy.bossId && this.progress) {
      this.progress.bossesDefeated ||= [];
      if (!this.progress.bossesDefeated.includes(enemy.bossId)) {
        this.progress.bossesDefeated.push(enemy.bossId);
        this.audio.tocar('chefe'); const fala = BOSS_QUOTES[enemy.name]; const rev = revelacaoDoChefe(enemy.bossId); const temUi = !!this.ui?.screens?.showStory;
        const limpeza = BIOME_CLEAN[enemy.name]; const final = enemy.name === 'Coração Residual' && this.ui?.screens?.showEnding;
        const mostrarFinal = () => { this.pause(); const resumo = resumoDaJornada(this.progress, this.world ? this.world.ids().map((i) => this.world.get(i)) : []).texto; this.ui.screens.showEnding(ENDING_INTRO, ENDINGS, (f) => { this.progress.final = f.id; this.saveProgress('final'); this.resume(); }, resumo, () => this.ui.screens.showTitle?.(true)); };
        if (rev && temUi) {   // cartões: revelação do chefe → capítulo novo → (limpeza do bioma) → final
          this.contarHistoria(rev, 2.2, () => { if (limpeza) this.toast(limpeza, 5000); if (final && !capituloNovo) mostrarFinal(); });
          const cap = capituloAtual(this.progress); var capituloNovo = !!(rev.capitulo && rev.capitulo === cap.id);
          if (capituloNovo) this.contarHistoria({ id: `cap_${cap.id}`, tema: `CAPÍTULO ${cap.n}`, titulo: cap.nome, linhas: [cap.sub] }, 0.2, final ? mostrarFinal : null);
        } else {
          this.toast(fala ? `${enemy.name} — ${fala[0]}: “${fala[1]}”` : `Chefe derrotado: ${enemy.name}!`, 6500);
          if (limpeza && typeof setTimeout === 'function') setTimeout(() => this.toast(limpeza, 5000), 6600);
          if (final && typeof setTimeout === 'function') setTimeout(mostrarFinal, 3500);
        }
        const evo = evolucoesAtivas([enemy.bossId])[0];   // v1.39.0: o mundo muda para sempre
        if (evo && typeof setTimeout === 'function') setTimeout(() => this.toast(evo.aviso, 4500), 9000);
        this.logger.info('combate', `Chefe persistente registrado: ${enemy.bossId}.`);
        this.saveProgress('chefe');
      }
    }
    this._impacto(0.07, 3); this._soltarOrbe(enemy);
  }

  /** Inimigo derrotado: às vezes solta um orbe de ESSÊNCIA (paga a cura das Feridas do Deus). A vida só volta pelo foco ou por checkpoints. */
  _soltarOrbe(enemy) {
    if (Math.random() < 0.5) this.orbs.push({ x: enemy.centerX, y: enemy.body.y, vida: 8 });
  }

  /** Corpo visual da Tecelã: cai até o chão e desaba; sem colisão com o jogador nem efeito em mecânicas. */
  _atualizarVisualFx(dt) {
    if (!this.visualFx?.length) return;
    for (const fx of this.visualFx) {
      fx.t += dt; fx.vy = Math.min(260, fx.vy + 520 * dt);
      if (this.map) moveBody(this.map, fx.body, 0, fx.vy * dt, {}, fx.contacts);
      if (fx.contacts.down) fx.vy = 0;
    }
    this.visualFx = this.visualFx.filter((fx) => !tecelaColapso(fx.t).done);
  }

  _atualizarOrbes(dt) {
    const p = this.player; const b = p.body;
    for (const o of this.orbs) {
      o.vida -= dt;
      if (p.life <= 0 || !rectsOverlap(b.x, b.y, b.w, b.h, o.x - 4, o.y - 4, 8, 8)) continue;
      if (this.progress && this.progress.essencia < (this.config.mecanicas?.ferida?.essenciaMax ?? 9)) {
        this.progress.essencia++; o.vida = 0; p.squash?.kick(1.5); this.toast(`+1 essência (${this.progress.essencia})`);   // guarda para curar feridas; não cura a vida
      }
    }
    if (this.orbs.some((o) => o.vida <= 0)) this.orbs = this.orbs.filter((o) => o.vida > 0);
  }

  // ---------------- o corpo do deus vivo: pulso, fungos de luz e feridas ----------------
  /** Varre o mapa atrás de tiles com `mecanica` (catálogo) e guarda onde estão; feridas curadas reabrem seus atalhos. */
  _prepararVivos() {
    this.pulsos = []; this.fungos = []; this._cura = null;
    const m = this.map;
    for (const camada of ['solid', 'platform', 'interactive']) {
      const arr = m.layers[camada]; if (!arr) continue;
      for (let i = 0; i < arr.length; i++) {
        const id = arr[i]; const mec = id ? m.catalog.get(id)?.mecanica : null; if (!mec) continue;
        const tx = i % m.width; const ty = (i / m.width) | 0;
        if (mec.tipo === 'pulso') this.pulsos.push({ camada, tx, ty, fase: mec.fase, fechado: mec.aberto ? mec.par : id, aberto: mec.aberto ? id : mec.par, estaFechado: !mec.aberto, aviso: false });
        else if (mec.tipo === 'fungo') {
          const f = { camada, tx, ty, idAceso: mec.aceso ? id : mec.par, idDormente: mec.aceso ? mec.par : id, t: 0, aceso: !!mec.aceso };
          this.fungos.push(f); this._definirTile(f, false);
        }
      }
    }
    this._atualizarPulsos(true);
    for (const e of this.roomData?.entities || []) if ((e.type === 'ferida' || e.type === 'tendrilObject') && this._feridaCurada(e)) this._abrirFerida(e);
    this._contarFeridas();
  }

  _definirTile(f, aceso) { f.aceso = aceso; this.map.setTileId(f.camada, f.tx, f.ty, aceso ? f.idAceso : f.idDormente); }

  _atualizarVivos(dt, dtMundo = dt) {
    this._atualizarPulsos(false);
    this._atualizarFungos(dtMundo);   // fungos de luz: ambiente, desacelera
    this._atualizarFeridas(dt);       // cura de ferida é ação do jogador: tempo normal
  }

  /** Esfíncteres: duas fases (A/B) que trocam a cada batida do deus. Só fecham se não houver ninguém dentro (nada esmaga). */
  _atualizarPulsos(forcar) {
    if (!this.pulsos || !this.pulsos.length) return;
    const cfg = this.config.mecanicas.pulso; const periodo = 3.2 * (cfg.batidasPorFase || 1);
    const tt = this.ambience.t; const fase = Math.floor(tt / periodo) % 2; const aviso = periodo - (tt % periodo) < cfg.aviso;
    const ts = this.map.tileSize; const b = this.player.body;
    for (const p of this.pulsos) {
      p.aviso = aviso;
      const quer = p.fase === fase;
      if (quer === p.estaFechado) continue;
      if (quer && !forcar) {
        const r = { x: p.tx * ts, y: p.ty * ts, w: ts, h: ts };
        if (rectsOverlap(b.x, b.y, b.w, b.h, r.x, r.y, ts, ts) || this.enemies.some((e) => e.alive && e.collidesWith(r))) continue;   // adia até liberar
      }
      p.estaFechado = quer;
      this.map.setTileId(p.camada, p.tx, p.ty, quer ? p.fechado : p.aberto);
    }
  }

  /** Fungos de luz: ficam sólidos enquanto a luz do Limo os alcança (e por alguns segundos depois). Paredes bloqueiam a luz. */
  _atualizarFungos(dt) {
    if (!this.fungos || !this.fungos.length) return;
    const cfg = this.config.mecanicas.fungo; const ts = this.map.tileSize; const p = this.player;
    const alc = (this.config.render.lightRadius ?? 70) * cfg.alcance; const px = p.centerX; const py = p.centerY - 1;
    for (const f of this.fungos) {
      const cx = (f.tx + 0.5) * ts; const cy = (f.ty + 0.5) * ts;
      let luz = false;
      if (p.life > 0) {
        const d = Math.hypot(cx - px, cy - py); luz = d <= alc;
        for (let s = 4; luz && s < d; s += 4) if (bloqueiaLuz(this.map, px + ((cx - px) * s) / d, py + ((cy - py) * s) / d)) luz = false;
      }
      f.t = luz ? cfg.duracao : Math.max(0, f.t - dt);
      if ((f.t > 0) !== f.aceso) this._definirTile(f, f.t > 0);
    }
  }

  _feridaCurada(e) { return !!this.progress?.collected.has(chaveItem(this.roomId, e.id)); }
  _contarFeridas() { this.feridasAbertas = (this.roomData?.entities || []).filter((e) => e.type === 'ferida' && !this._feridaCurada(e)).length; }

  /** Tira os tiles sólidos dos retângulos `abre` da ferida (atalho que o deus deixa aberto ao se curar). */
  _abrirFerida(e) {
    if (!e.abre) return;
    for (const r of e.abre) for (let y = r.y; y < r.y + r.h; y++) for (let x = r.x; x < r.x + r.w; x++) if (this.map.getTileId('solid', x, y)) this.map.setTileId('solid', x, y, 0);
    invalidarOpacidade(this.map);
  }

  /** Ficar perto de uma ferida aberta com essência suficiente: segurar ~1 s fecha a ferida. */
  _atualizarFeridas(dt) {
    if (!this.progress || this.player.life <= 0) return;
    const cfg = this.config.mecanicas.ferida; const ts = this.map.tileSize; const b = this.player.body; let alvo = null;
    for (const e of this.roomData.entities || []) {
      if (e.type !== 'ferida' || this._feridaCurada(e)) continue;
      if (rectsOverlap(b.x, b.y, b.w, b.h, e.x * ts - cfg.alcance, e.y * ts - cfg.alcance, ts + 2 * cfg.alcance, ts + 2 * cfg.alcance)) alvo = e;
    }
    if (!alvo) { this._cura = null; return; }
    const custo = alvo.custo ?? cfg.custoPadrao;
    if (this.progress.essencia < custo) {
      if (!this._cura || this._cura.id !== alvo.id) { this._cura = { id: alvo.id, t: 0, falta: true }; this.toast(`Ferida aberta: pede ${custo} essências (você tem ${this.progress.essencia}). Inimigos derrotados soltam essência.`, 3600); }
      return;
    }
    if (!this._cura || this._cura.id !== alvo.id || this._cura.falta) this._cura = { id: alvo.id, t: 0 };
    this._cura.t += dt;
    if (this._cura.t >= cfg.tempoCura) { this._curar(alvo, custo); this._cura = null; }
  }

  _curar(e, custo) {
    this.progress.essencia -= custo; this.progress.collected.add(chaveItem(this.roomId, e.id));
    this.flash = 0.5; this.player.squash.kick(3); this.camera.shake(3, 0.25);
    this._abrirFerida(e); this._contarFeridas();
    const menos = this.config.mecanicas.ferida.inimigoMenosVida;
    for (const en of this.enemies) if (en.alive && en.cfg?.kind !== 'boss') en.life = Math.max(1, en.life - menos);
    this.audio.tocar('ferida'); this.toast(e.text || 'A ferida se fecha. O deus respira melhor.', 3600);
    this.logger.info('habilidades', `Ferida \"${this.roomId}.${e.id}\" curada (${custo} essências).`);
    this.saveProgress('ferida');
  }

  /** Golpe para baixo que acertou algo: Limo quica e recupera pulo e investida do ar (o jogador encadeia quiques sobre inimigos e espinhos). */
  _pogo(velocidade) {
    const p = this.player; p.vy = -velocidade; p.onGround = false; p.groundInfo = null; p.coyote = 0; p.jumpHeldSinceStart = false;
    p.airDashesLeft = this.config.dash.airDashes; p.airJumpsLeft = this.config.abilities.saltoElastico?.extraJumps || 1;
    p.squash?.kick?.(2.5); p.particles?.spawnTinta?.(p.body.x, p.body.y + p.body.h, p.body.w, 2);
  }
  _impacto(parada, tremor) { this.hitStop = parada; this.camera.shake(tremor, 0.15); }
  /** Partículas do golpe de Pseudópode ao acertar (só visual): faíscas no ponto de contato; douradas e com onda no 3º golpe. */
  _particulasGolpe(en, passo) {
    const p = this.player; const m = this.melee; const ps = p?.particles; if (!ps?.spawnImpacto) return;
    const vert = m.direcao === 'cima' ? -1 : m.direcao === 'baixo' ? 1 : 0; const dir = m.dir || p.facing || 1;
    let x; let y;
    if (en?.body) { x = en.body.x + en.body.w / 2 - (vert ? 0 : dir * en.body.w * 0.35); y = vert ? (vert < 0 ? en.body.y + en.body.h : en.body.y) : en.body.y + en.body.h / 2; }
    else { const c = m.cfgPasso || {}; x = vert ? p.centerX : p.centerX + dir * ((c.alcance || 22) + 4); y = vert ? p.centerY + vert * ((c.alcance || 22) + 4) : p.centerY; }
    ps.spawnImpacto(x, y, vert ? 0.01 : dir, !vert && passo === 2);
  }

  /** Gotas arrancadas do braço no início de cada golpe (só visual). */
  _particulasSwoosh() {
    const p = this.player; const m = this.melee; if (!p?.particles?.spawnGolpe) return;
    const vert = m.direcao === 'cima' ? -1 : m.direcao === 'baixo' ? 1 : 0; const dir = m.dir || p.facing || 1; const c = m.cfgPasso || {};
    p.particles.spawnGolpe(vert ? p.centerX : p.centerX + dir * Math.min(14, (c.alcance || 22) * 0.55), vert ? p.centerY + vert * 10 : p.centerY, vert ? 0.01 : dir, Math.max(0, m.passo));
  }

  /** Objeto interativo da Tendril: ativa uma vez, grava no progresso (mesmo conjunto das feridas) e abre os retângulos `abre`. */
  _ativarAlvoTendril(alvo) {
    const e = alvo?.source || alvo; if (!e) return;
    if (this.progress && e.id) { if (this.progress.collected.has(chaveItem(this.roomId, e.id))) return; this.progress.collected.add(chaveItem(this.roomId, e.id)); }
    if (typeof e.onTendril === 'function') e.onTendril(this);
    this._abrirFerida(e);
    this.toast(e.text || 'Algo cede ao puxão da Tendril.', 2400);
    this.logger?.info?.('habilidades', `Tendril ativou objeto "${e.id || 'interativo'}".`);
    if (this.progress) this.saveProgress('tendril');
  }

  /** Sons da Tendril (timbre próprio por evento) pelo mesmo diretor de áudio: respeita o mudo e o contexto único. */
  _tocarSomTendril(tipo) {
    const NOTAS = {   // [onda, f0, f1, duração, volume]
      connect: ['triangle', 330, 560, 0.12, 0.04], miss: ['sawtooth', 170, 90, 0.14, 0.022], lost: ['triangle', 320, 140, 0.16, 0.03],
      resist: ['square', 95, 70, 0.1, 0.03], interrupt: ['square', 640, 880, 0.08, 0.025],
    };
    if (NOTAS[tipo]) this.audio.nota(...NOTAS[tipo]);
  }

  // ---------------- objetos e passagens da sala ----------------
  _entidadeLiberada(e) {
    if (!e?.requiresBoss) return true;
    const derrotados = this.progress?.bossesDefeated || [];
    return derrotados.includes(e.requiresBoss);
  }

  _processarObjetos() {
    const ts = this.map.tileSize; const b = this.player.body;
    this._checkpointPerto = null; this._npcPerto = null;
    for (const e of this.roomData.entities || []) {
      if (e.type !== 'checkpoint' && e.type !== 'mutation' && e.type !== 'vida' && e.type !== 'encaixe' && e.type !== 'cura' && e.type !== 'echo' && e.type !== 'gene') continue;
      if (!this._entidadeLiberada(e)) continue;
      if (!rectsOverlap(b.x, b.y, b.w, b.h, e.x * ts, e.y * ts, ts, ts)) continue;
      if (e.type === 'checkpoint') this._tocarCheckpoint(e);
      else if (e.type === 'gene') { if (!this.progress.genes?.has(e.gene)) this._coletarGene(e); }
      else if (!this.progress.collected.has(chaveItem(this.roomId, e.id))) {
        if (e.type === 'vida') this._coletarVida(e);
        else if (e.type === 'encaixe') this._coletarEncaixe(e);
        else if (e.type === 'cura') this._coletarCura(e);
        else if (e.type === 'echo') this._coletarEco(e);
        else this._coletarMutacao(e);
      }
    }
    // v1.43: NPC por perto (mesma regra de proximidade para teclado e toque; o botão de interação é o mesmo do casulo)
    if (!this._checkpointPerto) for (const e of this.roomData.entities || []) { if (e.type === 'npc' && this._entidadeLiberada(e) && this._pertoDoNpc(e)) { this._npcPerto = e; break; } }
    this.ui?.interagir?.(!!(this._checkpointPerto || this._npcPerto), this._npcPerto ? 'conversar' : 'descansar');   // botão de toque só aparece perto do casulo ou de um NPC
    if (this._checkpointPerto && this._queroDescansar()) this._descansar(this._checkpointPerto);
    else if (this._npcPerto && this._queroDescansar()) this._abrirDialogo(this._npcPerto);
  }

  /** O Limo está a menos de ~1,75 tile (horizontal) e ~1,25 tile (vertical) do centro do NPC? */
  _pertoDoNpc(e) {
    const ts = this.map.tileSize; const n = this.npcsVivos.get(e.id);   // v1.45: NPC que anda é medido pela posição VIVA; sem rotina, pelo tile fixo
    const dx = Math.abs(this.player.centerX - (n ? n.centerX : (e.x + 0.5) * ts)); const dy = Math.abs(this.player.centerY - (n ? n.centerY : (e.y + 0.5) * ts));
    return dx <= ts * 1.75 && dy <= ts * 1.25;
  }

  /**
   * v1.43: conversa com um NPC (caixa de diálogo em canvas). O jogo fica suspenso só enquanto a caixa está aberta;
   * fechar (último texto, Esc ou B) devolve o controle. Sem a caixa (testes/headless) não faz nada.
   */
  _abrirDialogo(e) {
    const dlg = this.ui?.dialogo; if (!dlg || !e?.falas?.length || this.suspended) return false;
    const fala = escolherFalas(e, this.sandbox || this.expedicao ? null : this.progress);   // v1.44.0: variante conforme o progresso (padrão = fala da sala)
    this.suspended = 'dialogo'; this._npcFalando = e; this.input.releaseAll(); this.input.endStep();
    this.foco.cancelar('dialogo'); this.melee.cancelar(); this.tendril.stop('dialogo'); this.player.vx = 0;
    const vivo = this.npcsVivos.get(e.id); if (vivo) { vivo.pausar('conversa'); vivo.virarPara(this.player.centerX); }   // v1.45: ele para e olha para o Limo enquanto conversam
    const naTela = (vivo ? vivo.centerY : (e.y + 0.5) * this.map.tileSize) - this.camera.y;   // NPC na metade de baixo da tela → caixa no alto (e vice-versa)
    // v2.1: a Jardineira, enquanto fala, é o ponto de atenção das plantas vizinhas (reuso do ecossistema)
    const focaPlantas = e.npc === 'jardineira' && this.vivo; if (focaPlantas) this.vivo.definirFoco(vivo ? vivo.centerX : (e.x + 0.5) * this.map.tileSize, vivo ? vivo.centerY : (e.y + 0.5) * this.map.tileSize);
    const ok = dlg.abrir({ nome: e.nome, falas: fala.falas, npc: e.npc, topo: naTela > this.config.render.internalHeight * 0.5, aoFechar: () => {
      if (this.suspended === 'dialogo') this.suspended = null; this._npcFalando = null; vivo?.retomar('conversa'); if (focaPlantas) this.vivo?.limparFoco();   // v1.45: retoma de onde parou
      this.input.releaseAll(); this.input.endStep();
    } });
    if (!ok) { this.suspended = null; this._npcFalando = null; vivo?.retomar('conversa'); return false; }
    for (const m of fala.marcas) this._descobrir(m);   // silencioso (sem aviso): só lembra que conversaram, para a próxima variante
    this.logger.info('interface', `Conversa com "${e.nome}" (${this.roomId}.${e.id}) · ${fala.id}.`); return true;
  }

  /**
   * CASULO DE REPOUSO (checkpoint). Encostar só DESCOBRE o casulo (vira destino da viagem rápida) e mostra o convite;
   * quem restaura a vida, grava o renascimento e abre a tela de genes é DESCANSAR: ↑ / E / joystick para cima / botão de toque.
   */
  _tocarCheckpoint(e) {
    this._checkpointPerto = e;
    const chave = `${this.roomId}:${e.id}`;
    if (!this.progress.bancos?.has(chave)) {
      (this.progress.bancos ||= new Set()).add(chave); this.toast('Casulo de Repouso descoberto', 2400); this.saveProgress('banco');
    }
  }

  _queroDescansar() {
    const p = this.player;
    if (!p || p.life <= 0 || p.dashing || p.tendrilPulling || p.hurtTimer > 0 || !p.onGround || this.suspended || this.paused || this.transition.active) return false;
    return !!(this.input.wasPressed('interact') || this.input.wasPressed('up'));
  }

  _descansar(e) {
    const chave = `${this.roomId}:${e.id}`;
    this.progress.checkpoint = { sala: this.roomId, id: e.id };
    (this.progress.bancos ||= new Set()).add(chave);
    if (this.config.player.healAtCheckpoint) this.player.life = this.player.maxLife;
    this.player.vx = 0; this.player.squash.kick(1.5); this.flash = 0.22;
    this.audio.tocar('checkpoint');
    this.logger.info('salvamento', `Descansou no casulo "${this.roomId}.${e.id}".`);
    this.saveProgress('repouso');
    this._abrirGenes();
  }

  /** v1.39.0: catálogo de descobertas. Abre do HUD, do menu de pausa (volta para a pausa ao fechar) ou da tecla C. */
  abrirCatalogo() {
    const menu = this.ui?.catalogoMenu; if (!menu || menu.open || this.editing || !this.progress) return false;
    if (this.suspended && this.suspended !== 'catalogo') return false;
    const veioDaPausa = this.paused; if (veioDaPausa) this.resume();
    this.suspended = 'catalogo'; this.input.releaseAll(); this.foco.cancelar('catalogo'); this.melee.cancelar(); this.tendril.stop('catalogo');
    menu.abrir({ progress: this.progress, world: this.world, aoFechar: () => {
      if (this.suspended === 'catalogo') this.suspended = null; this.input.releaseAll(); this.input.endStep();
      if (veioDaPausa) this.pause();
    } });
    return true;
  }

  /** Tela de genes (canvas): o jogo fica suspenso enquanto ela está aberta. Sem menu (testes/headless), só descansa. */
  _abrirGenes() {
    const menu = this.ui?.genesMenu; if (!menu) return false;
    this.suspended = 'genes'; this.input.releaseAll(); this.foco.cancelar('repouso'); this.melee.cancelar(); this.tendril.stop('repouso');
    menu.abrir({
      progress: this.progress,
      aoMudar: () => this._aplicarGenes(),
      aoFechar: () => {
        if (this.suspended === 'genes') this.suspended = null;
        this.input.releaseAll(); this.input.endStep(); this._aplicarGenes(); this.saveProgress('genes');
      },
    });
    return true;
  }

  /** Efeitos dos genes equipados → jogador (invulnerabilidade, investida) e foco (tempo de cura). */
  _aplicarGenes() {
    const m = calcularModificadores(this.progress?.genesEquipados || []);
    if (this.player) this.player.genes = m;
    if (this.foco) this.foco.tempoMul = m.focoTempoMul;
    return m;
  }

  _coletarGene(e) {
    const g = geneDe(e.gene); if (!g || !g.implementado || !this.progress.obterGene(e.gene)) return;
    this.player.squash.kick(4); this.flash = 0.45; this._impacto(0.12, 2.5);
    this.audio.tocar('mutacao'); this.toast(`Gene encontrado: ${g.nome}. Equipe-o num Casulo de Repouso.`, 4200);
    this.logger.info('habilidades', `Gene "${g.id}" encontrado em "${this.roomId}".`);
    this.saveProgress('gene');
  }

  /** Fragmentos de Carne (como as máscaras de Hollow Knight / tanques de Metroid): cada um sobe a vida máxima em 1. */
  _vidaExtra() {
    let n = 0;
    for (const k of this.progress.collected) { const [sala, id] = k.split(':'); if (this.world.get(sala)?.entities?.some((en) => en.id === id && en.type === 'vida')) n++; }
    return n;
  }

  /** Bulbos de Encaixe já colhidos (cada um = +1 encaixe de gene). Recontado a partir das salas, como a vida. */
  _encaixesColhidos() {
    let n = 0;
    for (const k of this.progress.collected) { const [sala, id] = k.split(':'); if (this.world.get(sala)?.entities?.some((en) => en.id === id && en.type === 'encaixe')) n++; }
    return n;
  }

  _coletarEncaixe(e) {
    this.progress.collected.add(chaveItem(this.roomId, e.id));
    this.progress.encaixesExtra = Math.max(this.progress.encaixesExtra | 0, this._encaixesColhidos());
    this.flash = 0.5; this._impacto(0.25, 3); this.player.squash.kick(4);
    this.audio.tocar('encaixe'); this.toast(`Bulbo de Encaixe: ${this.progress.encaixes} encaixes de gene (+1 permanente)`, 4200);
    this.logger.info('habilidades', `Bulbo de Encaixe "${this.roomId}.${e.id}" coletado (encaixes ${this.progress.encaixes}).`);
    this.saveProgress('encaixe');
  }

  _recalcularVidaMax(curar) {
    if (this.progress) this.progress.encaixesExtra = Math.max(this.progress.encaixesExtra | 0, this._encaixesColhidos());
    const m = this.config.player.maxLife + this._vidaExtra();
    this.player.maxLife = m; if (curar) this.player.life = m;
  }

  _coletarVida(e) {
    this.progress.collected.add(chaveItem(this.roomId, e.id));
    this._recalcularVidaMax(true);
    this.flash = 0.5; this._impacto(0.25, 3); this.player.squash.kick(4);
    this.audio.tocar('vida'); this.toast('Fragmento de Carne: vida máxima +1');
    this.logger.info('habilidades', `Fragmento de vida \"${this.roomId}.${e.id}\" coletado (vida máx. ${this.player.maxLife}).`);
    this.saveProgress('vida');
  }

  /** Vesícula de seiva: cura local reutilizável, sem virar recompensa permanente. */
  _coletarCura(e) {
    if (this.player.life >= this.player.maxLife) return;
    this.player.life = this.player.maxLife; this.player.squash.kick(2); this.flash = 0.2;
    this.audio.tocar('checkpoint'); this.toast('Seiva restaurou sua vida');
    this.logger.info('habilidades', `Cura em \"${this.roomId}.${e.id}\" usada.`);
  }

  _coletarEco(e) {
    this.progress.collected.add(chaveItem(this.roomId, e.id));
    const casulo = ehCasulo(this.roomId, e.id);   // v1.51.0: casulo vazio ganha um aviso mais longo e um sino
    this.flash = casulo ? 0.4 : 0.25; this.player.squash.kick(casulo ? 2.2 : 1.5);
    this.toast(e.text, casulo ? 6200 : 4400); if (casulo) this.audio?.tocar?.('mural');
    this.logger.info('habilidades', `Eco de memória "${this.roomId}.${e.id}" registrado.`);
    this.saveProgress('eco');
  }

  _coletarMutacao(e) {
    this.progress.abilities[e.ability] = true;                      
    this.progress.collected.add(chaveItem(this.roomId, e.id));
    this.player.squash.kick(5);
    this.flash = 0.7; this.cutscene = { id: e.ability, t: 0 };   // clarão + cena de nova mutação
    const nome = ABILITIES[e.ability] ? ABILITIES[e.ability].nome : e.ability;
    this.audio.tocar(e.ability === 'instanteVital' ? 'essenciaVital' : 'mutacao'); this.toast(e.ability === 'instanteVital' ? `Essência preservada: ${nome}!` : `Mutação adquirida: ${nome}!`);
    const abre = passagensDaHabilidade(this.world, this.progress, e.ability);   // o que ela abre entre as passagens já vistas
    const uso = ABILITIES[e.ability]?.uso;
    this.cutscene.uso = uso || ''; this.cutscene.abre = abre.length ? `Abre ${abre.length} passagem(ns) que você já viu: ${[...new Set(abre.map((a) => a.sala))].slice(0, 2).join(', ')}${abre.length > 2 ? '…' : ''}` : '';
    this.progress.novaHabilidade = e.ability; this._salaDaNovaHabilidade = this.roomId;   // o HUD destaca o ícone até a próxima sala
    this.logger.info('habilidades', `Mutação "${e.ability}" adquirida em "${this.roomId}.${e.id}".`);
    this.saveProgress('mutacao');
  }

  /** O jogador está tocando (ou a poucos px de) o limite da sala numa abertura? (v1.40.1: vale a borda, não o tile) */
  _naZonaDeTransicao() {
    const b = this.player.body;
    return (this.roomData.connections || []).some((c) => tocaBorda(this.roomData, c, b, 3));
  }

  _atualizarBloqueioDaChegada() {
    if (!this._passagemChegadaBloqueada || !this.roomData?.connections) return;
    const c = this.roomData.connections.find((q) => q.id === this._passagemChegadaBloqueada);
    if (!c) { this._passagemChegadaBloqueada = null; return; }
    // a passagem de retorno só volta a valer depois que o corpo se afasta da borda (sem temporizador)
    if (!tocaBorda(this.roomData, c, this.player.body, 3)) this._passagemChegadaBloqueada = null;
  }

  _progressoDaAberturaLateral(c) {
    const t = c?.trigger;
    if (!t || !this.roomData || !this.map) return null;
    const lateral = t.x <= 0 || t.x + t.w >= this.roomData.width;
    if (!lateral || t.h <= 0) return null;
    // Usa o centro real do corpo no instante em que ele cruza a porta.
    // O valor normalizado preserva a altura relativa na abertura pareada.
    const centroY = this.player.body.y + this.player.body.h / 2;
    const inicio = t.y * this.map.tileSize;
    const altura = t.h * this.map.tileSize;
    return Math.max(0, Math.min(1, (centroY - inicio) / altura));
  }

  /**
   * v1.40.1: a troca de sala acontece ao TOCAR O LIMITE da sala (ver world/borda.js), não ao entrar no
   * retângulo de tiles da passagem. O `trigger` continua dizendo onde está a abertura (arte, luz, barreira,
   * trecho do limite que vale). Passagem selada continua avisando quando o corpo chega perto do retângulo.
   */
  _processarConexoes() {
    if (!this.roomData.connections) return;
    const b = this.player.body;
    for (const c of this.roomData.connections) {
      const r = this.world.triggerRect(this.roomData, c);
      const tocando = tocaBorda(this.roomData, c, b);
      const perto = tocando || rectsOverlap(b.x, b.y, b.w, b.h, r.x - 3, r.y - 3, r.w + 6, r.h + 6);
      if (!perto || c.id === this._passagemChegadaBloqueada) continue;
      const progressoAbertura = tocando ? this._progressoDaAberturaLateral(c) : null;
      const res = this.world.resolveTransition(this.roomId, c.id, this.progress.abilities, this.roomData, progressoAbertura, this.progress.genesEquipados);
      if (!res.ok) { this._avisarPassagem(c, res); continue; }
      if (tocando) { this._transitar(c, res); return; }
    }
  }


  _avisarPassagem(c, res) {
    const chave = chaveItem(this.roomId, c.id);
    if (res.reason === 'bloqueada') this.progress.blockedFound.add(chave);
    else if (!this._errosConexao.has(chave)) { this._errosConexao.add(chave); this.logger.error('transicoes', `Transição bloqueada (${res.reason}): ${res.message}`); }
    const ultimo = this._avisos.get(chave);
    if (ultimo === undefined || this._tempoJogo - ultimo > 2.5) { this._avisos.set(chave, this._tempoJogo); this.toast(res.reason === 'bloqueada' ? res.message : 'Passagem indisponível.'); }
  }

  _transitar(c, res) {
    if (normalizeRequires(c.requires).length) this.progress.opened.add(chaveItem(this.roomId, c.id));
    this.logger.info('transicoes', `${this.roomId}.${c.id} -> ${res.toRoom}.${res.toConnection || '?'}`);
    this._irParaSala(res.toRoom, res.spawn, 'transicao', res.toConnection);
  }

  /** Fecha a tela em volta do jogador, troca de sala e deixa o enterRoom abrir a nova. */
  _irParaSala(id, spawn, motivo, arrivalConnection = null) {
    if (this.transition.active) return;
    this.tendril.stop('room-change'); this.melee.cancelar(); this.foco.cancelar('sala'); this.instante?.reset();
    const cam = this.camera;
    // v1.36: mudar de bioma é uma viagem — íris mais lenta, borda na cor do destino e um som próprio
    const plano = planoDeTransicao(this.roomData?.biome, this.world?.get?.(id)?.biome, { out: this.config.transition?.outTime ?? 0.28, in: this.config.transition?.inTime ?? 0.4 });
    this._planoTransicao = plano;
    if (motivo === 'transicao' || plano.muda) this.audio?.tocar?.(plano.som, plano.muda ? 1 : 0.6);
    this.transition.out(plano.out, this.player.centerX - cam.x, this.player.centerY - cam.y, () => {
      this.enterRoom(id, { spawnPx: spawn, arrivalConnection });
      this.saveProgress(motivo);
    }, plano.cor);
  }

  // ---------------- desenho ----------------
  render() {
    if (!this.renderer) return;
    if (this.customRender) { this.customRender(); return; }
    this.renderer.render(this);
    this.ui?.hud?.update(this.player, { novaHabilidade: this.progress?.novaHabilidade || null, sala: this.roomData?.name || this.roomId, essencia: this.progress?.essencia ?? 0, atacando: this.melee.ocupado, material: this.foco.material, materialMax: this.foco.config.materialMax, focoPronto: this.foco.pronto, focando: this.foco.ativo, focoProgresso: this.foco.progresso });
  }

  // ---------------- laço principal ----------------
  start() {
    if (this.running) return;
    this.running = true; this.lastTime = null;
    const laco = (t) => { if (!this.running) return; this.frame(t); this._rafId = globalThis.requestAnimationFrame(laco); };
    this._rafId = globalThis.requestAnimationFrame(laco);
  }

  stop() { this.running = false; if (this._rafId != null && globalThis.cancelAnimationFrame) globalThis.cancelAnimationFrame(this._rafId); }

  /** Um quadro de tela síncrono. */
  frame(agoraMs) {
    const inicio = agora();
    this.beforeFrame?.();
    const dtReal = this.lastTime == null ? 0 : Math.min((agoraMs - this.lastTime) / 1000, this.config.loop.maxFrameTime);
    this.lastTime = agoraMs;
    if (this.suspended === 'dialogo') this.ui?.dialogo?.update(dtReal, this.input);   // v1.43: o jogo está suspenso; só o texto anda
    const m = this.metrics;
    m.dt = dtReal;
    if (dtReal > 0) m.fps = m.fps ? m.fps * 0.9 + (1 / dtReal) * 0.1 : 1 / dtReal;

    this._tempoLogica = 0;
    let passos = 0;
    if (!this.paused && !this.editing && !this.suspended) {
      const passo = this.config.loop.fixedStep;
      this.accumulator += dtReal;
      while (this.accumulator >= passo && passos < this.config.loop.maxStepsPerFrame) {
        this.fixedUpdate(passo); 
        this.accumulator -= passo; 
        passos++;
      }
      if (passos === this.config.loop.maxStepsPerFrame && this.accumulator >= passo) {
        this.accumulator = 0; m.slowFrames++;
        this.logger.warn('fisica', 'Aparelho lento: passos de física descartados para recuperar o tempo.');
      }
    }
    m.stepsLastFrame = passos; m.updateMs = this._tempoLogica;

    const r0 = agora();
    this.render();
    m.renderMs = agora() - r0;
    m.frameMs = agora() - inicio;
  }

  // ---------------- pausa ----------------
  pause() { 
    if (this.paused) return; 
    this.paused = true; 
    this.tendril.stop('paused'); this.melee.cancelar(); this.foco.cancelar('pausa'); this.audio.pausar(true);
    this.input.releaseAll(); 
    this.ui?.screens?.setPause(true); 
    this.logger.info('interface', 'Jogo pausado.'); 
  }
  
  resume() { 
    if (!this.paused) return; 
    this.paused = false; this.audio.pausar(false);
    this.lastTime = null; 
    this.ui?.screens?.setPause(false); 
    this.logger.info('interface', 'Jogo retomado.'); 
  }

  togglePause() { if (this.paused) this.resume(); else this.pause(); }

  /** Avança exatamente um passo de física (só quando pausado; usado pelo debug). */
  stepOnce() {
    if (!this.paused) return false;
    this.fixedUpdate(this.config.loop.fixedStep);
    this.render();
    return true;
  }

  // ---------------- ferramentas de desenvolvimento ----------------
  teleportPlayer(x, y) {
    this.player.teleport(x, y); this.player.lastSafe = { x, y };
    this.snapCamera();
    this.logger.info('fisica', `Teleporte para (${Math.round(x)}, ${Math.round(y)}).`);
  }

  restoreLife() {
    this.player.life = this.player.maxLife; this.player.invuln = 0;
    if (this.player.state === 'dead') this.player.state = 'idle';
    this.deadTimer = 0; this.defeatShown = false; this.ui?.screens?.showDefeat(false);
  }

  applyConfigChanges() { this.renderer?.resize?.(); }
}
