// =====================================================================
// ÁUDIO — ambiente por bioma + efeitos curtos, 100% sintetizado (Web Audio, sem arquivos).
// Sem AudioContext (testes/Node) tudo é silencioso e inofensivo. O som só começa depois de um gesto do jogador.
//  raizes = pulso grave de coração · jardim = drone verde com gotas agudas · núcleo = drone dissonante e eco
//  + MÚSICA: violão de nylon melancólico ao fundo (arpejos lentos em tom menor, ver musica.js), com reverb de caverna.
// =====================================================================
import { SUPERFICIE, SFX_DE_SUPERFICIE } from '../render/polimento.js';
import { GeradorMusica, PERFIS_MUSICA, renderPluck, midiParaHz, notasDoAcorde } from './musica.js';
export const PERFIS_BIOMA = {
  // Ambiente ORGÂNICO, sem drone contínuo (nada de "zumbido de geladeira"): um sopro de ruído filtrado que respira + eventos esparsos.
  //  ruido: {freq, q, vol} = o "ar" da caverna · notas: escala dos toques longos (Hz) · gotas/esguicho: eventos aleatórios · batida: pulso do Deus
  // Frases lentas em menor: duas notas suaves formam uma pequena melodia, sem virar trilha invasiva.
  raizes: { ruido: { freq: 160, q: 0.7, vol: 0.018 }, notas: [73.4, 87.3, 110, 130.8], notaOnda: 'sine', notaVol: 0.021, notaCada: [9, 16], harmonia: 1.5, respiraCada: [22, 42], batida: { bpm: 46, vol: 0.036, eco: false }, gotas: false, esguicho: true },
  jardim: { ruido: { freq: 900, q: 0.5, vol: 0.012 }, notas: [220, 261.6, 329.6, 392, 440], notaOnda: 'triangle', notaVol: 0.012, notaCada: [8, 15], harmonia: 1.25, respiraCada: [24, 46], batida: { bpm: 32, vol: 0.018, eco: false }, gotas: true, esguicho: false },
  nucleo: { ruido: { freq: 240, q: 1.4, vol: 0.016 }, notas: [46.2, 55, 69.3, 82.4], notaOnda: 'sine', notaVol: 0.022, notaCada: [10, 18], harmonia: 1.5, respiraCada: [26, 50], batida: { bpm: 40, vol: 0.036, eco: true }, gotas: false, esguicho: false },
};
/** Efeitos: [onda, f0, f1, duração s, volume, atraso?] ou ['ruido', duração, volume, freqFiltro, atraso?] (camada de "gosma": ruído filtrado). */
export const SFX = {
  // Bipe de confirmação: toca uma vez ao liberar áudio no primeiro toque.
  teste_audio: [['sine', 440, 660, 0.16, 0.10], ['triangle', 660, 880, 0.18, 0.085, 0.12]],
  // v1.38.0: segredo descoberto (a rocha viva cede, com um brilho) e mural revelado (um sino curto e baixo).
  segredo: [['ruido', 0.22, 0.03, 380], ['sine', 110, 70, 0.3, 0.045], ['triangle', 392, 587, 0.22, 0.03, 0.12], ['triangle', 587, 784, 0.3, 0.03, 0.22]],
  mural: [['sine', 523, 523, 0.25, 0.025], ['sine', 784, 784, 0.4, 0.02, 0.1]],
  // Dano: uma bolha comprimida e uma gota que escorre, sem timbre metálico.
  dano: [['sine', 280, 115, 0.18, 0.046], ['ruido', 0.16, 0.030, 420], ['sine', 680, 160, 0.13, 0.024, 0.035]], morte: [['sawtooth', 180, 40, 0.5, 0.06]],
  focoInicio: [['sine', 180, 260, 0.18, 0.03]], focoCarga: [['sine', 300, 380, 0.09, 0.022]], focoVazio: [['square', 120, 90, 0.1, 0.025]],
  focoCura: [['triangle', 392, 392, 0.09, 0.04], ['triangle', 523, 523, 0.09, 0.04, 0.08], ['triangle', 784, 784, 0.2, 0.045, 0.16], ['ruido', 0.12, 0.02, 2200, 0.1]],
  checkpoint: [['triangle', 392, 392, 0.1, 0.04], ['triangle', 523, 523, 0.16, 0.04, 0.1]],
  vida: [['triangle', 440, 660, 0.12, 0.04]], ferida: [['sine', 150, 90, 0.35, 0.06], ['triangle', 330, 495, 0.2, 0.04, 0.2]],
  // v1.40.0 — Instante Vital. Aquisição: sino grave que abre em acorde suave + respiro de ruído (essência acordando).
  essenciaVital: [['sine', 196, 196, 0.5, 0.04], ['triangle', 294, 294, 0.45, 0.034, 0.18], ['triangle', 440, 440, 0.5, 0.034, 0.36], ['sine', 587, 880, 0.9, 0.04, 0.58], ['ruido', 0.7, 0.012, 1800, 0.3]],
  // Uso: ao concluir a cura — uma batida de coração que desce (o tempo hesita) e sobe de volta.
  instanteVital: [['sine', 150, 62, 0.2, 0.05], ['triangle', 520, 300, 0.16, 0.018, 0.02], ['sine', 330, 495, 0.14, 0.02, 0.12]],
  mutacao: [['triangle', 330, 330, 0.12, 0.045], ['triangle', 440, 440, 0.12, 0.045, 0.12], ['triangle', 660, 660, 0.3, 0.05, 0.24]],
  golpe0: [['sawtooth', 320, 170, 0.07, 0.028], ['ruido', 0.05, 0.015, 1500]], golpe1: [['sawtooth', 360, 190, 0.07, 0.028], ['ruido', 0.05, 0.015, 1700]], golpe2: [['sawtooth', 220, 90, 0.14, 0.045], ['square', 440, 200, 0.1, 0.025, 0.02], ['ruido', 0.1, 0.03, 1100]],
  acerto: [['square', 170, 60, 0.09, 0.05], ['ruido', 0.08, 0.04, 600]],
  // --- combate v1.35: cada ataque anunciado tem aviso e golpe com timbres próprios ---
  aviso_bote: [['sine', 110, 150, 0.30, 0.03]], bote: [['sawtooth', 240, 120, 0.12, 0.04], ['ruido', 0.08, 0.02, 900]],
  aviso_salto: [['sine', 130, 200, 0.26, 0.03]], aviso_escudada: [['triangle', 90, 130, 0.5, 0.04], ['ruido', 0.2, 0.015, 500]],
  escudada: [['sawtooth', 110, 70, 0.3, 0.05], ['ruido', 0.2, 0.03, 400]], aviso_mergulho: [['sine', 520, 620, 0.40, 0.02], ['triangle', 780, 900, 0.2, 0.012, 0.3]],
  mergulho: [['sawtooth', 600, 180, 0.3, 0.035]], atordoar: [['triangle', 500, 300, 0.2, 0.03], ['triangle', 380, 250, 0.2, 0.03, 0.1]],
  bate_parede: [['square', 100, 50, 0.1, 0.05], ['ruido', 0.1, 0.05, 300]],
  aparar: [['square', 900, 700, 0.06, 0.04], ['ruido', 0.05, 0.03, 4000]], quebra_guarda: [['square', 700, 120, 0.2, 0.05], ['ruido', 0.2, 0.05, 2500], ['sine', 80, 50, 0.25, 0.05]],
  contragolpe: [['square', 300, 700, 0.1, 0.05], ['sine', 880, 1200, 0.12, 0.035, 0.05], ['ruido', 0.1, 0.04, 1800]],
  acerto_pesado: [['square', 130, 40, 0.16, 0.06], ['ruido', 0.14, 0.05, 500]], membrana_reflexo: [['sine', 300, 700, 0.25, 0.04], ['triangle', 500, 220, 0.3, 0.03, 0.05]],
  aviso_chamado: [['sine', 70, 110, 0.7, 0.04]], atq_chamado: [['triangle', 180, 260, 0.2, 0.04], ['ruido', 0.2, 0.03, 700]],
  aviso_cavalgada: [['sine', 80, 120, 0.5, 0.04]], atq_cavalgada: [['sawtooth', 160, 90, 0.35, 0.05]],
  aviso_pisada: [['sine', 60, 90, 0.7, 0.045]], atq_pisada: [['square', 70, 35, 0.4, 0.06], ['ruido', 0.3, 0.05, 250]],
  aviso_mordida: [['triangle', 200, 260, 0.4, 0.03]], atq_mordida: [['sawtooth', 300, 120, 0.15, 0.05], ['ruido', 0.1, 0.04, 1200]],
  aviso_onda: [['sine', 90, 150, 0.6, 0.04]], atq_onda: [['sawtooth', 120, 60, 0.7, 0.05]],
  aviso_rugido: [['sine', 70, 130, 0.75, 0.05]], atq_rugido: [['sawtooth', 100, 50, 0.55, 0.06], ['ruido', 0.5, 0.04, 400]],
  aviso_sistole: [['sine', 55, 80, 0.7, 0.05]], atq_sistole: [['sine', 70, 40, 0.3, 0.07], ['sine', 70, 40, 0.3, 0.07, 0.25]],
  aviso_espinhos: [['triangle', 150, 100, 0.8, 0.03]], atq_espinhos: [['square', 90, 200, 0.25, 0.05], ['ruido', 0.25, 0.04, 1500]],
  // --- movimento do Limo: gosma + tom, com volume/variação por intensidade ---
  pulo: [['sine', 145, 255, 0.14, 0.027], ['ruido', 0.08, 0.014, 520]],
  pulo_duplo: [['sine', 175, 330, 0.16, 0.030], ['ruido', 0.07, 0.013, 760], ['triangle', 290, 390, 0.11, 0.016, 0.05]],
  pouso: [['sine', 130, 64, 0.16, 0.034], ['ruido', 0.10, 0.021, 340]],
  pouso_forte: [['sine', 92, 38, 0.24, 0.052], ['ruido', 0.18, 0.036, 280]],
  passo: [['ruido', 0.05, 0.008, 250], ['sine', 98, 76, 0.08, 0.014]],
  investida: [['ruido', 0.18, 0.025, 620], ['sine', 118, 52, 0.22, 0.032]],
  parede: [['ruido', 0.11, 0.020, 540], ['sine', 170, 105, 0.10, 0.014]],
  derrapar: [['ruido', 0.15, 0.021, 480], ['sine', 95, 70, 0.12, 0.010]],
  quebrar: [['ruido', 0.28, 0.07, 300], ['sine', 120, 40, 0.3, 0.06], ['square', 200, 70, 0.1, 0.02]],
  chefe: [['sawtooth', 110, 55, 0.5, 0.06], ['triangle', 262, 524, 0.4, 0.05, 0.3]],
  teia_nasce: [['sine', 72, 44, 0.65, 0.050], ['ruido', 0.34, 0.018, 310]],
  teia_ruptura: [['ruido', 0.18, 0.030, 980], ['triangle', 190, 92, 0.32, 0.032]],
  teia_tear_aviso: [['sine', 88, 128, 0.20, 0.024]], teia_stitch_aviso: [['triangle', 210, 250, 0.16, 0.018]],
  teia_return_aviso: [['ruido', 0.12, 0.016, 700]], teia_pulse_aviso: [['sine', 58, 76, 0.30, 0.030]],
  teia_tear: [['ruido', 0.16, 0.031, 840], ['sine', 140, 64, 0.23, 0.032]], teia_stitch: [['triangle', 260, 160, 0.18, 0.028], ['ruido', 0.08, 0.014, 1100]],
  teia_return: [['sine', 120, 72, 0.28, 0.034], ['ruido', 0.16, 0.016, 530]], teia_pulse: [['sine', 62, 38, 0.45, 0.044], ['triangle', 148, 96, 0.32, 0.020]],
  // Respostas do mundo: entrada, derrota comum e membranas da arena. Todas continuam orgânicas e curtas.
  // v1.36: viagens entre salas e entre biomas (cada bioma tem seu "portal" sonoro)
  transicao_sala: [['ruido', 0.22, 0.016, 320], ['sine', 110, 70, 0.26, 0.016]],
  bioma_raizes: [['ruido', 0.5, 0.03, 220], ['sine', 98, 55, 0.7, 0.04], ['triangle', 147, 98, 0.6, 0.02, 0.15]],
  bioma_jardim: [['ruido', 0.45, 0.02, 1400], ['triangle', 330, 495, 0.5, 0.03], ['sine', 495, 660, 0.55, 0.02, 0.18]],
  bioma_nucleo: [['ruido', 0.6, 0.026, 260], ['sine', 55, 41, 0.9, 0.055], ['sine', 220, 330, 0.8, 0.02, 0.2], ['sine', 330, 440, 0.8, 0.015, 0.4]],
  encaixe: [['triangle', 392, 392, 0.1, 0.04], ['triangle', 587, 587, 0.1, 0.04, 0.09], ['sine', 880, 1175, 0.4, 0.05, 0.18], ['ruido', 0.2, 0.012, 3000, 0.2]],
  entrada_sala: [['ruido', 0.34, 0.020, 240], ['sine', 78, 54, 0.42, 0.020, 0.07]],
  inimigo_cai: [['ruido', 0.22, 0.031, 390], ['sine', 155, 65, 0.26, 0.025]],
  arena_fecha: [['ruido', 0.34, 0.029, 190], ['sine', 95, 48, 0.46, 0.028, 0.05]],
  arena_abre: [['ruido', 0.22, 0.017, 460], ['triangle', 64, 138, 0.32, 0.020, 0.06]],
};
const CHAVE = 'limo.audio.mudo';

export class AudioDirector {
  constructor({ factory = null, storage = null, rand = Math.random, musica = true } = {}) {
    this.rand = rand; this.musicaLigada = !!musica; this.bus = null; this.musicaEstado = null; this._cordas = new Map();   // variação de tom entre repetições (injetável para testes)
    const AC = typeof globalThis !== 'undefined' ? (globalThis.AudioContext || globalThis.webkitAudioContext) : null;
    this.factory = factory || (AC ? () => new AC() : null);
    this.storage = storage ?? (typeof localStorage !== 'undefined' ? localStorage : null);
    this.ctx = null; this.master = null; this.camada = null; this.bioma = null; this.pausado = false; this._t = 0; this._prox = 1; this.volume = 3.0; this._confirmouSom = false;
    // A sala define apenas o espaço sonoro. Não toca em física, IA, colisões ou progressão.
    this.acustica = { intensidade: 0, repeticoes: 0, atraso: 0, ganho: 0 };
    this.mudo = false; try { this.mudo = this.storage?.getItem(CHAVE) === '1'; } catch { /* storage indisponível */ }
  }

  /** Chamar a partir de um gesto do jogador (toque/tecla): cria/retoma o contexto e liga o ambiente. */
  desbloquear() {
    if (!this.factory) return false;
    try {
      if (!this.ctx) { this.ctx = this.factory(); this.master = this.ctx.createGain(); this.master.gain.value = this.mudo ? 0 : this.volume; this.master.connect(this.ctx.destination); this._montarBusMusica(); }
      const retomada = this.ctx.resume?.();
      const pronto = () => { if (this.bioma) { const b = this.bioma; this.bioma = null; this.setBioma(b); } if (!this.mudo && !this._confirmouSom) { this._confirmouSom = true; this.tocar('teste_audio'); } };
      if (retomada?.then) retomada.then(pronto).catch(() => {}); else pronto();
      return true;
    } catch { this.ctx = null; return false; }
  }

  setMudo(v) {
    this.mudo = !!v; try { this.storage?.setItem(CHAVE, this.mudo ? '1' : '0'); } catch { /* ok */ }
    if (this.master) this.master.gain.setTargetAtTime(this.mudo ? 0 : (this.pausado ? this.volume * 0.3 : this.volume), this.ctx.currentTime, 0.05);
    return this.mudo;
  }
  toggleMudo() { return this.setMudo(!this.mudo); }

  /** Pausa deixa o ambiente baixo (30%), sem cortar. */
  pausar(v) { this.pausado = !!v; if (this.master && !this.mudo) this.master.gain.setTargetAtTime(v ? this.volume * 0.3 : this.volume, this.ctx.currentTime, 0.1); }

  /** Normaliza a acústica por área em tiles. Salas de 30×14 quase secas; salões perto de 44×18 ganham até 4 caudas discretas. */
  setSalaAcustica(largura = 0, altura = 0) {
    const area = Math.max(0, Number(largura) * Number(altura));
    const intensidade = Math.max(0, Math.min(1, (area - 420) / 380));
    this.acustica = {
      intensidade,
      repeticoes: intensidade < 0.14 ? 0 : 1 + Math.floor(intensidade * 3),
      atraso: 0.11 + intensidade * 0.12,
      ganho: 0.075 + intensidade * 0.065,
    };
    return this.acustica;
  }

  /** Troca a camada ambiente com crossfade; mesmo bioma = nada a fazer. */
  setBioma(id) {
    if (id === this.bioma) return; this.bioma = id;
    if (!this.ctx) return;                           // ainda sem gesto: guarda e aplica em desbloquear()
    this._iniciarMusica(id);
    const perfil = PERFIS_BIOMA[id]; const t0 = this.ctx.currentTime; const antiga = this.camada; this.camada = null;
    if (antiga) { antiga.gain.gain.setTargetAtTime(0, t0, 0.8); setTimeout(() => { try { antiga.fonte.stop(); } catch { /* já parada */ } }, 4000); }
    if (!perfil) return;
    try {   // "ar" da caverna: ruído em laço → passa-faixa → ganho; a respiração vem de automação lenta em tick()
      const fonte = this.ctx.createBufferSource(); fonte.buffer = this._bufferRuido(); fonte.loop = true;
      const filtro = this.ctx.createBiquadFilter(); filtro.type = 'bandpass'; filtro.frequency.value = perfil.ruido.freq; filtro.Q.value = perfil.ruido.q;
      const gain = this.ctx.createGain(); gain.gain.value = 0; gain.gain.setTargetAtTime(perfil.ruido.vol, t0, 1.2);
      fonte.connect(filtro); filtro.connect(gain); gain.connect(this.master); fonte.start();
      this.camada = { gain, filtro, fonte, perfil };
      this._timers = { respira: 0, suspiro: 20 + this.rand() * 12, nota: 2 + this.rand() * 3, batida: 1, gota: 2 + this.rand() * 3, esguicho: 8 + this.rand() * 10 };
    } catch { this.camada = null; }
  }

  // ------------------------------------------------------------------
  // MÚSICA: violão de fundo. O GeradorMusica (musica.js) compõe um compasso por vez; aqui só se agenda no Web Audio.
  // ------------------------------------------------------------------
  /** Cadeia da música: cordas → "corpo" do violão (passa-baixa) → seco + reverb de caverna (convolução) → master. */
  _montarBusMusica() {
    if (this.bus || !this.ctx) return;
    try {
      const c = this.ctx; const entrada = c.createGain(); const corpo = c.createBiquadFilter(); const seco = c.createGain(); const molhado = c.createGain();
      corpo.type = 'lowpass'; corpo.frequency.value = 3400; corpo.Q.value = 0.6; seco.gain.value = 1; molhado.gain.value = 0.35;
      entrada.connect(corpo); corpo.connect(seco); seco.connect(this.master);
      if (c.createConvolver) { const conv = c.createConvolver(); conv.buffer = this._impulsoCaverna(); corpo.connect(conv); conv.connect(molhado); molhado.connect(this.master); }
      this.bus = { entrada, corpo, seco, molhado };
    } catch { this.bus = null; }
  }

  /** Resposta ao impulso sintética: ruído estéreo que decai e escurece (≈2,4 s) — uma caverna úmida, não um salão. */
  _impulsoCaverna() {
    const sr = this.ctx.sampleRate; const n = Math.floor(sr * 2.4); const buf = this.ctx.createBuffer(2, n, sr); const pre = Math.floor(sr * 0.02);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch); let lp = 0;
      for (let i = pre; i < n; i++) {
        const t = (i - pre) / sr; const k = 0.55 * Math.exp(-t * 1.4) + 0.04;     // quanto mais tarde, mais abafado
        lp += ((this.rand() * 2 - 1) - lp) * k; d[i] = lp * Math.exp(-t * 3.0) * (i - pre < sr * 0.004 ? (i - pre) / (sr * 0.004) : 1);
      }
    }
    return buf;
  }

  /** Liga a música do bioma (mesmo bioma = nada a fazer; chamado por setBioma). Notas ainda não tocadas da música anterior são descartadas; as que já soam terminam sozinhas. */
  _iniciarMusica(id) {
    const perfil = this.musicaLigada ? PERFIS_MUSICA[id] : null; const agora = this.ctx.currentTime;
    this._cordas.clear();                                                      // libera memória; as cordas em uso seguem vivas nos nós
    if (!perfil || !this.bus) { this.musicaEstado = null; return; }
    const t = this.ctx.currentTime;
    this.bus.molhado.gain.setTargetAtTime(0.15 + 0.45 * perfil.reverb, t, 1.5);
    this.bus.corpo.frequency.setTargetAtTime(2200 + perfil.brilho * 3600, t, 1.5);
    const gerador = new GeradorMusica(perfil, this.rand);
    const aquecer = [...new Set(perfil.progressoes.flat().flatMap((n) => notasDoAcorde(n)))];   // pré-renderiza as cordas aos poucos (1 por tick), sem engasgar
    this.musicaEstado = { perfil, gerador, fila: [], proximo: agora + 0.9, aquecer };
  }

  _corda(midi, perfil) {
    const chave = midi; let b = this._cordas.get(chave);
    if (!b) {
      const sr = this.ctx.sampleRate; const dados = renderPluck(sr, midiParaHz(midi), { brilho: perfil.brilho, rand: this.rand });
      b = this.ctx.createBuffer(1, dados.length, sr); b.getChannelData(0).set(dados); this._cordas.set(chave, b);
    }
    return b;
  }

  _tocarCorda(e, perfil, quando) {
    try {
      const src = this.ctx.createBufferSource(); const g = this.ctx.createGain(); src.buffer = this._corda(e.midi, perfil);
      g.gain.value = Math.max(0.0005, perfil.vol * e.vel); src.connect(g);
      if (this.ctx.createStereoPanner) { const pn = this.ctx.createStereoPanner(); pn.pan.value = e.pan || 0; g.connect(pn); pn.connect(this.bus.entrada); } else g.connect(this.bus.entrada);
      src.start(quando);
    } catch { /* música é cosmética */ }
  }

  /** A cada passo: pré-renderiza uma corda, completa a fila com compassos novos (≈1 s à frente) e dispara as notas que vencem nos próximos 0,3 s. */
  _tickMusica() {
    const m = this.musicaEstado; if (!m || !this.ctx || !this.bus) return;
    const agora = this.ctx.currentTime;
    if (m.aquecer.length) { try { this._corda(m.aquecer.pop(), m.perfil); } catch { m.aquecer.length = 0; } }
    if (m.proximo < agora - 0.05) { m.proximo = agora + 0.1; m.fila.length = 0; }       // retomada depois de pausa/aba escondida: recomeça limpo
    while (m.proximo < agora + 1.0) {
      const c = m.gerador.proximoCompasso();
      for (const e of c.eventos) m.fila.push({ ...e, t: m.proximo + e.t });
      m.proximo += c.dur;
      m.fila.sort((a, b) => a.t - b.t);   // a melodia pode vazar para o compasso seguinte
    }
    while (m.fila.length && m.fila[0].t < agora + 0.3) {
      const e = m.fila.shift(); if (e.t < agora - 0.4) continue;
      this._tocarCorda(e, m.perfil, Math.max(e.t, agora));
    }
  }

  _bufferRuido() {
    if (!this._ruidoBuf) { const n = Math.floor(this.ctx.sampleRate * 2); this._ruidoBuf = this.ctx.createBuffer(1, n, this.ctx.sampleRate); const d = this._ruidoBuf.getChannelData(0); for (let i = 0; i < n; i++) d[i] = this.rand() * 2 - 1; }
    return this._ruidoBuf;
  }

  /** Uma nota curta (usada pelos efeitos e pela Tendril); respeita mudo. `escala` multiplica o volume. */
  nota(onda, f0, f1, dur, vol, atraso = 0, escala = 1) {
    if (!this.ctx || this.mudo) return;
    try {
      const t0 = this.ctx.currentTime + atraso; const o = this.ctx.createOscillator(); const g = this.ctx.createGain(); const v = Math.max(0.0005, vol * escala);
      o.type = onda; o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t0 + dur);
      g.gain.setValueAtTime(v, t0); g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
      o.connect(g); g.connect(this.master); o.start(t0); o.stop(t0 + dur + 0.02);
    } catch { /* áudio é cosmético */ }
  }
  /** Ruído filtrado curto: a "textura de gosma" dos passos, pulos e pousos. */
  ruido(dur, vol, freq, atraso = 0, escala = 1) {
    if (!this.ctx || this.mudo) return;
    try {
      if (!this._ruidoBuf) { const n = Math.floor(this.ctx.sampleRate * 0.5); this._ruidoBuf = this.ctx.createBuffer(1, n, this.ctx.sampleRate); const d = this._ruidoBuf.getChannelData(0); for (let i = 0; i < n; i++) d[i] = this.rand() * 2 - 1; }
      const t0 = this.ctx.currentTime + atraso; const src = this.ctx.createBufferSource(); const f = this.ctx.createBiquadFilter(); const g = this.ctx.createGain();
      src.buffer = this._ruidoBuf; f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = 1.2;
      g.gain.setValueAtTime(Math.max(0.0005, vol * escala), t0); g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
      src.connect(f); f.connect(g); g.connect(this.master); src.start(t0); src.stop(t0 + dur + 0.02);
    } catch { /* sem ruído: o tom sozinho já basta */ }
  }
  /** Repetições filtradas e decrescentes: espacializam o efeito sem usar feedback infinito ou elevar seu volume bruto. */
  _ecoar(tipo, escala) {
    const s = SFX[tipo]; const a = this.acustica;
    if (!s || !a?.repeticoes || !this.ctx || this.mudo) return;
    for (let r = 1; r <= a.repeticoes; r++) {
      const atraso = a.atraso * r; const cauda = a.ganho * Math.pow(0.52, r - 1);
      for (const n of s) {
        if (n[0] === 'ruido') this.ruido(n[1] * 1.08, n[2], Math.max(120, n[3] * (0.84 - r * 0.045)), (n[4] || 0) + atraso, escala * cauda);
        else this.nota(n[0], n[1] * 0.96, n[2] * 0.86, n[3] * 1.08, n[4], (n[5] || 0) + atraso, escala * cauda);
      }
    }
  }

  /** Toca um efeito; `escala` (0..1) = intensidade (queda forte, corrida rápida). Cada repetição varia ±5% no tom. */
  tocar(tipo, escala = 1) {
    const s = SFX[tipo]; if (!s) return false;
    const sup = SFX_DE_SUPERFICIE.has(tipo) ? SUPERFICIE[this.bioma] : null;   // o mesmo passo soa diferente em osso, musgo e santuário
    const v = (0.95 + this.rand() * 0.1) * (sup?.tom ?? 1); if (sup) escala *= sup.vol;
    for (const n of s) {
      if (n[0] === 'ruido') this.ruido(n[1], n[2], n[3] * v, n[4] || 0, escala);
      else this.nota(n[0], n[1] * v, n[2] * v, n[3], n[4], n[5] || 0, escala);
    }
    if (sup?.cauda) { const c = sup.cauda; this.nota(c[0], c[1] * v, c[2] * v, c[3], c[4], 0.02, escala); }
    this._ecoar(tipo, escala);
    return true;
  }

  /** Tensão de luta (0..1): o ar da caverna fica mais alto e mais agudo enquanto há um chefe vivo por perto. */
  setTensao(v = 0) {
    v = Math.max(0, Math.min(1, v)); if (!this.camada || !this.ctx || Math.abs(v - (this._tensao ?? 0)) < 0.02) return; this._tensao = v;
    const t = this.ctx.currentTime; const p = this.camada.perfil;
    try { this.camada.gain.gain.setTargetAtTime(p.ruido.vol * (1 + 1.2 * v), t, 0.6); this.camada.filtro.frequency.setTargetAtTime(p.ruido.freq * (1 + 0.8 * v), t, 0.8); } catch { /* sem áudio */ }
  }

  /** Chamado a cada passo fixo: a caverna "respira" (automação lenta), e eventos raros e aleatórios dão vida ao bioma. */
  tick(dt) {
    if (this.mudo || this.pausado) return;
    this._tickMusica();
    if (!this.camada) return;
    const T = this._timers; const p = this.camada.perfil; const r = this.rand; const al = (min, max) => min + r() * (max - min);
    for (const k of Object.keys(T)) T[k] -= dt;
    if (T.respira <= 0) {   // sopro: o volume e a cor do ruído derivam devagar (ciclos de 5–10 s)
      T.respira = al(5, 10); const t = this.ctx.currentTime;
      this.camada.gain.gain.setTargetAtTime(p.ruido.vol * al(0.35, 1.3) * (1 + 1.2 * (this._tensao || 0)), t, 2.2);
      this.camada.filtro.frequency.setTargetAtTime(p.ruido.freq * al(0.7, 1.5) * (1 + 0.8 * (this._tensao || 0)), t, 2.5);
    }
    if (T.suspiro <= 0) { T.suspiro = al(...(p.respiraCada || [24, 46])); this.nota('sine', p.ruido.freq * 0.38 + 26, p.ruido.freq * 0.38 + 13, 0.78, 0.013); this.ruido(0.42, 0.010, Math.max(130, p.ruido.freq * 0.7)); }
    if (T.nota <= 0) { T.nota = al(...p.notaCada); this._toqueLongo(p); }
    if (p.batida && T.batida <= 0) {
      T.batida = 60 / p.batida.bpm; const v = p.batida.vol;
      this.nota('sine', 70, 38, 0.16, v); this.nota('sine', 62, 34, 0.14, v * 0.6, 0.17);          // tum-tum
      if (p.batida.eco) this.nota('sine', 55, 30, 0.3, v * 0.35, 0.45);
    }
    if (p.gotas && T.gota <= 0) { T.gota = al(1.5, 6); this.nota('sine', al(800, 1500), al(500, 800), 0.1, 0.012); if (r() < 0.4) this.nota('sine', al(900, 1400), 600, 0.09, 0.007, 0.16); }   // pinga... pinga-pinga
    if (p.esguicho && T.esguicho <= 0) { T.esguicho = al(9, 20); this.ruido(0.35, 0.02, al(250, 420)); this.nota('sine', al(90, 130), 50, 0.3, 0.02, 0.05); }                // gorgolejo distante
  }

  /** Toque longo e suave (ataque/soltura lentos): escolhe uma nota da escala do bioma; no núcleo, às vezes duas dissonantes. */
  _toqueLongo(p) {
    if (!this.ctx || this.mudo) return;
    const f = p.notas[Math.floor(this.rand() * p.notas.length)]; const n = p.harmonia ? 2 : (this.bioma === 'nucleo' && this.rand() < 0.5 ? 2 : 1);
    for (let i = 0; i < n; i++) {
      try {
        const t0 = this.ctx.currentTime + (i ? 0.22 : 0); const o = this.ctx.createOscillator(); const g = this.ctx.createGain(); const dur = 4.8 + this.rand() * 1.8;
        o.type = p.notaOnda; o.frequency.value = f * (i ? (p.harmonia || 1.059) : 1);
        const vol = p.notaVol * (i ? 0.38 : 1);
        g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(vol, t0 + 1.5); g.gain.linearRampToValueAtTime(0.0001, t0 + dur);
        o.connect(g); g.connect(this.master); o.start(t0); o.stop(t0 + dur + 0.05);
      } catch { /* cosmético */ }
    }
  }
}
