// =====================================================================
// MODO DESENVOLVEDOR (debug + editor): como ele liga e desliga, sem precisar de teclado.
//   - ?dev=1 na URL liga só nesta visita; ?dev=0 desliga e esquece.
//   - O botão "Modo desenvolvedor" do menu de pausa grava a escolha no aparelho (localStorage),
//     então no celular basta ligar uma vez.
// Fica DESLIGADO por padrão. Para a versão final, ponha config.debug.allowDevToggle = false.
// =====================================================================
export const CHAVE_DEV = 'limo.dev';

function ler(obterStorage) {
  try { const s = obterStorage(); return s ? s.getItem(CHAVE_DEV) : null; } catch (e) { return null; }
}

/** Decide se o modo dev está ativo. @returns {{ativo:boolean, origem:'url'|'salvo'|'desligado', esquecer:boolean}} */
export function resolveDevMode(search, obterStorage = () => globalThis.localStorage) {
  const p = new URLSearchParams(search || '');
  const valor = p.has('dev') ? p.get('dev') : (p.get('debug') === '1' ? '1' : null);
  if (valor !== null) {
    if (valor === '0' || valor === 'false') return { ativo: false, origem: 'url', esquecer: true };
    return { ativo: true, origem: 'url', esquecer: false };
  }
  if (ler(obterStorage) === '1') return { ativo: true, origem: 'salvo', esquecer: false };
  return { ativo: false, origem: 'desligado', esquecer: false };
}

/** Grava (ou apaga) a escolha. Devolve false se o navegador bloquear o armazenamento. */
export function gravarDevMode(ligado, obterStorage = () => globalThis.localStorage) {
  try {
    const s = obterStorage();
    if (!s) return false;
    if (ligado) s.setItem(CHAVE_DEV, '1'); else s.removeItem(CHAVE_DEV);
    return true;
  } catch (e) { return false; }
}

/** Endereço para recarregar depois de alternar: tira ?dev/?debug/?editor para valer só a escolha salva. */
export function urlSemDev(href) {
  const u = new URL(href);
  for (const k of ['dev', 'debug', 'editor']) u.searchParams.delete(k);
  return u.toString();
}
